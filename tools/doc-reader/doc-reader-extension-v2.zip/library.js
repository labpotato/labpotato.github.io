/* every page with highlights, comments or edits, newest first; open, export or remove */
const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
let PAGES = [];
const md = p => `# ${p.title || p.url}\n\n<${p.url}>\n\n` + ((p.pageNote || "").trim() ? `**Page note:** ${p.pageNote.trim()}\n\n` : "") + p.marks.map(m => `> ${m.quote.exact}\n${m.note ? `\n${m.note}\n` : ""}`).join("\n") + (p.edits.length ? `\n_${p.edits.length} paragraph(s) edited on the page._\n` : "");
function download(text, name) { const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([text], { type: "text/markdown" })); a.download = name; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 3000); }
async function load() {
  const all = await chrome.storage.local.get(null);
  PAGES = Object.entries(all).filter(([k, v]) => k.startsWith("lp:") && k !== "lp:settings" && v && v.url).map(([k, v]) => ({ key: k, ...v, marks: v.marks || [], edits: v.edits || [] })).sort((a, b) => (b.updated || 0) - (a.updated || 0));
  document.getElementById("btnOn").checked = (all["lp:settings"] || {}).button !== false;
  try { const b = await chrome.storage.local.getBytesInUse(null); document.getElementById("usage").textContent = `${PAGES.length} page${PAGES.length === 1 ? "" : "s"} · ${(b / 1024).toFixed(0)} KB kept in this browser's extension storage (chrome.storage.local). Back up to keep a copy outside the browser.`; } catch (e) {}
  draw();
}
function draw() {
  const q = document.getElementById("q").value.toLowerCase().trim(), box = document.getElementById("list");
  const list = PAGES.filter(p => !q || (p.title + " " + p.url + " " + p.marks.map(m => m.quote.exact + " " + m.note).join(" ")).toLowerCase().includes(q));
  box.innerHTML = list.length ? list.map(p => `<div class="page" data-k="${esc(p.key)}"><h2><a href="${esc(p.url)}" target="_blank">${esc(p.title || p.url)}</a></h2><div class="url">${esc(p.url)}</div>
    <div class="meta">${p.marks.length} highlight${p.marks.length === 1 ? "" : "s"}${p.edits.length ? ` · ${p.edits.length} edit${p.edits.length === 1 ? "" : "s"}` : ""} · ${new Date(p.updated || p.created).toLocaleString()}</div>
    ${(p.pageNote || "").trim() ? `<div class="pn">📝 ${esc(p.pageNote.trim().slice(0, 300))}</div>` : ""}${p.marks.slice(0, 4).map(m => `<div class="q" style="--c:${esc(m.color)}">${esc(m.quote.exact.slice(0, 200))}${m.note ? `<div class="n">💬 ${esc(m.note)}</div>` : ""}</div>`).join("")}${p.marks.length > 4 ? `<div class="meta">and ${p.marks.length - 4} more</div>` : ""}
    <div class="row"><a class="btn" href="${esc(p.url)}" target="_blank">Open the page</a><button data-a="md">Export Markdown</button><button data-a="del" class="danger">Remove</button></div></div>`).join("")
    : `<p class="empty">${PAGES.length ? "Nothing matches." : "Nothing yet. On any page, select text and press Highlight."}</p>`;
}
document.getElementById("list").addEventListener("click", async e => {
  const b = e.target.closest("button[data-a]"); if (!b) return; const k = b.closest(".page").dataset.k, p = PAGES.find(x => x.key === k);
  if (b.dataset.a === "md") download(md(p), (p.title || "page").replace(/[\\/:*?"<>|]+/g, " ").trim().slice(0, 60) + "_notes.md");
  if (b.dataset.a === "del" && confirm("Remove the highlights, comments and edits kept for this page?")) { await chrome.storage.local.remove(k); load(); }
});
document.getElementById("q").addEventListener("input", draw);
/* back up and restore: every page's marks plus the settings, as one JSON file */
document.getElementById("backup").addEventListener("click", async () => {
  const all = await chrome.storage.local.get(null), data = Object.fromEntries(Object.entries(all).filter(([k]) => k.startsWith("lp:")));
  const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([JSON.stringify({ format: "lab-potato-doc-reader-backup", version: 1, savedAt: new Date().toISOString(), data }, null, 1)], { type: "application/json" }));
  a.download = "lab_potato_highlights_" + new Date().toISOString().slice(0, 10) + ".json"; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 3000); });
document.getElementById("restore").addEventListener("click", () => document.getElementById("restoreIn").click());
document.getElementById("restoreIn").addEventListener("change", async e => {
  const f = e.target.files[0]; e.target.value = ""; if (!f) return; let d; try { d = JSON.parse(await f.text()); } catch (x) {}
  if (!d || d.format !== "lab-potato-doc-reader-backup" || !d.data) return alert("That is not a Lab Potato backup file.");
  const cur = await chrome.storage.local.get(null), put = {}; let added = 0, merged = 0;
  for (const [k, v] of Object.entries(d.data)) { if (!k.startsWith("lp:")) continue;
    if (k === "lp:settings") { if (!cur[k]) put[k] = v; continue; }
    const c = cur[k]; if (!c) { put[k] = v; added++; continue; }
    // the same page on both sides: keep every highlight and edit from either, the newer page note
    const byId = new Map([...(c.marks || []), ...(v.marks || [])].map(m => [m.id, m])), eds = new Map([...(c.edits || []), ...(v.edits || [])].map(x => [x.id, x]));
    put[k] = Object.assign({}, c, { marks: [...byId.values()], edits: [...eds.values()], pageNote: (v.updated || 0) > (c.updated || 0) ? v.pageNote : c.pageNote, updated: Math.max(c.updated || 0, v.updated || 0) }); merged++; }
  await chrome.storage.local.set(put); alert(`Restored: ${added} new page${added === 1 ? "" : "s"}, ${merged} merged with what was here.`); load(); });
document.getElementById("allMd").addEventListener("click", () => download(PAGES.map(md).join("\n---\n\n"), "lab_potato_highlights.md"));
document.getElementById("btnOn").addEventListener("change", async e => { const s = (await chrome.storage.local.get("lp:settings"))["lp:settings"] || {}; s.button = e.target.checked; await chrome.storage.local.set({ "lp:settings": s }); });
chrome.storage.onChanged.addListener(() => load());
load();
