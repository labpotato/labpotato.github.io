/* Lab Potato Doc Reader: the extension's background worker.
   Clicking the button (or Alt+Shift+R) opens the current page in the reader. PDFs are passed by
   address; other pages are copied as they are shown right now (so pages you are signed in to work). */
const isPdf = url => /\.pdf($|[?#])/i.test(url || "") || /^chrome-extension:\/\/mhjfbmdgcfjbbpaeojofohoefgiehjai\//.test(url || "");

async function openPage(tab, selectionOnly) {
  const url = tab.url || "";
  if (!url || /^(chrome|edge|about|devtools):/i.test(url)) { chrome.tabs.create({ url: chrome.runtime.getURL("reader.html") }); return; }
  if (isPdf(url) && !selectionOnly) { chrome.tabs.create({ url: chrome.runtime.getURL("reader.html?file=" + encodeURIComponent(url)) }); return; }
  try {
    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: sel => {
        let selection = "";
        if (sel) { const s = getSelection(); if (s && !s.isCollapsed) { const d = document.createElement("div"); for (let i = 0; i < s.rangeCount; i++) d.append(s.getRangeAt(i).cloneContents()); selection = d.innerHTML; } }
        // the live page as it is now (after scripts), without its scripts
        const doc = document.documentElement.cloneNode(true); doc.querySelectorAll("script,noscript").forEach(e => e.remove());
        return { html: "<!doctype html>" + doc.outerHTML, url: location.href, title: document.title, selection };
      },
      args: [!!selectionOnly]
    });
    if (selectionOnly && !result.selection) { chrome.tabs.create({ url: chrome.runtime.getURL("reader.html?url=" + encodeURIComponent(url)) }); return; }
    const key = "cap-" + Date.now();
    await chrome.storage.local.set({ [key]: result });
    chrome.tabs.create({ url: chrome.runtime.getURL("reader.html?cap=" + key) });
  } catch (e) {
    // pages that refuse scripts (the Web Store, some PDFs): fetch by address instead
    chrome.tabs.create({ url: chrome.runtime.getURL("reader.html?url=" + encodeURIComponent(url)) });
  }
}
chrome.action.onClicked.addListener(tab => openPage(tab, false));
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({ id: "lp-page", title: "Open this page in Doc Reader", contexts: ["page"] });
  chrome.contextMenus.create({ id: "lp-sel", title: "Open the selection in Doc Reader", contexts: ["selection"] });
  chrome.contextMenus.create({ id: "lp-link", title: "Open this link in Doc Reader", contexts: ["link"] });
  chrome.contextMenus.create({ id: "lp-new", title: "New blank document in Doc Reader", contexts: ["action"] });
});
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "lp-page") openPage(tab, false);
  else if (info.menuItemId === "lp-sel") openPage(tab, true);
  else if (info.menuItemId === "lp-link") chrome.tabs.create({ url: chrome.runtime.getURL(isPdf(info.linkUrl) ? "reader.html?file=" + encodeURIComponent(info.linkUrl) : "reader.html?url=" + encodeURIComponent(info.linkUrl)) });
  else if (info.menuItemId === "lp-new") chrome.tabs.create({ url: chrome.runtime.getURL("reader.html") });
});
