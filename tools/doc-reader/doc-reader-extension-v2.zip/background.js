/* Lab Potato Doc Reader v3: the extension's background worker.
   The tools now work on top of the page itself (content.js). The toolbar icon (or Alt+Shift+R) opens
   and folds them; on pages where an extension can't run (the Web Store, chrome:// pages, the PDF viewer)
   it opens Doc Reader instead. "Open in Doc Reader" copies the page as it is shown, with your marks. */
const isPdf = url => /\.pdf($|[?#])/i.test(url || "") || /^chrome-extension:\/\/mhjfbmdgcfjbbpaeojofohoefgiehjai\//.test(url || "");
const reader = q => chrome.tabs.create({ url: chrome.runtime.getURL("reader.html" + (q || "")) });
const library = () => chrome.tabs.create({ url: chrome.runtime.getURL("library.html") });

/* the tools on this tab: ask the page; if the page was open before the extension was installed, add them first */
async function onPage(tab, msg) {
  const url = tab.url || "";
  if (!/^(https?|file):/i.test(url) || /^https:\/\/chrome(webstore)?\.google\.com\/(webstore|extensions)/i.test(url)) return false;
  if (isPdf(url)) return false;
  try { await chrome.tabs.sendMessage(tab.id, msg); return true; }
  catch (e) {
    try { await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] }); await new Promise(r => setTimeout(r, 300)); await chrome.tabs.sendMessage(tab.id, msg); return true; }
    catch (e2) { return false; }
  }
}
async function toggle(tab) {
  if (await onPage(tab, { t: "toggle" })) return;
  const url = tab.url || "";
  if (isPdf(url)) reader("?file=" + encodeURIComponent(url)); else if (/^https?:/i.test(url)) openPage(tab, false); else reader();
}

async function openPage(tab, selectionOnly) {
  const url = tab.url || "";
  if (!url || /^(chrome|edge|about|devtools):/i.test(url)) return reader();
  if (isPdf(url) && !selectionOnly) return reader("?file=" + encodeURIComponent(url));
  try {
    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: sel => {
        let selection = "";
        if (sel) { const s = getSelection(); if (s && !s.isCollapsed) { const d = document.createElement("div"); for (let i = 0; i < s.rangeCount; i++) d.append(s.getRangeAt(i).cloneContents()); selection = d.innerHTML; } }
        // styles the page added from script (CSS-in-JS, adopted sheets) are not in any <style> text: copy their rules
        let extra = "";
        for (const sh of [...document.styleSheets, ...(document.adoptedStyleSheets || [])]) {
          try { const own = sh.ownerNode; if (own && own.tagName === "LINK") continue; if (own && own.textContent.trim()) continue; extra += [...sh.cssRules].map(r => r.cssText).join("\n") + "\n"; } catch (e) { /* another site's sheet */ }
        }
        const doc = document.documentElement.cloneNode(true);
        doc.querySelectorAll("script,noscript,#lp-dr-host").forEach(e => e.remove());
        doc.querySelector("body")?.removeAttribute("contenteditable");
        // lazy pictures: use the real address
        doc.querySelectorAll("img").forEach(im => { const ds = im.getAttribute("data-src") || im.getAttribute("data-lazy-src") || im.getAttribute("data-original"); if (ds && (!im.getAttribute("src") || /^data:/.test(im.getAttribute("src")))) im.setAttribute("src", ds); im.removeAttribute("loading"); });
        // your highlights and comments travel as Doc Reader marks
        const comments = {}, LP = window.__lpDR?.data;
        const byId = LP ? Object.fromEntries(LP.marks.map(m => [m.id, m])) : {};
        doc.querySelectorAll("lp-hl").forEach(w => { const m = byId[w.dataset.id] || { color: "#ffe066", note: "", at: Date.now() };
          const n = document.createElement(m.note ? "span" : "mark"); if (m.note) n.className = "cmt"; n.dataset.id = w.dataset.id; n.style.setProperty(m.note ? "--c" : "--hl", m.color);
          while (w.firstChild) n.append(w.firstChild); w.replaceWith(n);
          comments[w.dataset.id] = { at: m.at || Date.now(), color: m.color, t: m.note ? "cmt" : "mark", text: m.note || "" }; });
        if (extra) { const st = document.createElement("style"); st.textContent = extra; doc.querySelector("head")?.append(st); }
        if (Object.keys(comments).length) { const j = document.createElement("script"); j.type = "application/json"; j.id = "lp-comments"; j.textContent = JSON.stringify(comments); doc.querySelector("body")?.append(j); }
        return { html: "<!doctype html>" + doc.outerHTML, url: location.href, title: document.title, selection };
      },
      args: [!!selectionOnly]
    });
    if (selectionOnly && !result.selection) return reader("?url=" + encodeURIComponent(url));
    const key = "cap-" + Date.now();
    await chrome.storage.local.set({ [key]: result });
    reader("?cap=" + key);
  } catch (e) {
    // pages that refuse scripts (the Web Store, some PDFs): fetch by address instead
    reader("?url=" + encodeURIComponent(url));
  }
}

chrome.action.onClicked.addListener(tab => toggle(tab));
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({ id: "lp-hl", title: "Highlight (Lab Potato)", contexts: ["selection"] });
    chrome.contextMenus.create({ id: "lp-tools", title: "Lab Potato tools on this page", contexts: ["page"] });
    chrome.contextMenus.create({ id: "lp-page", title: "Open this page in Doc Reader", contexts: ["page"] });
    chrome.contextMenus.create({ id: "lp-sel", title: "Open the selection in Doc Reader", contexts: ["selection"] });
    chrome.contextMenus.create({ id: "lp-link", title: "Open this link in Doc Reader", contexts: ["link"] });
    chrome.contextMenus.create({ id: "lp-lib", title: "All my marked pages", contexts: ["action"] });
    chrome.contextMenus.create({ id: "lp-new", title: "New blank document in Doc Reader", contexts: ["action"] });
  });
});
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  const id = info.menuItemId;
  if (id === "lp-hl") { if (!(await onPage(tab, { t: "highlight" }))) openPage(tab, true); }
  else if (id === "lp-tools") toggle(tab);
  else if (id === "lp-page") openPage(tab, false);
  else if (id === "lp-sel") openPage(tab, true);
  else if (id === "lp-link") reader(isPdf(info.linkUrl) ? "?file=" + encodeURIComponent(info.linkUrl) : "?url=" + encodeURIComponent(info.linkUrl));
  else if (id === "lp-lib") library();
  else if (id === "lp-new") reader();
});
chrome.runtime.onMessage.addListener((msg, sender) => {
  if (msg.t === "reader" && sender.tab) openPage(sender.tab, false);
  else if (msg.t === "library") library();
});

/* ---------- sync across computers (Chrome Sync) ----------
   Each page's marks are mirrored, compactly, into chrome.storage.sync. When you are signed in to Chrome
   with sync on, Chrome copies them to every computer where you are signed in, and they are merged into
   that computer's own store; the newer copy of a page wins, so a removed highlight stays removed.
   Chrome Sync holds about 100 KB in all (512 entries, 8 KB each), so a page too big for it stays local,
   and the library says so. Edited text travels only while it is small. */
const SYNC_ON = async () => ((await chrome.storage.local.get("lp:settings"))["lp:settings"] || {}).sync !== false;
const hashKey = s => { let h = 5381; for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) >>> 0; return h.toString(36); };
const CHUNK = 7600;
function pack(rec) {
  const c = { u: rec.url, t: (rec.title || "").slice(0, 120), up: rec.updated || 0, n: rec.pageNote || "",
    m: (rec.marks || []).map(m => [m.id, m.color, m.quote.exact, m.quote.prefix, m.quote.suffix, +(m.quote.pos || 0).toFixed(4), m.note || "", m.at || 0]) };
  const ed = (rec.edits || []).map(e => [e.id, e.path, e.tag, e.orig, e.html, e.at || 0]);
  if (JSON.stringify(ed).length < 3000) c.e = ed;
  return JSON.stringify(c);
}
function unpack(str, cur) {
  const c = JSON.parse(str), o = cur ? Object.assign({}, cur) : { created: c.up };
  Object.assign(o, { url: c.u, title: c.t, updated: c.up, pageNote: c.n,
    marks: c.m.map(([id, color, exact, prefix, suffix, pos, note, at]) => ({ id, color, quote: { exact, prefix, suffix, pos }, note, at })) });
  if (c.e) o.edits = c.e.map(([id, path, tag, orig, html, at]) => ({ id, path, tag, orig, html, at }));
  return o;
}
let syncBusy = false;
const pushQ = new Set(); let pushT = null;
async function pushNow() {
  pushT = null; if (!(await SYNC_ON())) return pushQ.clear();
  const keys = [...pushQ]; pushQ.clear(); const local = await chrome.storage.local.get(keys), set = {}, del = [];
  const cur = await chrome.storage.sync.get(null);
  for (const k of keys) {
    const h = "s:" + hashKey(k.slice(3)), old = Object.keys(cur).filter(x => x === h || x.startsWith(h + ":"));
    const rec = local[k];
    if (!rec) { del.push(...old); set["x:" + hashKey(k.slice(3))] = Date.now(); continue; }   // removed here: tell the others
    const s = pack(rec), parts = []; for (let i = 0; i < s.length; i += CHUNK) parts.push(s.slice(i, i + CHUNK));
    del.push("x:" + hashKey(k.slice(3)));
    set[h] = { n: parts.length, up: rec.updated || 0, p: parts[0] }; for (let i = 1; i < parts.length; i++) set[h + ":" + i] = parts[i];
    old.filter(x => x !== h && +x.split(":")[2] >= parts.length).forEach(x => del.push(x));
  }
  syncBusy = true;
  try { if (del.length) await chrome.storage.sync.remove(del); if (Object.keys(set).length) await chrome.storage.sync.set(set);
    await chrome.storage.local.set({ "lp:syncState": { ok: true, at: Date.now() } }); }
  catch (e) { await chrome.storage.local.set({ "lp:syncState": { ok: false, at: Date.now(), error: String(e.message || e) } }); }
  finally { setTimeout(() => { syncBusy = false; }, 500); }
}
/* bring in what other computers sent */
async function pullAll() {
  if (!(await SYNC_ON())) return;
  const all = await chrome.storage.sync.get(null), local = await chrome.storage.local.get(null), put = {}, rm = [];
  for (const [k, v] of Object.entries(all)) {
    if (k.startsWith("x:")) { const lk = Object.keys(local).find(x => x.startsWith("lp:http") && hashKey(x.slice(3)) === k.slice(2)); if (lk && (local[lk].updated || 0) < v) rm.push(lk); continue; }
    if (!/^s:[^:]+$/.test(k) || !v || !v.p) continue;
    let s = v.p; for (let i = 1; i < v.n; i++) { if (all[k + ":" + i] == null) { s = null; break; } s += all[k + ":" + i]; } if (s == null) continue;
    let rec; try { rec = unpack(s); } catch (e) { continue; }
    const lk = "lp:" + rec.url, cur = local[lk];
    if (!cur || (rec.updated || 0) > (cur.updated || 0)) put[lk] = unpack(s, cur);
  }
  syncBusy = true;
  try { if (rm.length) await chrome.storage.local.remove(rm); if (Object.keys(put).length) await chrome.storage.local.set(put); } finally { setTimeout(() => { syncBusy = false; }, 500); }
}
chrome.storage.onChanged.addListener((ch, area) => {
  if (area === "local" && !syncBusy) { let any = false; for (const k of Object.keys(ch)) if (k.startsWith("lp:http") || k.startsWith("lp:file")) { pushQ.add(k); any = true; }
    if (any) { clearTimeout(pushT); pushT = setTimeout(pushNow, 2500); noteChange(); } }
  if (area === "local" && ch["lp:settings"] && (ch["lp:settings"].newValue || {}).sync !== false && (ch["lp:settings"].oldValue || {}).sync === false) syncEverything();
  if (area === "sync" && !syncBusy) pullAll();
});
async function syncEverything() { const local = await chrome.storage.local.get(null); Object.keys(local).filter(k => k.startsWith("lp:http") || k.startsWith("lp:file")).forEach(k => pushQ.add(k)); await pullAll(); await pushNow(); }
chrome.runtime.onStartup.addListener(() => { pullAll(); });
chrome.runtime.onInstalled.addListener(() => { setTimeout(syncEverything, 1500); });

/* ---------- a save file on this computer, in case the browser's storage is cleared ----------
   Once a day after a change (and whenever you press Save now), everything is written to
   Downloads/LabPotato/lab_potato_backup.json, replacing the previous one. Restore it from the library. */
async function backupJson() { const all = await chrome.storage.local.get(null);
  return JSON.stringify({ format: "lab-potato-doc-reader-backup", version: 1, savedAt: new Date().toISOString(), data: Object.fromEntries(Object.entries(all).filter(([k]) => k.startsWith("lp:") && k !== "lp:syncState" && k !== "lp:backupState")) }); }
async function saveBackup(reason) {
  const json = await backupJson(), url = "data:application/json;base64," + btoa(unescape(encodeURIComponent(json)));
  try { const id = await chrome.downloads.download({ url, filename: "LabPotato/lab_potato_backup.json", conflictAction: "overwrite", saveAs: false });
    await chrome.storage.local.set({ "lp:backupState": { ok: true, at: Date.now(), id, reason, bytes: json.length } }); return true; }
  catch (e) { await chrome.storage.local.set({ "lp:backupState": { ok: false, at: Date.now(), error: String(e.message || e) } }); return false; }
}
async function noteChange() {
  const s = (await chrome.storage.local.get("lp:settings"))["lp:settings"] || {}; if (s.autoBackup === false) return;
  const st = (await chrome.storage.local.get("lp:backupState"))["lp:backupState"] || {};
  const day = d => new Date(d).toDateString(); if (st.at && day(st.at) === day(Date.now())) return;
  clearTimeout(noteChange.t); noteChange.t = setTimeout(() => saveBackup("daily"), 60000);   // a minute after the day's first change
}
chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (msg.t === "backupNow") { saveBackup("now").then(ok => reply({ ok })); return true; }
  if (msg.t === "syncNow") { syncEverything().then(() => reply({ ok: true })); return true; }
});
