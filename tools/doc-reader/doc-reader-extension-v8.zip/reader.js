window.PDF_WORKER_SRC = "pdf.worker.min.js";
(function(){
/* Lab Potato Doc Reader v1
   Read, mark up and edit PDFs, Markdown, web pages and images. Everything stays in the browser
   (IndexedDB) unless you export or save a project file. */
"use strict";
const $ = (s, r = document) => { const e = r.querySelector(s); return e && r === document && s[0] === "#" && e.closest("#flow") ? [...document.querySelectorAll(s)].find(x => !x.closest("#flow")) || e : e; };
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const debounce = (fn, ms) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };
const fmtTime = d => new Date(d).toLocaleString("en", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
const IS_EXT = typeof chrome !== "undefined" && !!(chrome.runtime && chrome.runtime.id);
const COLORS = [["#ffe066", "Yellow"], ["#a8e6a1", "Green"], ["#9ecbff", "Blue"], ["#ffb3c7", "Pink"], ["#d9b8ff", "Purple"], ["#ffbe76", "Orange"]];
const INK_COLORS = ["#d1495b", "#0a5fd0", "#0f9d76", "#c9800f", "#16181d", "#ffffff"];
const EL = (tag, attrs = {}, ...kids) => {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === "class") e.className = v; else if (k === "style") e.style.cssText = v; else if (k === "html") e.innerHTML = v;
    else if (k.startsWith("on")) e.addEventListener(k.slice(2), v); else if (v != null) e.setAttribute(k, v);
  }
  for (const k of kids.flat()) if (k != null) e.append(k.nodeType ? k : document.createTextNode(String(k)));
  return e;
};
const ICON = (id, cls = "") => { const s = document.createElementNS("http://www.w3.org/2000/svg", "svg"); if (cls) s.setAttribute("class", cls); s.innerHTML = `<use href="#${id}"/>`; return s; };

/* ---------- state ---------- */
const S = {
  doc: null,            // the open document record (see newDoc)
  pdf: null,            // pdf.js document, when kind === "pdf" and a source PDF exists
  pages: [],            // virtual pages in display order: {id, src (0-based index in the PDF) | img {data,w,h} | blank {w,h}, rot}
  views: new Map(),     // page id -> {el, canvas, vp, page, rendered, textDivs}
  pageCache: new Map(), // src index -> pdf.js page proxy
  scale: 1, zoomMode: "width",
  tool: "select", color: COLORS[0][0], inkColor: INK_COLORS[0], inkWidth: 2.5, shapeKind: "rect", fontSize: 12,
  sel: null,            // selected annotation id (pdf mode)
  hist: [], hi: -1, histLock: false,
  dirty: false, saving: false, fileHandle: null,
  current: 1, speaking: false,
  findRanges: [], findIdx: -1
};
const work = $("#work"), viewer = $("#viewer"), pagesEl = $("#pages"), flowEl = $("#flow"), flowWrap = $("#flowWrap"), marginEl = $("#margin");

/* ---------- small UI ---------- */
let toastT;
function toast(msg, action) {
  const t = $("#toast"); t.innerHTML = ""; t.append(msg);
  if (action) t.append(EL("button", { onclick: () => { action.fn(); t.hidden = true; } }, action.label));
  t.hidden = false; clearTimeout(toastT); toastT = setTimeout(() => { t.hidden = true; }, action ? 8000 : 3200);
}
function status(msg, cls = "") { const s = $("#status"); s.textContent = msg; s.className = "status " + cls; }
function closeMenu() { const m = $("#menu"); m.hidden = true; m.innerHTML = ""; }
/* items: {label, icon, k (shortcut), on, sub, danger, sep:true, head:"..."} */
function menu(items, anchor, opts = {}) {
  closeMenu(); const m = $("#menu");
  for (const it of items) {
    if (it.sep) { m.append(EL("div", { class: "msep" })); continue; }
    if (it.head) { m.append(EL("div", { class: "mh" }, it.head)); continue; }
    if (it.node) { m.append(it.node); continue; }
    const b = EL("button", { type: "button", class: (it.on ? "on " : "") + (it.danger ? "danger" : ""), onclick: () => { closeMenu(); it.fn && it.fn(); } });
    if (it.icon) b.append(ICON(it.icon));
    const lbl = EL("span", {}, it.label); if (it.sub) lbl.append(EL("span", { class: "sub" }, it.sub)); b.append(lbl);
    if (it.k) b.append(EL("span", { class: "k" }, it.k));
    m.append(b);
  }
  m.hidden = false;
  let x, y;
  if (anchor instanceof Event) { x = anchor.clientX; y = anchor.clientY; }
  else { const r = anchor.getBoundingClientRect(); x = opts.right ? r.right - m.offsetWidth : r.left; y = r.bottom + 4;
    // v3: a menu from the standing (vertical) toolbar opens beside it, on the side with room
    const vb = anchor.closest?.(".wv-bar.vert"); if (vb) { const br = vb.getBoundingClientRect(); x = br.left + br.width / 2 < innerWidth / 2 ? br.right + 6 : br.left - m.offsetWidth - 6; y = r.top; }
    else if (anchor.closest?.(".wv-bar") && r.bottom + m.offsetHeight > innerHeight - 8) y = r.top - m.offsetHeight - 4; }
  if (x < 8) x = 8;
  if (x + m.offsetWidth > innerWidth - 8) x = Math.max(8, innerWidth - m.offsetWidth - 8);
  if (y + m.offsetHeight > innerHeight - 8) y = Math.max(8, innerHeight - m.offsetHeight - 8);
  m.style.left = x + "px"; m.style.top = y + "px";
  setTimeout(() => $("button", m)?.focus({ preventScroll: true }), 0);
}
document.addEventListener("pointerdown", e => { if (!e.target.closest("#menu")) closeMenu(); if (!e.target.closest("#pop") && !e.target.closest(".bubble,.mnote,.note,.cmt,mark,.mk")) closePop(); }, true);
document.addEventListener("keydown", e => { if (e.key === "Escape") { closeMenu(); closePop(); closeModal(false); } });
/* modal(html) → promise resolving with the form's values when a [data-ok] button is pressed, or null */
let modalResolve = null;
function modal(html, opts = {}) {
  return new Promise(res => {
    modalResolve = res; const m = $("#modal"); m.innerHTML = html; $("#modalBack").hidden = false;
    m.onclick = e => {
      const b = e.target.closest("[data-ok],[data-cancel]"); if (!b) return;
      if (b.dataset.cancel != null) return closeModal(false);
      const vals = {}; $$("input,select,textarea", m).forEach(i => { if (!i.name) return; vals[i.name] = i.type === "checkbox" ? i.checked : i.type === "radio" ? (i.checked ? i.value : vals[i.name]) : i.value; });
      vals.btn = b.dataset.ok; closeModal(vals);
    };
    setTimeout(() => { const f = $(opts.focus || "input:not([type=hidden]):not([type=radio]):not([type=checkbox]),textarea,button[data-ok]", m); f && f.focus(); if (f && f.select && opts.select) f.select(); }, 30);
  });
}
function closeModal(v) { if (modalResolve) { const r = modalResolve; modalResolve = null; $("#modalBack").hidden = true; $("#modal").innerHTML = ""; r(v); } }
$("#modalBack").addEventListener("pointerdown", e => { if (e.target === e.currentTarget) closeModal(null); });

/* ---------- storage (IndexedDB) ---------- */
const DB = {
  _p: null,
  open() {
    if (this._p) return this._p;
    return (this._p = new Promise((res, rej) => {
      const r = indexedDB.open("lp-docreader", 1);
      r.onupgradeneeded = () => { const d = r.result; if (!d.objectStoreNames.contains("docs")) d.createObjectStore("docs", { keyPath: "id" }); if (!d.objectStoreNames.contains("kv")) d.createObjectStore("kv"); };
      r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error);
    }));
  },
  async tx(store, mode, fn) { const d = await this.open(); return new Promise((res, rej) => { const t = d.transaction(store, mode), s = t.objectStore(store); const q = fn(s); t.oncomplete = () => res(q && q.result); t.onerror = () => rej(t.error); }); },
  get(store, k) { return this.tx(store, "readonly", s => s.get(k)); },
  put(store, v, k) { return this.tx(store, "readwrite", s => k === undefined ? s.put(v) : s.put(v, k)); },
  del(store, k) { return this.tx(store, "readwrite", s => s.delete(k)); },
  all(store) { return this.tx(store, "readonly", s => s.getAll()); }
};
const Prefs = { data: {}, async load() { try { this.data = (await DB.get("kv", "prefs")) || {}; } catch (e) { this.data = {}; } }, get(k, d) { return this.data[k] ?? d; }, set(k, v) { this.data[k] = v; DB.put("kv", this.data, "prefs").catch(() => {}); } };

/* ---------- history (undo/redo) ---------- */
function snapshot() {
  return JSON.stringify({ annots: S.doc.annots, pages: S.pages.map(p => ({ id: p.id, src: p.src, blank: p.blank, img: p.img, rot: p.rot })), comments: S.doc.comments, html: S.doc.kind === "flow" ? flowEl.innerHTML : null });
}
function pushHistory() {
  if (S.histLock || !S.doc) return;
  const s = snapshot(); if (S.hist[S.hi] === s) return;
  S.hist = S.hist.slice(0, S.hi + 1); S.hist.push(s); if (S.hist.length > 80) S.hist.shift(); S.hi = S.hist.length - 1;
  updateUndo();
}
const pushHistorySoon = debounce(pushHistory, 500);
function updateUndo() { $("#undoBtn").disabled = S.hi <= 0; $("#redoBtn").disabled = S.hi >= S.hist.length - 1; }
function restore(s) {
  const o = JSON.parse(s); S.histLock = true;
  S.doc.annots = o.annots; S.doc.comments = o.comments || {};
  const changedPages = JSON.stringify(S.pages.map(p => [p.id, p.rot])) !== JSON.stringify(o.pages.map(p => [p.id, p.rot]));
  S.pages = o.pages;
  if (S.doc.kind === "flow") { flowEl.innerHTML = o.html; S.doc.html = o.html; layoutMargin(); }
  else if (changedPages) buildPages(); else redrawAllAnnots();
  S.histLock = false; refreshNotes(); markDirty();
}
function undo() { if (S.hi > 0) { S.hi--; restore(S.hist[S.hi]); updateUndo(); } }
function redo() { if (S.hi < S.hist.length - 1) { S.hi++; restore(S.hist[S.hi]); updateUndo(); } }
/* call after any change: records history and schedules the autosave */
function changed(opts = {}) { if (opts.soon) pushHistorySoon(); else pushHistory(); markDirty(); if (!opts.quiet) refreshNotes(); }

/* ---------- viewport math (same as pdf.js PageViewport) ----------
   Annotation geometry is stored in PDF user space (points, y up), so a page can be rotated
   or exported without touching the marks. A viewport converts between that space and
   screen pixels for a given scale and rotation. */
function makeViewport(viewBox, scale, rotation) {
  const [x1, y1, x2, y2] = viewBox, cx = (x1 + x2) / 2, cy = (y1 + y2) / 2;
  rotation = ((rotation % 360) + 360) % 360;
  let a, b, c, d;
  if (rotation === 180) { a = -1; b = 0; c = 0; d = 1; } else if (rotation === 90) { a = 0; b = 1; c = 1; d = 0; } else if (rotation === 270) { a = 0; b = -1; c = -1; d = 0; } else { a = 1; b = 0; c = 0; d = -1; }
  let ox, oy, width, height;
  if (a === 0) { ox = Math.abs(cy - y1) * scale; oy = Math.abs(cx - x1) * scale; width = Math.abs(y2 - y1) * scale; height = Math.abs(x2 - x1) * scale; }
  else { ox = Math.abs(cx - x1) * scale; oy = Math.abs(cy - y1) * scale; width = Math.abs(x2 - x1) * scale; height = Math.abs(y2 - y1) * scale; }
  const t = [a * scale, b * scale, c * scale, d * scale, ox - a * scale * cx - c * scale * cy, oy - b * scale * cx - d * scale * cy];
  return {
    width, height, scale, rotation, transform: t, viewBox,
    convertToViewportPoint(x, y) { return [t[0] * x + t[2] * y + t[4], t[1] * x + t[3] * y + t[5]]; },
    convertToPdfPoint(x, y) { const det = t[0] * t[3] - t[1] * t[2]; return [(x * t[3] - y * t[2] + t[2] * t[5] - t[4] * t[3]) / det, (-x * t[1] + y * t[0] + t[4] * t[1] - t[5] * t[0]) / det]; },
    convertToViewportRectangle(r) { const p1 = this.convertToViewportPoint(r[0], r[1]), p2 = this.convertToViewportPoint(r[2], r[3]); return [p1[0], p1[1], p2[0], p2[1]]; }
  };
}
/* a page that is an image or blank paper; behaves like a pdf.js page for the parts we use */
class ImgPage {
  constructor(w, h, img) { this.w = w; this.h = h; this.img = img || null; this.rotate = 0; this.view = [0, 0, w, h]; this._im = null; }
  getViewport({ scale = 1, rotation = 0 } = {}) { return makeViewport(this.view, scale, rotation); }
  async image() { if (!this.img) return null; if (!this._im) this._im = await loadImage(this.img); return this._im; }
  render({ canvasContext: ctx, viewport: vp }) {
    const promise = (async () => {
      ctx.save(); ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, vp.width, vp.height);
      const im = await this.image();
      if (im) { ctx.setTransform(...vp.transform); ctx.transform(1, 0, 0, -1, 0, this.h); ctx.drawImage(im, 0, 0, this.w, this.h); }
      ctx.restore();
    })();
    return { promise, cancel() {} };
  }
  async getTextContent() { return { items: [], styles: {} }; }
}
function loadImage(src) { return new Promise((res, rej) => { const im = new Image(); im.onload = () => res(im); im.onerror = rej; im.src = src; }); }
/* normalise a rectangle to [minx, miny, maxx, maxy] */
const normRect = r => [Math.min(r[0], r[2]), Math.min(r[1], r[3]), Math.max(r[0], r[2]), Math.max(r[1], r[3])];
/* page-local pixel point -> PDF point, via the page's current viewport */
function toPdf(view, x, y) { return view.vp.convertToPdfPoint(x, y); }
function pdfRectToPx(view, r) { return normRect(view.vp.convertToViewportRectangle(r)); }
function pxRectToPdf(view, r) { const a = toPdf(view, r[0], r[1]), b = toPdf(view, r[2], r[3]); return normRect([a[0], a[1], b[0], b[1]]); }
/* a point in page pixels, from a mouse event */
function pagePoint(e, el) { const r = el.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; }

/* ---------- PDF / page view ---------- */
const RENDER_MARGIN = "900px";
let io = null, thumbIO = null, buildToken = 0;

async function getPage(entry) {
  if (entry.src != null) {
    if (!S.pageCache.has(entry.src)) S.pageCache.set(entry.src, await S.pdf.getPage(entry.src + 1));
    return S.pageCache.get(entry.src);
  }
  if (!entry._page) entry._page = entry.img ? new ImgPage(entry.img.w, entry.img.h, entry.img.data) : new ImgPage(entry.blank.w, entry.blank.h);
  return entry._page;
}
function pageRotation(entry, page) { return ((page.rotate || 0) + (entry.rot || 0)) % 360; }

/* (re)build every page element at the current scale; rendering itself is lazy */
async function buildPages() {
  const token = ++buildToken;   // a newer build (zoom, rotate) wins over one still running
  if (io) io.disconnect();
  pagesEl.innerHTML = ""; S.views.clear();
  io = new IntersectionObserver(ents => { for (const en of ents) { const v = S.views.get(en.target.dataset.id); if (!v) continue; if (en.isIntersecting) renderPage(v); else unrenderPage(v); } }, { root: viewer, rootMargin: RENDER_MARGIN });
  let n = 0;
  for (const entry of S.pages) {
    const page = await getPage(entry); if (token !== buildToken) return;
    const vp = page.getViewport({ scale: S.scale, rotation: pageRotation(entry, page) });
    const el = EL("div", { class: "page lazy", "data-id": entry.id, style: `width:${vp.width}px;height:${vp.height}px` });
    el.style.setProperty("--scale-factor", S.scale);
    el.append(EL("div", { class: "pnum" }, String(++n)));
    pagesEl.append(el);
    S.views.set(entry.id, { el, entry, page, vp, rendered: false, textDivs: [], n });
    io.observe(el);
  }
  $("#pageOf").textContent = "/ " + S.pages.length;
  buildThumbs(); updateCurrent();
}
async function renderPage(v) {
  if (v.rendered || v.rendering) return;
  v.rendering = true;
  const dpr = Math.min(3, devicePixelRatio || 1), vp = v.vp;
  const canvas = EL("canvas", { class: "pg", width: Math.floor(vp.width * dpr), height: Math.floor(vp.height * dpr) });
  const ctx = canvas.getContext("2d", { alpha: false }); ctx.scale(dpr, dpr);
  try { await v.page.render({ canvasContext: ctx, viewport: vp }).promise; } catch (e) { if (e && e.name === "RenderingCancelledException") { v.rendering = false; return; } console.warn(e); }
  if (!S.views.has(v.entry.id) || v.vp !== vp) { v.rendering = false; return; }   // zoomed meanwhile
  v.el.querySelector("canvas.pg")?.remove(); v.el.prepend(canvas); v.el.classList.remove("lazy");
  // text layer (selectable, searchable text)
  v.el.querySelector(".textLayer")?.remove();
  if (v.entry.src != null) {
    const tl = EL("div", { class: "textLayer" }); tl.style.setProperty("--scale-factor", S.scale); v.el.append(tl);
    try {
      const tc = await getTextContent(v); v.textDivs = [];
      await pdfjsLib.renderTextLayer({ textContentSource: tc, container: tl, viewport: vp, textDivs: v.textDivs }).promise;
      tl.append(EL("div", { class: "endOfContent" }));
    } catch (e) { console.warn("text layer", e); }
  }
  drawAnnots(v);
  v.rendered = true; v.rendering = false;
  if (S.findQuery) highlightFindOnPage(v);
}
function unrenderPage(v) {
  if (!v.rendered) return;
  v.el.querySelector("canvas.pg")?.remove(); v.el.querySelector(".textLayer")?.remove(); v.el.querySelector(".annots")?.remove(); v.el.classList.add("lazy"); v.rendered = false; v.textDivs = [];
}
const textCache = new Map();
async function getTextContent(v) {
  const k = v.entry.src; if (k == null) return { items: [], styles: {} };
  if (!textCache.has(k)) textCache.set(k, await v.page.getTextContent());
  return textCache.get(k);
}
async function pageText(entry) { if (entry.src == null) return ""; const tc = await getTextContent({ entry, page: await getPage(entry) }); let s = ""; for (const it of tc.items) { s += it.str; if (it.hasEOL) s += "\n"; } return s; }

/* zoom */
async function firstPageSize() { if (!S.pages.length) return [612, 792]; const e = S.pages[0], pg = await getPage(e), vp = pg.getViewport({ scale: 1, rotation: pageRotation(e, pg) }); return [vp.width, vp.height]; }
async function setZoom(mode, val) {
  if (S.doc?.kind === "flow") {   // documents zoom as a whole (CSS zoom), fit width = 100%
    S.flowZoom = mode === "custom" ? clamp(val, .4, 3) : 1; S.zoomMode = mode === "custom" ? "custom" : "width";
    $(".flow-paper").style.zoom = S.flowZoom; $("#zoomVal").textContent = Math.round(S.flowZoom * 100) + "%"; layoutMargin(); return;
  }
  S.zoomMode = mode; Prefs.set("zoomMode", mode);
  const old = S.scale, keep = viewer.scrollTop / Math.max(1, viewer.scrollHeight), [w0, h0] = await firstPageSize();
  if (mode === "width") S.scale = clamp((viewer.clientWidth - 44) / w0, .2, 6); else if (mode === "page") S.scale = clamp((viewer.clientHeight - 50) / h0, .2, 6); else { S.scale = clamp(val, .2, 6); Prefs.set("zoom", S.scale); }
  if (Math.abs(S.scale - old) < .001 && S.views.size) return;
  $("#zoomVal").textContent = Math.round(S.scale * 100) + "%";
  await buildPages(); viewer.scrollTop = keep * viewer.scrollHeight;
}
function zoomBy(f) { setZoom("custom", (S.doc?.kind === "flow" ? (S.flowZoom || 1) : S.scale) * f); }

/* current page from scroll position */
function updateCurrent() {
  if (S.doc?.kind !== "pdf") return;
  const vr = viewer.getBoundingClientRect(); let best = null, bestV = -1;
  for (const v of S.views.values()) { const r = v.el.getBoundingClientRect(); const vis = Math.min(r.bottom, vr.bottom) - Math.max(r.top, vr.top); if (vis > bestV) { bestV = vis; best = v; } }
  if (best && best.n !== S.current) { S.current = best.n; $$(".thumb").forEach(t => t.classList.toggle("on", +t.dataset.n === S.current)); }
  $("#pageIn").value = S.current;
}
function goToPage(n, opts = {}) {
  n = clamp(n, 1, S.pages.length); const v = [...S.views.values()][n - 1]; if (!v) return;
  v.el.scrollIntoView({ block: "start", behavior: opts.smooth ? "smooth" : "auto" }); viewer.scrollTop -= 12;
  S.current = n; $("#pageIn").value = n;
}
viewer.addEventListener("scroll", debounce(updateCurrent, 60));

/* thumbnails: click to go, drag to reorder, right-click for page actions */
function buildThumbs() {
  const box = $("#thumbs"); box.innerHTML = ""; if (thumbIO) thumbIO.disconnect();
  thumbIO = new IntersectionObserver(ents => { for (const en of ents) if (en.isIntersecting) { renderThumb(en.target); thumbIO.unobserve(en.target); } }, { root: box.parentElement, rootMargin: "300px" });
  S.pages.forEach((p, i) => {
    const t = EL("div", { class: "thumb" + (i + 1 === S.current ? " on" : ""), "data-id": p.id, "data-n": i + 1, draggable: "true", title: "Page " + (i + 1) + " · right-click for page options" });
    t.append(EL("canvas"), EL("div", { class: "tn" }, String(i + 1)));
    t.addEventListener("click", () => goToPage(i + 1));
    t.addEventListener("contextmenu", e => { e.preventDefault(); pageMenu(p.id, e); });
    t.addEventListener("dragstart", e => { e.dataTransfer.setData("text/lp-page", p.id); t.classList.add("drag"); });
    t.addEventListener("dragend", () => t.classList.remove("drag"));
    t.addEventListener("dragover", e => { if (e.dataTransfer.types.includes("text/lp-page")) e.preventDefault(); });
    t.addEventListener("drop", e => { const from = e.dataTransfer.getData("text/lp-page"); if (!from || from === p.id) return; e.preventDefault(); movePage(from, p.id); });
    box.append(t); thumbIO.observe(t);
  });
}
async function renderThumb(t) {
  const entry = S.pages.find(p => p.id === t.dataset.id); if (!entry) return;
  const page = await getPage(entry), vp0 = page.getViewport({ scale: 1, rotation: pageRotation(entry, page) }), sc = 170 / vp0.width, vp = page.getViewport({ scale: sc, rotation: vp0.rotation });
  const c = $("canvas", t); c.width = Math.floor(vp.width * 1.5); c.height = Math.floor(vp.height * 1.5); const ctx = c.getContext("2d"); ctx.scale(1.5, 1.5);
  try { await page.render({ canvasContext: ctx, viewport: vp }).promise; } catch (e) { /* cancelled */ }
}
function pageMenu(id, ev) {
  const i = S.pages.findIndex(p => p.id === id);
  menu([
    { head: "Page " + (i + 1) },
    { label: "Rotate right", icon: "i-rotate", fn: () => rotatePage(id, 90) },
    { label: "Rotate left", fn: () => rotatePage(id, -90) },
    { sep: true },
    { label: "Insert blank page after", icon: "i-pageadd", fn: () => insertBlank(i + 1) },
    { label: "Insert image as a page after…", icon: "i-image", fn: () => pickImage(src => insertImagePage(i + 1, src)) },
    { label: "Duplicate page", fn: () => duplicatePage(id) },
    { label: "Save page as PNG", fn: () => savePagePng(id) },
    { sep: true },
    { label: "Delete page", icon: "i-trash", danger: true, fn: () => deletePage(id) }
  ], ev);
}
function rotatePage(id, d) { const p = S.pages.find(x => x.id === id); p.rot = ((p.rot || 0) + d + 360) % 360; buildPages(); changed(); }
function deletePage(id) { if (S.pages.length < 2) return toast("A document needs at least one page."); S.pages = S.pages.filter(p => p.id !== id); S.doc.annots = S.doc.annots.filter(a => a.p !== id); buildPages(); changed(); }
async function insertBlank(at) { const ref = S.pages[Math.max(0, at - 1)], pg = await getPage(ref), vp = pg.getViewport({ scale: 1 }); const w = ref.rot % 180 ? vp.height : vp.width, h = ref.rot % 180 ? vp.width : vp.height; S.pages.splice(at, 0, { id: uid(), blank: { w: w / 1, h: h / 1 }, rot: 0 }); buildPages(); changed(); }
async function insertImagePage(at, src) { const im = await loadImage(src); const w = 612, h = Math.max(100, 612 * im.naturalHeight / im.naturalWidth); S.pages.splice(at, 0, { id: uid(), img: { data: src, w, h }, rot: 0 }); buildPages(); changed(); }
function duplicatePage(id) { const i = S.pages.findIndex(p => p.id === id), p = S.pages[i], np = { ...p, id: uid(), _page: undefined }; S.pages.splice(i + 1, 0, np); S.doc.annots.push(...S.doc.annots.filter(a => a.p === id).map(a => ({ ...a, id: uid(), p: np.id }))); buildPages(); changed(); }
function movePage(fromId, toId) { const a = S.pages.findIndex(p => p.id === fromId), b = S.pages.findIndex(p => p.id === toId); const [p] = S.pages.splice(a, 1); S.pages.splice(b, 0, p); buildPages(); changed(); }
async function savePagePng(id) { const entry = S.pages.find(p => p.id === id), page = await getPage(entry), vp = page.getViewport({ scale: 2, rotation: pageRotation(entry, page) }); const c = EL("canvas", { width: vp.width, height: vp.height }); await page.render({ canvasContext: c.getContext("2d"), viewport: vp }).promise; c.toBlob(b => download(b, (S.doc.name.replace(/\.[^.]+$/, "")) + "-page" + (S.pages.indexOf(entry) + 1) + ".png")); }

/* outline (bookmarks) */
async function buildOutline() {
  const box = $("#outline"); box.innerHTML = "";
  if (S.doc.kind === "flow") {
    const hs = $$("h1,h2,h3,h4", flowEl); if (!hs.length) { box.append(EL("div", { class: "empty" }, "No headings yet. Headings you add appear here.")); return; }
    hs.forEach(h => box.append(EL("button", { class: "l" + h.tagName[1], onclick: () => h.scrollIntoView({ block: "start", behavior: "smooth" }) }, h.textContent.trim() || "(empty heading)")));
    return;
  }
  let items = []; try { items = S.pdf ? (await S.pdf.getOutline()) || [] : []; } catch (e) { /* none */ }
  if (!items.length) { box.append(EL("div", { class: "empty" }, "This PDF has no bookmarks.")); return; }
  const add = async (list, lvl) => { for (const it of list) { const b = EL("button", { class: "l" + Math.min(4, lvl) }, it.title || "(untitled)"); b.addEventListener("click", async () => { const n = await outlinePage(it); if (n) goToPage(n, { smooth: true }); }); box.append(b); if (it.items?.length) await add(it.items, lvl + 1); } };
  await add(items, 1);
}
async function outlinePage(it) {
  try { let d = it.dest; if (typeof d === "string") d = await S.pdf.getDestination(d); if (!Array.isArray(d)) return 0; const ref = d[0]; const idx = typeof ref === "object" ? await S.pdf.getPageIndex(ref) : ref; const vi = S.pages.findIndex(p => p.src === idx); return vi + 1; } catch (e) { return 0; }
}

/* ---------- annotations on pages (PDF and image documents) ----------
   Every mark is one object in S.doc.annots:
     {id, p: pageId, t: "hl"|"ul"|"st" (text marks: rects[] + quote), "area", "note", "text", "ink", "shape", "image", "edit",
      color, text (the comment), replies[], resolved, at}
   Geometry is in PDF points (see 10-viewport.js). */
const NS = "http://www.w3.org/2000/svg";
const annotsOf = pid => S.doc.annots.filter(a => a.p === pid);
const annotById = id => S.doc.annots.find(a => a.id === id);

function redrawAllAnnots() { for (const v of S.views.values()) if (v.rendered) drawAnnots(v); }
function drawAnnots(v) {
  v.el.querySelector(".annots")?.remove();
  const layer = EL("div", { class: "annots" }), svg = document.createElementNS(NS, "svg"); layer.append(svg); v.el.append(layer);
  for (const a of annotsOf(v.entry.id)) drawOne(v, a, svg, layer);
  // the draw/interaction layer catches pointer events for area, pen, shapes, comment and text tools
  const dl = EL("div", { class: "drawlayer" }); layer.append(dl); bindDrawLayer(v, dl);
}
function svgEl(tag, attrs) { const e = document.createElementNS(NS, tag); for (const [k, val] of Object.entries(attrs)) e.setAttribute(k, val); return e; }
function drawOne(v, a, svg, layer) {
  const sel = a.id === S.sel, cls = "mk" + (sel ? " sel" : "");
  const onClick = e => { e.stopPropagation(); if (S.tool === "erase") return removeAnnot(a.id); selectAnnot(a.id); if (a.t !== "text" && a.t !== "image") openPop(a, e); };
  if (a.t === "hl" || a.t === "ul" || a.t === "st" || a.t === "area") {
    const g = svgEl("g", { class: cls, "data-id": a.id });
    const rects = a.t === "area" ? [a.rect] : a.rects;
    for (const r of rects) {
      const [x1, y1, x2, y2] = pdfRectToPx(v, r), w = x2 - x1, h = y2 - y1;
      if (a.t === "hl" || a.t === "area") g.append(svgEl("rect", { x: x1, y: y1, width: w, height: h, fill: a.color, "fill-opacity": a.t === "area" ? .35 : .45, rx: 1.5, style: "mix-blend-mode:multiply" }));
      else if (a.t === "ul") g.append(svgEl("rect", { x: x1, y: y2 - Math.max(1.5, h * .08), width: w, height: Math.max(1.5, h * .08), fill: a.color, "fill-opacity": .95 }), svgEl("rect", { x: x1, y: y1, width: w, height: h, fill: "transparent" }));
      else g.append(svgEl("rect", { x: x1, y: y1 + h * .5 - Math.max(1, h * .06), width: w, height: Math.max(1.5, h * .1), fill: a.color, "fill-opacity": .95 }), svgEl("rect", { x: x1, y: y1, width: w, height: h, fill: "transparent" }));
    }
    if (sel) { const bb = boundsPx(v, rects); g.append(svgEl("rect", { class: "selbox", x: bb[0] - 2, y: bb[1] - 2, width: bb[2] - bb[0] + 4, height: bb[3] - bb[1] + 4 })); }
    g.addEventListener("click", onClick); svg.append(g);
    if (a.text || a.replies?.length) layer.append(bubbleEl(v, a, boundsPx(v, rects)));
  } else if (a.t === "ink") {
    const g = svgEl("g", { class: cls, "data-id": a.id });
    for (const path of a.paths) { const pts = path.map(([x, y]) => v.vp.convertToViewportPoint(x, y)); g.append(svgEl("path", { d: "M" + pts.map(p => p[0].toFixed(1) + " " + p[1].toFixed(1)).join("L"), stroke: a.color, "stroke-width": a.width * S.scale, fill: "none", "stroke-linecap": "round", "stroke-linejoin": "round", "stroke-opacity": a.opacity ?? 1 })); }
    if (sel) { const bb = inkBounds(v, a); g.append(svgEl("rect", { class: "selbox", x: bb[0] - 3, y: bb[1] - 3, width: bb[2] - bb[0] + 6, height: bb[3] - bb[1] + 6 })); }
    g.addEventListener("click", onClick); svg.append(g);
  } else if (a.t === "shape") {
    const [x1, y1, x2, y2] = pdfRectToPx(v, a.rect), w = x2 - x1, h = y2 - y1, sw = a.width * S.scale, g = svgEl("g", { class: cls, "data-id": a.id });
    if (a.kind === "rect") g.append(svgEl("rect", { x: x1, y: y1, width: w, height: h, stroke: a.color, "stroke-width": sw, fill: a.fill || "none", "fill-opacity": .25, rx: 2 }));
    else if (a.kind === "whiteout") g.append(svgEl("rect", { x: x1, y: y1, width: w, height: h, fill: "var(--page-bg)", stroke: sel ? "var(--line-2)" : "none", "stroke-dasharray": "3 2" }));
    else if (a.kind === "ellipse") g.append(svgEl("ellipse", { cx: x1 + w / 2, cy: y1 + h / 2, rx: w / 2, ry: h / 2, stroke: a.color, "stroke-width": sw, fill: "none" }));
    else {
      const [sx, sy] = v.vp.convertToViewportPoint(a.pts[0][0], a.pts[0][1]), [ex, ey] = v.vp.convertToViewportPoint(a.pts[1][0], a.pts[1][1]);
      g.append(svgEl("line", { x1: sx, y1: sy, x2: ex, y2: ey, stroke: a.color, "stroke-width": sw, "stroke-linecap": "round" }));
      if (a.kind === "arrow") { const ang = Math.atan2(ey - sy, ex - sx), L = 6 + sw * 3; g.append(svgEl("path", { d: `M${ex} ${ey}L${ex - L * Math.cos(ang - .45)} ${ey - L * Math.sin(ang - .45)}M${ex} ${ey}L${ex - L * Math.cos(ang + .45)} ${ey - L * Math.sin(ang + .45)}`, stroke: a.color, "stroke-width": sw, fill: "none", "stroke-linecap": "round" })); }
      g.append(svgEl("line", { x1: sx, y1: sy, x2: ex, y2: ey, stroke: "transparent", "stroke-width": 12 }));
    }
    if (sel) g.append(svgEl("rect", { class: "selbox", x: x1 - 3, y: y1 - 3, width: w + 6, height: h + 6 }));
    g.addEventListener("click", onClick); svg.append(g);
    if (a.text) layer.append(bubbleEl(v, a, [x1, y1, x2, y2]));
  } else if (a.t === "note") {
    const [x, y] = v.vp.convertToViewportPoint(a.pt[0], a.pt[1]); layer.append(bubbleEl(v, a, [x, y, x, y], true));
  } else if (a.t === "text" || a.t === "image" || a.t === "edit") {
    layer.append(nodeEl(v, a));
    if (a.text && a.t !== "edit") { const r = pdfRectToPx(v, a.rect); layer.append(bubbleEl(v, a, r)); }
  }
}
function boundsPx(v, rects) { let b = [1e9, 1e9, -1e9, -1e9]; for (const r of rects) { const p = pdfRectToPx(v, r); b = [Math.min(b[0], p[0]), Math.min(b[1], p[1]), Math.max(b[2], p[2]), Math.max(b[3], p[3])]; } return b; }
function inkBounds(v, a) { let b = [1e9, 1e9, -1e9, -1e9]; for (const path of a.paths) for (const [x, y] of path) { const p = v.vp.convertToViewportPoint(x, y); b = [Math.min(b[0], p[0]), Math.min(b[1], p[1]), Math.max(b[2], p[2]), Math.max(b[3], p[3])]; } return b; }
function bubbleEl(v, a, px, standalone) {
  const b = EL("div", { class: "bubble" + (a.resolved ? " resolved" : "") + (a.id === S.sel ? " on" : ""), style: `left:${standalone ? px[0] : px[2]}px;top:${px[1]}px;background:${bubbleColor(a)}`, title: (a.text || "Comment").slice(0, 120) });
  b.append(ICON("i-comment"));
  b.addEventListener("click", e => { e.stopPropagation(); if (S.tool === "erase" && standalone) return removeAnnot(a.id); selectAnnot(a.id); openPop(a, e); });
  if (standalone) makeDraggable(b, v, a, "pt");
  return b;
}
function bubbleColor(a) { const c = a.color || "#ffe066"; return (a.t === "note" || a.t === "hl" || a.t === "area") ? darken(c) : c; }
function darken(hex) { const n = parseInt(hex.slice(1), 16), r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255; const f = .62; return `rgb(${r * f | 0},${g * f | 0},${b * f | 0})`; }
/* text boxes, placed images and text edits are HTML nodes positioned over the page */
function nodeEl(v, a) {
  const [x1, y1, x2, y2] = pdfRectToPx(v, a.rect), sel = a.id === S.sel;
  let n;
  if (a.t === "image") { n = EL("div", { class: "anode imgbox" + (sel ? " sel" : ""), style: `left:${x1}px;top:${y1}px;width:${x2 - x1}px;height:${y2 - y1}px` }); n.append(EL("img", { src: a.data, draggable: "false" })); }
  else if (a.t === "edit") { n = EL("div", { class: "anode textbox editnode" + (sel ? " sel" : ""), style: `left:${x1}px;top:${y1}px;min-width:${x2 - x1}px;height:${y2 - y1}px;font-size:${a.size * S.scale}px;font-family:${a.font || "serif"};color:${a.color || "#111"};background:var(--page-bg);padding:0;line-height:${y2 - y1}px;white-space:pre` }); n.textContent = a.text; }
  else { n = EL("div", { class: "anode textbox" + (sel ? " sel" : ""), style: `left:${x1}px;top:${y1}px;width:${x2 - x1}px;font-size:${a.size * S.scale}px;color:${a.color};font-family:${a.font || "inherit"};background:${a.bg || "transparent"};text-align:${a.align || "left"}` }); if (a.html) n.innerHTML = a.html; else n.textContent = a.body || ""; }
  n.dataset.id = a.id;
  n.addEventListener("pointerdown", e => { if (S.tool === "erase") { e.stopPropagation(); return removeAnnot(a.id); } });
  n.addEventListener("click", e => { e.stopPropagation(); if (!n.isContentEditable) selectAnnot(a.id); });
  n.addEventListener("dblclick", e => { e.stopPropagation(); if (a.t === "image") return editImageAnnot(a); editTextNode(v, a, n); });
  makeDraggable(n, v, a, "rect");
  if (a.t !== "edit") { const h = EL("div", { class: "hdl" }); n.append(h); makeResizable(h, n, v, a); }
  return n;
}
function makeDraggable(n, v, a, kind) {
  n.addEventListener("pointerdown", e => {
    if (e.button !== 0 || n.isContentEditable || e.target.classList.contains("hdl")) return;
    if (S.tool === "erase") return;
    const wasSel = S.sel === a.id;
    e.preventDefault(); e.stopPropagation(); selectAnnot(a.id);
    const start = pagePoint(e, v.el), orig = kind === "pt" ? a.pt.slice() : a.rect.slice(); let moved = false;
    const mv = ev => {
      const p = pagePoint(ev, v.el), dx = p[0] - start[0], dy = p[1] - start[1]; if (Math.abs(dx) + Math.abs(dy) > 2) moved = true; if (!moved) return;
      const p0 = toPdf(v, 0, 0), p1 = toPdf(v, dx, dy), ddx = p1[0] - p0[0], ddy = p1[1] - p0[1];
      if (kind === "pt") a.pt = [orig[0] + ddx, orig[1] + ddy]; else a.rect = [orig[0] + ddx, orig[1] + ddy, orig[2] + ddx, orig[3] + ddy];
      drawAnnots(v);
    };
    const up = () => { document.removeEventListener("pointermove", mv); document.removeEventListener("pointerup", up); if (moved) changed({ quiet: true }); else if (wasSel && a.t === "text") { const node = v.el.querySelector(`.anode[data-id="${a.id}"]`); if (node) editTextNode(v, a, node); } };
    document.addEventListener("pointermove", mv); document.addEventListener("pointerup", up);
  });
}
function makeResizable(h, n, v, a) {
  h.addEventListener("pointerdown", e => {
    e.preventDefault(); e.stopPropagation(); const start = pagePoint(e, v.el), orig = a.rect.slice(), px0 = pdfRectToPx(v, orig);
    const ratio = a.t === "image" ? (px0[2] - px0[0]) / (px0[3] - px0[1]) : 0;
    const mv = ev => { const p = pagePoint(ev, v.el); let w = Math.max(16, px0[2] - px0[0] + p[0] - start[0]), hh = Math.max(12, px0[3] - px0[1] + p[1] - start[1]); if (ratio && !ev.shiftKey) hh = w / ratio; a.rect = pxRectToPdf(v, [px0[0], px0[1], px0[0] + w, px0[1] + hh]); drawAnnots(v); };
    const up = () => { document.removeEventListener("pointermove", mv); document.removeEventListener("pointerup", up); changed({ quiet: true }); };
    document.addEventListener("pointermove", mv); document.addEventListener("pointerup", up);
  });
}
/* text boxes are edited in place with Word-style formatting (bold, italic, size, colour, alignment, line breaks) */
function editTextNode(v, a, n) {
  n.contentEditable = "true"; n.focus(); if (!a.body && !a.html) document.execCommand("selectAll", false, null); else { const r = document.createRange(); r.selectNodeContents(n); r.collapse(false); getSelection().removeAllRanges(); getSelection().addRange(r); }
  S.editingText = a.id; showCtx();
  const done = () => {
    if (!n.isConnected) return; n.contentEditable = "false"; S.editingText = null;
    a.html = DOMPurify.sanitize(n.innerHTML, { ALLOWED_TAGS: ["b", "strong", "i", "em", "u", "s", "strike", "br", "div", "span", "font", "sup", "sub"], ALLOWED_ATTR: ["style", "color", "size", "face"] }); a.body = n.innerText.replace(/\n+$/, "");
    const r = n.getBoundingClientRect(), pr = v.el.getBoundingClientRect(); a.rect = pxRectToPdf(v, [r.left - pr.left, r.top - pr.top, r.right - pr.left, r.bottom - pr.top]);
    if (!a.body.trim()) removeAnnot(a.id); else { drawAnnots(v); showCtx(); changed(); }
  };
  n.addEventListener("blur", () => setTimeout(() => { if (!document.activeElement?.closest("#ctxbar")) done(); else n.focus(); }, 0), { once: false });
  n.addEventListener("keydown", e => { if (e.key === "Escape") { e.preventDefault(); n.blur(); } if ((e.ctrlKey || e.metaKey) && /^[biu]$/i.test(e.key)) { e.preventDefault(); document.execCommand({ b: "bold", i: "italic", u: "underline" }[e.key.toLowerCase()]); } e.stopPropagation(); });
}
async function editImageAnnot(a) { const out = await editImage(a.data); if (!out) return; const im = await loadImage(out); const [x1, y1, x2, y2] = normRect(a.rect); const w = x2 - x1, h = w * im.naturalHeight / im.naturalWidth; a.data = out; a.rect = [x1, y2 - h, x2, y2]; redrawAllAnnots(); changed(); }
function selectAnnot(id) { S.sel = id; redrawAllAnnots(); showCtx(); $$(".note").forEach(n => n.classList.toggle("on", n.dataset.id === id)); }
function removeAnnot(id) { S.doc.annots = S.doc.annots.filter(a => a.id !== id); if (S.sel === id) S.sel = null; closePop(); redrawAllAnnots(); showCtx(); changed(); }
function addAnnot(a) { a.id = a.id || uid(); a.at = a.at || Date.now(); S.doc.annots.push(a); const v = S.views.get(a.p); if (v) drawAnnots(v); changed(); return a; }

/* the small context bar under the toolbar: tool options and the selected mark */
function showCtx() {
  const c = $("#ctxbar"); c.innerHTML = ""; c.hidden = true;
  if (S.doc?.kind !== "pdf") return;
  const a = S.sel && annotById(S.sel);
  if (S.editingText && a && a.id === S.editingText) {   // formatting bar for the text box being typed in
    c.hidden = false; const X = (lbl, fn, title) => c.append(EL("button", { class: "btn small", title, onpointerdown: e => e.preventDefault(), onclick: fn }, lbl));
    c.append(EL("span", {}, "Text box:")); X(EL("b", {}, "B"), () => document.execCommand("bold"), "Bold (Ctrl+B)"); X(EL("i", {}, "I"), () => document.execCommand("italic"), "Italic (Ctrl+I)"); X(EL("u", {}, "U"), () => document.execCommand("underline"), "Underline (Ctrl+U)");
    X("A−", () => { a.size = Math.max(4, a.size - 1); const n = $(`.anode[data-id="${a.id}"]`); if (n) n.style.fontSize = a.size * S.scale + "px"; }, "Smaller"); X("A+", () => { a.size = Math.min(96, a.size + 1); const n = $(`.anode[data-id="${a.id}"]`); if (n) n.style.fontSize = a.size * S.scale + "px"; }, "Larger");
    X("⇤", () => { a.align = "left"; $(`.anode[data-id="${a.id}"]`).style.textAlign = "left"; }, "Align left"); X("↔", () => { a.align = "center"; $(`.anode[data-id="${a.id}"]`).style.textAlign = "center"; }, "Centre"); X("⇥", () => { a.align = "right"; $(`.anode[data-id="${a.id}"]`).style.textAlign = "right"; }, "Align right");
    const sw = EL("span", { class: "ctx-sw" }); INK_COLORS.forEach(col => sw.append(EL("i", { class: "sw", style: "background:" + col, onpointerdown: e => e.preventDefault(), onclick: () => document.execCommand("foreColor", false, col) }))); c.append(sw);
    c.append(EL("label", { onpointerdown: e => e.preventDefault() }, EL("input", { type: "checkbox", checked: a.bg ? "" : null, onchange: e => { a.bg = e.target.checked ? "rgba(255,255,255,.92)" : ""; $(`.anode[data-id="${a.id}"]`).style.background = a.bg || "transparent"; } }), " White background"));
    X("Done", () => $(`.anode[data-id="${a.id}"]`)?.blur(), "Finish editing (Esc)"); return;
  }
  if (a) {
    c.hidden = false;
    c.append(EL("span", {}, { hl: "Highlight", ul: "Underline", st: "Strikethrough", area: "Area highlight", note: "Comment", text: "Text box", ink: "Drawing", shape: "Shape", image: "Image", edit: "Text edit" }[a.t]));
    const sw = EL("span", { class: "ctx-sw" }); (a.t === "ink" || a.t === "shape" || a.t === "text" || a.t === "edit" ? INK_COLORS : COLORS.map(x => x[0])).forEach(col => sw.append(EL("i", { class: "sw" + (a.color === col ? " on" : ""), style: "background:" + col, onclick: () => { a.color = col; redrawAllAnnots(); showCtx(); changed(); } }))); c.append(sw);
    if (a.t === "ink" || a.t === "shape") c.append(EL("label", {}, "Width ", EL("input", { type: "range", min: 1, max: 12, step: .5, value: a.width, oninput: e => { a.width = +e.target.value; redrawAllAnnots(); changed({ soon: true, quiet: true }); } })));
    if (a.t === "text" || a.t === "edit") c.append(EL("label", {}, "Size ", EL("input", { type: "number", min: 4, max: 96, value: a.size, oninput: e => { a.size = +e.target.value || 12; redrawAllAnnots(); changed({ soon: true, quiet: true }); } })));
    if (a.t === "text") c.append(EL("button", { class: "btn small", onclick: () => { const v = S.views.get(a.p), n = v?.el.querySelector(`.anode[data-id="${a.id}"]`); if (n) editTextNode(v, a, n); } }, "Edit text"));
    if (a.t === "image") c.append(EL("button", { class: "btn small", onclick: () => editImageAnnot(a) }, "Edit image… (crop, rotate, light)"));
    if (a.t !== "note" && a.t !== "edit") c.append(EL("button", { class: "btn small", onclick: e => openPop(a, e) }, a.text ? "Edit comment" : "Add comment"));
    if (a.t === "hl" || a.t === "ul" || a.t === "st") { const sel2 = EL("select", { class: "tsel", onchange: e => { a.t = e.target.value; redrawAllAnnots(); changed(); } }); [["hl", "Highlight"], ["ul", "Underline"], ["st", "Strikethrough"]].forEach(([k, l]) => sel2.append(EL("option", { value: k, selected: a.t === k ? "" : null }, l))); c.append(sel2); c.append(EL("button", { class: "btn small", onclick: () => { navigator.clipboard.writeText(a.quote || ""); toast("Copied the text."); } }, "Copy text")); }
    c.append(EL("button", { class: "btn small danger", onclick: () => removeAnnot(a.id) }, "Delete"));
    c.append(EL("button", { class: "btn small ghost", onclick: () => { S.sel = null; redrawAllAnnots(); showCtx(); } }, "Done"));
    return;
  }
  const t = S.tool; if (t === "select") return;
  c.hidden = false;
  if (t === "highlight" || t === "underline" || t === "strike" || t === "area") { c.append(EL("span", {}, { highlight: "Drag over text to highlight it.", underline: "Drag over text to underline it.", strike: "Drag over text to strike it through.", area: "Drag a box around a figure, table or any part of the page." }[t])); }
  if (t === "comment") c.append(EL("span", {}, "Click where the comment belongs."));
  if (t === "text") { c.append(EL("span", {}, "Click to place a text box.")); c.append(EL("label", {}, "Size ", EL("input", { type: "number", min: 4, max: 96, value: S.fontSize, oninput: e => { S.fontSize = +e.target.value || 12; } }))); inkColorRow(c); }
  if (t === "pen") { c.append(EL("span", {}, "Draw with the mouse or a pen.")); inkColorRow(c); c.append(EL("label", {}, "Width ", EL("input", { type: "range", min: 1, max: 12, step: .5, value: S.inkWidth, oninput: e => { S.inkWidth = +e.target.value; } }))); }
  if (t === "shape") { const sel2 = EL("select", { class: "tsel", onchange: e => { S.shapeKind = e.target.value; } }); [["rect", "Box"], ["ellipse", "Circle"], ["arrow", "Arrow"], ["line", "Line"], ["whiteout", "White-out (cover something)"]].forEach(([k, l]) => sel2.append(EL("option", { value: k, selected: S.shapeKind === k ? "" : null }, l))); c.append(sel2); inkColorRow(c); c.append(EL("label", {}, "Width ", EL("input", { type: "range", min: 1, max: 12, step: .5, value: S.inkWidth, oninput: e => { S.inkWidth = +e.target.value; } }))); }
  if (t === "image") c.append(EL("span", {}, "Click where the image should go, or drag a box for its size."));
  if (t === "edit") c.append(EL("span", {}, "Click a line of the PDF's text to retype it. The original is covered and your text drawn on top; use the Shape tool's white-out to remove things."));
  if (t === "erase") c.append(EL("span", {}, "Click any mark to remove it."));
}
function inkColorRow(c) { const sw = EL("span", { class: "ctx-sw" }); INK_COLORS.forEach(col => sw.append(EL("i", { class: "sw" + (S.inkColor === col ? " on" : ""), style: "background:" + col, onclick: () => { S.inkColor = col; showCtx(); } }))); c.append(sw); }

/* ---- the draw layer: area, pen, shapes, comment, text, image placement ---- */
function bindDrawLayer(v, dl) {
  dl.addEventListener("pointerdown", e => {
    if (e.button !== 0) return;
    const t = S.tool;
    if (t === "select" || t === "highlight" || t === "underline" || t === "strike" || t === "edit" || t === "erase") { if (S.sel) { S.sel = null; redrawAllAnnots(); showCtx(); } return; }
    e.preventDefault(); dl.setPointerCapture(e.pointerId);
    const p0 = pagePoint(e, v.el);
    if (t === "comment") { const pt = toPdf(v, p0[0], p0[1]); const a = addAnnot({ t: "note", p: v.entry.id, pt, color: S.color, text: "" }); selectAnnot(a.id); openPop(a, e, true); setTool("select"); return; }
    if (t === "text") { setTool("select"); const pt = toPdf(v, p0[0], p0[1]), pt2 = toPdf(v, p0[0] + 160, p0[1] + S.fontSize * S.scale * 1.4); const a = addAnnot({ t: "text", p: v.entry.id, rect: normRect([pt[0], pt[1], pt2[0], pt2[1]]), size: S.fontSize, color: S.inkColor, body: "" }); selectAnnot(a.id); const n = v.el.querySelector(`.anode[data-id="${a.id}"]`); if (n) editTextNode(v, a, n); return; }
    if (t === "pen") {
      const pts = [toPdf(v, p0[0], p0[1])], svg = v.el.querySelector(".annots svg"), path = svgEl("path", { stroke: S.inkColor, "stroke-width": S.inkWidth * S.scale, fill: "none", "stroke-linecap": "round", "stroke-linejoin": "round" }); svg.append(path);
      let d = "M" + p0[0] + " " + p0[1];
      const mv = ev => { const p = pagePoint(ev, v.el); pts.push(toPdf(v, p[0], p[1])); d += "L" + p[0].toFixed(1) + " " + p[1].toFixed(1); path.setAttribute("d", d); };
      const up = () => { dl.removeEventListener("pointermove", mv); dl.removeEventListener("pointerup", up); path.remove(); if (pts.length > 1) addAnnot({ t: "ink", p: v.entry.id, paths: [pts], color: S.inkColor, width: S.inkWidth }); };
      dl.addEventListener("pointermove", mv); dl.addEventListener("pointerup", up); return;
    }
    // drag a rectangle: area, shape, image
    const box = EL("div", { class: "sel-rect", style: `left:${p0[0]}px;top:${p0[1]}px;width:0;height:0` }); v.el.append(box); let p1 = p0;
    const mv = ev => { p1 = pagePoint(ev, v.el); const r = normRect([p0[0], p0[1], p1[0], p1[1]]); box.style.left = r[0] + "px"; box.style.top = r[1] + "px"; box.style.width = (r[2] - r[0]) + "px"; box.style.height = (r[3] - r[1]) + "px"; };
    const up = () => {
      dl.removeEventListener("pointermove", mv); dl.removeEventListener("pointerup", up); box.remove();
      const r = normRect([p0[0], p0[1], p1[0], p1[1]]), tiny = (r[2] - r[0]) < 6 && (r[3] - r[1]) < 6;
      if (t === "area") { if (tiny) return; addAnnot({ t: "area", p: v.entry.id, rect: pxRectToPdf(v, r), color: S.color, text: "" }); }
      else if (t === "shape") { if (tiny) return; const a = { t: "shape", p: v.entry.id, kind: S.shapeKind, rect: pxRectToPdf(v, r), color: S.inkColor, width: S.inkWidth, text: "" }; if (S.shapeKind === "arrow" || S.shapeKind === "line") a.pts = [toPdf(v, p0[0], p0[1]), toPdf(v, p1[0], p1[1])]; addAnnot(a); }
      else if (t === "image") pickImage(async src => { const im = await loadImage(src); let rr = r; if (tiny) { const w = Math.min(v.vp.width * .4, im.naturalWidth), h = w * im.naturalHeight / im.naturalWidth; rr = [p0[0], p0[1], p0[0] + w, p0[1] + h]; } const a = addAnnot({ t: "image", p: v.entry.id, rect: pxRectToPdf(v, rr), data: src }); selectAnnot(a.id); setTool("select"); });
    };
    dl.addEventListener("pointermove", mv); dl.addEventListener("pointerup", up);
  });
}
function pickImage(cb) { const inp = $("#imgIn"); inp.value = ""; inp.onchange = () => { const f = inp.files[0]; if (!f) return; fileToDataUrl(f).then(cb); }; inp.click(); }
function fileToDataUrl(f) { return new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = rej; r.readAsDataURL(f); }); }
/* shrink big images so a document with many of them stays small */
async function shrinkImage(dataUrl, max = 1800) {
  try { const im = await loadImage(dataUrl); if (im.naturalWidth <= max && im.naturalHeight <= max && dataUrl.length < 1.5e6) return dataUrl; const f = Math.min(1, max / Math.max(im.naturalWidth, im.naturalHeight)); const c = EL("canvas", { width: Math.round(im.naturalWidth * f), height: Math.round(im.naturalHeight * f) }); c.getContext("2d").drawImage(im, 0, 0, c.width, c.height); return c.toDataURL(/png/.test(dataUrl.slice(0, 20)) ? "image/png" : "image/jpeg", .88); } catch (e) { return dataUrl; }
}

/* ---- text marks from a selection (highlight / underline / strike) ---- */
function selectionMarks() {
  const sel = getSelection(); if (!sel || sel.isCollapsed || !sel.rangeCount) return null;
  const range = sel.getRangeAt(0), out = new Map(), quote = sel.toString().replace(/\s+/g, " ").trim();
  for (const v of S.views.values()) {
    const tl = v.el.querySelector(".textLayer"); if (!tl || !range.intersectsNode(tl)) continue;
    const pr = v.el.getBoundingClientRect(), rects = [];
    for (const r of range.getClientRects()) {
      if (r.width < 1 || r.height < 1) continue;
      const cx = r.left + r.width / 2, cy = r.top + r.height / 2; if (cx < pr.left || cx > pr.right || cy < pr.top || cy > pr.bottom) continue;
      rects.push([r.left - pr.left, r.top - pr.top, r.right - pr.left, r.bottom - pr.top]);
    }
    if (rects.length) out.set(v, mergeRects(rects));
  }
  return out.size ? { byView: out, quote } : null;
}
/* join rects that sit on the same line into one, so a highlight is one clean band */
function mergeRects(rs) {
  rs = rs.slice().sort((a, b) => a[1] - b[1] || a[0] - b[0]); const out = [];
  for (const r of rs) { const last = out[out.length - 1]; if (last && Math.abs(last[1] - r[1]) < (r[3] - r[1]) * .5 && Math.abs(last[3] - r[3]) < (r[3] - r[1]) * .5 && r[0] <= last[2] + 12) { last[0] = Math.min(last[0], r[0]); last[2] = Math.max(last[2], r[2]); last[1] = Math.min(last[1], r[1]); last[3] = Math.max(last[3], r[3]); } else out.push(r.slice()); }
  return out;
}
function markSelection(kind, opts = {}) {
  const m = selectionMarks(); if (!m) return null; let first = null;
  for (const [v, rects] of m.byView) { const a = addAnnot({ t: kind, p: v.entry.id, rects: rects.map(r => pxRectToPdf(v, r)), color: S.color, quote: m.quote, text: "" }); first = first || a; }
  getSelection().removeAllRanges(); closeSelPop();
  if (opts.comment && first) { selectAnnot(first.id); openPop(first, null, true); }
  return first;
}
/* a small floating bar when text is selected in Select mode */
function showSelPop() {
  closeSelPop(); const sel = getSelection(); if (!sel || sel.isCollapsed || !sel.rangeCount) return;
  const r = sel.getRangeAt(0).getBoundingClientRect(); if (!r.width) return;
  const p = EL("div", { class: "imgtools selpop", style: `position:fixed;left:${clamp(r.left, 8, innerWidth - 300)}px;top:${Math.max(60, r.top - 40)}px` });
  const mk = (lbl, fn, title) => p.append(EL("button", { onclick: e => { e.preventDefault(); fn(); }, onpointerdown: e => e.preventDefault(), title }, lbl));
  if (S.doc.kind === "pdf") { mk("Highlight", () => markSelection("hl")); mk("Underline", () => markSelection("ul")); mk("Strike", () => markSelection("st")); mk("Comment", () => markSelection("hl", { comment: true })); }
  else { mk("Highlight", () => flowHighlight()); mk("Comment", () => flowComment()); }
  mk("Copy", () => { navigator.clipboard.writeText(sel.toString()); toast("Copied."); closeSelPop(); });
  mk("Read aloud", () => speak(sel.toString()));
  document.body.append(p);
}
function closeSelPop() { $$(".selpop").forEach(p => p.remove()); }

/* ---- edit the PDF's own text: click a text span, retype it ---- */
function bindEditTool() {
  pagesEl.addEventListener("click", e => {
    if (S.tool !== "edit") return; const span = e.target.closest(".textLayer span"); if (!span || !span.textContent.trim()) return;
    const pageEl = span.closest(".page"), v = S.views.get(pageEl.dataset.id); if (!v) return;
    const r = span.getBoundingClientRect(), pr = pageEl.getBoundingClientRect(), px = [r.left - pr.left, r.top - pr.top, r.right - pr.left, r.bottom - pr.top];
    const size = parseFloat(getComputedStyle(span).fontSize) / S.scale, fam = /serif|times|georgia|book/i.test(span.style.fontFamily) && !/sans/i.test(span.style.fontFamily) ? "serif" : (/mono|courier/i.test(span.style.fontFamily) ? "monospace" : "sans-serif");
    const box = EL("div", { class: "editbox", contenteditable: "true", style: `left:${px[0]}px;top:${px[1]}px;height:${px[3] - px[1]}px;line-height:${px[3] - px[1]}px;font-size:${size * S.scale}px;font-family:${fam}` }); box.textContent = span.textContent;
    pageEl.append(box); box.focus(); document.execCommand("selectAll", false, null);
    const done = () => { const txt = box.textContent; if (box.isConnected) box.remove(); if (txt === span.textContent) return; addAnnot({ t: "edit", p: v.entry.id, rect: pxRectToPdf(v, px), text: txt, size, font: fam, color: "#111111", orig: span.textContent }); };
    box.addEventListener("blur", done, { once: true });
    box.addEventListener("keydown", ev => { ev.stopPropagation(); if (ev.key === "Escape") { box.textContent = span.textContent; box.blur(); } if (ev.key === "Enter") { ev.preventDefault(); box.blur(); } });
  });
}

/* ---- comment popup (shared by PDF marks and flow comments) ---- */
let popFor = null;
function openPop(a, ev, focusNew) {
  const pop = $("#pop"); pop.innerHTML = ""; popFor = a;
  const head = EL("div", { class: "ph" }, EL("span", { class: "dot", style: "background:" + (a.color || "#ffe066") }), EL("span", {}, { hl: "Highlight", ul: "Underline", st: "Strikethrough", area: "Area", note: "Comment", shape: "Shape", text: "Text box", image: "Image", ink: "Drawing", cmt: "Comment", mark: "Highlight" }[a.t] || "Note"), EL("span", { class: "sp" }), EL("span", {}, a.at ? fmtTime(a.at) : ""));
  pop.append(head);
  if (a.quote) pop.append(EL("div", { class: "quote" }, a.quote.slice(0, 400)));
  if (a.replies?.length) { const rs = EL("div", { class: "replies" }); a.replies.forEach((r, i) => rs.append(EL("div", { class: "reply" }, EL("div", { class: "who" }, EL("span", {}, "Reply"), EL("span", {}, fmtTime(r.at))), r.text, EL("button", { class: "ibtn", style: "float:right", title: "Delete reply", onclick: () => { a.replies.splice(i, 1); changed(); openPop(a, ev); } }, ICON("i-x"))))); pop.append(rs); }
  const ta = EL("textarea", { placeholder: a.text ? "Reply…" : "Write a comment… (Ctrl+Enter saves)" }); if (!a.text) ta.value = ""; pop.append(ta);
  if (a.text) { const cur = EL("div", { class: "reply", style: "margin-top:6px" }, EL("div", { class: "who" }, EL("span", {}, "Comment"), EL("button", { class: "ibtn", title: "Edit", onclick: () => { ta.value = a.text; ta.dataset.editing = "1"; ta.focus(); } }, ICON("i-edit"))), a.text); pop.insertBefore(cur, ta); }
  const btns = EL("div", { class: "pbtns" });
  const sw = EL("div", { class: "pswatches" }); const palette = (a.t === "ink" || a.t === "shape" || a.t === "text") ? INK_COLORS : COLORS.map(x => x[0]);
  palette.forEach(c => sw.append(EL("i", { class: "sw" + (a.color === c ? " on" : ""), style: "background:" + c, onclick: () => { a.color = c; applyColor(a); openPop(a, ev); changed(); } }))); btns.append(sw, EL("span", { class: "sp" }));
  btns.append(EL("button", { class: "ibtn", title: a.resolved ? "Reopen" : "Mark resolved", onclick: () => { a.resolved = !a.resolved; applyColor(a); changed(); openPop(a, ev); } }, a.resolved ? "↺" : "✓"));
  btns.append(EL("button", { class: "ibtn", title: "Delete", onclick: () => { if (S.doc.kind === "pdf") removeAnnot(a.id); else flowRemove(a); closePop(); } }, ICON("i-trash")));
  btns.append(EL("button", { class: "btn small primary", onclick: () => savePop(a, ta, ev) }, "Save"));
  pop.append(btns);
  ta.addEventListener("keydown", e => { e.stopPropagation(); if ((e.ctrlKey || e.metaKey) && e.key === "Enter") savePop(a, ta, ev); if (e.key === "Escape") closePop(); });
  pop.hidden = false;
  let x = 80, y = 120; if (ev && ev.clientX) { x = ev.clientX + 14; y = ev.clientY - 10; } else { const b = $(`.bubble.on, .cmt.on, mark.on`); if (b) { const r = b.getBoundingClientRect(); x = r.right + 10; y = r.top; } }
  if (x + 310 > innerWidth) x = Math.max(8, innerWidth - 318); if (y + pop.offsetHeight > innerHeight - 8) y = Math.max(8, innerHeight - pop.offsetHeight - 8);
  pop.style.left = x + "px"; pop.style.top = y + "px";
  if (focusNew || !a.text) setTimeout(() => ta.focus(), 20);
}
function savePop(a, ta, ev) { const t = ta.value.trim(); if (ta.dataset.editing) { a.text = t; delete ta.dataset.editing; } else if (!a.text) a.text = t; else if (t) { a.replies = a.replies || []; a.replies.push({ text: t, at: Date.now() }); } if (!a.text && a.t === "note") { if (S.doc.kind === "pdf") removeAnnot(a.id); closePop(); return; } applyColor(a); changed(); closePop(); }
function applyColor(a) { if (S.doc.kind === "pdf") redrawAllAnnots(); else { $$(`[data-id="${a.id}"]`, flowEl).forEach(el => { el.style.setProperty(el.tagName === "MARK" ? "--hl" : "--c", a.color); el.classList.toggle("resolved", !!a.resolved); }); layoutMargin(); } }
function closePop() { const p = $("#pop"); if (!p.hidden) { p.hidden = true; p.innerHTML = ""; popFor = null; } }

/* ---- notes panel (right side) ---- */
function noteItems() {
  if (!S.doc) return [];
  if (S.doc.kind === "pdf") {
    const order = new Map(S.pages.map((p, i) => [p.id, i]));
    return S.doc.annots.filter(a => a.t !== "image").map(a => ({ id: a.id, a, page: order.get(a.p) + 1, y: -(a.rects ? a.rects[0][3] : a.rect ? a.rect[3] : a.pt ? a.pt[1] : a.paths ? a.paths[0][0][1] : 0), kind: a.t === "note" ? "comment" : (a.t === "hl" || a.t === "ul" || a.t === "st" || a.t === "area") ? "highlight" : a.t === "edit" ? "edit" : "draw", quote: a.quote || (a.t === "edit" ? `"${a.orig}" → "${a.text}"` : a.t === "text" ? a.body : ""), text: a.t === "edit" ? "" : a.text, replies: a.replies || [], color: a.color, resolved: a.resolved })).sort((p, q) => p.page - q.page || p.y - q.y);
  }
  const out = []; const seen = new Set();
  $$("mark[data-id],.cmt[data-id]", flowEl).forEach(el => { const id = el.dataset.id; if (seen.has(id)) return; seen.add(id); const c = S.doc.comments[id] || {}; out.push({ id, el, page: 1, y: el.offsetTop, kind: el.tagName === "MARK" ? "highlight" : "comment", quote: $$(`[data-id="${id}"]`, flowEl).map(x => x.textContent).join(""), text: c.text || "", replies: c.replies || [], color: el.style.getPropertyValue("--hl") || el.style.getPropertyValue("--c") || c.color || "#ffe066", resolved: !!c.resolved }); });
  return out.sort((p, q) => p.y - q.y);
}
let noteColorsOff = new Set();
function refreshNotes() {
  const list = $("#notes"); list.innerHTML = ""; const items = noteItems(), f = $("#noteFilter").value, q = $("#noteSearch").value.trim().toLowerCase();
  $("#noteCount").textContent = items.length; if (S.webview) wvBarState();
  const rc = $("#rcolors"); rc.innerHTML = ""; COLORS.forEach(([c, n]) => rc.append(EL("i", { class: "sw" + (noteColorsOff.has(c) ? " off" : ""), style: "background:" + c, title: n + " (click to hide or show)", onclick: () => { noteColorsOff.has(c) ? noteColorsOff.delete(c) : noteColorsOff.add(c); refreshNotes(); } })));
  const shown = items.filter(it => (f === "all" || it.kind === f) && !noteColorsOff.has(it.color) && (!q || (it.quote + " " + it.text + " " + it.replies.map(r => r.text).join(" ")).toLowerCase().includes(q)));
  if (!shown.length) { list.append(EL("div", { class: "empty" }, items.length ? "Nothing matches the filter." : "No notes yet. Select text and pick Highlight or Comment, or use the tools above.")); return; }
  for (const it of shown) {
    const n = EL("div", { class: "note" + (it.resolved ? " resolved" : "") + (it.id === S.sel ? " on" : ""), "data-id": it.id, style: "--c:" + it.color });
    if (it.quote) n.append(EL("div", { class: "nq" }, it.kind === "highlight" ? EL("mark", {}, it.quote) : it.quote));
    if (it.text || it.replies.length) { const c = EL("div", { class: "nc" }, it.text); it.replies.forEach(r => c.append(EL("div", { class: "r" }, r.text))); n.append(c); }
    if (!it.quote && !it.text) n.append(EL("div", { class: "nq muted" }, { draw: "Drawing or shape", edit: "Edit", comment: "Empty comment" }[it.kind] || ""));
    n.append(EL("div", { class: "nm" }, EL("span", { class: "tag" }, it.kind + (S.doc.kind === "pdf" ? " · p. " + it.page : "")), EL("span", {}, it.a?.at ? fmtTime(it.a.at) : "")));
    n.addEventListener("click", e => { if (S.doc.kind === "pdf") { goToAnnot(it.a); openPop(it.a, null); } else if (S.webview) { S.sel = it.id; const at = wvFocus(it.id); openPop(flowAnnot(it.id), at); } else { it.el.scrollIntoView({ block: "center", behavior: "smooth" }); flowSelect(it.id); openPop(flowAnnot(it.id), null); } });
    list.append(n);
  }
}
async function goToAnnot(a) { const i = S.pages.findIndex(p => p.id === a.p); goToPage(i + 1); selectAnnot(a.id); await new Promise(r => setTimeout(r, 80)); const v = S.views.get(a.p); if (!v) return; const px = a.rects ? boundsPx(v, a.rects) : a.rect ? pdfRectToPx(v, a.rect) : a.pt ? (() => { const p = v.vp.convertToViewportPoint(a.pt[0], a.pt[1]); return [p[0], p[1], p[0], p[1]]; })() : inkBounds(v, a); viewer.scrollTop += (v.el.getBoundingClientRect().top + px[1]) - viewer.getBoundingClientRect().top - viewer.clientHeight * .35; }
function notesMarkdown() {
  const items = noteItems(); if (!items.length) return "";
  let md = `# Notes on ${S.doc.name}\n\n`; let lastPage = 0;
  for (const it of items) { if (S.doc.kind === "pdf" && it.page !== lastPage) { md += `\n## Page ${it.page}\n\n`; lastPage = it.page; } if (it.quote) md += `> ${it.quote.replace(/\n/g, "\n> ")}\n`; if (it.text) md += `\n${it.text}\n`; it.replies.forEach(r => md += `\n  - ${r.text}\n`); md += "\n"; }
  return md;
}

/* ---------- image editor: crop, rotate, flip, light and colour; returns a new data URL ----------
   editImage(dataUrl) → Promise<dataUrl | null>. Works on a canvas; nothing leaves the browser. */
async function editImage(src, opts = {}) {
  const im = await loadImage(src);
  const st = { rot: 0, flipH: false, flipV: false, bright: 100, contrast: 100, sat: 100, gray: 0, sharpen: false, crop: null, scale: 100 };
  return new Promise(resolve => {
    const back = $("#modalBack"), m = $("#modal"); m.innerHTML = ""; m.className = "modal imgedit"; back.hidden = false;
    const stage = EL("div", { class: "ie-stage" }), canvas = EL("canvas", { class: "ie-canvas" }), cropBox = EL("div", { class: "ie-crop", hidden: "" });
    const wrap = EL("div", { class: "ie-wrap" }); wrap.append(canvas, cropBox); stage.append(wrap);
    const row = (label, input) => EL("label", { class: "ie-row" }, EL("span", {}, label), input);
    const slider = (k, min, max) => { const i = EL("input", { type: "range", min, max, value: st[k] }); i.oninput = () => { st[k] = +i.value; draw(); }; return i; };
    const side = EL("div", { class: "ie-side" },
      EL("div", { class: "ie-btns" },
        EL("button", { class: "btn small", onclick: () => { st.rot = (st.rot + 90) % 360; st.crop = null; draw(); } }, ICON("i-rotate"), "Rotate"),
        EL("button", { class: "btn small", onclick: () => { st.flipH = !st.flipH; st.crop = null; draw(); } }, "Flip ↔"),
        EL("button", { class: "btn small", onclick: () => { st.flipV = !st.flipV; st.crop = null; draw(); } }, "Flip ↕")),
      EL("p", { class: "muted", style: "font-size:12px;margin:8px 0 4px" }, "Crop: drag on the picture. Click outside the box to clear."),
      row("Brightness", slider("bright", 20, 200)), row("Contrast", slider("contrast", 20, 200)), row("Colour", slider("sat", 0, 200)), row("Greyscale", slider("gray", 0, 100)),
      row("Size", (() => { const i = EL("input", { type: "range", min: 10, max: 100, value: 100 }); i.oninput = () => { st.scale = +i.value; sizeNote(); }; return i; })()),
      EL("div", { class: "ie-size muted", id: "ieSize" }),
      EL("button", { class: "btn small ghost", onclick: () => { Object.assign(st, { rot: 0, flipH: false, flipV: false, bright: 100, contrast: 100, sat: 100, gray: 0, crop: null, scale: 100 }); $$("input[type=range]", side).forEach(i => { i.value = i.max === "100" && i.min === "10" ? 100 : (i.min === "0" ? 0 : 100); }); $$("input[type=range]", side)[0].value = 100; $$("input[type=range]", side)[1].value = 100; $$("input[type=range]", side)[2].value = 100; draw(); } }, "Reset"));
    const btns = EL("div", { class: "mrow" }, EL("button", { class: "btn", onclick: () => finish(null) }, "Cancel"), EL("button", { class: "btn primary", onclick: () => finish(result()) }, "Apply"));
    m.append(EL("h3", {}, opts.title || "Edit image"), EL("div", { class: "ie-body" }, stage, side), btns);
    const ctx = canvas.getContext("2d");
    function baseSize() { return st.rot % 180 ? [im.naturalHeight, im.naturalWidth] : [im.naturalWidth, im.naturalHeight]; }
    function drawTo(c, cx, outW, outH, cropRect) {
      const [bw, bh] = baseSize(); const cr = cropRect || [0, 0, bw, bh];
      c.width = Math.max(1, Math.round(cr[2] * outW)); c.height = Math.max(1, Math.round(cr[3] * outH));
      cx.save(); cx.filter = `brightness(${st.bright}%) contrast(${st.contrast}%) saturate(${st.sat}%) grayscale(${st.gray}%)`;
      cx.scale(outW, outH); cx.translate(-cr[0], -cr[1]);
      cx.translate(bw / 2, bh / 2); cx.rotate(st.rot * Math.PI / 180); cx.scale(st.flipH ? -1 : 1, st.flipV ? -1 : 1);
      cx.drawImage(im, -im.naturalWidth / 2, -im.naturalHeight / 2); cx.restore();
    }
    function draw() {
      const [bw, bh] = baseSize(); const maxW = Math.min(560, innerWidth - 360), maxH = Math.min(440, innerHeight - 260), f = Math.min(maxW / bw, maxH / bh, 1);
      drawTo(canvas, ctx, f, f, null); canvas.style.width = Math.round(bw * f) + "px"; canvas.style.height = Math.round(bh * f) + "px"; canvas.dataset.f = f;
      if (st.crop) { const [x, y, w, h] = st.crop; cropBox.hidden = false; cropBox.style.cssText = `left:${x * f}px;top:${y * f}px;width:${w * f}px;height:${h * f}px`; } else cropBox.hidden = true;
      sizeNote();
    }
    function sizeNote() { const [bw, bh] = baseSize(); const cr = st.crop || [0, 0, bw, bh]; $("#ieSize").textContent = `Result: ${Math.round(cr[2] * st.scale / 100)} × ${Math.round(cr[3] * st.scale / 100)} px`; }
    function result() { const c = document.createElement("canvas"); drawTo(c, c.getContext("2d"), st.scale / 100, st.scale / 100, st.crop); return c.toDataURL(/png|gif|svg/.test(src.slice(0, 20)) ? "image/png" : "image/jpeg", .9); }
    // crop by dragging on the picture
    stage.addEventListener("pointerdown", e => {
      if (e.target !== canvas && e.target !== cropBox && e.target !== wrap) return; e.preventDefault(); const r = canvas.getBoundingClientRect(), f = +canvas.dataset.f, [bw, bh] = baseSize();
      const x0 = clamp((e.clientX - r.left) / f, 0, bw), y0 = clamp((e.clientY - r.top) / f, 0, bh); let moved = false;
      const mv = ev => { const x1 = clamp((ev.clientX - r.left) / f, 0, bw), y1 = clamp((ev.clientY - r.top) / f, 0, bh); if (Math.abs(x1 - x0) > 3 || Math.abs(y1 - y0) > 3) moved = true; if (moved) { st.crop = [Math.min(x0, x1), Math.min(y0, y1), Math.abs(x1 - x0), Math.abs(y1 - y0)]; draw(); } };
      const up = () => { document.removeEventListener("pointermove", mv); document.removeEventListener("pointerup", up); if (!moved) { st.crop = null; draw(); } else if (st.crop && (st.crop[2] < 4 || st.crop[3] < 4)) { st.crop = null; draw(); } };
      document.addEventListener("pointermove", mv); document.addEventListener("pointerup", up);
    });
    function finish(v) { back.hidden = true; m.innerHTML = ""; m.className = "modal"; resolve(v); }
    modalResolve = () => finish(null);
    draw();
  });
}

/* ---------- flow documents: Markdown, web pages, text, notes (a Word-like editor) ----------
   The document is the HTML in #flow. Highlights are <mark data-id style="--hl">, comments are
   <span class="cmt" data-id>; their text and replies live in S.doc.comments[id]. */
function flowAnnot(id) { const c = S.doc.comments[id] || (S.doc.comments[id] = { at: Date.now() }); const els = $$(`[data-id="${id}"]`, flowEl); c.id = id; c.t = els[0]?.tagName === "MARK" ? "mark" : "cmt"; c.quote = els.map(e => e.textContent).join("").slice(0, 400); c.color = c.color || els[0]?.style.getPropertyValue("--hl") || els[0]?.style.getPropertyValue("--c") || S.color; return c; }
function flowSelect(id) { S.sel = id; $$("mark.on,.cmt.on", flowEl).forEach(e => e.classList.remove("on")); $$(`[data-id="${id}"]`, flowEl).forEach(e => e.classList.add("on")); $$(".mnote").forEach(n => n.classList.toggle("on", n.dataset.id === id)); $$(".note").forEach(n => n.classList.toggle("on", n.dataset.id === id)); }
function flowRemove(a) { $$(`[data-id="${a.id}"]`, flowEl).forEach(el => { const p = el.parentNode; while (el.firstChild) p.insertBefore(el.firstChild, el); p.removeChild(el); p.normalize(); }); delete S.doc.comments[a.id]; S.sel = null; layoutMargin(); changed(); }

/* text nodes inside a range, split at its ends */
function rangeTextNodes(range) {
  if (range.startContainer.nodeType === 3 && range.startOffset > 0) { range.startContainer.splitText(range.startOffset); range.setStart(range.startContainer.nextSibling, 0); }
  if (range.endContainer.nodeType === 3 && range.endOffset < range.endContainer.length) range.endContainer.splitText(range.endOffset);
  // text nodes in the range, skipping the whitespace between tags (they would become empty marks)
  const cac = range.commonAncestorContainer, root = cac.nodeType === 3 ? cac.parentNode : cac;   // a walker never visits its own root
  const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, { acceptNode: n => range.intersectsNode(n) && n.data.length && (n.ownerDocument !== document || n.parentElement.closest("#flow")) && (n.data.trim() || n.parentElement.closest("pre")) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT });
  const out = []; let n; while ((n = w.nextNode())) { if (n === range.startContainer && range.startOffset >= n.length) continue; if (n === range.endContainer && range.endOffset === 0) continue; out.push(n); }
  return out;
}
function wrapSelection(tag, cls, id, color) {
  const sel = getSelection(); if (!sel || sel.isCollapsed || !sel.rangeCount) return null;
  const range = sel.getRangeAt(0); const r = wrapRange(range, tag, cls, id, color); if (r) sel.removeAllRanges(); return r;
}
function wrapRange(range, tag, cls, id, color) {
  if (!flowEl.contains(range.commonAncestorContainer)) return null;
  const nodes = rangeTextNodes(range); if (!nodes.length) return null;
  for (const n of nodes) { const w = EL(tag, { class: cls || null, "data-id": id }); w.style.setProperty(tag === "mark" ? "--hl" : "--c", color); n.parentNode.insertBefore(w, n); w.append(n); }
  return id;
}
function flowHighlight() { const id = wrapSelection("mark", "", uid(), S.color); if (!id) return toast("Select some text first."); S.doc.comments[id] = { at: Date.now(), color: S.color, t: "mark" }; closeSelPop(); layoutMargin(); changed(); }
function flowComment() {
  const sel = getSelection(); let id;
  if (sel && !sel.isCollapsed && flowEl.contains(sel.anchorNode)) id = wrapSelection("span", "cmt", uid(), S.color);
  else { // no selection: attach to the current block
    const n = sel?.anchorNode; const block = n && (n.nodeType === 1 ? n : n.parentElement)?.closest("#flow p,#flow h1,#flow h2,#flow h3,#flow h4,#flow li,#flow td,#flow th,#flow blockquote,#flow figure"); if (!block) return toast("Select text, or click into a paragraph, then add the comment.");
    id = uid(); const w = EL("span", { class: "cmt", "data-id": id }); w.style.setProperty("--c", S.color); while (block.firstChild) w.append(block.firstChild); block.append(w);
  }
  if (!id) return; S.doc.comments[id] = { at: Date.now(), color: S.color, t: "cmt", text: "" }; closeSelPop(); layoutMargin(); flowSelect(id); changed(); openPop(flowAnnot(id), null, true);
}
/* margin notes next to the text */
function layoutMargin() {
  if (S.doc?.kind !== "flow") return; marginEl.innerHTML = ""; const items = []; const seen = new Set();
  const z = S.flowZoom || 1;
  $$(".cmt[data-id]", flowEl).forEach(el => { const id = el.dataset.id; if (seen.has(id)) return; seen.add(id); const c = S.doc.comments[id]; if (!c || (!c.text && !c.replies?.length)) return; items.push({ id, el, c, top: (el.getBoundingClientRect().top - flowEl.getBoundingClientRect().top) / z }); });
  $("#margin").parentElement.classList.toggle("nomargin", !items.length && !$$("mark[data-id]", flowEl).length);
  items.sort((a, b) => a.top - b.top); let last = -1e9;
  for (const it of items) {
    const n = EL("div", { class: "mnote" + (it.c.resolved ? " resolved" : "") + (it.id === S.sel ? " on" : ""), "data-id": it.id, style: "--c:" + (it.c.color || "#ffd166") });
    n.append(EL("div", { class: "mq" }, it.el.textContent.slice(0, 60)), EL("div", { class: "mt" }, it.c.text || ""));
    if (it.c.replies?.length) n.append(EL("div", { class: "mr" }, it.c.replies.length + (it.c.replies.length === 1 ? " reply" : " replies")));
    n.addEventListener("click", e => { flowSelect(it.id); openPop(flowAnnot(it.id), e); });
    marginEl.append(n); let top = Math.max(it.top, last + 8); n.style.top = top + "px"; last = top + n.offsetHeight;
  }
}
const layoutMarginSoon = debounce(layoutMargin, 120);

/* editor commands */
function cmd(name, val = null) { flowEl.focus(); document.execCommand(name, false, val); flowChanged(); }
function flowChanged() { S.doc.html = flowEl.innerHTML; changed({ soon: true, quiet: true }); layoutMarginSoon(); refreshNotesSoon(); updateFlowToolbar(); }
const refreshNotesSoon = debounce(refreshNotes, 400);
function setBlock(tag) { if (tag === "pre") { cmd("formatBlock", "<pre>"); return; } cmd("formatBlock", "<" + tag + ">"); }
function currentBlock() { const n = getSelection()?.anchorNode; const el = n && (n.nodeType === 1 ? n : n.parentElement); return el && el.closest("#flow h1,#flow h2,#flow h3,#flow h4,#flow p,#flow blockquote,#flow pre,#flow li"); }
function updateFlowToolbar() {
  if (S.doc?.kind !== "flow") return;
  const b = currentBlock(); const tag = b ? (b.tagName === "LI" ? "p" : b.tagName.toLowerCase()) : "p"; $("#blockSel").value = ["p", "h1", "h2", "h3", "h4", "blockquote", "pre"].includes(tag) ? tag : "p";
  for (const btn of $$("#flowTools [data-cmd]")) { let on = false; try { on = document.queryCommandState(btn.dataset.cmd); } catch (e) { /* unsupported */ } btn.classList.toggle("on", !!on); }
  showTableCtx();
}
function insertHtml(html) { flowEl.focus(); document.execCommand("insertHTML", false, html); flowChanged(); }
function insertTable(r, c) {
  let h = '<table><thead><tr>' + '<th>Heading</th>'.repeat(c) + '</tr></thead><tbody>'; for (let i = 0; i < r; i++) h += "<tr>" + "<td><br></td>".repeat(c) + "</tr>"; h += "</tbody></table><p><br></p>"; insertHtml(h);
}
function tableMenu(anchor) {
  const grid = EL("div", { class: "tbl-pick" }), lbl = EL("div", { class: "tbl-lbl" }, "Pick a size"); let R = 0, C = 0;
  for (let r = 1; r <= 6; r++) for (let c = 1; c <= 8; c++) { const i = EL("i", { "data-r": r, "data-c": c }); i.addEventListener("mouseenter", () => { R = r; C = c; $$("i", grid).forEach(x => x.classList.toggle("on", +x.dataset.r <= r && +x.dataset.c <= c)); lbl.textContent = `${c} × ${r}`; }); i.addEventListener("click", () => { closeMenu(); insertTable(r, c); }); grid.append(i); }
  menu([{ node: grid }, { node: lbl }], anchor);
}
function tableCtx() { const n = getSelection()?.anchorNode; const el = n && (n.nodeType === 1 ? n : n.parentElement); return el && { cell: el.closest("#flow td,#flow th"), table: el.closest("#flow table") }; }
function showTableCtx() {
  const c = $("#ctxbar"); const t = tableCtx(); if (!t || !t.table) { if (c.dataset.kind === "table") { c.hidden = true; c.innerHTML = ""; delete c.dataset.kind; } return; }
  c.hidden = false; c.dataset.kind = "table"; c.innerHTML = ""; c.append(EL("span", {}, "Table:"));
  const row = t.cell?.parentElement, ri = row ? [...t.table.rows].indexOf(row) : 0, ci = t.cell ? [...row.cells].indexOf(t.cell) : 0;
  const B = (l, fn) => c.append(EL("button", { class: "btn small", onpointerdown: e => e.preventDefault(), onclick: () => { fn(); flowChanged(); } }, l));
  B("Row above", () => insertRow(t.table, ri)); B("Row below", () => insertRow(t.table, ri + 1)); B("Column left", () => insertCol(t.table, ci)); B("Column right", () => insertCol(t.table, ci + 1));
  B("Delete row", () => { if (t.table.rows.length > 1) row.remove(); }); B("Delete column", () => { for (const r of t.table.rows) if (r.cells[ci] && r.cells.length > 1) r.cells[ci].remove(); });
  B("Header row on/off", () => { const first = t.table.rows[0]; for (const cell of first.cells) { const nc = EL(cell.tagName === "TH" ? "td" : "th", { html: cell.innerHTML }); cell.replaceWith(nc); } });
  c.append(EL("button", { class: "btn small danger", onpointerdown: e => e.preventDefault(), onclick: () => { t.table.remove(); flowChanged(); } }, "Delete table"));
}
function insertRow(table, at) { const ref = table.rows[Math.min(at, table.rows.length - 1)]; const tr = EL("tr"); for (let i = 0; i < ref.cells.length; i++) tr.append(EL("td", { html: "<br>" })); if (at >= table.rows.length) ref.after(tr); else ref.before(tr); }
function insertCol(table, at) { for (const r of table.rows) { const cell = EL(r.cells[0]?.tagName === "TH" ? "th" : "td", { html: "<br>" }); if (at >= r.cells.length) r.append(cell); else r.cells[at].before(cell); } }
async function insertImageFile(f) { const src = await shrinkImage(await fileToDataUrl(f)); insertHtml(`<figure><img src="${src}" alt="${esc(f.name)}"><figcaption>${esc(f.name.replace(/\.[^.]+$/, ""))}</figcaption></figure><p><br></p>`); }
function imageTools(img) {
  $$(".imgtools:not(.selpop)").forEach(x => x.remove()); $$("img.sel", flowEl).forEach(i => i.classList.remove("sel")); img.classList.add("sel");
  const r = img.getBoundingClientRect(), t = EL("div", { class: "imgtools", style: `position:fixed;left:${Math.max(8, r.left)}px;top:${Math.max(60, r.top - 36)}px` });
  const B = (l, fn) => t.append(EL("button", { onpointerdown: e => e.preventDefault(), onclick: () => { fn(); flowChanged(); t.remove(); } }, l));
  B("25%", () => { img.style.width = "25%"; }); B("50%", () => { img.style.width = "50%"; }); B("100%", () => { img.style.width = "100%"; }); B("Original", () => { img.style.width = ""; });
  B("Left", () => { img.style.float = "left"; img.style.margin = "0 1em .5em 0"; }); B("Centre", () => { img.style.float = ""; img.style.display = "block"; img.style.margin = "0 auto"; });
  B("Caption", () => { let fig = img.closest("figure"); if (!fig) { fig = EL("figure"); img.replaceWith(fig); fig.append(img); } let cap = fig.querySelector("figcaption"); if (!cap) { cap = EL("figcaption", {}, "Caption"); fig.append(cap); } const rg = document.createRange(); rg.selectNodeContents(cap); getSelection().removeAllRanges(); getSelection().addRange(rg); });
  B("Enlarge", () => openLightbox(img, $$("img", flowEl), () => flowChanged()));
  B("Edit…", async () => { const out = await editImage(img.src); if (out) { img.src = out; flowChanged(); } });
  B("Remove", () => { (img.closest("figure") || img).remove(); });
  document.body.append(t);
  // a corner handle: drag to resize freely
  const z = S.flowZoom || 1, hd = EL("div", { class: "img-hdl", style: `position:fixed;left:${r.right - 7}px;top:${r.bottom - 7}px`, title: "Drag to resize" });
  hd.addEventListener("pointerdown", e => { e.preventDefault(); e.stopPropagation(); const w0 = img.getBoundingClientRect().width / z, x0 = e.clientX; const mv = ev => { img.style.width = Math.max(24, w0 + (ev.clientX - x0) / z) + "px"; img.style.height = "auto"; const rr = img.getBoundingClientRect(); hd.style.left = rr.right - 7 + "px"; hd.style.top = rr.bottom - 7 + "px"; }; const up = () => { document.removeEventListener("pointermove", mv); document.removeEventListener("pointerup", up); flowChanged(); }; document.addEventListener("pointermove", mv); document.addEventListener("pointerup", up); });
  document.body.append(hd);
}
document.addEventListener("pointerdown", e => { if (!e.target.closest(".imgtools,.img-hdl") && !(e.target.tagName === "IMG" && flowEl.contains(e.target))) { $$(".imgtools:not(.selpop),.img-hdl").forEach(x => x.remove()); $$("img.sel", flowEl).forEach(i => i.classList.remove("sel")); } }, true);
async function linkPrompt() {
  const sel = getSelection(); const a = sel?.anchorNode && (sel.anchorNode.nodeType === 1 ? sel.anchorNode : sel.anchorNode.parentElement)?.closest("a");
  const saved = sel.rangeCount ? sel.getRangeAt(0).cloneRange() : null;
  const v = await modal(`<h3>Link</h3><label>Web address</label><input type="url" name="url" value="${esc(a?.href || "https://")}"><div class="mrow">${a ? '<button class="btn danger" data-ok="unlink">Remove link</button>' : ""}<span class="sp"></span><button class="btn" data-cancel>Cancel</button><button class="btn primary" data-ok="ok">Apply</button></div>`, { select: true });
  if (!v) return; if (saved) { sel.removeAllRanges(); sel.addRange(saved); }
  if (v.btn === "unlink") return cmd("unlink"); if (!v.url) return;
  if (sel.isCollapsed && !a) insertHtml(`<a href="${esc(v.url)}">${esc(v.url)}</a>`); else cmd("createLink", v.url);
}
function toggleChecklist() {
  const b = currentBlock(); if (b && b.tagName === "LI") { b.classList.toggle("task"); if (b.classList.contains("task")) b.prepend(EL("input", { type: "checkbox" })); else b.querySelector("input[type=checkbox]")?.remove(); flowChanged(); return; }
  insertHtml('<ul><li class="task"><input type="checkbox"> </li></ul>');
}
function alignMenu(anchor) { menu([{ label: "Left", icon: "i-al", fn: () => cmd("justifyLeft") }, { label: "Centre", icon: "i-ac", fn: () => cmd("justifyCenter") }, { label: "Right", icon: "i-ar", fn: () => cmd("justifyRight") }, { sep: true }, { label: "Indent", fn: () => cmd("indent") }, { label: "Outdent", fn: () => cmd("outdent") }], anchor); }

/* flow editor events */
function bindFlow() {
  flowEl.addEventListener("input", flowChanged);
  flowEl.addEventListener("keyup", () => { updateFlowToolbar(); });
  flowEl.addEventListener("mouseup", () => { updateFlowToolbar(); setTimeout(showSelPop, 10); });
  flowEl.addEventListener("keydown", e => {
    if (e.key === "Tab" && tableCtx()?.cell) { e.preventDefault(); const cells = $$("td,th", tableCtx().table), i = cells.indexOf(tableCtx().cell); const next = cells[i + (e.shiftKey ? -1 : 1)]; if (next) { const r = document.createRange(); r.selectNodeContents(next); r.collapse(true); getSelection().removeAllRanges(); getSelection().addRange(r); } else if (!e.shiftKey) { insertRow(tableCtx().table, tableCtx().table.rows.length); flowChanged(); } return; }
    if (e.key === "Tab") { e.preventDefault(); cmd(e.shiftKey ? "outdent" : "indent"); }
  });
  flowEl.addEventListener("click", e => {
    const t = e.target;
    if (t.tagName === "IMG") { e.preventDefault(); imageTools(t); return; }
    if (t.tagName === "A" && (e.ctrlKey || e.metaKey)) { e.preventDefault(); window.open(t.href, "_blank", "noopener"); return; }
    if (t.type === "checkbox") { t.toggleAttribute("checked", t.checked); flowChanged(); return; }
    const m = t.closest("mark[data-id],.cmt[data-id]"); if (m && getSelection().isCollapsed) { flowSelect(m.dataset.id); openPop(flowAnnot(m.dataset.id), e); }
  });
  flowEl.addEventListener("paste", e => {
    const items = [...(e.clipboardData?.items || [])]; const img = items.find(i => i.type.startsWith("image/"));
    if (img) { e.preventDefault(); insertImageFile(img.getAsFile()); return; }
    const html = e.clipboardData.getData("text/html"), text = e.clipboardData.getData("text/plain");
    if (html) { e.preventDefault(); insertHtml(cleanHtml(html)); } else if (text && /^(#|\*|-|\d+\.|>|\|)/m.test(text) && text.includes("\n")) { e.preventDefault(); insertHtml(mdToHtml(text)); }
  });
  flowEl.addEventListener("drop", e => { const f = [...(e.dataTransfer?.files || [])].find(x => x.type.startsWith("image/")); if (f) { e.preventDefault(); insertImageFile(f); } });
  viewer.addEventListener("scroll", () => { $$(".imgtools:not(.selpop),.img-hdl").forEach(x => x.remove()); });
}
/* keep pasted HTML tidy: no scripts, styles, classes or ids from other sites */
function cleanHtml(html, base) {
  const doc = new DOMParser().parseFromString(html, "text/html");
  if (base) { const b = doc.createElement("base"); b.href = base; doc.head.prepend(b); $$("img[src],a[href]", doc).forEach(el => { try { if (el.tagName === "IMG") el.setAttribute("src", new URL(el.getAttribute("src"), base).href); else el.setAttribute("href", new URL(el.getAttribute("href"), base).href); } catch (e) { /* leave */ } }); }
  const clean = DOMPurify.sanitize(doc.body.innerHTML, { USE_PROFILES: { html: true }, FORBID_TAGS: ["style", "script", "iframe", "form", "input", "button", "svg", "canvas", "video", "audio", "noscript", "object", "embed", "select", "textarea"], FORBID_ATTR: ["class", "id", "style", "onclick", "width", "height", "srcset", "sizes", "loading", "decoding", "data-src"] });
  const d2 = new DOMParser().parseFromString(clean, "text/html");
  $$("span,div,section,article,header,footer,nav,aside,main,font,center", d2.body).forEach(el => { if (el.tagName === "DIV" && !el.querySelector("p,h1,h2,h3,h4,ul,ol,table,pre,blockquote,figure,img")) { const p = d2.createElement("p"); p.innerHTML = el.innerHTML; el.replaceWith(p); } else if (el.tagName !== "DIV" || el.parentElement === d2.body) { while (el.firstChild) el.parentNode.insertBefore(el.firstChild, el); el.remove(); } });
  $$("p,li,td,th,h1,h2,h3,h4", d2.body).forEach(el => { if (!el.textContent.trim() && !el.querySelector("img")) el.remove(); });
  return d2.body.innerHTML;
}
function mdToHtml(md) { marked.setOptions({ gfm: true, breaks: false }); let html = marked.parse(md); html = html.replace(/<li><input (?:checked="" )?disabled="" type="checkbox">/g, m => `<li class="task"><input type="checkbox"${/checked/.test(m) ? " checked" : ""}>`); return DOMPurify.sanitize(html, { USE_PROFILES: { html: true }, ADD_ATTR: ["class", "checked"] }); }

/* ---------- web view: the page exactly as a browser shows it, with a floating toolbar on top ----------
   The document is rendered in an iframe (its own head and styles, no scripts). One click on a link
   follows it, on a button presses it, on an image enlarges it; a double-click edits that element.
   While web view is open, the iframe's body is the live copy; wvPull() copies it back into #flow. */
const WV_CSS = `mark[data-id]{background:var(--hl,#ffe066);color:inherit;border-radius:2px;cursor:pointer}
.cmt[data-id]{background:color-mix(in srgb,var(--c,#ffd166) 45%,transparent);border-bottom:2px solid var(--c,#ffd166);cursor:pointer}
.lp-editing{outline:2px solid #0a5fd0!important;outline-offset:2px;cursor:text!important;background-clip:padding-box}
.lp-press{transform:scale(.95);filter:brightness(.9);transition:transform .08s,filter .08s}
.lp-flash{outline:3px solid #ff9f1c!important;outline-offset:3px;transition:outline-color .6s}
img{cursor:zoom-in}
body[contenteditable="true"] img{cursor:default}
a[href],button,[role=button],input[type=button],input[type=submit]{cursor:pointer}`;
let wvClickT = null, wvEditing = null;
const wvFrame = () => $("#wvFrame"), wvDoc = () => wvFrame()?.contentDocument;

function enterWebView() {
  if (S.doc?.kind !== "flow") return toast("Web view is for HTML, Markdown and web pages. PDFs already show as they print.");
  S.webview = true; S.wvZoom = S.wvZoom || 1; document.body.classList.add("webview");
  const wv = $("#webview"); wv.hidden = false;
  const base = S.doc.meta?.sourceUrl ? `<base href="${esc(S.doc.meta.sourceUrl)}">` : "";
  const head = S.doc.meta?.head || `<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><style>${DEFAULT_HEAD_CSS}</style>`;
  const fr = wvFrame(); fr.onload = bindFrame;
  fr.srcdoc = `<!doctype html><html ${S.doc.meta?.htmlAttr || ""}><head>${base}${head}<style id="lp-wv">${WV_CSS}</style></head><body ${S.doc.meta?.bodyAttr || ""}>${flowEl.innerHTML}</body></html>`;   // v3: the page's own <html>/<body> classes and styles, so it looks as it did
  wv.append($("#right")); $("#right").classList.add("closed"); wvBarState(); closePop(); closeSelPop();
}
function exitWebView() {
  if (!S.webview) return; wvStopEdit(); wvPull(); S.webview = false; document.body.classList.remove("webview");
  $("#webview").hidden = true; closeLightbox(); $$(".wv-selpop").forEach(p => p.remove());
  const panes = $(".panes"); panes.append($("#right")); $("#right").classList.toggle("closed", Prefs.get("right", true) === false);
  wvFrame().srcdoc = "<!doctype html><title></title>"; layoutMargin(); buildOutline(); refreshNotes();
}
/* copy the live page back into the document (and so into autosave and the file) */
function wvPull(silent) {
  if (!S.webview) return; const d = wvDoc(); if (!d?.body) return;
  const b = d.body.cloneNode(true);
  b.querySelectorAll("[contenteditable]").forEach(e => e.removeAttribute("contenteditable"));
  b.querySelectorAll(".lp-editing,.lp-press,.lp-flash,mark.on,.cmt.on").forEach(e => { e.classList.remove("lp-editing", "lp-press", "lp-flash", "on"); if (!e.className) e.removeAttribute("class"); });
  b.removeAttribute("contenteditable");
  const h = b.innerHTML; if (h === flowEl.innerHTML) return;
  flowEl.innerHTML = h; S.doc.html = h; if (!silent) { changed({ soon: true, quiet: true }); refreshNotesSoon(); }
}
const wvPullSoon = debounce(() => wvPull(), 400);
/* the other way: after undo, a colour change or a removed note */
function wvPush() { const d = wvDoc(); if (!S.webview || !d?.body) return; wvEditing = null; d.body.innerHTML = flowEl.innerHTML; d.body.contentEditable = S.wvEditAll ? "true" : "inherit"; }
// keep the iframe in step when the shared functions change #flow
{ const o1 = applyColor; applyColor = a => { o1(a); if (S.webview && S.doc?.kind === "flow") wvPush(); };
  const o2 = flowRemove; flowRemove = a => { o2(a); if (S.webview) wvPush(); };
  const o3 = restore; restore = s => { o3(s); if (S.webview) wvPush(); }; }

function bindFrame() {
  const d = wvDoc(); if (!d || !S.webview) return;
  d.documentElement.style.zoom = S.wvZoom; d.body.contentEditable = S.wvEditAll ? "true" : "inherit";
  const off = () => wvFrame().getBoundingClientRect();
  const pos = e => ({ clientX: e.clientX * (S.wvZoom || 1) + off().left, clientY: e.clientY * (S.wvZoom || 1) + off().top });
  d.addEventListener("pointerdown", e => { closeMenu(); if (!e.target.closest?.(".lp-editing")) closePop(); $$(".wv-selpop").forEach(p => p.remove()); }, true);
  d.addEventListener("click", e => {
    const t = e.target; if (!t.closest) return;
    const a = t.closest("a[href]"), btn = t.closest("button,input[type=button],input[type=submit],input[type=reset],[role=button]"), img = t.tagName === "IMG" ? t : null;
    if (t.closest('[contenteditable="true"]')) { if (a || btn) e.preventDefault(); return; }   // editing: clicks place the caret
    if (img || a || btn) {
      e.preventDefault(); clearTimeout(wvClickT);
      // wait a moment so a double-click (edit) can cancel the single-click action
      wvClickT = setTimeout(() => { if (img) openLightbox(img, wvImages(), () => wvPull()); else if (a) wvFollow(a); else wvPress(btn); }, 260);
      return;
    }
    const m = t.closest("mark[data-id],.cmt[data-id]");
    if (m && d.getSelection().isCollapsed) { d.querySelectorAll("mark.on,.cmt.on").forEach(x => x.classList.remove("on")); d.querySelectorAll(`[data-id="${m.dataset.id}"]`).forEach(x => x.classList.add("on")); S.sel = m.dataset.id; openPop(flowAnnot(m.dataset.id), pos(e)); }
  });
  d.addEventListener("dblclick", e => {
    clearTimeout(wvClickT); const t = e.target; if (!t.closest) return;
    if (t.tagName === "IMG") { e.preventDefault(); return wvEditImage(t); }
    if (t.matches("input[type=button],input[type=submit],input[type=reset]")) { e.preventDefault(); return wvEditInput(t); }
    const el = t.closest("button,a,[role=button],summary,label,figcaption,h1,h2,h3,h4,h5,h6,p,li,td,th,dt,dd,blockquote,pre,caption,legend") || t.closest("span,div,section,article,header,footer,nav,aside,main");
    if (!el || el === d.body || el.closest('[contenteditable="true"]') === el) return;
    e.preventDefault(); wvStartEdit(el, e);
  });
  d.addEventListener("input", wvPullSoon);
  d.addEventListener("mouseup", e => setTimeout(() => wvSelPop(e), 10));
  d.addEventListener("submit", e => e.preventDefault(), true);
  d.addEventListener("keydown", e => {
    const mod = e.ctrlKey || e.metaKey, k = e.key.toLowerCase();
    if (mod && k === "s") { e.preventDefault(); wvPull(true); e.shiftKey ? saveAs() : saveToSource(); }
    else if (mod && (k === "=" || k === "+")) { e.preventDefault(); wvZoom(S.wvZoom * 1.15); }
    else if (mod && k === "-") { e.preventDefault(); wvZoom(S.wvZoom / 1.15); }
    else if (mod && k === "0") { e.preventDefault(); wvZoom(1); }
    else if (mod && e.shiftKey && k === "h") { e.preventDefault(); wvMark("mark"); }
    else if (mod && e.altKey && k === "m") { e.preventDefault(); wvMark("cmt"); }
    else if (e.key === "Escape") { if (!$("#lightbox").hidden) closeLightbox(); else if (wvEditing) wvStopEdit(); else closePop(); }
    else if (!$("#lightbox").hidden && (e.key === "ArrowRight" || e.key === "ArrowLeft")) { e.preventDefault(); lbStep(e.key === "ArrowRight" ? 1 : -1); }
  });
  d.addEventListener("wheel", e => { if (e.ctrlKey || e.metaKey) { e.preventDefault(); wvZoom(S.wvZoom * (e.deltaY < 0 ? 1.1 : 1 / 1.1)); } }, { passive: false });
  wvBarState();
}
const wvImages = () => [...wvDoc().images].filter(i => i.naturalWidth > 1 || i.width > 1);

/* links and buttons do what they look like they do */
function wvFollow(a) {
  const raw = a.getAttribute("href") || "", d = wvDoc();
  if (raw.startsWith("#")) { const id = decodeURIComponent(raw.slice(1)); const tgt = id ? (d.getElementById(id) || d.getElementsByName(id)[0]) : d.body; if (tgt) { tgt.scrollIntoView({ behavior: "smooth", block: "start" }); wvFlash(tgt); } else toast("No part of this page is called “" + id + "”."); return; }
  if (/^javascript:/i.test(raw)) return toast("That link runs a script, which a saved page doesn't keep.");
  if (!/^[a-z][a-z0-9+.-]*:/i.test(raw) && !S.doc.meta?.sourceUrl) return toast("That link points to “" + raw + "”, a file next to the original page; it can't be opened from here.");
  wvFlash(a); window.open(a.href, "_blank", "noopener");
}
function wvPress(btn) {
  btn.classList.add("lp-press"); setTimeout(() => btn.classList.remove("lp-press"), 160);
  const label = (btn.value || btn.textContent || "").trim().slice(0, 40) || "button";
  if (btn.tagName === "SUMMARY") return;
  const det = btn.closest("details"); if (det && btn.closest("summary")) { det.open = !det.open; return; }
  const href = btn.getAttribute("formaction") || btn.dataset.href || btn.dataset.url || btn.getAttribute("href") || btn.closest("form")?.getAttribute("action");
  if (href && !/^javascript:/i.test(href)) { try { window.open(new URL(href, S.doc.meta?.sourceUrl || location.href).href, "_blank", "noopener"); return; } catch (e) { /* fall through */ } }
  toast(`“${label}” is a button. What it did came from the page's scripts, which a saved page doesn't keep. Double-click it to change its text.`);
}
function wvFlash(el) { el.classList.add("lp-flash"); setTimeout(() => { el.classList.remove("lp-flash"); if (!el.className) el.removeAttribute("class"); }, 900); }

/* double-click editing of one element */
function wvStartEdit(el, e) {
  wvStopEdit(); const d = wvDoc(); wvEditing = el;
  el.contentEditable = "true"; el.classList.add("lp-editing"); el.focus();
  const r = d.caretRangeFromPoint ? d.caretRangeFromPoint(e.clientX, e.clientY) : null;
  if (r && el.contains(r.startContainer)) { const s = d.getSelection(); s.removeAllRanges(); s.addRange(r); }
  const isBtn = el.matches("button,a,[role=button],summary");
  el.addEventListener("keydown", ev => {
    if (ev.key === "Escape" || (ev.key === "Enter" && isBtn)) { ev.preventDefault(); wvStopEdit(); }
    else if (ev.key === " " && isBtn) { ev.preventDefault(); d.execCommand("insertText", false, " "); }   // a space would press the button
    ev.stopPropagation();
  });
  el.addEventListener("blur", () => setTimeout(() => { if (wvEditing === el && d.activeElement !== el) wvStopEdit(); }, 120), { once: true });
  wvBarState(); status("Editing: Esc or click elsewhere to finish");
}
function wvStopEdit() { const el = wvEditing; if (!el) return; wvEditing = null; el.removeAttribute("contenteditable"); el.classList.remove("lp-editing"); if (!el.className) el.removeAttribute("class"); wvPull(); wvBarState(); status(""); }
async function wvEditInput(inp) {
  const v = await modal(`<h3>Button text</h3><input type="text" name="v" value="${esc(inp.value)}"><div class="mrow"><button class="btn" data-cancel>Cancel</button><button class="btn primary" data-ok="ok">Change</button></div>`, { select: true });
  if (v) { inp.value = v.v; inp.setAttribute("value", v.v); wvPull(); }
}
async function wvEditImage(img) { const out = await editImage(img.src); if (out) { img.src = out; img.removeAttribute("srcset"); wvPull(); } }

/* highlight and comment on a selection in the page */
function wvMark(kind) {
  const d = wvDoc(), sel = d.getSelection(); let id = uid();
  if (sel && !sel.isCollapsed) {
    const range = sel.getRangeAt(0), nodes = rangeTextNodes(range); if (!nodes.length) return;
    for (const n of nodes) { const w = d.createElement(kind === "mark" ? "mark" : "span"); if (kind !== "mark") w.className = "cmt"; w.dataset.id = id; w.style.setProperty(kind === "mark" ? "--hl" : "--c", S.color); n.parentNode.insertBefore(w, n); w.append(n); }
    sel.removeAllRanges();
  } else if (kind === "cmt") {
    const n = sel?.anchorNode, block = n && (n.nodeType === 1 ? n : n.parentElement)?.closest("p,h1,h2,h3,h4,h5,h6,li,td,th,blockquote,figure,button,a,div"); if (!block || block === d.body) return toast("Select some text, or click into a paragraph, first.");
    const w = d.createElement("span"); w.className = "cmt"; w.dataset.id = id; w.style.setProperty("--c", S.color); while (block.firstChild) w.append(block.firstChild); block.append(w);
  } else return toast("Select some text first.");
  S.doc.comments[id] = { at: Date.now(), color: S.color, t: kind, text: "" };
  $$(".wv-selpop").forEach(p => p.remove()); wvPull(); changed();
  if (kind === "cmt") { const el = d.querySelector(`[data-id="${id}"]`), r = el.getBoundingClientRect(), o = wvFrame().getBoundingClientRect(); S.sel = id; openPop(flowAnnot(id), { clientX: r.right * S.wvZoom + o.left, clientY: r.top * S.wvZoom + o.top }, true); }
}
function wvSelPop(e) {
  $$(".wv-selpop").forEach(p => p.remove()); const d = wvDoc(), sel = d?.getSelection(); if (!sel || sel.isCollapsed || !sel.rangeCount || wvEditing) return;
  const r = sel.getRangeAt(0).getBoundingClientRect(), o = wvFrame().getBoundingClientRect(), z = S.wvZoom || 1; if (!r.width) return;
  const p = EL("div", { class: "imgtools wv-selpop", style: `position:fixed;z-index:340;left:${clamp(r.left * z + o.left, 8, innerWidth - 320)}px;top:${Math.max(8, r.top * z + o.top - 42)}px` });
  const B = (l, fn) => p.append(EL("button", { onpointerdown: ev => ev.preventDefault(), onclick: fn }, l));
  B("Highlight", () => wvMark("mark")); B("Comment", () => wvMark("cmt")); B("Copy", () => { navigator.clipboard.writeText(sel.toString()); toast("Copied."); p.remove(); }); B("Read aloud", () => speak(sel.toString()));
  document.body.append(p);
}
function wvFocus(id) { const d = wvDoc(), el = d?.querySelector(`[data-id="${id}"]`); if (!el) return null; el.scrollIntoView({ block: "center", behavior: "smooth" }); d.querySelectorAll("mark.on,.cmt.on").forEach(x => x.classList.remove("on")); d.querySelectorAll(`[data-id="${id}"]`).forEach(x => x.classList.add("on")); const r = el.getBoundingClientRect(), o = wvFrame().getBoundingClientRect(); return { clientX: r.right * S.wvZoom + o.left + 8, clientY: r.top * S.wvZoom + o.top }; }
function wvZoom(z) { S.wvZoom = clamp(z, .3, 3); const d = wvDoc(); if (d) d.documentElement.style.zoom = S.wvZoom; wvBarState(); }
function wvToggleEditAll() { S.wvEditAll = !S.wvEditAll; wvStopEdit(); const d = wvDoc(); d.body.contentEditable = S.wvEditAll ? "true" : "inherit"; if (S.wvEditAll) d.body.focus(); else wvPull(); wvBarState(); toast(S.wvEditAll ? "Edit page: type anywhere. Links and buttons don't open while editing." : "Reading: links and buttons work again; double-click to edit one thing."); }

/* the floating toolbar */
/* the bar can stand up along the left or right edge so it doesn't cover the page */
function wvSetVert(v, keepPlace) {
  const bar = $("#wvBar"), r = bar.getBoundingClientRect(); S.wvVert = v; Prefs.set("wvVert", v); bar.classList.toggle("vert", v);
  if (keepPlace) { bar.style.transform = "none"; bar.style.left = clamp(r.left, 4, innerWidth - bar.offsetWidth - 4) + "px"; bar.style.top = clamp(r.top, 4, innerHeight - bar.offsetHeight - 4) + "px"; Prefs.set("wvBarPos", [bar.style.left, bar.style.top]); }
  wvKeepBarOnScreen();
}
/* dropped near an edge: left/right edge → vertical against it; top/bottom edge → horizontal */
function wvSnap(x, y) {
  const bar = $("#wvBar"), E = 70;
  if (x < E || x > innerWidth - E) { wvSetVert(true); bar.style.left = (x < E ? 8 : innerWidth - bar.offsetWidth - 8) + "px"; bar.style.top = clamp(y - bar.offsetHeight / 2, 8, innerHeight - bar.offsetHeight - 8) + "px"; }
  else if (y < E || y > innerHeight - E) { wvSetVert(false); bar.style.left = clamp(x - bar.offsetWidth / 2, 8, innerWidth - bar.offsetWidth - 8) + "px"; bar.style.top = (y < E ? 8 : innerHeight - bar.offsetHeight - 8) + "px"; }
  bar.style.transform = "none";
}
/* a bar moved on a wide window must still be reachable on a narrow one */
/* v3: turning the bar puts it in a top corner on the side it was on: standing at the left or right edge, or lying along the top */
function wvTurn() {
  const bar = $("#wvBar"), r = bar.getBoundingClientRect(), right = r.left + r.width / 2 > innerWidth / 2;
  wvSetVert(!S.wvVert); bar.style.transform = "none";
  bar.style.left = (right ? innerWidth - bar.offsetWidth - 8 : 8) + "px"; bar.style.top = "8px";
  Prefs.set("wvBarPos", [bar.style.left, bar.style.top]); wvBarState();
}
/* v3: floating (on top of the page, movable) or docked (its own strip, so it never covers the page) */
function wvSetDock(on) { S.wvDock = on; Prefs.set("wvDock", on); if (on) S.wvMin = false; wvBarState(); }
function wvKeepBarOnScreen() {
  const bar = $("#wvBar"); if (!bar || bar.style.transform !== "none" || S.wvDock) return;
  const r = bar.getBoundingClientRect(); if (r.right > innerWidth - 4) bar.style.left = Math.max(4, innerWidth - r.width - 4) + "px"; if (r.bottom > innerHeight - 4) bar.style.top = Math.max(4, innerHeight - r.height - 4) + "px";
}
function wvBarState() {
  const bar = $("#wvBar"); if (!bar) return; requestAnimationFrame?.(wvKeepBarOnScreen);
  $("#wvZoomVal").textContent = Math.round((S.wvZoom || 1) * 100) + "%";
  $("#wvEditAll").classList.toggle("on", !!S.wvEditAll);
  $("#wvColor").style.background = S.color;
  $("#wvNoteCount").textContent = $("#noteCount").textContent;
  $("#wvNotes").classList.toggle("on", !$("#right").classList.contains("closed"));
  bar.classList.toggle("min", !!S.wvMin);
  const r = bar.getBoundingClientRect(), right = !S.wvDock && r.left + r.width / 2 > innerWidth / 2;
  document.body.classList.toggle("wv-docked", !!S.wvDock); document.body.classList.toggle("wv-vert", !!S.wvVert);
  document.body.classList.toggle("wv-bar-right", !!S.wvVert && right); document.body.classList.toggle("wv-bar-left", !!S.wvVert && !right && !S.wvDock);
  const db = $("#wvDock"); if (db){ db.classList.toggle("on", !!S.wvDock); db.title = S.wvDock ? "Docked: the bar has its own strip. Click to float it over the page again" : "Floating: click to dock the bar in its own strip, so it never covers the page"; $(".lbl", db).textContent = S.wvDock ? "Float" : "Dock"; }
  if (S.wvDock) requestAnimationFrame?.(() => { const wv = $("#webview"); wv.style.setProperty("--wvbh", bar.offsetHeight + "px"); wv.style.setProperty("--wvbw", bar.offsetWidth + "px"); });
}
function bindWvBar() {
  const bar = $("#wvBar");
  bar.addEventListener("click", e => {
    const b = e.target.closest("[data-wv]"); if (!b) return; const a = b.dataset.wv;
    if (a === "hl") wvMark("mark"); else if (a === "cmt") wvMark("cmt");
    else if (a === "color") menu(COLORS.map(([c, n]) => ({ node: EL("button", { class: S.color === c ? "on" : "", onclick: () => { S.color = c; Prefs.set("color", c); buildSwatches(); closeMenu(); wvBarState(); } }, EL("i", { class: "sw", style: "background:" + c }), n) })), b);
    else if (a === "edit") wvToggleEditAll();
    else if (a === "zin") wvZoom(S.wvZoom * 1.15); else if (a === "zout") wvZoom(S.wvZoom / 1.15); else if (a === "z1") wvZoom(1);
    else if (a === "notes") { $("#right").classList.toggle("closed"); refreshNotes(); wvBarState(); }
    else if (a === "undo") { wvPull(true); undo(); } else if (a === "redo") { wvPull(true); redo(); }
    else if (a === "save") { wvPull(true); saveMenu(b); } else if (a === "export") { wvPull(true); exportMenu(b); }
    else if (a === "editor") exitWebView(); else if (a === "home") { exitWebView(); goHome(); }
    else if (a === "min") { S.wvMin = !S.wvMin; Prefs.set("wvMin", S.wvMin); wvBarState(); }
    else if (a === "turn") wvTurn();
    else if (a === "dock") wvSetDock(!S.wvDock);
  });
  $$("button", bar).forEach(b => b.addEventListener("pointerdown", e => e.preventDefault()));   // keep the page's selection
  // drag the bar by its handle; remember where it was put
  const grip = $(".wv-grip", bar);
  // the grip captures the pointer, so the drag keeps going over the page's iframe
  grip.addEventListener("pointerdown", e => {
    e.preventDefault(); grip.setPointerCapture(e.pointerId); if (S.wvDock) { wvSetDock(false); bar.style.transform = "none"; } const r = bar.getBoundingClientRect(), dx = e.clientX - r.left, dy = e.clientY - r.top, x0 = e.clientX, y0 = e.clientY; let moved = false;
    const mv = ev => { if (!moved && Math.abs(ev.clientX - x0) + Math.abs(ev.clientY - y0) < 4) return; moved = true; bar.style.left = clamp(ev.clientX - dx, 4, innerWidth - bar.offsetWidth - 4) + "px"; bar.style.top = clamp(ev.clientY - dy, 4, innerHeight - bar.offsetHeight - 4) + "px"; bar.style.transform = "none"; };
    const up = ev => { grip.removeEventListener("pointermove", mv); grip.removeEventListener("pointerup", up); if (moved) { wvSnap(ev.clientX, ev.clientY); Prefs.set("wvBarPos", [bar.style.left, bar.style.top]); } else { S.wvMin = !S.wvMin; Prefs.set("wvMin", S.wvMin); wvBarState(); } };
    grip.addEventListener("pointermove", mv); grip.addEventListener("pointerup", up);
  });
  grip.addEventListener("click", e => e.stopPropagation());
  S.wvVert = Prefs.get("wvVert", false); bar.classList.toggle("vert", S.wvVert);
  const p = Prefs.get("wvBarPos", null); if (p) { bar.style.left = p[0]; bar.style.top = p[1]; bar.style.transform = "none"; } S.wvMin = Prefs.get("wvMin", false); S.wvDock = Prefs.get("wvDock", false);
  addEventListener("resize", () => wvKeepBarOnScreen());
}

/* ---------- picture viewer: one image enlarged, with next/previous, actual size, edit, download ---------- */
let LB = null;
function openLightbox(img, list, onChange) {
  list = list?.length ? list : [img]; LB = { list, i: Math.max(0, list.indexOf(img)), onChange, actual: false };
  $("#lightbox").hidden = false; lbShow();
}
function lbShow() {
  const lb = $("#lightbox"), im = LB.list[LB.i], big = $(".lb-img", lb);
  big.src = im.currentSrc || im.src; lb.classList.toggle("actual", LB.actual);
  const cap = im.closest("figure")?.querySelector("figcaption")?.textContent || im.alt || im.title || "";
  $(".lb-cap", lb).textContent = cap; $(".lb-count", lb).textContent = LB.list.length > 1 ? `${LB.i + 1} / ${LB.list.length}` : "";
  $$(".lb-nav", lb).forEach(b => b.hidden = LB.list.length < 2);
  const a = im.closest("a[href]"); $("[data-lb=link]", lb).hidden = !a;
}
function lbStep(d) { LB.i = (LB.i + d + LB.list.length) % LB.list.length; LB.actual = false; lbShow(); }
function closeLightbox() { $("#lightbox").hidden = true; LB = null; }
function bindLightbox() {
  const lb = $("#lightbox");
  lb.addEventListener("click", async e => {
    const b = e.target.closest("[data-lb]"); const im = LB?.list[LB.i];
    if (e.target === lb || e.target.classList.contains("lb-stage")) return closeLightbox();
    if (e.target.classList.contains("lb-img")) { LB.actual = !LB.actual; lbShow(); return; }
    if (!b || !im) return; const a = b.dataset.lb;
    if (a === "close") closeLightbox(); else if (a === "prev") lbStep(-1); else if (a === "next") lbStep(1);
    else if (a === "actual") { LB.actual = !LB.actual; lbShow(); }
    else if (a === "edit") { const out = await editImage(im.src); if (out) { im.src = out; im.removeAttribute("srcset"); LB.onChange?.(); lbShow(); } }
    else if (a === "download") { try { const blob = await (await fetch(im.src)).blob(); download(blob, (im.alt || "image").replace(/[^\w.-]+/g, "_").slice(0, 40) + "." + (blob.type.split("/")[1] || "png").replace("jpeg", "jpg").replace("svg+xml", "svg")); } catch (er) { window.open(im.src, "_blank", "noopener"); } }
    else if (a === "link") { const ln = im.closest("a[href]"); if (ln) window.open(ln.href, "_blank", "noopener"); }
  });
  document.addEventListener("keydown", e => { if (!LB) return; if (e.key === "Escape") closeLightbox(); else if (e.key === "ArrowRight") lbStep(1); else if (e.key === "ArrowLeft") lbStep(-1); });
}

/* ---------- marks beside the scroll bar ----------
   A thin strip next to the document's scroll bar with a tick for every highlight (in its colour) and a
   bubble for every comment, at the height where it sits in the document; a faint box shows the part on
   screen. Click a tick: the document scrolls there and the text flashes. Alt+Down / Alt+Up step through
   them in order. Works for PDFs, documents and the web view. */
let railIdx = -1;
const rail = EL("div", { class: "mark-rail", id: "markRail", role: "navigation", "aria-label": "Highlights and comments in this document", hidden: "" });
rail.append(EL("button", { class: "mr-step", type: "button", title: "Previous mark (Alt+Up)", "aria-label": "Previous mark", onclick: () => stepMark(-1) }, "▲"),
  EL("div", { class: "mr-track" }, EL("div", { class: "mr-view" })),
  EL("button", { class: "mr-step", type: "button", title: "Next mark (Alt+Down)", "aria-label": "Next mark", onclick: () => stepMark(1) }, "▼"));
document.body.append(rail);
const railTrack = $(".mr-track", rail), railView = $(".mr-view", rail);

/* where each mark sits, as a fraction of the whole document's height */
function railItems() {
  if (!S.doc) return [];
  const items = noteItems();
  if (S.webview) {
    const d = wvDoc(), se = d && d.scrollingElement; if (!se) return [];
    const H = Math.max(1, se.scrollHeight);
    return items.map(it => { const el = d.querySelector(`[data-id="${it.id}"]`); if (!el) return null; return { it, f: (el.getBoundingClientRect().top + se.scrollTop) / H }; }).filter(Boolean);
  }
  const H = Math.max(1, viewer.scrollHeight), top = viewer.getBoundingClientRect().top - viewer.scrollTop;
  if (S.doc.kind === "pdf") {
    return items.map(it => { const a = it.a, v = S.views.get(a.p); if (!v || !v.el) return null;
      let y = 0; try { const px = a.rects ? boundsPx(v, a.rects) : a.rect ? pdfRectToPx(v, a.rect) : a.pt ? (() => { const p = v.vp.convertToViewportPoint(a.pt[0], a.pt[1]); return [p[0], p[1]]; })() : inkBounds(v, a); y = px[1]; } catch (e) { y = 0; }
      return { it, f: (v.el.getBoundingClientRect().top - top + y) / H }; }).filter(Boolean);
  }
  return items.map(it => it.el ? { it, f: (it.el.getBoundingClientRect().top - top) / H } : null).filter(Boolean);
}
function drawRail() {
  const marks = S.doc ? railItems() : [];
  rail.hidden = !S.doc || !marks.length || Prefs.get("markRail", true) === false;
  if (rail.hidden) return;
  // the strip sits just inside the right edge of the visible document (the window in web view)
  const box = S.webview ? { left: 0, top: 0, right: innerWidth, bottom: innerHeight } : viewer.getBoundingClientRect();
  const sbw = S.webview ? 16 : Math.max(0, viewer.offsetWidth - viewer.clientWidth);
  Object.assign(rail.style, { top: (box.top + 6) + "px", height: Math.max(80, box.bottom - box.top - 12) + "px", left: (box.right - sbw - 18) + "px" });
  rail.classList.toggle("wv", !!S.webview);
  $$(".mr-tick", railTrack).forEach(t => t.remove());
  marks.forEach(({ it, f }, k) => {
    const t = EL("button", { type: "button", class: "mr-tick " + (it.kind === "comment" ? "cm" : it.kind === "edit" ? "ed" : "hl") + (it.id === S.sel ? " on" : ""), "data-k": k,
      style: `top:${(clamp(f, 0, 1) * 100).toFixed(2)}%;--c:${it.color || "#ffe066"}`,
      title: (it.kind === "comment" ? "Comment" : it.kind === "edit" ? "Edit" : "Highlight") + (S.doc.kind === "pdf" ? ", page " + it.page : "") + ": " + (it.text || it.quote || "").slice(0, 120),
      onclick: () => goMark(k) });
    railTrack.append(t);
  });
  rail._marks = marks; railViewBox();
}
/* the faint box: which part of the document is on screen */
function railViewBox() {
  if (rail.hidden) return;
  let a, b;
  if (S.webview) { const se = wvDoc()?.scrollingElement; if (!se) return; a = se.scrollTop / se.scrollHeight; b = (se.scrollTop + se.clientHeight) / se.scrollHeight; }
  else { a = viewer.scrollTop / viewer.scrollHeight; b = (viewer.scrollTop + viewer.clientHeight) / viewer.scrollHeight; }
  railView.style.top = (a * 100) + "%"; railView.style.height = Math.max(2, (b - a) * 100) + "%";
}
/* go to a mark: scroll it into the middle of the screen and make it flash */
async function goMark(k) {
  const m = rail._marks && rail._marks[k]; if (!m) return; railIdx = k; const it = m.it; S.sel = it.id;
  if (S.doc.kind === "pdf") { await goToAnnot(it.a); $$(`#pages .page [data-id="${it.id}"]`).forEach(flashEl); }
  else if (S.webview) { wvFocus(it.id); const d = wvDoc(); d.querySelectorAll(`[data-id="${it.id}"]`).forEach(x => { x.classList.add("lp-flash"); setTimeout(() => { x.classList.remove("lp-flash"); }, 1400); }); }
  else { it.el.scrollIntoView({ block: "center", behavior: "smooth" }); flowSelect(it.id); afterScroll(viewer, () => $$(`[data-id="${it.id}"]`, flowEl).forEach(flashEl)); }
  $$(".mr-tick", railTrack).forEach(t => t.classList.toggle("on", +t.dataset.k === k));
  refreshNotesSel(it.id);
}
/* flash once the smooth scroll has arrived, so the eye lands on it */
function afterScroll(el, fn) { let t = setTimeout(done, 900), last = -1, poll; function done() { clearTimeout(t); clearInterval(poll); fn(); }
  poll = setInterval(() => { if (el.scrollTop === last) done(); last = el.scrollTop; }, 120); }
function flashEl(n) { if (!n) return; n.classList.remove("mark-flash"); void n.offsetWidth; n.classList.add("mark-flash"); setTimeout(() => n.classList.remove("mark-flash"), 2000); }
function refreshNotesSel(id) { $$("#notes .note").forEach(n => n.classList.toggle("on", n.dataset.id === id)); }
/* Alt+Down / Alt+Up: the next or previous mark below or above what is on screen */
function stepMark(dir) {
  if (!rail._marks || !rail._marks.length) { drawRail(); if (!rail._marks || !rail._marks.length) return toast("No highlights or comments in this document yet."); }
  const n = rail._marks.length;
  if (railIdx < 0 || railIdx >= n) { const se = S.webview ? wvDoc()?.scrollingElement : viewer; const mid = se ? (se.scrollTop + se.clientHeight / 2) / se.scrollHeight : 0;
    railIdx = dir > 0 ? rail._marks.findIndex(m => m.f > mid) : (() => { let j = -1; rail._marks.forEach((m, i) => { if (m.f < mid) j = i; }); return j; })(); if (railIdx < 0) railIdx = dir > 0 ? 0 : n - 1; goMark(railIdx); return; }
  goMark((railIdx + dir + n) % n);
}
const drawRailSoon = debounce(drawRail, 120);
{ const o = refreshNotes; refreshNotes = (...a) => { const r = o(...a); drawRailSoon(); return r; }; }
viewer.addEventListener("scroll", () => requestAnimationFrame(railViewBox), { passive: true });
addEventListener("resize", drawRailSoon);
new ResizeObserver(drawRailSoon).observe(viewer);
new ResizeObserver(drawRailSoon).observe(pagesEl);
new ResizeObserver(drawRailSoon).observe(flowEl);
document.addEventListener("keydown", e => { if (!S.doc || !e.altKey || e.ctrlKey || e.metaKey) return; if (e.key === "ArrowDown") { e.preventDefault(); stepMark(1); } else if (e.key === "ArrowUp") { e.preventDefault(); stepMark(-1); } });
/* web view: the page lives in a frame, so follow its scrolling and keys too */
{ const o = bindFrame; bindFrame = (...a) => { o(...a); const d = wvDoc(); if (!d) return;
    d.addEventListener("scroll", () => requestAnimationFrame(railViewBox), { passive: true });
    d.addEventListener("keydown", e => { if (e.altKey && !e.ctrlKey && (e.key === "ArrowDown" || e.key === "ArrowUp")) { e.preventDefault(); stepMark(e.key === "ArrowDown" ? 1 : -1); } });
    if (d.defaultView) new d.defaultView.ResizeObserver(drawRailSoon).observe(d.body);
    drawRailSoon(); };
  const e1 = enterWebView, e2 = exitWebView; enterWebView = (...a) => { const r = e1(...a); setTimeout(drawRail, 300); return r; }; exitWebView = (...a) => { const r = e2(...a); setTimeout(drawRail, 50); return r; }; }
{ const o = closeDoc; closeDoc = async (...a) => { const r = await o(...a); railIdx = -1; drawRail(); return r; }; }

/* ---------- opening, saving, exporting ---------- */
function newDoc(kind, name, extra = {}) { return { id: uid(), kind, name, created: Date.now(), modified: Date.now(), annots: [], comments: {}, html: "", origHtml: "", pages: [], meta: {}, ...extra }; }
function download(blob, name) { const u = URL.createObjectURL(blob); const a = EL("a", { href: u, download: name }); document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(u), 4000); }
const baseName = n => String(n || "document").replace(/\.[^.]+$/, "");
const b64 = { enc(buf) { const u = new Uint8Array(buf); let s = ""; for (let i = 0; i < u.length; i += 8192) s += String.fromCharCode.apply(null, u.subarray(i, i + 8192)); return btoa(s); }, dec(s) { const b = atob(s), u = new Uint8Array(b.length); for (let i = 0; i < b.length; i++) u[i] = b.charCodeAt(i); return u; } };

/* ---- open things ---- */
/* open a file; `handle` (from the file picker or a drop) lets Save write back to the same file */
async function openFile(f, handle) {
  const name = f.name || "document", ext = (name.match(/\.([^.]+)$/) || [, ""])[1].toLowerCase();
  status("Opening " + name + "…");
  const src = d => { d.srcHandle = handle || null; d.meta.srcName = name; d.meta.srcExt = ext || (f.type.startsWith("image/") ? f.type.split("/")[1] : ""); return d; };
  try {
    if (ext === "lpdoc" || (ext === "json" && (await f.slice(0, 40).text()).includes("lpdoc"))) return openProject(JSON.parse(await f.text()), handle);
    if (ext === "pdf" || f.type === "application/pdf") return openPdfDoc(src(newDoc("pdf", name, { src: new Blob([await f.arrayBuffer()], { type: "application/pdf" }) })));
    if (f.type.startsWith("image/")) { const data = await shrinkImage(await fileToDataUrl(f), 2600); return openImageDoc(name, data, src); }
    const text = await f.text();
    if (ext === "html" || ext === "htm" || f.type === "text/html") return openHtmlFile(name, text, src);
    if (ext === "md" || ext === "markdown" || ext === "txt" || ext === "" || f.type.startsWith("text/")) return openDoc(src(newDoc("flow", name, { html: ext === "txt" ? textToHtml(text) : mdToHtml(text), orig: text })));
    toast("That file type isn't supported: " + name);
  } catch (e) { console.error(e); status("Could not open " + name, "err"); toast("Could not open " + name + ": " + (e.message || e)); }
}
function textToHtml(t) { return t.split(/\n{2,}/).map(p => "<p>" + esc(p).replace(/\n/g, "<br>") + "</p>").join(""); }
async function openImageDoc(name, src, attach) { const im = await loadImage(src); const w = 612, h = Math.max(100, 612 * im.naturalHeight / im.naturalWidth); let d = newDoc("pdf", name, { src: null, pages: [{ id: uid(), img: { data: src, w, h }, rot: 0 }] }); if (attach) d = attach(d); return openPdfDoc(d); }
/* an HTML file from disk: kept whole (its own styles scoped to the document), editable, and written back as a full page */
function openHtmlFile(name, html, attach, base) {
  const dom = new DOMParser().parseFromString(html, "text/html");
  if (base) {   // a web page: make its addresses absolute so pictures, styles and links still work here
    for (const [sel, at] of [["img[src]", "src"], ["a[href]", "href"], ["link[href]", "href"], ["source[srcset]", "srcset"], ["img[srcset]", "srcset"]]) dom.querySelectorAll(sel).forEach(el => { const v = el.getAttribute(at); if (!v || /^(data|blob|javascript|mailto|#)/i.test(v)) return; try { if (at === "srcset") el.setAttribute(at, v.split(",").map(p => { const [u, w] = p.trim().split(/\s+/); return new URL(u, base).href + (w ? " " + w : ""); }).join(", ")); else el.setAttribute(at, new URL(v, base).href); } catch (e) { /* leave */ } });
    dom.querySelectorAll("img[data-src]:not([src]),img[data-src][src^='data:']").forEach(el => { try { el.setAttribute("src", new URL(el.dataset.src, base).href); } catch (e) { /* leave */ } });
  }
  let comments = {}; const cj = dom.getElementById("lp-comments"); if (cj) { try { comments = JSON.parse(cj.textContent); } catch (e) { /* ignore */ } cj.remove(); }
  // v3: no <meta http-equiv> (a refresh or a security policy in a saved page sends the frame away or blocks its styles)
  const head = [...dom.head.children].filter(e => (/^(STYLE|TITLE)$/.test(e.tagName) || (e.tagName === "META" && !e.hasAttribute("http-equiv"))) || (e.tagName === "LINK" && /stylesheet/i.test(e.rel))).map(e => e.outerHTML).join("\n");
  // v3: the page's own <html> and <body> classes, styles and language (sites hang their layout and theme on them)
  const attrs = el => [...el.attributes].filter(a => /^(class|style|lang|dir|data-[\w-]+|theme)$/i.test(a.name)).map(a => `${a.name}="${esc(a.value)}"`).join(" ");
  const htmlAttr = attrs(dom.documentElement), bodyAttr = attrs(dom.body);
  const css = [...dom.querySelectorAll("style")].map(s => s.textContent).join("\n");
  dom.querySelectorAll("script,noscript,iframe,object,embed").forEach(e => e.remove());
  const body = DOMPurify.sanitize(dom.body.innerHTML, { FORCE_BODY: true, CUSTOM_ELEMENT_HANDLING: { tagNameCheck: /^[a-z][\w]*-[\w-]*$/, attributeNameCheck: /^[a-z][\w-]*$/, allowCustomizedBuiltInElements: true }, USE_PROFILES: { html: true, svg: true, svgFilters: true }, ADD_ATTR: ["style", "class", "id", "width", "height", "colspan", "rowspan", "target", "checked", "srcset", "sizes", "role", "formaction", "value", "type", "name"], ADD_TAGS: ["mark", "button", "style", "picture", "source"] });
  let d = newDoc("flow", (dom.title || name).trim(), { html: body, comments, orig: html, meta: { faithful: true, head, css, htmlAttr, bodyAttr } }); if (attach) d = attach(d);
  return openDoc(d);
}
/* the file's own CSS, limited to the document so it can't restyle the app */
function scopeCss(css) {
  try {
    const doc = document.implementation.createHTMLDocument(""), st = doc.createElement("style"); st.textContent = css; doc.head.append(st); const out = [];
    const walk = rules => { for (const r of rules) { if (r.type === 1) { const sel = r.selectorText.split(",").map(s => { s = s.trim(); if (/^(html|body|:root)$/i.test(s)) return "#flow"; return "#flow " + s.replace(/^(html|body)\s+/i, ""); }).join(", "); out.push(sel + "{" + r.style.cssText + "}"); } else if (r.cssRules) { out.push("@media " + (r.conditionText || r.media?.mediaText || "all") + "{"); walk(r.cssRules); out.push("}"); } else if (r.type === 5) out.push(r.cssText); } };
    walk(st.sheet.cssRules); return out.join("\n");
  } catch (e) { return ""; }
}
/* v3: the newest copy of a web address kept in this browser, so opening it again brings back your highlights and edits */
const urlKey = u => String(u || "").replace(/#.*$/, "").replace(/\/$/, "");
async function savedFor(url) { if (!url) return null; try { return (await DB.all("docs")).filter(d => d.meta?.sourceUrl && urlKey(d.meta.sourceUrl) === urlKey(url)).sort((a, b) => (b.modified || 0) - (a.modified || 0))[0] || null; } catch (e) { return null; } }
async function reopenSaved(url, fresh) { const prev = !fresh && await savedFor(url); if (!prev) return false;
  await (prev.kind === "pdf" ? openPdfDoc(prev) : openDoc(prev));
  toast(`Opened your copy of this page from ${fmtTime(prev.modified)}, with your changes.`, { label: "Load it fresh", fn: () => openUrl(url, true) }); return true; }
async function openHtmlDoc(name, html, url, fresh) {
  if (url && await reopenSaved(url, fresh)) return;
  if (Prefs.get("webLayout", "original") === "original") return openHtmlFile(name, html, d => { d.meta.sourceUrl = url || ""; return d; }, url);
  const dom = new DOMParser().parseFromString(html, "text/html");
  if (url) { const b = dom.createElement("base"); b.href = url; dom.head.prepend(b); }
  let title = dom.title || name, body;
  try { const art = new Readability(dom.cloneNode(true), { keepClasses: false }).parse(); if (art && art.content && art.textContent.trim().length > 200) { body = art.content; title = art.title || title; if (art.byline) body = `<p><em>${esc(art.byline)}</em></p>` + body; } } catch (e) { /* fall back to the whole page */ }
  if (!body) body = dom.body.innerHTML;
  let out = cleanHtml(body, url); if (!/^\s*<h1/i.test(out)) out = `<h1>${esc(title)}</h1>` + out;
  if (url) out = `<p class="src-note">Source: <a href="${esc(url)}">${esc(url)}</a> · saved ${fmtTime(Date.now())}</p>` + out;
  return openDoc(newDoc("flow", title.replace(/[\\/:*?"<>|]/g, " ").trim() || name, { html: out, meta: { sourceUrl: url || "" } }));
}
async function openUrl(url, fresh) {
  url = url.trim(); if (!/^https?:\/\//i.test(url)) url = "https://" + url;
  if (await reopenSaved(url, fresh)) return;
  const note = $("#urlNote"); note.className = "url-note"; note.textContent = "Loading " + url + " …"; status("Loading…");
  try {
    const r = await fetch(url, { mode: "cors", credentials: "omit" }); if (!r.ok) throw new Error("HTTP " + r.status);
    const ct = (r.headers.get("content-type") || "").toLowerCase(), fname = decodeURIComponent(url.split("?")[0].split("/").pop() || "page");
    if (ct.includes("pdf") || /\.pdf$/i.test(url.split("?")[0])) { const buf = await r.arrayBuffer(); note.textContent = ""; return openPdfDoc(newDoc("pdf", fname.endsWith(".pdf") ? fname : fname + ".pdf", { src: new Blob([buf], { type: "application/pdf" }), meta: { sourceUrl: url } })); }
    if (ct.startsWith("image/")) { const src = await shrinkImage(await fileToDataUrl(await r.blob()), 2600); note.textContent = ""; return openImageDoc(fname, src); }
    const text = await r.text(); note.textContent = "";
    if (ct.includes("markdown") || /\.(md|markdown)$/i.test(fname)) return openDoc(newDoc("flow", fname, { html: mdToHtml(text), meta: { sourceUrl: url } }));
    if (ct.includes("text/plain")) return openDoc(newDoc("flow", fname, { html: textToHtml(text), meta: { sourceUrl: url } }));
    return openHtmlDoc(fname, text, url, true);
  } catch (e) {
    console.warn(e); status("");
    if (IS_EXT) { note.className = "url-note err"; note.textContent = "Could not load that address (" + (e.message || e) + ")."; return; }
    note.className = "url-note err";
    note.innerHTML = `This page can't fetch <b>${esc(url)}</b> from here: most sites only let their own pages read them (the browser's cross-origin rule). Three ways round it: use the <b>Chrome extension</b> (right), or open the page in another tab, select all (Ctrl+A), copy, and press <b>Paste</b> here, or save the page as PDF from the browser's print dialog and drop it in.`;
    const v = await modal(`<h3>Can't fetch that page directly</h3><p>Websites usually block other pages from reading them. Pick one:</p><div class="opts">
      <label class="opt"><input type="radio" name="how" value="frame" checked><div><b>Show it in a frame (read only)</b><span>You can read and scroll it here, but not highlight it. Some sites refuse to be framed.</span></div></label>
      <label class="opt"><input type="radio" name="how" value="paste"><div><b>Paste the page</b><span>Open it in a tab, Ctrl+A, Ctrl+C, then paste here. Text, images and headings are kept, and you can mark it all up.</span></div></label>
      <label class="opt"><input type="radio" name="how" value="ext"><div><b>Use the Chrome extension</b><span>One click opens any page, including ones you are signed in to.</span></div></label></div>
      <div class="mrow"><button class="btn" data-cancel>Cancel</button><button class="btn primary" data-ok="ok">Continue</button></div>`);
    if (!v) return;
    if (v.how === "frame") return openDoc(newDoc("flow", url.replace(/^https?:\/\//, "").slice(0, 60), { html: `<p class="readonly-note">Read-only view of <a href="${esc(url)}">${esc(url)}</a>. Highlights and comments can't be placed on a framed page; paste the page instead to mark it up.</p><iframe src="${esc(url)}" sandbox="allow-scripts allow-same-origin allow-popups" referrerpolicy="no-referrer"></iframe>`, meta: { sourceUrl: url, frame: true } }));
    if (v.how === "paste") return pasteNew();
    $("#extCard")?.scrollIntoView({ behavior: "smooth" });
  }
}
async function pasteNew() {
  const v = await modal(`<h3>Paste</h3><p>Paste text, Markdown, or a copied web page (Ctrl+A, Ctrl+C on the page). Formatting and images come along when the page allows it.</p><div id="pasteBox" contenteditable="true" style="min-height:200px;max-height:50vh;overflow:auto;border:1px solid var(--line-2);border-radius:9px;padding:10px;background:var(--paper)"></div><input type="hidden" name="x"><div class="mrow"><button class="btn" data-cancel>Cancel</button><button class="btn primary" data-ok="ok">Open as a document</button></div>`, { focus: "#pasteBox" });
  if (!v) return; const box = $("#pasteBox"); const html = window._lastPaste?.html, text = window._lastPaste?.text || box?.textContent || "";
  if (html) return openHtmlDoc("Pasted page", html, window._lastPaste.url || null);
  if (!text.trim()) return toast("Nothing was pasted.");
  return openDoc(newDoc("flow", text.split("\n")[0].replace(/^#+\s*/, "").slice(0, 60) || "Pasted text", { html: /^(#|\*|-|\d+\.|>|\|)/m.test(text) ? mdToHtml(text) : textToHtml(text) }));
}
document.addEventListener("paste", e => { if (!e.target.closest("#pasteBox")) return; const html = e.clipboardData.getData("text/html"), text = e.clipboardData.getData("text/plain"); window._lastPaste = { html, text }; });
function openProject(p, handle) {
  if (p.format !== "lpdoc") throw new Error("Not a Doc Reader project file");
  const d = { ...newDoc(p.kind, p.name), ...p.doc, id: p.doc.id || uid() }; if (p.srcB64) d.src = new Blob([b64.dec(p.srcB64)], { type: "application/pdf" }); else d.src = null;
  if (handle) { S.fileHandle = handle; d.handle = handle; }
  return d.kind === "pdf" ? openPdfDoc(d) : openDoc(d);
}

/* ---- show a document ---- */
async function openPdfDoc(d) {
  d.kind = "pdf"; await closeDoc();
  S.doc = d; S.pdf = null; S.pageCache.clear(); textCache.clear();
  if (d.src) { const data = new Uint8Array(await d.src.arrayBuffer()); S.pdf = await pdfjsLib.getDocument({ data, cMapUrl: undefined }).promise; if (!d.pages?.length) d.pages = Array.from({ length: S.pdf.numPages }, (_, i) => ({ id: uid(), src: i, rot: 0 })); }
  S.pages = d.pages.map(p => ({ ...p })); return showDoc();
}
async function openDoc(d) { await closeDoc(); S.doc = d; S.pages = []; S.pdf = null; return showDoc(); }
async function showDoc() {
  const d = S.doc; $("#home").hidden = true; work.hidden = false; $("#homeBtn").hidden = false; $("#docActions").hidden = false; $("#docTitle").hidden = false; $("#docTitle").value = d.name;
  work.classList.remove("mode-pdf", "mode-flow"); work.classList.add("mode-" + d.kind, "loading");
  S.hist = []; S.hi = -1; S.sel = null; S.current = 1; closePop(); $("#ctxbar").hidden = true;
  if (d.kind === "pdf") {
    flowWrap.hidden = true; pagesEl.hidden = false; setTool("select"); S.scale = 0;
    await setZoom(Prefs.get("zoomMode", "width"), Prefs.get("zoom", 1));
    buildOutline(); if (!d.thumb) makeThumb();
  } else {
    pagesEl.hidden = true; flowWrap.hidden = false; flowEl.innerHTML = d.html || "<p><br></p>"; if (!d.origHtml) d.origHtml = d.html; flowEl.dataset.font = Prefs.get("flowFont", "serif"); flowEl.contentEditable = d.meta?.frame ? "false" : "true";
    flowEl.classList.toggle("faithful", !!d.meta?.faithful); $("#flow-filecss")?.remove(); if (d.meta?.css) { const sc = scopeCss(d.meta.css); if (sc) document.head.append(EL("style", { id: "flow-filecss" }, sc)); }
    S.flowZoom = 1; await setZoom("custom", 1);
    layoutMargin(); buildOutline(); updateFlowToolbar(); $("#thumbs").innerHTML = "";
    if (d.meta?.faithful && Prefs.get("htmlWebView", true)) enterWebView();   // HTML files open as the page looks
  }
  work.classList.remove("loading"); pushHistory(); refreshNotes(); status("");
  document.title = d.name + " · Doc Reader"; if (!d.saved) { markDirty(); } else status("Opened", "ok");
  d.opened = Date.now(); saveSoon();
}
async function closeDoc() { if (S.webview) exitWebView(); if (S.doc && S.dirty) await saveNow(); $("#flow-filecss")?.remove(); S.fileHandle = null; S.confirmedOverwrite = false; if (S.pdf) { try { await S.pdf.destroy(); } catch (e) { /* ignore */ } } S.pdf = null; S.doc = null; speechSynthesis?.cancel?.(); S.speaking = false; }
function goHome() { closeDoc().then(() => { work.hidden = true; $("#home").hidden = false; $("#homeBtn").hidden = true; $("#docActions").hidden = true; $("#docTitle").hidden = true; document.title = "Doc Reader · Lab Potato"; status(""); listRecent(); }); }
async function makeThumb() { try { const v = S.views.values().next().value; if (!v) return; const vp = v.page.getViewport({ scale: 120 / v.page.getViewport({ scale: 1 }).width }); const c = EL("canvas", { width: vp.width, height: vp.height }); await v.page.render({ canvasContext: c.getContext("2d"), viewport: vp }).promise; S.doc.thumb = c.toDataURL("image/jpeg", .7); } catch (e) { /* no thumb */ } }

/* ---- autosave (IndexedDB, and a file if one was chosen) ---- */
function markDirty() { S.dirty = true; S.doc && (S.doc.modified = Date.now()); status("Unsaved changes"); saveSoon(); }
const saveSoon = debounce(() => saveNow(), 1500);
async function saveNow() {
  if (!S.doc) return; if (S.webview) wvPull(true); const d = S.doc; d.pages = S.pages.map(p => ({ id: p.id, src: p.src, blank: p.blank, img: p.img, rot: p.rot })); if (d.kind === "flow") d.html = flowEl.innerHTML; d.saved = true;
  try { await DB.put("docs", recordOf(d)); S.dirty = false; status("Saved " + new Date().toLocaleTimeString("en", { hour: "2-digit", minute: "2-digit" }), "ok"); } catch (e) { console.warn(e); status("Could not autosave (" + (e.message || e) + ")", "err"); }
  if (S.fileHandle) writeFileHandle().catch(e => { console.warn(e); status("Could not write the file: " + (e.message || e), "err"); });
}
function recordOf(d) { const { _page, ...rest } = d; return { ...rest, annots: d.annots, comments: d.comments, pages: d.pages, src: d.src || null, handle: S.fileHandle || d.handle || null, srcHandle: d.srcHandle || null }; }
async function projectBlob() { const d = S.doc; d.pages = S.pages.map(p => ({ id: p.id, src: p.src, blank: p.blank, img: p.img, rot: p.rot })); if (d.kind === "flow") d.html = flowEl.innerHTML; const { src, handle, srcHandle, thumb, ...doc } = d; const out = { format: "lpdoc", v: 1, kind: d.kind, name: d.name, app: "Lab Potato Doc Reader v9", doc, srcB64: src ? b64.enc(await src.arrayBuffer()) : null }; return new Blob([JSON.stringify(out)], { type: "application/json" }); }
async function saveProjectFile() { download(await projectBlob(), baseName(S.doc.name) + ".lpdoc"); toast("Saved the project file. Open it here again any time to carry on."); }
async function chooseAutosaveFile() {
  if (!window.showSaveFilePicker) return toast("This browser can't keep a file updated automatically. Use Save → Project file instead.");
  try { S.fileHandle = await showSaveFilePicker({ suggestedName: baseName(S.doc.name) + ".lpdoc", types: [{ description: "Doc Reader project", accept: { "application/json": [".lpdoc"] } }] }); await writeFileHandle(); S.doc.handle = S.fileHandle; await saveNow(); toast("Autosaving to " + S.fileHandle.name + " from now on."); } catch (e) { if (e.name !== "AbortError") toast("Could not set that up: " + e.message); }
}
async function writeFileHandle() { const w = await S.fileHandle.createWritable(); await w.write(await projectBlob()); await w.close(); }
async function reconnectHandle(h) { try { if ((await h.queryPermission({ mode: "readwrite" })) === "granted" || (await h.requestPermission({ mode: "readwrite" })) === "granted") { S.fileHandle = h; return true; } } catch (e) { /* not available */ } return false; }

/* ---- recent list on the start page ---- */
async function listRecent() {
  const box = $("#recentList"); let docs = []; try { docs = await DB.all("docs"); } catch (e) { box.innerHTML = '<p class="muted">Saving in this browser is not available (private window?). You can still open files and save project files.</p>'; return; }
  docs.sort((a, b) => (b.opened || b.modified) - (a.opened || a.modified)); box.innerHTML = "";
  if (!docs.length) { box.innerHTML = '<p class="muted">Nothing yet. Open a file to start.</p>'; return; }
  for (const d of docs) {
    const kind = d.kind === "pdf" ? (d.src ? "pdf" : "img") : d.meta?.sourceUrl ? "html" : "md";
    const c = EL("button", { class: "rc", title: d.name }); const ic = EL("span", { class: "ic " + kind }); if (d.thumb) ic.style.cssText = `background:url(${d.thumb}) center/cover`; else ic.textContent = kind.toUpperCase(); c.append(ic);
    c.append(EL("span", { class: "t" }, EL("span", { class: "n" }, d.name), EL("span", { class: "m" }, `${fmtTime(d.modified)} · ${d.annots?.length || Object.keys(d.comments || {}).length || 0} notes`)));
    c.append(EL("span", { class: "x", title: "Remove from this browser", onclick: async e => { e.stopPropagation(); if (await modal(`<h3>Remove "${esc(d.name)}"?</h3><p>It is removed from this browser's list. Files on your computer are not touched.</p><div class="mrow"><button class="btn" data-cancel>Keep</button><button class="btn danger" data-ok="ok">Remove</button></div>`)) { await DB.del("docs", d.id); listRecent(); } } }, ICON("i-x")));
    c.addEventListener("click", async () => { if (d.handle) { if (await reconnectHandle(d.handle)) status("Autosaving to " + d.handle.name, "ok"); } d.kind === "pdf" ? openPdfDoc(d) : openDoc(d); });
    if (d.srcHandle) c.title += " · can save back to " + d.srcHandle.name;
    box.append(c);
  }
}

/* ---- export ---- */
function hexRgb(h) { const n = parseInt(h.slice(1), 16); return [((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255]; }
const winAnsi = s => s.replace(/[^\x20-\x7E\xA0-\xFF–—‘’“”•…€]/g, "?");
async function exportPdf(opts) {
  const { PDFDocument, rgb, StandardFonts, PDFName, PDFString, PDFArray, PDFNumber, BlendMode } = PDFLib;
  status("Building the PDF…"); const out = await PDFDocument.create(); out.setTitle(S.doc.name); out.setProducer("Lab Potato Doc Reader");
  const srcDoc = S.doc.src ? await PDFDocument.load(await S.doc.src.arrayBuffer(), { ignoreEncryption: true }) : null;
  const font = await out.embedFont(StandardFonts.Helvetica), mono = await out.embedFont(StandardFonts.Courier), serif = await out.embedFont(StandardFonts.TimesRoman);
  for (const entry of S.pages) {
    let page;
    if (entry.src != null && srcDoc) { const [cp] = await out.copyPages(srcDoc, [entry.src]); page = out.addPage(cp); }
    else { const w = entry.img ? entry.img.w : entry.blank.w, h = entry.img ? entry.img.h : entry.blank.h; page = out.addPage([w, h]); if (entry.img) { const bytes = b64.dec(entry.img.data.split(",")[1]); const im = /png/.test(entry.img.data.slice(0, 20)) ? await out.embedPng(bytes) : await out.embedJpg(bytes); page.drawImage(im, { x: 0, y: 0, width: w, height: h }); } }
    if (entry.rot) page.setRotation(PDFLib.degrees((page.getRotation().angle + entry.rot) % 360));
    const annots = annotsOf(entry.id), realAnnots = [];
    const addAnnotObj = dict => { const ref = out.context.register(out.context.obj(dict)); realAnnots.push(ref); };
    for (const a of annots) {
      const col = hexRgb(a.color || "#ffe066"), R = rgb(...col);
      if ((a.t === "hl" || a.t === "ul" || a.t === "st" || a.t === "area") && opts.interactive) {
        const rects = a.t === "area" ? [a.rect] : a.rects, quads = [], bb = [1e9, 1e9, -1e9, -1e9];
        for (const r of rects) { const [x1, y1, x2, y2] = normRect(r); quads.push(x1, y2, x2, y2, x1, y1, x2, y1); bb[0] = Math.min(bb[0], x1); bb[1] = Math.min(bb[1], y1); bb[2] = Math.max(bb[2], x2); bb[3] = Math.max(bb[3], y2); }
        addAnnotObj({ Type: "Annot", Subtype: a.t === "ul" ? "Underline" : a.t === "st" ? "StrikeOut" : "Highlight", Rect: bb, QuadPoints: quads, C: col, CA: a.t === "area" ? .5 : 1, F: 4, T: PDFString.of("Doc Reader"), Contents: PDFString.of(commentText(a)), M: PDFString.fromDate(new Date(a.at || Date.now())), NM: PDFString.of(a.id) });
        if (opts.draw) drawMarks(page, a, R);
      } else if (a.t === "hl" || a.t === "ul" || a.t === "st" || a.t === "area") drawMarks(page, a, R);
      else if (a.t === "note" && opts.interactive) addAnnotObj({ Type: "Annot", Subtype: "Text", Rect: [a.pt[0], a.pt[1] - 20, a.pt[0] + 20, a.pt[1]], Name: "Comment", C: col, F: 4, T: PDFString.of("Doc Reader"), Contents: PDFString.of(commentText(a)), M: PDFString.fromDate(new Date(a.at || Date.now())), Open: false });
      else if (a.t === "note") { page.drawCircle({ x: a.pt[0] + 6, y: a.pt[1] - 6, size: 7, color: R }); page.drawText(winAnsi(commentText(a)).slice(0, 300), { x: a.pt[0] + 16, y: a.pt[1] - 10, size: 7, font, color: rgb(.2, .2, .2), maxWidth: 200, lineHeight: 8.5 }); }
      else if (a.t === "ink") { for (const path of a.paths) { if (path.length < 2) continue; let d = `M ${path[0][0]} ${path[0][1]}`; for (let i = 1; i < path.length; i++) d += ` L ${path[i][0]} ${path[i][1]}`; page.drawSvgPath(d, { borderColor: rgb(...hexRgb(a.color)), borderWidth: a.width, borderLineCap: 1, x: 0, y: 0, scale: 1 }); } }
      else if (a.t === "shape") {
        const [x1, y1, x2, y2] = normRect(a.rect), C = rgb(...hexRgb(a.color));
        if (a.kind === "rect") page.drawRectangle({ x: x1, y: y1, width: x2 - x1, height: y2 - y1, borderColor: C, borderWidth: a.width });
        else if (a.kind === "whiteout") page.drawRectangle({ x: x1, y: y1, width: x2 - x1, height: y2 - y1, color: rgb(1, 1, 1) });
        else if (a.kind === "ellipse") page.drawEllipse({ x: (x1 + x2) / 2, y: (y1 + y2) / 2, xScale: (x2 - x1) / 2, yScale: (y2 - y1) / 2, borderColor: C, borderWidth: a.width });
        else { const [p, q] = a.pts; page.drawLine({ start: { x: p[0], y: p[1] }, end: { x: q[0], y: q[1] }, color: C, thickness: a.width }); if (a.kind === "arrow") { const ang = Math.atan2(q[1] - p[1], q[0] - p[0]), L = 6 + a.width * 3; for (const s of [-.45, .45]) page.drawLine({ start: { x: q[0], y: q[1] }, end: { x: q[0] - L * Math.cos(ang + s), y: q[1] - L * Math.sin(ang + s) }, color: C, thickness: a.width }); } }
      } else if (a.t === "image") { try { const bytes = b64.dec(a.data.split(",")[1]); const im = /png/.test(a.data.slice(0, 20)) ? await out.embedPng(bytes) : await out.embedJpg(bytes); const [x1, y1, x2, y2] = normRect(a.rect); page.drawImage(im, { x: x1, y: y1, width: x2 - x1, height: y2 - y1 }); } catch (e) { console.warn("image", e); } }
      else if (a.t === "text") { const [x1, y1, x2, y2] = normRect(a.rect); const f = a.bold ? await out.embedFont(StandardFonts.HelveticaBold) : font; page.drawText(winAnsi((a.body || "").replace(/\r/g, "")), { x: x1 + 3, y: y2 - a.size - 2, size: a.size, font: f, color: rgb(...hexRgb(a.color || "#111111")), maxWidth: Math.max(20, x2 - x1 - 6), lineHeight: a.size * 1.3 }); }
      else if (a.t === "edit") { const [x1, y1, x2, y2] = normRect(a.rect); page.drawRectangle({ x: x1 - 1, y: y1 - 1, width: x2 - x1 + 2, height: y2 - y1 + 2, color: rgb(1, 1, 1) }); const f = a.font === "serif" ? serif : a.font === "monospace" ? mono : font; page.drawText(winAnsi(a.text || ""), { x: x1, y: y1 + (y2 - y1 - a.size) / 2 + a.size * .15, size: a.size, font: f, color: rgb(...hexRgb(a.color || "#111111")) }); }
    }
    if (realAnnots.length) { const existing = page.node.lookup(PDFName.of("Annots")); const arr = existing instanceof PDFArray ? existing : out.context.obj([]); realAnnots.forEach(r => arr.push(r)); page.node.set(PDFName.of("Annots"), arr); }
  }
  if (opts.summary) {
    const md = notesMarkdown(); if (md) { const lines = md.replace(/^#+ /gm, "").split("\n"); let page = out.addPage([595, 842]), y = 800; page.drawText("Notes", { x: 50, y, size: 18, font }); y -= 30; for (const ln of lines) { const wrapped = wrapText(winAnsi(ln), font, 10, 495); for (const w of wrapped) { if (y < 50) { page = out.addPage([595, 842]); y = 800; } page.drawText(w, { x: 50, y, size: 10, font, color: rgb(.1, .1, .1) }); y -= 14; } } }
  }
  const bytes = await out.save(); if (opts.returnBytes) return bytes; download(new Blob([bytes], { type: "application/pdf" }), baseName(S.doc.name) + (opts.suffix || "-annotated") + ".pdf"); status("Exported", "ok");
}
function commentText(a) { let s = a.text || ""; (a.replies || []).forEach(r => s += "\n— " + r.text); if (a.quote && a.t !== "hl" && a.t !== "ul" && a.t !== "st") s = (s ? s + "\n" : "") + "“" + a.quote + "”"; return s; }
function drawMarks(page, a, R) { const { rgb } = PDFLib; const rects = a.t === "area" ? [a.rect] : a.rects; for (const r of rects) { const [x1, y1, x2, y2] = normRect(r); if (a.t === "hl" || a.t === "area") page.drawRectangle({ x: x1, y: y1, width: x2 - x1, height: y2 - y1, color: R, opacity: a.t === "area" ? .35 : .45, blendMode: PDFLib.BlendMode.Multiply }); else if (a.t === "ul") page.drawLine({ start: { x: x1, y: y1 + 1 }, end: { x: x2, y: y1 + 1 }, color: R, thickness: Math.max(1, (y2 - y1) * .08) }); else page.drawLine({ start: { x: x1, y: (y1 + y2) / 2 }, end: { x: x2, y: (y1 + y2) / 2 }, color: R, thickness: Math.max(1, (y2 - y1) * .1) }); } }
function wrapText(s, font, size, maxW) { const words = s.split(" "), lines = []; let cur = ""; for (const w of words) { const t = cur ? cur + " " + w : w; if (font.widthOfTextAtSize(t, size) > maxW && cur) { lines.push(cur); cur = w; } else cur = t; } lines.push(cur); return lines; }

/* Markdown export of a flow document: highlights as ==text==, comments as footnotes */
function flowToMarkdown(opts = {}) {
  if (S.webview) wvPull(true);
  const clone = flowEl.cloneNode(true); const notes = []; const seen = new Map();
  $$(".src-note,.readonly-note,iframe", clone).forEach(e => e.remove());
  $$(".cmt[data-id]", clone).forEach(el => { const id = el.dataset.id, c = S.doc.comments[id]; if (!c || (!c.text && !c.replies?.length)) { el.replaceWith(...el.childNodes); return; } let n = seen.get(id); if (!n) { n = notes.length + 1; seen.set(id, n); notes.push({ n, c, q: el.textContent }); } const fn = document.createTextNode(`[^${n}]`); el.after(fn); el.replaceWith(...el.childNodes); });
  $$("mark[data-id]", clone).forEach(el => { const c = S.doc.comments[el.dataset.id]; const t = document.createTextNode("==" + el.textContent + "=="); el.replaceWith(t); if (c?.text) { const n = notes.length + 1; notes.push({ n, c, q: el.textContent }); t.after(document.createTextNode(`[^${n}]`)); } });
  $$("li.task", clone).forEach(li => { const cb = li.querySelector("input[type=checkbox]"); const on = cb && (cb.checked || cb.hasAttribute("checked")); cb?.remove(); li.prepend(document.createTextNode(on ? "[x] " : "[ ] ")); });
  if (!opts.embedImages) $$("img[src^='data:']", clone).forEach((im, i) => { im.setAttribute("src", `image-${i + 1}.png`); });
  const td = new TurndownService({ headingStyle: "atx", codeBlockStyle: "fenced", bulletListMarker: "-", emDelimiter: "*" }); td.use(turndownPluginGfm.gfm);
  td.addRule("figure", { filter: "figure", replacement: (c, node) => { const im = node.querySelector("img"), cap = node.querySelector("figcaption"); return im ? `\n\n![${(cap?.textContent || im.alt || "").trim()}](${im.getAttribute("src")})\n\n` : c; } });
  td.addRule("underline", { filter: "u", replacement: c => `<u>${c}</u>` }); td.addRule("sup", { filter: ["sup", "sub"], replacement: (c, n) => `<${n.tagName.toLowerCase()}>${c}</${n.tagName.toLowerCase()}>` });
  let md = td.turndown(clone.innerHTML);
  if (notes.length) { md += "\n\n"; for (const { n, c, q } of notes) { md += `[^${n}]: ${(c.text || "").replace(/\n/g, "\n    ")}${c.replies?.length ? "\n    " + c.replies.map(r => "— " + r.text).join("\n    ") : ""}${c.text ? "" : `(on “${q.slice(0, 80)}”)`}\n`; } }
  if (S.doc.meta?.sourceUrl) md = `<!-- source: ${S.doc.meta.sourceUrl} -->\n\n` + md;
  return md.trim() + "\n";
}
async function exportMarkdown(opts = {}) {
  if (S.doc.kind === "flow") { const md = flowToMarkdown(opts); download(new Blob([md], { type: "text/markdown" }), baseName(S.doc.name) + ".md"); if (!opts.embedImages && /\]\(image-\d+\.png\)/.test(md)) toast("Images were written as image-N.png links; choose 'embed images' to keep them inside the file."); }
  else if (opts.text) { download(new Blob([await pdfToMarkdown()], { type: "text/markdown" }), baseName(S.doc.name) + ".md"); }
  else { const md = notesMarkdown() || `# Notes on ${S.doc.name}\n\n(no notes yet)\n`; download(new Blob([md], { type: "text/markdown" }), baseName(S.doc.name) + "-notes.md"); }
  status("Exported", "ok");
}
const DEFAULT_HEAD_CSS = `body{max-width:760px;margin:40px auto;padding:0 20px;font:17px/1.6 Charter,Georgia,serif;color:#222}img{max-width:100%}table{border-collapse:collapse}td,th{border:1px solid #ccc;padding:6px 9px}mark{background:var(--hl,#ffe066)}.cmt{background:#fff1b8;border-bottom:2px solid #f0c040}pre{background:#f3f3f3;padding:12px;border-radius:8px;overflow:auto}blockquote{border-left:3px solid #ccc;padding-left:1em;color:#555}`;
/* a complete HTML page: the file's own head when it came from an HTML file, plus the comments so they survive a round trip */
async function exportHtmlString(opts = {}) {
  if (S.webview) wvPull(true);
  let body = S.doc.kind === "pdf" ? await pdfToHtml() : flowEl.innerHTML;
  { const t = EL("div", { html: body }); $$(".on,.sel", t).forEach(e => { e.classList.remove("on", "sel"); if (!e.className) e.removeAttribute("class"); }); body = t.innerHTML; }   // no transient UI classes in the file
  const comments = Object.fromEntries(Object.entries(S.doc.comments || {}).filter(([id, c]) => c.text || c.replies?.length || body.includes(`data-id="${id}"`)));
  const cj = Object.keys(comments).length ? `\n<script type="application/json" id="lp-comments">${JSON.stringify(comments).replace(/<\//g, "<\\/")}<\/script>` : "";
  const head = S.doc.meta?.head ? S.doc.meta.head.replace(/<title>.*?<\/title>/is, "") + `<title>${esc(S.doc.name)}</title>` : `<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>${esc(S.doc.name)}</title><style>${DEFAULT_HEAD_CSS}</style>`;
  return `<!doctype html>\n<html>\n<head>\n${head}\n</head>\n<body>\n${body}${opts.appendComments === false ? "" : commentsHtml()}${cj}\n</body>\n</html>\n`;
}
async function exportHtml() { download(new Blob([await exportHtmlString()], { type: "text/html" }), baseName(S.doc.name) + ".html"); status("Exported", "ok"); }
/* the text of a PDF as HTML (headings by font size, paragraphs by spacing), with highlights and comments wrapped in */
async function pdfToHtml() {
  if (!S.pdf) return S.pages.map((p, i) => p.img ? `<figure><img src="${p.img.data}" alt="page ${i + 1}"></figure>` : "").join("");
  let html = "";
  for (const entry of S.pages) {
    if (entry.src == null) { if (entry.img) html += `<figure><img src="${entry.img.data}"></figure>`; continue; }
    const tc = await getTextContent({ entry, page: await getPage(entry) }); const items = tc.items.filter(i => i.str != null);
    const sizes = items.map(i => Math.abs(i.transform[3]) || i.height).filter(Boolean).sort((a, b) => a - b), med = sizes[sizes.length >> 1] || 10;
    let lines = [], cur = null;
    for (const it of items) { const y = it.transform[5], sz = Math.abs(it.transform[3]) || it.height; if (!cur || Math.abs(cur.y - y) > sz * .6) { cur = { y, sz, text: "", x: it.transform[4] }; lines.push(cur); } cur.text += (cur.text && !cur.text.endsWith(" ") && !it.str.startsWith(" ") && it.str ? " " : "") + it.str; cur.sz = Math.max(cur.sz, sz); }
    let para = "", paraSz = 0, lastY = null, lastSz = 0;
    const flush = () => { if (!para.trim()) { para = ""; return; } const t = para.replace(/\s+/g, " ").trim(); const tag = paraSz > med * 1.6 ? "h2" : paraSz > med * 1.22 ? "h3" : "p"; html += `<${tag}>${esc(t)}</${tag}>`; para = ""; paraSz = 0; };
    for (const ln of lines) { const gap = lastY == null ? 0 : lastY - ln.y; const newPara = lastY != null && (gap > lastSz * 1.7 || Math.abs(ln.sz - lastSz) > 1.5 || /[.:!?]$/.test(para.trim()) && gap > lastSz * 1.25); if (newPara) flush(); para += (para.endsWith("-") ? "" : " ") + ln.text; paraSz = Math.max(paraSz, ln.sz); lastY = ln.y; lastSz = ln.sz; }
    flush(); html += `<p class="src-note">— page ${S.pages.indexOf(entry) + 1} —</p>`;
  }
  // wrap highlights and comments around their text (spacing may differ, so compare without spaces)
  const box = EL("div", { html }); const tmp = flowEl; let n = 0;
  for (const a of S.doc.annots) { if (!a.quote) continue; const rs = looseRanges(box, a.quote.replace(/\s+/g, "").slice(0, 80)); if (!rs.length) continue; const nodes = []; const w = document.createTreeWalker(rs[0].commonAncestorContainer.nodeType === 3 ? rs[0].commonAncestorContainer.parentNode : rs[0].commonAncestorContainer, NodeFilter.SHOW_TEXT); let t; const r = rs[0]; if (r.startContainer === r.endContainer) { const node = r.startContainer; const after = node.splitText(r.endOffset), mid = node.splitText(r.startOffset); const el = EL(a.text ? "span" : "mark", { class: a.text ? "cmt" : null, "data-id": a.id, style: (a.text ? "--c:" : "--hl:") + (a.color || "#ffe066") }); mid.replaceWith(el); el.append(mid); n++; } }
  return box.innerHTML;
}
/* ---- save back to the file that was opened, or to a new file ---- */
async function verifyHandle(h) { try { if ((await h.queryPermission({ mode: "readwrite" })) === "granted") return true; return (await h.requestPermission({ mode: "readwrite" })) === "granted"; } catch (e) { return false; } }
async function sourceBlob(ext) {
  if (S.webview) wvPull(true);
  const d = S.doc;
  if (ext === "pdf") return new Blob([await exportPdf({ interactive: true, draw: false, summary: false, returnBytes: true })], { type: "application/pdf" });
  if (ext === "md" || ext === "markdown") return new Blob([d.kind === "pdf" ? await pdfToMarkdown() : flowToMarkdown({ embedImages: true })], { type: "text/markdown" });
  if (ext === "html" || ext === "htm") return new Blob([await exportHtmlString({ appendComments: false })], { type: "text/html" });
  if (ext === "txt") return new Blob([d.kind === "pdf" ? (await pdfToMarkdown()).replace(/[#>*=]/g, "") : flowEl.innerText], { type: "text/plain" });
  if (/^(png|jpe?g|webp|gif|bmp)$/.test(ext)) return pageImageBlob(S.pages[0], ext === "png" || ext === "gif" || ext === "bmp" ? "image/png" : "image/jpeg");
  if (ext === "lpdoc") return projectBlob();
  throw new Error("Can't write a ." + ext + " file");
}
async function pdfToMarkdown() { const html = await pdfToHtml(); const keep = flowEl.innerHTML; flowEl.innerHTML = html; try { return flowToMarkdown({ embedImages: true }); } finally { flowEl.innerHTML = keep; } }
async function saveToSource() {
  const d = S.doc; if (!d) return;
  if (!d.srcHandle) return saveAs();
  if (!(await verifyHandle(d.srcHandle))) return toast("No permission to write " + d.srcHandle.name + ". Use Save as… instead.");
  const ext = (d.meta.srcExt || "").toLowerCase();
  if (!S.confirmedOverwrite) {
    const v = await modal(`<h3>Save into ${esc(d.srcHandle.name)}?</h3><p>The file on your computer is replaced with this version${ext === "pdf" ? ", with your highlights and comments inside it" : ""}. Autosave in the browser continues as before.</p><div class="chkrow"><label><input type="checkbox" name="backup" checked> Download a copy of the original first (${esc(baseName(d.srcHandle.name))}-original.${esc(ext)})</label></div><div class="mrow"><button class="btn" data-cancel>Cancel</button><button class="btn primary" data-ok="ok">Save into the file</button></div>`);
    if (!v) return; S.confirmedOverwrite = true;
    if (v.backup) { if (d.src) download(d.src, baseName(d.srcHandle.name) + "-original." + ext); else if (d.orig != null) download(new Blob([d.orig]), baseName(d.srcHandle.name) + "-original." + ext); else if (d.pages?.[0]?.img) { const b = await (await fetch(d.pages[0].img.data)).blob(); download(b, baseName(d.srcHandle.name) + "-original." + ext); } }
  }
  status("Saving to " + d.srcHandle.name + "…");
  try { const blob = await sourceBlob(ext); const w = await d.srcHandle.createWritable(); await w.write(blob); await w.close(); await saveNow(); status("Saved to " + d.srcHandle.name, "ok"); toast("Saved into " + d.srcHandle.name + "."); }
  catch (e) { console.error(e); status("Could not save: " + (e.message || e), "err"); toast("Could not save into the file: " + (e.message || e)); }
}
async function saveAs() {
  const d = S.doc; const isPdf = d.kind === "pdf";
  const v = await modal(`<h3>Save as</h3><div class="opts">
    ${isPdf ? `<label class="opt"><input type="radio" name="fmt" value="pdf" checked><div><b>PDF</b><span>With your highlights and comments live inside (Acrobat, Preview, Zotero)</span></div></label>` : ""}
    <label class="opt"><input type="radio" name="fmt" value="html" ${isPdf ? "" : "checked"}><div><b>HTML</b><span>${isPdf ? "The text with headings, highlights and comments" : "The page as it is now, comments kept inside"}</span></div></label>
    <label class="opt"><input type="radio" name="fmt" value="md"><div><b>Markdown</b><span>==highlights== and comments as footnotes; images embedded</span></div></label>
    ${isPdf ? "" : `<label class="opt"><input type="radio" name="fmt" value="printpdf"><div><b>PDF</b><span>Through the print dialog (choose "Save as PDF" there)</span></div></label>`}
    <label class="opt"><input type="radio" name="fmt" value="lpdoc"><div><b>Project file (.lpdoc)</b><span>Everything, to reopen here later</span></div></label></div>
    <div class="mrow"><button class="btn" data-cancel>Cancel</button><button class="btn primary" data-ok="ok">Save</button></div>`);
  if (!v) return; if (v.fmt === "printpdf") return printFlow();
  const ext = v.fmt, mime = { pdf: "application/pdf", html: "text/html", md: "text/markdown", lpdoc: "application/json" }[ext], name = baseName(d.name) + "." + ext;
  if (window.showSaveFilePicker) {
    try { const h = await showSaveFilePicker({ suggestedName: name, types: [{ description: ext.toUpperCase(), accept: { [mime]: ["." + ext] } }] }); const blob = await sourceBlob(ext); const w = await h.createWritable(); await w.write(blob); await w.close(); if (ext !== "lpdoc") { d.srcHandle = h; d.meta.srcExt = ext; d.meta.srcName = h.name; S.confirmedOverwrite = true; } else { S.fileHandle = h; d.handle = h; } await saveNow(); status("Saved to " + h.name, "ok"); toast("Saved " + h.name + ". Ctrl+S saves there again."); } catch (e) { if (e.name !== "AbortError") toast("Could not save: " + (e.message || e)); }
  } else { download(await sourceBlob(ext), name); }
}
async function pageImageBlob(entry, mime) {
  const page = await getPage(entry), vp = page.getViewport({ scale: 2, rotation: pageRotation(entry, page) }), c = EL("canvas", { width: vp.width, height: vp.height }), ctx = c.getContext("2d");
  await page.render({ canvasContext: ctx, viewport: vp }).promise;
  // draw the marks: the vector layer through an SVG image, text boxes and images directly
  const tmp = { el: EL("div"), entry, page, vp, rendered: true }; drawAnnots(tmp); const svg = tmp.el.querySelector("svg"); svg.setAttribute("xmlns", "http://www.w3.org/2000/svg"); svg.setAttribute("width", vp.width); svg.setAttribute("height", vp.height);
  try { const im = await loadImage("data:image/svg+xml;charset=utf-8," + encodeURIComponent(svg.outerHTML.replace(/var\(--page-bg\)/g, "#fff"))); ctx.drawImage(im, 0, 0); } catch (e) { console.warn("svg layer", e); }
  for (const a of annotsOf(entry.id)) {
    const r = a.rect ? pdfRectToPx(tmp, a.rect) : null;
    if (a.t === "image") { try { ctx.drawImage(await loadImage(a.data), r[0], r[1], r[2] - r[0], r[3] - r[1]); } catch (e) { /* skip */ } }
    else if (a.t === "text" || a.t === "edit") { if (a.t === "edit") { ctx.fillStyle = "#fff"; ctx.fillRect(r[0] - 1, r[1] - 1, r[2] - r[0] + 2, r[3] - r[1] + 2); } ctx.fillStyle = a.color || "#111"; ctx.font = `${a.bold ? "bold " : ""}${a.size * 2}px ${a.font === "serif" ? "serif" : a.font === "monospace" ? "monospace" : "sans-serif"}`; ctx.textBaseline = "top"; (a.t === "edit" ? a.text : (a.body || "")).split("\n").forEach((ln, i) => ctx.fillText(ln, r[0] + (a.t === "edit" ? 0 : 6), r[1] + (a.t === "edit" ? (r[3] - r[1] - a.size * 2) / 2 : 4) + i * a.size * 2.6)); }
  }
  return new Promise(res => c.toBlob(res, mime, .92));
}
function commentsHtml() { const items = Object.entries(S.doc.comments).filter(([id, c]) => c.text || c.replies?.length); if (!items.length) return ""; return `<hr><h2>Comments</h2><ol>${items.map(([id, c]) => `<li><em>${esc($(`[data-id="${id}"]`, flowEl)?.textContent.slice(0, 120) || "")}</em><br>${esc(c.text || "")}${(c.replies || []).map(r => `<br>— ${esc(r.text)}`).join("")}</li>`).join("")}</ol>`; }
function printFlow() {
  if (S.webview) { wvPull(true); const d = wvDoc(), extra = d.createElement("div"); extra.innerHTML = commentsHtml(); d.body.append(extra); wvFrame().contentWindow.print(); setTimeout(() => extra.remove(), 1000); return; } const cs = $$(".cmt[data-id]", flowEl); let n = 0; const seen = new Map(); cs.forEach(el => { const c = S.doc.comments[el.dataset.id]; if (!c?.text) return; if (!seen.has(el.dataset.id)) seen.set(el.dataset.id, ++n); el.dataset.n = seen.get(el.dataset.id); }); const extra = EL("div", { class: "print-only", html: commentsHtml() }); flowEl.append(extra); const st = EL("style", {}, `@media print{.cmt[data-n]::after{content:" [" attr(data-n) "]";font-size:.75em;color:#555}}`); document.head.append(st); window.print(); setTimeout(() => { extra.remove(); st.remove(); }, 1000); }
async function exportMenu(anchor) {
  const pdf = S.doc.kind === "pdf";
  menu([
    { head: "Export as" },
    pdf ? { label: "PDF…", icon: "i-export", sub: "Highlights and comments live inside; opens in Acrobat, Preview, Zotero", fn: exportPdfDialog } : { label: "PDF (print)…", icon: "i-export", sub: "Choose 'Save as PDF' in the print dialog; comments listed at the end", fn: printFlow },
    { label: "HTML", icon: "i-web", sub: pdf ? "The text with headings, your highlights and comments" : "The page as it is now; comments kept inside", fn: exportHtml },
    { label: "Markdown", icon: "i-doc", sub: pdf ? "The text with ==highlights== and comments as footnotes" : "==highlights==, comments as footnotes, images linked", fn: () => exportMarkdown({ text: true }) },
    ...(pdf ? [{ label: "Markdown of the notes only", sub: "Highlights as quotes with your comments, by page", fn: () => exportMarkdown() }] : [{ label: "Markdown with images inside", sub: "Larger file, but one file", fn: () => exportMarkdown({ embedImages: true }) }]),
    { label: "Copy notes", fn: () => { navigator.clipboard.writeText(notesMarkdown()); toast("Copied the notes as Markdown."); } },
    { sep: true }, { label: "Project file (.lpdoc)", icon: "i-save", sub: "Everything, to reopen here later", fn: saveProjectFile }
  ], anchor, { right: true });
}
async function exportPdfDialog() {
  const v = await modal(`<h3>Export PDF</h3><p>Comments, highlights and the other marks are written into the PDF.</p><div class="opts">
    <label class="opt"><input type="radio" name="mode" value="interactive" checked><div><b>Live comments</b><span>Highlights and comment bubbles stay editable in Acrobat, Preview, Zotero and most readers. Drawings, text boxes, images and text edits are drawn in.</span></div></label>
    <label class="opt"><input type="radio" name="mode" value="flat"><div><b>Flattened</b><span>Everything is drawn into the page, like a printout. Comment bubbles become small notes in the margin.</span></div></label></div>
    <div class="chkrow"><label><input type="checkbox" name="summary" checked> Add a page at the end listing every highlight and comment</label></div>
    <div class="mrow"><button class="btn" data-cancel>Cancel</button><button class="btn primary" data-ok="ok">Export</button></div>`);
  if (!v) return; try { await exportPdf({ interactive: v.mode === "interactive", draw: false, summary: v.summary }); } catch (e) { console.error(e); status("Export failed", "err"); toast("Export failed: " + (e.message || e)); }
}
function saveMenu(anchor) {
  const h = S.doc.srcHandle;
  menu([
    h ? { label: "Save into " + h.name, icon: "i-save", k: "Ctrl+S", sub: "Replaces the file you opened with this version", fn: saveToSource } : { label: "Save to a file…", icon: "i-save", k: "Ctrl+S", sub: window.showSaveFilePicker ? "Pick where; Ctrl+S saves there from then on" : "Downloads the file", fn: saveAs },
    ...(h ? [{ label: "Save as…", sub: "A new file, in PDF, HTML or Markdown", fn: saveAs }] : []),
    { label: "Save project file (.lpdoc)", sub: "Everything in one file to keep, move or share", fn: saveProjectFile },
    { label: S.fileHandle ? "Autosaving to " + S.fileHandle.name : "Autosave to a file on this computer…", sub: S.fileHandle ? "Click to pick another file" : "Pick a file once; it is kept up to date as you work", fn: chooseAutosaveFile },
    { sep: true },
    { label: "Rename", fn: () => { $("#docTitle").focus(); $("#docTitle").select(); } },
    ...(S.doc.meta?.sourceUrl && /^https?:/i.test(S.doc.meta.sourceUrl) ? [{ label: "Load the page fresh from the web", sub: "Opens the address again as a new copy; this one stays in your list", fn: () => openUrl(S.doc.meta.sourceUrl, true) }] : []),
    ...(S.doc.kind === "flow" && S.doc.origHtml ? [{ label: "Revert to the original text", sub: "Undoes every edit, keeps nothing you changed", fn: async () => { if (await modal(`<h3>Revert?</h3><p>All edits, highlights and comments in this document are removed.</p><div class="mrow"><button class="btn" data-cancel>Keep</button><button class="btn danger" data-ok="ok">Revert</button></div>`)) { flowEl.innerHTML = S.doc.origHtml; S.doc.comments = {}; flowChanged(); layoutMargin(); refreshNotes(); } } }] : []),
    { label: "Remove from this browser", danger: true, fn: async () => { if (await modal(`<h3>Remove "${esc(S.doc.name)}"?</h3><p>Removed from this browser's saved list. Project files you saved are not affected.</p><div class="mrow"><button class="btn" data-cancel>Keep</button><button class="btn danger" data-ok="ok">Remove</button></div>`)) { const id = S.doc.id; S.dirty = false; S.doc = null; await DB.del("docs", id); goHome(); } } }
  ], anchor, { right: true });
}

/* ---------- tools, find, read aloud, themes, PDF → document, start-up ---------- */
function setTool(t) {
  S.tool = t; $$("#pdfTools .tool").forEach(b => b.classList.toggle("on", b.dataset.tool === t));
  work.className = work.className.replace(/\btool-\S+/g, "").trim() + " tool-" + t;
  if (t !== "select") { S.sel = null; redrawAllAnnots(); } showCtx(); closeSelPop();
}
function buildSwatches() { const s = $("#swatches"); s.innerHTML = ""; COLORS.forEach(([c, n]) => s.append(EL("i", { class: "sw" + (S.color === c ? " on" : ""), style: "background:" + c, title: n, onclick: () => { S.color = c; Prefs.set("color", c); buildSwatches(); if (S.sel) { const a = annotById(S.sel); if (a && (a.t === "hl" || a.t === "ul" || a.t === "st" || a.t === "area" || a.t === "note")) { a.color = c; redrawAllAnnots(); changed(); } } } }))); }

/* ---- find (CSS highlights, so the text itself is untouched) ---- */
S.findQuery = ""; const findHL = typeof Highlight !== "undefined" && CSS.highlights ? { all: new Highlight(), cur: new Highlight() } : null;
if (findHL) { CSS.highlights.set("find", findHL.all); CSS.highlights.set("findcur", findHL.cur); document.head.append(EL("style", {}, "::highlight(find){background:rgba(255,224,102,.6)} ::highlight(findcur){background:rgba(255,140,0,.8);color:#000}")); }
function textRanges(root, q, caseSens) {
  const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, { acceptNode: n => n.parentElement.closest(".endOfContent,.pnum,.annots,.bubble") ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT }); const nodes = []; let s = "", n;
  while ((n = w.nextNode())) { nodes.push({ n, start: s.length }); s += n.data; if (root.classList?.contains("textLayer")) s += " "; }
  const hay = caseSens ? s : s.toLowerCase(), needle = caseSens ? q : q.toLowerCase(), out = []; let i = 0;
  const locate = pos => { let lo = 0, hi = nodes.length - 1; while (lo < hi) { const m = (lo + hi + 1) >> 1; if (nodes[m].start <= pos) lo = m; else hi = m - 1; } return nodes[lo]; };
  while ((i = hay.indexOf(needle, i)) !== -1) { const a = locate(i), b = locate(i + needle.length - 1); const r = document.createRange(); try { r.setStart(a.n, i - a.start); r.setEnd(b.n, Math.min(b.n.length, i + needle.length - b.start)); out.push(r); } catch (e) { /* across a gap */ } i += needle.length; }
  return out;
}
async function runFind() {
  const q = $("#findIn").value.trim(), cs = $("#findCase").checked; S.findQuery = q; findHL?.all.clear(); findHL?.cur.clear(); S.findRanges = []; S.findIdx = -1;
  const res = $("#findRes"), sum = $("#findSum"); res.innerHTML = ""; sum.textContent = ""; if (!q) return;
  if (S.doc.kind === "flow") {
    const rs = textRanges(flowEl, q, cs); S.findRanges = rs.map(r => ({ r })); rs.forEach(r => findHL?.all.add(r)); sum.textContent = rs.length + (rs.length === 1 ? " match" : " matches");
    rs.slice(0, 200).forEach((r, i) => { const t = r.startContainer.data, a = Math.max(0, r.startOffset - 30); res.append(EL("button", { class: "fr", onclick: () => gotoFind(i) }, EL("span", {}, t.slice(a, r.startOffset)), EL("mark", {}, t.slice(r.startOffset, r.startOffset + q.length)), EL("span", {}, t.slice(r.startOffset + q.length, r.startOffset + q.length + 40)))); });
    if (rs.length) gotoFind(0); return;
  }
  let total = 0; const hits = [];
  for (let i = 0; i < S.pages.length; i++) { const txt = await pageText(S.pages[i]); const hay = cs ? txt : txt.toLowerCase(), nd = cs ? q : q.toLowerCase(); let k = 0; while ((k = hay.indexOf(nd, k)) !== -1) { hits.push({ page: i + 1, pos: k, ctx: txt.slice(Math.max(0, k - 30), k + q.length + 40), q }); total++; k += nd.length; if (total > 500) break; } if (total > 500) break; }
  S.findRanges = hits; sum.textContent = total + (total === 1 ? " match" : " matches") + (total > 500 ? " (first 500)" : "");
  hits.slice(0, 300).forEach((h, i) => res.append(EL("button", { class: "fr", onclick: () => gotoFind(i) }, EL("span", { class: "pg" }, "p." + h.page), EL("span", {}, h.ctx.slice(0, h.pos - Math.max(0, h.pos - 30)).replace(/\s+/g, " ")), EL("mark", {}, q), EL("span", {}, h.ctx.slice(h.pos - Math.max(0, h.pos - 30) + q.length).replace(/\s+/g, " ")))));
  for (const v of S.views.values()) if (v.rendered) highlightFindOnPage(v);
  if (hits.length) gotoFind(0);
}
function highlightFindOnPage(v) { if (!findHL || !S.findQuery) return; const tl = v.el.querySelector(".textLayer"); if (!tl) return; textRanges(tl, S.findQuery, $("#findCase").checked).forEach(r => findHL.all.add(r)); }
async function gotoFind(i) {
  if (!S.findRanges.length) return; S.findIdx = (i + S.findRanges.length) % S.findRanges.length; $$(".fr").forEach((b, k) => b.classList.toggle("on", k === S.findIdx));
  const h = S.findRanges[S.findIdx]; findHL?.cur.clear();
  if (S.doc.kind === "flow") { findHL?.cur.add(h.r); const el = h.r.startContainer.parentElement; el.scrollIntoView({ block: "center" }); return; }
  goToPage(h.page); const v = [...S.views.values()][h.page - 1]; await renderPage(v); await new Promise(r => setTimeout(r, 60));
  const tl = v.el.querySelector(".textLayer"); if (!tl) return; const rs = textRanges(tl, S.findQuery, $("#findCase").checked); const same = S.findRanges.filter(x => x.page === h.page), k = same.indexOf(h); const r = rs[k] || rs[0]; if (r) { findHL?.cur.add(r); const rc = r.getBoundingClientRect(), vr = viewer.getBoundingClientRect(); if (rc.top < vr.top + 40 || rc.bottom > vr.bottom - 40) viewer.scrollTop += rc.top - vr.top - viewer.clientHeight / 2; }
}
function replaceFind(all) {
  if (S.doc.kind !== "flow") return; const rep = $("#replIn").value; const list = all ? S.findRanges.map(x => x.r) : [S.findRanges[Math.max(0, S.findIdx)]?.r].filter(Boolean); if (!list.length) return;
  for (const r of list.slice().reverse()) { r.deleteContents(); r.insertNode(document.createTextNode(rep)); } flowEl.normalize(); flowChanged(); pushHistory(); runFind();
}

/* ---- read aloud ---- */
async function speak(text) {
  if (!("speechSynthesis" in window)) return toast("This browser can't read aloud.");
  if (S.speaking) { speechSynthesis.cancel(); S.speaking = false; work.classList.remove("speaking"); if (!text) return; }
  if (!text) { const sel = getSelection(); text = sel && !sel.isCollapsed ? sel.toString() : S.doc.kind === "flow" ? flowEl.innerText : await pageText(S.pages[S.current - 1]); }
  if (!text?.trim()) return toast("Nothing to read on this page.");
  const u = new SpeechSynthesisUtterance(text.replace(/\s+/g, " ").slice(0, 20000)); u.rate = 1.05; u.lang = /[가-힣]/.test(text) ? "ko-KR" : "en-US";
  u.onend = u.onerror = () => { S.speaking = false; work.classList.remove("speaking"); }; S.speaking = true; work.classList.add("speaking"); speechSynthesis.speak(u);
}
/* ---- themes ---- */
function setTheme(t) { if (t === "auto") delete document.documentElement.dataset.theme; else document.documentElement.dataset.theme = t; Prefs.set("theme", t); if (S.doc?.kind === "pdf") redrawAllAnnots(); }
function themeMenu(anchor) { const cur = document.documentElement.dataset.theme || "auto"; menu([{ head: "Reading colours" }, ...[["auto", "Match the system"], ["light", "Light"], ["sepia", "Sepia (paper)"], ["dark", "Dark"]].map(([k, l]) => ({ label: l, on: cur === k, fn: () => setTheme(k) })), { sep: true }, { head: "Document font" }, ...[["serif", "Serif (book)"], ["sans", "Sans-serif"], ["mono", "Monospace"]].map(([k, l]) => ({ label: l, on: flowEl.dataset.font === k, fn: () => { flowEl.dataset.font = k; Prefs.set("flowFont", k); } }))], anchor, { right: true }); }
function zoomMenu(anchor) { const flow = S.doc?.kind === "flow", cur = flow ? (S.flowZoom || 1) : S.scale; menu([{ label: flow ? "Normal size" : "Fit width", on: S.zoomMode === "width", fn: () => setZoom("width") }, ...(flow ? [] : [{ label: "Fit page", on: S.zoomMode === "page", fn: () => setZoom("page") }]), { sep: true }, ...[50, 75, 100, 125, 150, 200, 300].map(z => ({ label: z + "%", on: S.zoomMode === "custom" && Math.round(cur * 100) === z, fn: () => setZoom("custom", z / 100) }))], anchor); }

/* ---- turn a PDF into an editable document: text with headings, highlights and comments carried over ---- */
async function convertToFlow() {
  if (!S.pdf) return toast("Only a real PDF can be converted; this document is an image.");
  status("Reading the text…"); const html = await pdfToHtml();
  const comments = {}; let carried = 0; for (const a of S.doc.annots) if (a.quote && html.includes(`data-id="${a.id}"`)) { comments[a.id] = { at: a.at, color: a.color, t: a.text ? "cmt" : "mark", text: a.text || "", replies: a.replies || [] }; carried++; }
  const d = newDoc("flow", baseName(S.doc.name) + " (editable)", { html, comments, meta: { from: S.doc.id, sourceUrl: S.doc.meta?.sourceUrl || "" } });
  await openDoc(d); S.doc.origHtml = html; layoutMargin(); refreshNotes();
  toast(`Made an editable copy${carried ? ` and carried ${carried} note${carried === 1 ? "" : "s"} over` : ""}. Figures are not copied; place them with the image button.`);
}

/* find text ignoring spaces: returns ranges in the live document */
function looseRanges(root, q) {
  const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT); const map = []; let s = "", n;
  while ((n = w.nextNode())) { for (let i = 0; i < n.data.length; i++) { const ch = n.data[i]; if (/\s/.test(ch)) continue; s += ch.toLowerCase(); map.push([n, i]); } }
  const out = []; let i = 0; const needle = q.toLowerCase(); if (!needle) return out;
  while ((i = s.indexOf(needle, i)) !== -1) { const [n1, o1] = map[i], [n2, o2] = map[i + needle.length - 1]; const r = document.createRange(); r.setStart(n1, o1); r.setEnd(n2, o2 + 1); out.push(r); i += needle.length; }
  return out;
}
/* ---- extension hooks: a captured page or a URL handed over by the extension ---- */
async function extStart() {
  const q = new URLSearchParams(location.search);
  if (q.get("cap") && IS_EXT) { const st = await chrome.storage.local.get(q.get("cap")); const cap = st[q.get("cap")]; if (cap) { chrome.storage.local.remove(q.get("cap")); if (cap.selection) return openDoc(newDoc("flow", (cap.title || "Selection").slice(0, 80), { html: cleanHtml(cap.selection, cap.url), meta: { sourceUrl: cap.url } })); return openHtmlDoc(cap.title || "page", cap.html, cap.url, true); } }
  if (q.get("url")) { $("#urlInput").value = q.get("url"); return openUrl(q.get("url")); }
  if (q.get("file") && IS_EXT) { try { const r = await fetch(q.get("file")); return openPdfDoc(newDoc("pdf", decodeURIComponent(q.get("file").split("/").pop()), { src: await r.blob(), meta: { sourceUrl: q.get("file") } })); } catch (e) { toast("Could not read the file: " + e.message); } }
}

/* ---- wiring ---- */
function bindUI() {
  document.addEventListener("click", e => {
    const b = e.target.closest("[data-act]"); if (!b) return; const act = b.dataset.act;
    const A = {
      openFile: async () => {
        if (window.showOpenFilePicker) { try { const hs = await showOpenFilePicker({ multiple: true, types: [{ description: "Documents", accept: { "application/pdf": [".pdf"], "text/markdown": [".md", ".markdown"], "text/html": [".html", ".htm"], "text/plain": [".txt"], "image/*": [".png", ".jpg", ".jpeg", ".webp", ".gif"], "application/json": [".lpdoc"] } }] }); for (const h of hs) await openFile(await h.getFile(), h); } catch (e) { if (e.name !== "AbortError") console.warn(e); } return; }
        const i = $("#fileIn"); i.value = ""; i.click();
      },
      pasteNew, newBlank: () => openDoc(newDoc("flow", "Untitled", { html: "<p><br></p>" })), home: goHome,
      undo, redo, saveMenu: () => saveMenu(b), exportMenu: () => exportMenu(b),
      toggleLeft: () => { $("#left").classList.toggle("closed"); Prefs.set("left", !$("#left").classList.contains("closed")); }, toggleRight: () => { $("#right").classList.toggle("closed"); Prefs.set("right", !$("#right").classList.contains("closed")); },
      prevPage: () => goToPage(S.current - 1), nextPage: () => goToPage(S.current + 1), zoomIn: () => zoomBy(1.2), zoomOut: () => zoomBy(1 / 1.2), zoomMenu: () => zoomMenu(b),
      search: () => { showLeft("find"); $("#findIn").focus(); $("#findIn").select(); }, speak: () => speak(), themeMenu: () => themeMenu(b), convertFlow: convertToFlow,
      inlineCode: () => { const sel = getSelection(); if (!sel || sel.isCollapsed) return; insertHtml("<code>" + esc(sel.toString()) + "</code>"); }, checklist: toggleChecklist, alignMenu: () => alignMenu(b), link: linkPrompt,
      insertImage: () => pickImage(src => insertHtml(`<figure><img src="${src}"><figcaption></figcaption></figure><p><br></p>`)), tableMenu: () => tableMenu(b), flowHighlight, flowComment,
      webView: enterWebView,
      replaceOne: () => replaceFind(false), replaceAll: () => replaceFind(true), copyNotes: () => { navigator.clipboard.writeText(notesMarkdown()); toast("Copied the notes as Markdown."); }
    };
    if (A[act]) { if (b.closest("#flowTools")) e.preventDefault(); A[act](); }
  });
  $$("#flowTools [data-cmd]").forEach(b => b.addEventListener("pointerdown", e => { e.preventDefault(); cmd(b.dataset.cmd); }));
  $("#fileIn").addEventListener("change", e => { [...e.target.files].forEach(openFile); });
  $("#blockSel").addEventListener("change", e => setBlock(e.target.value)); $("#textColor").addEventListener("input", e => cmd("foreColor", e.target.value));
  $$("#pdfTools .tool").forEach(b => b.addEventListener("click", () => setTool(b.dataset.tool)));
  $("#pageIn").addEventListener("change", e => goToPage(+e.target.value || 1)); $("#pageIn").addEventListener("keydown", e => { if (e.key === "Enter") e.target.blur(); });
  $$(".ltab").forEach(t => t.addEventListener("click", () => showLeft(t.dataset.ltab)));
  $("#findForm").addEventListener("submit", e => { e.preventDefault(); if (S.findQuery === $("#findIn").value.trim() && S.findRanges.length) gotoFind(S.findIdx + 1); else runFind(); });
  $("#findIn").addEventListener("input", debounce(runFind, 300));
  $("#noteFilter").addEventListener("change", refreshNotes); $("#noteSearch").addEventListener("input", debounce(refreshNotes, 200));
  $("#docTitle").addEventListener("change", e => { if (S.doc) { S.doc.name = e.target.value.trim() || "Untitled"; document.title = S.doc.name + " · Doc Reader"; markDirty(); } });
  $("#docTitle").addEventListener("keydown", e => { if (e.key === "Enter") e.target.blur(); e.stopPropagation(); });
  $("#urlForm").addEventListener("submit", e => { e.preventDefault(); const u = $("#urlInput").value.trim(); if (u) openUrl(u); });
  // text selection → marks (PDF)
  pagesEl.addEventListener("pointerdown", e => { const tl = e.target.closest(".textLayer"); if (tl) tl.querySelector(".endOfContent")?.classList.add("active"); if (S.sel && !S.editingText && !e.target.classList.contains("drawlayer") && ["select", "erase", "highlight", "underline", "strike", "edit"].includes(S.tool) && !e.target.closest(".mk,.anode,.bubble,.editbox")) { S.sel = null; redrawAllAnnots(); showCtx(); } });
  // toolbar buttons must not take the selection away from the editor
  $$("#flowTools button, #tbar button[data-act=flowHighlight], #tbar button[data-act=flowComment]").forEach(b => b.addEventListener("pointerdown", e => e.preventDefault()));
  document.addEventListener("pointerup", e => {
    $$(".textLayer .endOfContent.active").forEach(x => x.classList.remove("active"));
    if (S.doc?.kind !== "pdf") return; const t = S.tool;
    setTimeout(() => { if (t === "highlight") markSelection("hl"); else if (t === "underline") markSelection("ul"); else if (t === "strike") markSelection("st"); else if (t === "select" && e.target.closest(".textLayer")) showSelPop(); }, 10);
  });
  document.addEventListener("selectionchange", () => { const s = getSelection(); if (!s || s.isCollapsed) closeSelPop(); });
  bindEditTool(); bindFlow();
  // drag and drop anywhere
  let dragN = 0; document.addEventListener("dragenter", e => { if ([...e.dataTransfer.types].includes("Files")) { dragN++; $("#dropOverlay").hidden = false; } }); document.addEventListener("dragleave", () => { if (--dragN <= 0) { dragN = 0; $("#dropOverlay").hidden = true; } });
  document.addEventListener("dragover", e => { if ([...e.dataTransfer.types].includes("Files")) e.preventDefault(); });
  document.addEventListener("drop", async e => { dragN = 0; $("#dropOverlay").hidden = true; const fs = [...e.dataTransfer.files]; if (!fs.length) return; if (e.target.closest("#flow") && fs.every(f => f.type.startsWith("image/"))) return; e.preventDefault();
    const items = [...e.dataTransfer.items]; for (let k = 0; k < fs.length; k++) { let h = null; try { h = items[k]?.getAsFileSystemHandle ? await items[k].getAsFileSystemHandle() : null; } catch (er) { /* no handle */ } await openFile(fs[k], h && h.kind === "file" ? h : null); } });
  $("#drop").addEventListener("keydown", e => { if (e.key === "Enter") $("[data-act=openFile]").click(); });
  // keyboard
  document.addEventListener("keydown", e => {
    const inEdit = e.target.closest("input,textarea,[contenteditable=true]"), mod = e.ctrlKey || e.metaKey;
    if (mod && e.key.toLowerCase() === "s") { e.preventDefault(); if (S.doc) { if (e.shiftKey) saveAs(); else saveToSource(); } return; }
    if (mod && e.key.toLowerCase() === "f" && S.doc) { e.preventDefault(); showLeft("find"); $("#findIn").focus(); $("#findIn").select(); return; }
    if (mod && e.key.toLowerCase() === "z" && !e.shiftKey && S.doc) { if (inEdit && e.target.closest("#pop,.editbox,.textbox")) return; e.preventDefault(); undo(); return; }
    if (mod && (e.key.toLowerCase() === "y" || (e.key.toLowerCase() === "z" && e.shiftKey)) && S.doc) { e.preventDefault(); redo(); return; }
    if (mod && e.key.toLowerCase() === "k" && S.doc?.kind === "flow") { e.preventDefault(); linkPrompt(); return; }
    if (mod && e.shiftKey && e.key.toLowerCase() === "h" && S.doc?.kind === "flow") { e.preventDefault(); flowHighlight(); return; }
    if (mod && e.altKey && e.key.toLowerCase() === "m" && S.doc?.kind === "flow") { e.preventDefault(); flowComment(); return; }
    if (mod && (e.key === "=" || e.key === "+") && S.doc) { e.preventDefault(); zoomBy(1.2); return; } if (mod && e.key === "-" && S.doc) { e.preventDefault(); zoomBy(1 / 1.2); return; } if (mod && e.key === "0" && S.doc) { e.preventDefault(); setZoom("width"); return; }
    if (inEdit || mod || e.altKey || !S.doc) return;
    if (S.doc.kind === "pdf") {
      const keys = { v: "select", h: "highlight", u: "underline", k: "strike", a: "area", c: "comment", t: "text", d: "pen", r: "shape", i: "image", e: "edit", x: "erase" }; const k = e.key.toLowerCase();
      if (keys[k]) { setTool(keys[k]); return; }
      if (e.key === "ArrowRight" || e.key === "PageDown") { goToPage(S.current + 1); e.preventDefault(); } if (e.key === "ArrowLeft" || e.key === "PageUp") { goToPage(S.current - 1); e.preventDefault(); }
      if ((e.key === "Delete" || e.key === "Backspace") && S.sel) { removeAnnot(S.sel); e.preventDefault(); }
      if (e.key === "Escape") { if (S.sel) { S.sel = null; redrawAllAnnots(); showCtx(); } else setTool("select"); }
    }
    if (e.key === "Escape" && S.speaking) speak();
  });
  viewer.addEventListener("wheel", e => { if ((e.ctrlKey || e.metaKey) && S.doc) { e.preventDefault(); zoomBy(e.deltaY < 0 ? 1.1 : 1 / 1.1); } }, { passive: false });
  addEventListener("resize", debounce(() => { if (S.doc?.kind === "pdf" && S.zoomMode === "width") setZoom("width"); if (S.doc?.kind === "flow") layoutMargin(); }, 200));
  addEventListener("beforeunload", e => { if (S.dirty && S.doc) { saveNow(); } });
  document.addEventListener("visibilitychange", () => { if (document.hidden && S.dirty) saveNow(); });
}
function showLeft(tab) { $("#left").classList.remove("closed"); $$(".ltab").forEach(t => t.classList.toggle("on", t.dataset.ltab === tab)); $$(".lpane").forEach(p => p.classList.toggle("on", p.dataset.lpane === tab)); Prefs.set("ltab", tab); }

async function init() {
  await Prefs.load(); S.color = Prefs.get("color", COLORS[0][0]); buildSwatches();
  const th = Prefs.get("theme", "auto"); if (th !== "auto") document.documentElement.dataset.theme = th;
  if (Prefs.get("left", true) === false) $("#left").classList.add("closed"); if (Prefs.get("right", true) === false) $("#right").classList.add("closed"); showLeft(Prefs.get("ltab", "pages"));
  bindUI(); bindWvBar(); bindLightbox(); listRecent();
  $("#webLayout").value = Prefs.get("webLayout", "original"); $("#webLayout").addEventListener("change", e => Prefs.set("webLayout", e.target.value));
  if (IS_EXT) { $("#extCard").hidden = true; $$("a[href^='https://labpotato']").forEach(a => a.target = "_blank"); }
  // pdf.js worker: from the file next to this page in the extension, or from the inline copy on the website
  try { if (window.PDF_WORKER_SRC) pdfjsLib.GlobalWorkerOptions.workerSrc = window.PDF_WORKER_SRC; else { const src = document.getElementById("pdfworker")?.textContent; if (src) pdfjsLib.GlobalWorkerOptions.workerPort = new Worker(URL.createObjectURL(new Blob([src.replace(/<\\\/script/g, "<\/script")], { type: "text/javascript" }))); } } catch (e) { console.warn("worker", e); }
  const started = await extStart();
  if (!started && !IS_EXT) { const q = new URLSearchParams(location.search); if (q.get("url")) openUrl(q.get("url")); }
  if (navigator.storage?.persist) navigator.storage.persist().catch(() => {});
}
document.addEventListener("DOMContentLoaded", init);
/* ---------- Doc Reader AI editor: ask an AI about a selection, get the answer back as tracked changes ----------
   Runs inside Doc Reader's scope (inserted by build.py), so it uses S, flowEl, $, EL, modal, menu, toast...
   One chat per document lives in S.doc.ai: the thread sent to the AI (append-only), the changes it proposed,
   and the log shown in the chat panel. A change in the text is <span class="ai-chg" data-ai="id">; its
   original HTML and every suggestion are kept in S.doc.ai.changes[id], so undo, reload and reject all work. */

const AI_PROVIDERS = {
  demo: { label: "Demo", sub: "No key, no AI: canned edits made in the browser, to try the tools" },
  claude: { label: "Claude", sub: "Anthropic API, your own key", def: "claude-opus-5-5" },
  openai: { label: "OpenAI", sub: "OpenAI API, your own key", base: "https://api.openai.com/v1" },
  gemini: { label: "Gemini", sub: "Google AI Studio key (OpenAI-compatible endpoint)", base: "https://generativelanguage.googleapis.com/v1beta/openai" },
  custom: { label: "Other", sub: "Any OpenAI-compatible server: OpenRouter, Ollama, LM Studio…" }
};
const AI_FALLBACK_MODELS = new Set(["claude-opus-5-5", "claude-fable-5-1", "claude-sonnet-5-5"]);   // server-side refusal fallbacks
/* Claude models: id, name, what it is for, price per million tokens in / out (Anthropic API) */
const CLAUDE_MODELS = [
  ["claude-opus-5-5", "Opus 5.5", "Default: the best everyday choice", "$4 / $20"],
  ["claude-fable-5-1", "Fable 5.1", "Most capable; slower and dearer", "$10 / $50"],
  ["claude-sonnet-5-5", "Sonnet 5.5", "Fast and capable", "$2 / $10"],
  ["claude-haiku-5-5", "Haiku 5.5", "Fastest and cheapest, for quick fixes", "$0.10 / $0.50"],
  ["claude-fable-5", "Fable 5", "Earlier generation", "$10 / $50"],
  ["claude-opus-5", "Opus 5", "Earlier generation", "$5 / $25"],
  ["claude-sonnet-5", "Sonnet 5", "Earlier generation", "$2 / $10"],
  ["claude-opus-4-8", "Opus 4.8", "Earlier generation", "$5 / $25"],
  ["claude-opus-4-7", "Opus 4.7", "Earlier generation", "$5 / $25"],
  ["claude-opus-4-6", "Opus 4.6", "Earlier generation", "$5 / $25"],
  ["claude-sonnet-4-6", "Sonnet 4.6", "Earlier generation", "$3 / $15"],
  ["claude-haiku-4-5", "Haiku 4.5", "Earlier generation", "$1 / $5"]
];
const claudeName = id => (CLAUDE_MODELS.find(m => m[0] === id) || [])[1] || id;
const NO_EFFORT = new Set(["claude-haiku-4-5"]), NO_XHIGH = new Set(["claude-opus-4-6", "claude-sonnet-4-6"]);
const AI_PRESETS = ["Better logical flow", "Make it more concise", "More formal academic tone", "Fix grammar and spelling", "Clarify the meaning", "Add appropriate hedging", "Strengthen the argument", "Simplify for a broad audience"];
const AI_SYSTEM = `You are a meticulous academic editor working with the author of a scientific manuscript, inside their editor. During this conversation you receive the manuscript (sent once, and again when it has changed a lot) and requests about passages the author has selected, each with the paragraph around it.

For a request about a selected passage:
- Rewrite only the selected passage. The paragraph is context: your text replaces the selection in place, so it must join the text before and after it (capitalisation, spacing and punctuation at both ends).
- Follow the instruction. Keep the scientific meaning, data, numbers, units, statistics, citations and reference markers, gene, protein and species nomenclature, and abbreviations defined elsewhere in the manuscript. Do not invent findings or references.
- Keep the author's voice, spelling variant (British or American) and terminology, consistent with the rest of the manuscript.
- The passage may contain the inline tags <i>, <b>, <sup>, <sub> and <code>. Keep them where they belong; use no other markup and no Markdown.
- Reply in exactly this form:
<revision>the new passage</revision>
<note>one short sentence on what you changed and why</note>
- If the passage is best left as it is, return it unchanged and say why in the note.
- When the author asks you to redo one marked part of your earlier version, put only the new text for that part in <revision>, written to fit between the text before and after it.

For a message marked QUESTION, answer briefly in plain prose, with reference to the manuscript, and do not use the revision form.`;

/* ---- settings and keys ---- */
const AIKeys = { mem: {} };
function aiCfg() { const c = Prefs.get("ai", {}); return { provider: c.provider || "demo", models: c.models || {}, base: c.base || "", effort: c.effort || "", remember: !!c.remember, presets: c.presets?.length ? c.presets : AI_PRESETS }; }
function aiSetCfg(c) { Prefs.set("ai", c); }
function aiModel(c = aiCfg()) { return c.models[c.provider] || AI_PROVIDERS[c.provider]?.def || ""; }
function aiBase(c = aiCfg()) { return (c.provider === "custom" ? c.base : AI_PROVIDERS[c.provider]?.base || "").replace(/\/+$/, ""); }
function aiKey(p) {
  if (AIKeys.mem[p]) return AIKeys.mem[p];
  try { const k = sessionStorage.getItem("lpw-key-" + p); if (k) return (AIKeys.mem[p] = k); } catch (e) { /* storage blocked */ }
  return (Prefs.get("aiKeys", {}) || {})[p] || "";
}
function aiSetKey(p, k, remember) {
  AIKeys.mem[p] = k;
  try { if (k) sessionStorage.setItem("lpw-key-" + p, k); else sessionStorage.removeItem("lpw-key-" + p); } catch (e) { /* storage blocked */ }
  const all = { ...(Prefs.get("aiKeys", {}) || {}) }; if (remember && k) all[p] = k; else delete all[p]; Prefs.set("aiKeys", all);
}
function aiWho(c = aiCfg()) { return c.provider === "demo" ? "Demo mode (no AI)" : AI_PROVIDERS[c.provider].label + (aiModel(c) ? " · " + (c.provider === "claude" ? claudeName(aiModel(c)) : aiModel(c)) : ""); }
/* quick switch of model from the chat panel or the request box */
function aiModelMenu(anchor) {
  const c = aiCfg(), cur = aiModel(c), pick = id => { aiSetCfg({ ...c, provider: "claude", models: { ...c.models, claude: id } }); aiHome(); if (S.doc) aiRenderChat(); toast("AI: " + aiWho()); };
  menu([{ head: c.provider === "claude" ? "Claude model" : "AI: " + aiWho(c) }, ...(c.provider === "claude" ? CLAUDE_MODELS.map(([id, n, d, p]) => ({ label: "Claude " + n, sub: `${d} · ${p}`, on: id === cur, fn: () => pick(id) })) : []), { sep: true }, { label: "AI settings…", sub: "Provider, key, model, effort", fn: () => aiSettings() }], anchor);
}

/* ---- the chat of the open document ---- */
function aiState() {
  const d = S.doc; if (!d) return null;
  if (!d.ai) d.ai = { thread: [], changes: {}, log: [], n: 0, paper: null, feedback: [], usage: { in: 0, out: 0, cacheRead: 0, cacheWrite: 0, calls: 0 } };
  return d.ai;
}
const aiChange = id => aiState()?.changes[id];
let aiExtraRoot = null;   // v8: the AI stage holds suggestions too (stage.js)
const aiSpan = id => flowEl.querySelector(`.ai-chg[data-ai="${id}"]`) || (aiExtraRoot && aiExtraRoot.querySelector(`.ai-chg[data-ai="${id}"]`));
const aiRoots = () => aiExtraRoot && aiExtraRoot.isConnected ? [flowEl, aiExtraRoot] : [flowEl];
const inAiRoot = n => aiRoots().some(r => r.contains(n));
let aiActive = null;   // id of the change the review bar is for

/* ---- light HTML: text with only i, b, sup, sub, code (what the AI sees and returns) ---- */
const AI_STY = { I: "i", EM: "i", B: "b", STRONG: "b", SUP: "sup", SUB: "sub", CODE: "code" };
function toLight(node) {
  let s = "";
  for (const n of node.childNodes) {
    if (n.nodeType === 3) s += esc(n.data);
    else if (n.nodeType === 1) {
      if (n.tagName === "BR") { s += " "; continue; }
      if (n.matches("del.ai-d,.ai-old")) continue;
      const t = AI_STY[n.tagName]; const inner = toLight(n); s += t ? `<${t}>${inner}</${t}>` : inner;
    }
  }
  return s;
}
function lightFrag(light) { const t = document.createElement("template"); t.innerHTML = light; return t.content; }
function lightText(light) { return lightFrag(light).textContent; }
function cleanLight(s) {
  const clean = DOMPurify.sanitize(s, { ALLOWED_TAGS: ["i", "b", "em", "strong", "sup", "sub", "code"], ALLOWED_ATTR: [] });
  const d = document.createElement("div"); d.innerHTML = clean; return toLight(d);
}
const AI_TOK = /\s+|[\p{L}\p{N}]+(?:['’‐-][\p{L}\p{N}]+)*|[^\s\p{L}\p{N}]/gu;
function lightTokens(light) {
  const out = [];
  (function walk(node, sty) {
    for (const n of node.childNodes) {
      if (n.nodeType === 3) { for (const m of n.data.matchAll(AI_TOK)) out.push({ t: m[0], s: sty }); }
      else if (n.nodeType === 1) { const t = AI_STY[n.tagName]; walk(n, t ? [...new Set([...sty.split(",").filter(Boolean), t])].sort().join(",") : sty); }
    }
  })(lightFrag(light), "");
  return out;
}
function renderTokens(toks) {
  let h = "", i = 0;
  while (i < toks.length) {
    let j = i, txt = ""; while (j < toks.length && toks[j].s === toks[i].s) txt += toks[j++].t;
    let piece = esc(txt); for (const t of toks[i].s.split(",").filter(Boolean).reverse()) piece = `<${t}>${piece}</${t}>`;
    h += piece; i = j;
  }
  return h;
}

/* ---- word diff (longest common subsequence), Word-style hunks ---- */
const isWs = t => /^\s+$/.test(t.t);
function aiDiff(oldL, newL) {
  const a = lightTokens(oldL), b = lightTokens(newL), key = t => t.t + "\u0001" + t.s;
  let p = 0; while (p < a.length && p < b.length && key(a[p]) === key(b[p])) p++;
  let sa = a.length, sb = b.length; while (sa > p && sb > p && key(a[sa - 1]) === key(b[sb - 1])) { sa--; sb--; }
  const A = a.slice(p, sa), B = b.slice(p, sb), n = A.length, m = B.length;
  const ops = a.slice(0, p).map(t => ({ op: "=", t }));
  if (n * m > 4e6) { A.forEach(t => ops.push({ op: "-", t })); B.forEach(t => ops.push({ op: "+", t })); }
  else {
    const W = m + 1, L = new Uint16Array((n + 1) * W);
    for (let i = n - 1; i >= 0; i--) for (let j = m - 1; j >= 0; j--) L[i * W + j] = key(A[i]) === key(B[j]) ? L[(i + 1) * W + j + 1] + 1 : Math.max(L[(i + 1) * W + j], L[i * W + j + 1]);
    let i = 0, j = 0;
    while (i < n && j < m) { if (key(A[i]) === key(B[j])) { ops.push({ op: "=", t: B[j] }); i++; j++; } else if (L[(i + 1) * W + j] >= L[i * W + j + 1]) ops.push({ op: "-", t: A[i++] }); else ops.push({ op: "+", t: B[j++] }); }
    while (i < n) ops.push({ op: "-", t: A[i++] }); while (j < m) ops.push({ op: "+", t: B[j++] });
  }
  a.slice(sa).forEach(t => ops.push({ op: "=", t }));
  // a space or one short word left between two edits joins them, so the result reads as one change
  for (let k = 1; k < ops.length - 1; k++) {
    if (ops[k].op !== "=" || ops[k - 1].op === "=") continue;
    let e = k; while (e < ops.length && ops[e].op === "=") e++;
    if (e >= ops.length) break;
    const run = ops.slice(k, e), words = run.filter(o => !isWs(o.t));
    if (words.length <= 1 && words.every(o => o.t.t.length <= 3)) { ops.splice(k, e - k, ...run.flatMap(o => [{ op: "-", t: o.t }, { op: "+", t: o.t }])); k += run.length * 2 - 1; }
  }
  // runs: equal text, or a hunk with its deletions first, then its insertions
  const runs = []; let cur = null;
  for (const o of ops) { const kind = o.op === "=" ? "=" : "x"; if (!cur || cur.kind !== kind) runs.push(cur = { kind, eq: [], del: [], ins: [] }); (o.op === "=" ? cur.eq : o.op === "-" ? cur.del : cur.ins).push(o.t); }
  const chars = ts => ts.filter(t => !isWs(t)).reduce((s, t) => s + t.t.length, 0);
  const eq = runs.filter(r => r.kind === "=").reduce((s, r) => s + chars(r.eq), 0);
  const sim = eq / Math.max(1, chars(a), chars(b)), hunks = runs.filter(r => r.kind === "x").length, words = a.filter(t => /[\p{L}\p{N}]/u.test(t.t)).length;
  const html = runs.map(r => r.kind === "=" ? renderTokens(r.eq) : `<span class="ai-h">${r.del.length ? `<del class="ai-d">${renderTokens(r.del)}</del>` : ""}${r.ins.length ? `<ins class="ai-i">${renderTokens(r.ins)}</ins>` : ""}</span>`).join("");
  return { html, sim, hunks, same: hunks === 0, big: sim < 0.5 || (hunks >= 4 && hunks / Math.max(1, words) > 0.3), oldHtml: renderTokens(a), newHtml: renderTokens(b) };
}

/* ---- the selection → a target inside one paragraph ---- */
const AI_BLOCK = "p,li,td,th,h1,h2,h3,h4,h5,h6,blockquote,figcaption,pre,dd,dt,caption";
const elOf = n => n && (n.nodeType === 1 ? n : n.parentElement);
function aiTarget() {
  const sel = getSelection(); if (!sel || sel.isCollapsed || !sel.rangeCount) return { err: "Select the words you want help with first." };
  const range = sel.getRangeAt(0).cloneRange(); if (!flowEl.contains(range.commonAncestorContainer)) return { err: "Select text in the document first." };
  const sb = elOf(range.startContainer).closest(AI_BLOCK) || elOf(range.startContainer).closest("#flow > *");
  // a triple-click selection ends at the start of the next paragraph: keep it to the first
  if (sb && range.endOffset === 0 && !sb.contains(range.endContainer)) range.setEnd(sb, sb.childNodes.length);
  const eb = elOf(range.endContainer).closest(AI_BLOCK) || elOf(range.endContainer).closest("#flow > *");
  if (!sb || sb !== eb) return { err: "Select text inside one paragraph (for a longer part, one paragraph at a time)." };
  if (elOf(range.commonAncestorContainer).closest(".ai-chg") || range.cloneContents().querySelector?.(".ai-chg")) return { err: "That text already has an AI suggestion: accept or reject it first." };
  const text = range.toString(); if (!text.trim()) return { err: "Select some words first." };
  if (text.length > 8000) return { err: "That selection is long: select one paragraph at a time." };
  return { range, block: sb, text };
}
function aiSection(block) {
  let n = block; while (n && n.parentElement !== flowEl) n = n.parentElement;
  for (let p = n; p; p = p.previousElementSibling) if (/^H[1-4]$/.test(p.tagName)) return p.textContent.trim();
  return "";
}
function aiParagraph(span) {
  const block = span.closest(AI_BLOCK) || span.parentElement, c = block.cloneNode(true);
  for (const s of c.querySelectorAll(".ai-chg")) {
    const mine = s.dataset.ai === span.dataset.ai, ch = aiChange(s.dataset.ai);
    s.replaceWith(document.createTextNode(mine ? "⟦" + lightText(ch.oldLight) + "⟧" : (ch ? aiOrigFrag(s).textContent : s.textContent)));
  }
  return c.textContent.replace(/\s+/g, " ").trim();
}

/* ---- the request box ---- */
let aiAskEl = null, aiAskRange = null;
function aiSelHighlight(range) { try { if (range) CSS.highlights.set("ai-sel", new Highlight(range)); else CSS.highlights.delete("ai-sel"); } catch (e) { /* no highlight API */ } }
function aiAskClose() { if (aiAskEl) { aiAskEl.remove(); aiAskEl = null; } aiSelHighlight(null); aiAskRange = null; }
function aiAskOpen() {
  if (!S.doc) return;
  if (S.doc.kind !== "flow") return toast("The AI edits documents: use “Edit as document” to turn this PDF into one first.");
  if (S.webview) return toast("Switch to the Editor view to use the AI.");
  const t = aiTarget(); if (t.err) return toast(t.err);
  closeSelPop(); aiAskClose(); aiAskRange = t.range; aiSelHighlight(t.range);
  const c = aiCfg(), box = EL("div", { class: "ai-ask", role: "dialog", "aria-label": "Ask AI" });
  box.append(EL("div", { class: "ah" }, ICON("i-ai"), EL("b", {}, "Ask AI"), EL("span", { class: "sp" }), EL("button", { class: "who", title: "AI settings", onclick: () => { aiAskClose(); aiSettings(); } }, aiWho(c))));
  box.append(EL("div", { class: "quote" }, t.text.length > 220 ? t.text.slice(0, 220) + "…" : t.text));
  const chips = EL("div", { class: "ai-chips" }); c.presets.forEach(p => chips.append(EL("button", { type: "button", onclick: () => go(p) }, p))); box.append(chips);
  const ta = EL("textarea", { placeholder: "Or tell the AI what to do… (Enter sends, Shift+Enter new line)", rows: 2 }); box.append(ta);
  box.append(EL("div", { class: "arow" }, EL("span", { class: "hint" }, "Sends this paragraph with the request; the AI keeps the whole paper from this document's chat."), EL("button", { class: "btn small ai", onclick: () => go(ta.value.trim()) }, "Send")));
  function go(instr) { if (!instr) { ta.focus(); return toast("Pick a request or type one."); } const r = aiAskRange; aiAskClose(); aiRequest(r, instr); }
  ta.addEventListener("keydown", e => { e.stopPropagation(); if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); go(ta.value.trim()); } if (e.key === "Escape") { aiAskClose(); flowEl.focus(); } });
  box.addEventListener("keydown", e => { if (e.key === "Escape") { e.stopPropagation(); aiAskClose(); } });
  document.body.append(box); aiAskEl = box;
  const r = t.range.getBoundingClientRect(), h = box.offsetHeight, w = box.offsetWidth;
  let x = clamp(r.left, 8, innerWidth - w - 8), y = r.bottom + 8; if (y + h > innerHeight - 8) y = Math.max(8, r.top - h - 8);
  box.style.left = x + "px"; box.style.top = y + "px";
  setTimeout(() => ta.focus(), 20);
}
document.addEventListener("pointerdown", e => { if (aiAskEl && !e.target.closest(".ai-ask")) aiAskClose(); }, true);

/* ---- a request: put the selection in a busy span, ask, show the answer as a change ---- */
async function aiRequest(range, instr) {
  const ai = aiState(); if (!range || !inAiRoot(range.commonAncestorContainer)) return toast("The selection changed; select the text again.");
  const id = uid(), frag = range.extractContents(), hold = EL("div"); hold.append(frag.cloneNode(true));
  const span = EL("span", { class: "ai-chg busy", "data-ai": id, contenteditable: "false" }); span.append(frag); range.insertNode(span);
  const ch = ai.changes[id] = { id, n: ++ai.n, at: Date.now(), instr, oldHtml: hold.innerHTML, oldLight: toLight(hold), sugg: [], cur: -1, status: "busy", via: aiCfg().provider };
  getSelection().removeAllRanges();
  ai.log.push({ t: "req", id, at: ch.at });
  if (!Prefs.get("aiPanelSeen")) { Prefs.set("aiPanelSeen", 1); aiTogglePanel(true); }
  aiRenderChat();
  try { await aiAsk(ch, {}); }
  catch (e) { console.warn(e); const s = aiSpan(id); if (s) { s.replaceWith(lightOrHtml(ch.oldHtml)); flowEl.normalize(); } ch.status = "failed"; ch.error = String(e.message || e); aiRenderChat(); toast("AI request failed: " + ch.error); }
}
const lightOrHtml = html => { const t = document.createElement("template"); t.innerHTML = html; return t.content; };
async function aiAgain(id, extra) {
  const ch = aiChange(id), s = aiSpan(id); if (!ch || !s || s.classList.contains("busy")) return;
  s.classList.add("busy"); aiBar();
  try { await aiAsk(ch, { retry: true, extra }); }
  catch (e) { console.warn(e); s.classList.remove("busy"); aiBar(); toast("AI request failed: " + (e.message || e)); }
}
async function aiAsk(ch, o) {
  const ai = aiState(), c = aiCfg(), span = aiSpan(ch.id); if (!span) return;
  const section = aiSection(span), para = aiParagraph(span), prev = ch.sugg[ch.cur];
  let res;
  if (c.provider === "demo") res = await aiDemoRevise(ch, o);
  else {
    let msg = `Request ${ch.n}${o.retry ? " (asking again)" : ""}\n` + (section ? `Section: ${section}\n` : "") + `Instruction: ${ch.instr}\n\nParagraph, with the selected passage between ⟦ and ⟧:\n${para}\n\nSelected passage:\n<selection>${ch.oldLight}</selection>`;
    if (o.retry) msg += `\n\nYour last version, which the author has not accepted:\n<previous>${prev?.light || ""}</previous>\n${o.extra ? "Extra instructions: " + o.extra : "Write a different version."}`;
    res = await aiTurn(msg);
  }
  const s = aiSpan(ch.id); if (!s) return;   // the change was removed (undo, delete) while we waited
  let light = cleanLight(res.revision ?? res.text), note = res.note || "";
  // keep the selection's own spaces at both ends
  const ot = lightText(ch.oldLight), lead = ot.match(/^\s*/)[0], trail = ot.match(/\s*$/)[0];
  light = lead + light.replace(/^\s+|\s+$/g, "") + trail;
  const d = aiDiff(ch.oldLight, light);
  if (d.same && o.retry) { s.classList.remove("busy"); aiPaint(ch); aiBar(); aiRenderChat(); toast("The AI gave the same text back" + (note ? ": " + note : ".")); return; }
  if (d.same) {
    s.replaceWith(lightOrHtml(ch.oldHtml)); flowEl.normalize(); ch.status = "unchanged"; ch.sugg.push({ light, note, at: Date.now() }); ch.cur = 0;
    aiRenderChat(); toast("The AI suggests leaving this as it is" + (note ? ": " + note : ".")); return;
  }
  ch.sugg.push({ light, note, at: Date.now(), big: d.big }); ch.cur = ch.sugg.length - 1; ch.status = "pending"; ch.view = null;
  aiPaint(ch); aiSetActive(ch.id); aiCommit(); aiRenderChat();
}
/* draw the current suggestion of a change into its span: each edit is its own <span class="ai-h"> to review */
function aiPaint(ch) {
  const s = aiSpan(ch.id), sg = ch.sugg[ch.cur]; if (!s || !sg) return;
  const d = aiDiff(ch.oldLight, sg.light), rw = ch.view ? ch.view === "rw" : d.big;
  s.className = "ai-chg" + (rw ? " rw" : ""); delete s.dataset.acc; delete s.dataset.rej;
  s.innerHTML = rw ? aiSentenceHunks(ch.oldLight, sg.light) : d.html;
  s.title = (rw ? "AI rewrite" : "AI suggestion") + (sg.note ? ": " + sg.note : "");
}
/* v8: a rewrite is offered sentence by sentence. Each sentence of the AI's version is paired with the sentence(s)
   of yours it replaces (by shared words, in order), so each can be accepted or rolled back on its own. A sentence
   the AI dropped shows struck through; one it added stands alone. */
function aiSentences(toks) {
  const out = []; let cur = [];
  for (let i = 0; i < toks.length; i++) {
    cur.push(toks[i]);
    const t = toks[i].t, prev = toks[i - 1]?.t || "", next = toks[i + 1], after = toks[i + 2];
    if (/^[.!?…]$/.test(t) && next && isWs(next) && (!after || /^[\p{Lu}\p{N}"'“‘(\[]/u.test(after.t)) && !(prev.length === 1 && /\p{L}/u.test(prev)) && !/^(al|vs|etc|Fig|Figs|Eq|cf|approx|ca|Dr|No|resp)$/.test(prev)) { cur.push(next); i++; out.push(cur); cur = []; }
  }
  if (cur.length) out.push(cur);
  return out;
}
function aiSentenceHunks(oldL, newL) {
  const A = aiSentences(lightTokens(oldL)), B = aiSentences(lightTokens(newL));
  const words = ss => new Set(ss.map(t => t.t.toLowerCase()).filter(w => /[\p{L}\p{N}]/u.test(w)));
  const WA = A.map(words), WB = B.map(words), key = ss => ss.map(t => t.t + "\u0001" + t.s).join("").trim();
  const sim = (i, j) => { let c = 0; for (const w of WA[i]) if (WB[j].has(w)) c++; return c / Math.max(1, WA[i].size, WB[j].size); };
  const n = A.length, m = B.length, F = [...Array(n + 1)].map(() => new Float64Array(m + 1));
  for (let i = n - 1; i >= 0; i--) for (let j = m - 1; j >= 0; j--) { const s = sim(i, j); F[i][j] = Math.max(F[i + 1][j], F[i][j + 1], s >= 0.2 ? F[i + 1][j + 1] + s : -1); }
  const out = []; let i = 0, j = 0;
  const hunk = (o, nw, title) => `<span class="ai-h"${title ? ` title="${esc(title)}"` : ""}>${o ? `<del class="ai-d${nw ? " ai-old" : ""}">${renderTokens(o)}</del>` : ""}${nw ? `<ins class="ai-i ai-new">${renderTokens(nw)}</ins>` : ""}</span>`;
  while (i < n || j < m) {
    if (i < n && j < m && sim(i, j) >= 0.2 && F[i][j] === F[i + 1][j + 1] + sim(i, j)) { out.push(key(A[i]) === key(B[j]) ? renderTokens(B[j]) : hunk(A[i], B[j], "Your sentence: " + A[i].map(t => t.t).join("").trim())); i++; j++; }
    else if (i < n && (j >= m || F[i][j] === F[i + 1][j])) out.push(hunk(A[i++], null));
    else out.push(hunk(null, B[j++]));
  }
  return out.join("");
}
/* accepted text stays editable inside a change that is still being reviewed */
function aiOkWrap(frag) { if (!frag.textContent) return frag; const o = EL("span", { class: "ai-ok", contenteditable: "true", spellcheck: "true" }); o.append(frag); return o; }
const aiUnwrapOk = root => $$(".ai-ok", root).forEach(x => x.replaceWith(...x.childNodes));
function aiCommit() { S.doc.html = flowEl.innerHTML; changed({ quiet: true }); layoutMarginSoon(); refreshNotesSoon(); }

/* ---- accept, reject: one edit at a time, or the whole suggestion ---- */
let aiHunk = null;   // the edit the review bar is for
const hunksIn = s => $$(".ai-h", s), allHunks = () => aiRoots().flatMap(r => $$(".ai-chg:not(.busy) .ai-h", r));
const partOf = (h, sel) => { const f = document.createDocumentFragment(); const e = h.querySelector(sel); if (e) f.append(...e.childNodes); return f; };
/* the text a suggestion stands for if its open edits are rejected (for exports and the AI): exact original if nothing was decided */
function aiOrigFrag(s) {
  const ch = aiChange(s.dataset.ai);
  if (ch && !s.dataset.acc && !s.dataset.rej) return lightOrHtml(ch.oldHtml);
  const c = s.cloneNode(true); hunksIn(c).forEach(h => h.replaceWith(partOf(h, "del"))); aiUnwrapOk(c); const f = document.createDocumentFragment(); f.append(...c.childNodes); return f;
}
function aiDecide(h, accept) {
  const s = h?.closest(".ai-chg"); if (!s || s.classList.contains("busy") || h.classList.contains("busy")) return;
  const ch = aiChange(s.dataset.ai), all = allHunks(), i = all.indexOf(h);
  // the leftover of a partly taken sentence has no words of yours behind it: rolling it back keeps one space so words do not run together
  const gap = !accept && h.classList.contains("part") && /^\s|\s$/.test(h.textContent) ? document.createTextNode(" ") : null;
  h.replaceWith(accept ? aiOkWrap(partOf(h, "ins")) : gap || partOf(h, "del")); s.dataset[accept ? "acc" : "rej"] = "1";
  if (!hunksIn(s).length) aiFinish(s, ch);
  aiCommit(); const rest = allHunks(); aiSetHunk(rest[Math.min(i, rest.length - 1)] || null); aiRenderChat();
}
/* every edit decided: the suggestion becomes plain text again */
function aiFinish(s, ch) {
  const acc = !!s.dataset.acc, rej = !!s.dataset.rej; aiUnwrapOk(s);
  if (!acc) s.replaceWith(lightOrHtml(ch.oldHtml)); else { const last = s.lastChild; s.replaceWith(...s.childNodes); if (last && aiActive === ch.id && flowEl.contains(last)) { const r = document.createRange(); r.setStartAfter(last); r.collapse(true); flowEl.focus({ preventScroll: true }); getSelection().removeAllRanges(); getSelection().addRange(r); } }
  flowEl.normalize(); ch.status = acc && rej ? "partly" : acc ? "accepted" : "rejected";
  if (ch.via !== "demo") aiState().feedback.push(`${ch.status === "partly" ? "accepted part of" : ch.status} your version for request ${ch.n}`);
}
function aiAccept(id = aiActive) {
  const ch = aiChange(id), s = aiSpan(id); if (!ch || !s || s.classList.contains("busy")) return;
  if (!s.dataset.acc && !s.dataset.rej) { const frag = lightFrag(ch.sugg[ch.cur].light); s.innerHTML = ""; s.append(frag); s.dataset.acc = "1"; }
  else hunksIn(s).forEach(h => h.replaceWith(partOf(h, "ins"))), s.dataset.acc = "1";
  aiFinish(s, ch); aiAfterResolve();
}
function aiReject(id = aiActive) {
  const ch = aiChange(id), s = aiSpan(id); if (!ch || !s || s.classList.contains("busy")) return;
  hunksIn(s).forEach(h => h.replaceWith(partOf(h, "del"))); s.dataset.rej = "1";
  aiFinish(s, ch); aiAfterResolve();
}
function aiAfterResolve() { aiCommit(); aiSetHunk(allHunks()[0] || null); aiRenderChat(); }
function aiDecideAll(accept) {
  const ids = [...new Set(aiRoots().flatMap(r => $$(".ai-chg[data-ai]:not(.busy)", r)).map(s => s.dataset.ai))]; if (!ids.length) return toast("No AI suggestions to review.");
  ids.forEach(id => accept ? aiAccept(id) : aiReject(id)); toast(`${accept ? "Accepted" : "Rejected"} ${ids.length} suggestion${ids.length === 1 ? "" : "s"}.`);
}
function aiStep(d) { const all = allHunks(); if (!all.length) return toast("No AI suggestions to review."); const i = all.indexOf(aiHunk); const h = all[(i < 0 ? (d > 0 ? 0 : all.length - 1) : i + d + all.length) % all.length]; aiSetHunk(h); h.scrollIntoView({ block: "center", behavior: "smooth" }); afterScroll(viewer, placeBar); }

/* revise one edit: the AI rewrites just that part of its version */
async function aiReviseHunk(h, extra) {
  const s = h?.closest(".ai-chg"), ch = s && aiChange(s.dataset.ai); if (!ch || h.classList.contains("busy")) return;
  const ins = h.querySelector("ins"), del = h.querySelector("del"), part = ins ? toLight(ins) : "", orig = del ? toLight(del) : "";
  const c = s.cloneNode(true), PH = "\u0000PART\u0000"; hunksIn(c)[hunksIn(s).indexOf(h)].replaceWith(document.createTextNode(PH));
  const passage = toLight(c).replace(PH, "⟦" + part + "⟧");
  h.classList.add("busy"); aiBar();
  try {
    let res;
    if (aiCfg().provider === "demo") { await sleep(500 + Math.random() * 500); res = demoPart(part, orig, extra || ch.instr); }
    else res = await aiTurn(`Request ${ch.n}, one part again\nInstruction for the passage: ${ch.instr}\n\nYour current version of the passage, with the part to redo between ⟦ and ⟧:\n${passage}\n\nThe author's original text for that part: «${orig || "(nothing: you added this part)"}»\n${extra ? "What the author wants: " + extra : "The author is not happy with this part: write it differently."}\n\nReply with the new text for the marked part only, in <revision>, so it fits between the text before and after it.`);
    if (!h.isConnected) return;
    const sp = (part || orig).match(/^\s*/)[0], tr = (part || orig).match(/\s*$/)[0], body = cleanLight(res.revision ?? res.text).replace(/^\s+|\s+$/g, "");
    const html = body ? renderTokens(lightTokens(sp + body + tr)) : (sp || tr) ? " " : "";
    if (html) { let i2 = h.querySelector("ins"); if (!i2) { i2 = EL("ins", { class: "ai-i" }); h.append(i2); } i2.innerHTML = html; } else h.querySelector("ins")?.remove();
    if (res.note) h.dataset.note = res.note.replace(/^Demo: /, ch.via === "demo" ? "Demo: " : "");
    h.classList.remove("busy"); aiCommit(); aiSetHunk(h); flashEl(h); aiRenderChat();
  } catch (e) { console.warn(e); h.classList.remove("busy"); aiBar(); toast("AI request failed: " + (e.message || e)); }
}

/* ---- show changes on / off: off shows the text as it would read with every suggestion accepted ---- */
function aiMarkup(on) { if (on != null) Prefs.set("aiMarkup", on); const show = Prefs.get("aiMarkup", true); flowEl.classList.toggle("markup-off", !show); $("#aiMarkupBtn")?.classList.toggle("on", show); placeBar(); return show; }

/* ---- the review bar, under the edit being reviewed ---- */
const aiBarEl = EL("div", { class: "ai-bar", hidden: "", role: "toolbar", "aria-label": "AI suggestion" }); document.body.append(aiBarEl);
function aiSetHunk(h) {
  aiHunk = h && h.isConnected ? h : null; aiActive = aiHunk ? aiHunk.closest(".ai-chg").dataset.ai : null;
  $$(".ai-h.on,.ai-chg.on", flowEl).forEach(e => e.classList.remove("on")); if (aiHunk) { aiHunk.classList.add("on"); aiHunk.closest(".ai-chg").classList.add("on"); }
  aiBar();
}
function aiSetActive(id) { const s = id && aiSpan(id); aiSetHunk(s ? (hunksIn(s)[0] || null) : null); if (s && !aiHunk) { aiActive = id; aiBar(); } }
/* the review remote: a slim column of buttons in the page margin, level with the change being reviewed.
   The AI's note and the "revise" box open beside it only when asked for, so nothing covers the passage. */
let aiNoteOpen = false;
function aiBar() {
  const ch = aiActive && aiChange(aiActive), s = aiActive && aiSpan(aiActive);
  if (!ch || !s || S.doc?.kind !== "flow" || S.webview) { aiBarEl.hidden = true; return; }
  const h = aiHunk && aiHunk.isConnected ? aiHunk : null, busy = s.classList.contains("busy") || !!h?.classList.contains("busy"), sg = ch.sugg[ch.cur], rw = s.classList.contains("rw");
  const all = allHunks(), here = hunksIn(s), keep = aiBarEl.querySelector(".again input"), keepMode = aiBarEl.dataset.mode, againVal = keep?.value || "", againOpen = !!keep && !keep.closest(".again").hidden && aiBarEl.dataset.for === ch.id;
  aiBarEl.innerHTML = ""; aiBarEl.dataset.for = ch.id;
  const B = (lbl, fn, title, cls = "", dis = false) => { const b = EL("button", { type: "button", class: cls, title, "aria-label": title, onclick: e => { e.preventDefault(); fn(); }, onpointerdown: e => e.preventDefault() }); b.innerHTML = lbl; b.disabled = dis; return b; };
  const note = !busy && (h?.dataset.note || sg?.note) || "";
  const row = EL("div", { class: "br" });
  row.append(EL("span", { class: "tag" + (busy ? " busy" : ""), title: busy ? "The AI is working on it…" : rw ? "AI rewrite: the passage was rewritten as a whole" : "AI change" }, ICON("i-ai")));
  row.append(B("✓", () => aiDecide(h, true), "Accept this change (Tab)", "ok", busy || !h));
  row.append(B("✕", () => aiDecide(h, false), "Reject this change and keep your words (Esc)", "no", busy || !h));
  row.append(B("✎", () => openAgain("part"), "Ask the AI to redo this change, optionally saying what is wrong", "", busy || !h));
  if (note) row.append(B("?", () => { aiNoteOpen = !aiNoteOpen; aiBar(); }, aiNoteOpen ? "Hide the AI's reason" : "Why did the AI change this?", aiNoteOpen ? "on" : ""));
  if (all.length > 1 && h) row.append(EL("span", { class: "bsep" }), B("↑", () => aiStep(-1), "Previous change (Alt+↑)", "", busy), EL("span", { class: "ver", title: "Change " + (all.indexOf(h) + 1) + " of " + all.length }, `${all.indexOf(h) + 1}/${all.length}`), B("↓", () => aiStep(1), "Next change (Alt+↓)", "", busy));
  row.append(EL("span", { class: "bsep" }));
  /* v7: one click between the marked-up text and the text as it would read with the changes */
  const mk = Prefs.get("aiMarkup", true);
  row.append(B(mk ? '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg>'
    : '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M3 3l18 18M10.6 5.1A10 10 0 0 1 12 5c6.4 0 10 7 10 7a17 17 0 0 1-3 3.9M6.6 6.6C3.9 8.4 2 12 2 12s3.6 7 10 7a9.6 9.6 0 0 0 5.4-1.6"/><path d="M9.9 9.9a3 3 0 0 0 4.2 4.2"/></svg>',
    () => { aiMarkup(!Prefs.get("aiMarkup", true)); aiBar(); }, mk ? "Showing the changes in colour. Click to read the changed version only (Alt+M)" : "Showing the changed version only. Click to show the changes in colour (Alt+M)", mk ? "" : "on"));
  const more = B("⋯", () => menu([
    ...(here.length > 1 ? [{ label: `Accept all ${here.length} changes in this passage`, fn: () => aiAccept(ch.id) }, { label: `Reject all ${here.length} changes in this passage`, fn: () => aiReject(ch.id) }, { sep: true }] : []),
    { label: "Ask again for the whole passage…", sub: "Get a new version of everything you selected", fn: () => openAgain("all") },
    ...(ch.sugg.length > 1 ? [{ label: `Version ${ch.cur + 1} of ${ch.sugg.length}: show the ${ch.cur + 1 < ch.sugg.length ? "next" : "first"}`, sub: "Your accept/reject choices in this passage start over", fn: () => { ch.cur = (ch.cur + 1) % ch.sugg.length; ch.view = null; aiPaint(ch); aiCommit(); aiSetActive(ch.id); } }] : []),
    { label: rw ? "Show word by word" : "Show as one rewrite", sub: "Your accept/reject choices in this passage start over", fn: () => { ch.view = rw ? "edits" : "rw"; aiPaint(ch); aiCommit(); aiSetActive(ch.id); } },
    ...(rw ? [{ label: s.classList.contains("showold") ? "Hide my original text" : "Show my original text", fn: () => { s.classList.toggle("showold"); aiBar(); } }] : []),
    { sep: true }, { label: (Prefs.get("aiMarkup", true) ? "✓ " : "") + "Show changes in colour", sub: "Off: read the text as if every change were accepted", fn: () => aiMarkup(!Prefs.get("aiMarkup", true)) },
    { label: "Accept every AI change in the document", fn: () => aiDecideAll(true) }, { label: "Reject every AI change in the document", fn: () => aiDecideAll(false) }
  ], more), "More: whole passage, versions, view", "", busy);
  row.append(more);
  aiBarEl.append(row);
  const side = EL("div", { class: "side" });
  if (note && aiNoteOpen) side.append(EL("div", { class: "bnote" }, note));
  const inp = EL("input", { type: "text", "aria-label": "Instructions for the AI" }); inp.value = againVal;
  let mode = keepMode || "part";
  const ph = m => m === "part" ? "What should change? (optional) Enter sends" : "Extra instructions for the whole passage (optional) Enter sends";
  const send = () => { const x = inp.value.trim(); againRow.hidden = true; inp.value = ""; mode === "part" ? aiReviseHunk(h, x) : aiAgain(ch.id, x); };
  const againRow = EL("div", { class: "again" }, inp, EL("button", { type: "button", onclick: e => { e.preventDefault(); send(); }, onpointerdown: e => e.preventDefault() }, "Send")); againRow.hidden = !againOpen;
  function openAgain(m) { mode = m; aiBarEl.dataset.mode = m; inp.placeholder = ph(m); againRow.hidden = false; side.hidden = false; inp.focus(); placeBar(); }
  if (againOpen) inp.placeholder = ph(mode);
  inp.addEventListener("keydown", e => { e.stopPropagation(); if (e.key === "Enter") { e.preventDefault(); send(); } if (e.key === "Escape") { againRow.hidden = true; side.hidden = !side.querySelector(".bnote"); placeBar(); } });
  side.append(againRow); side.hidden = !(note && aiNoteOpen) && !againOpen;
  aiBarEl.append(side); aiBarEl.hidden = false; placeBar();
}
/* beside the page, level with the change: the margin right of the page, then left; with no margin (side panels open,
   page as wide as the window) the page's blank border; never over the text column */
function placeBar() {
  if (aiBarEl.hidden) return; const s = aiActive && aiSpan(aiActive); if (!s) { aiBarEl.hidden = true; return; }
  if (aiBarEl.dataset.placed && aiBarEl.matches(":hover")) return;   // v8: under the pointer it stays put, so ✓ can be pressed again and again
  const onStage = aiExtraRoot && aiExtraRoot.contains(s), box = onStage ? aiExtraRoot : viewer, page = onStage ? aiExtraRoot : flowEl;
  const t = aiHunk && aiHunk.isConnected ? aiHunk : s, rs = t.getClientRects(), last = rs[rs.length - 1] || t.getBoundingClientRect(), vr = box.getBoundingClientRect(), pg = page.getBoundingClientRect();
  // v8: level with the paragraph, not the change: moving to the next change in the same paragraph does not move it
  const blk = t.closest(AI_BLOCK) || t, first = blk.getBoundingClientRect();
  const w = aiBarEl.offsetWidth, h = aiBarEl.offsetHeight, gap = 12, sideW = 256;
  let x, left = false;
  const cs = getComputedStyle(page), padR = parseFloat(cs.paddingRight) || 0, padL = parseFloat(cs.paddingLeft) || 0;
  if (vr.right - pg.right >= w + gap + 4) x = pg.right + gap;                          // the margin right of the page
  else if (pg.left - vr.left >= w + gap + 4) { x = pg.left - gap - w; left = true; }   // the margin left of the page
  else if (padR >= w + 8) x = pg.right - padR + (padR - w) / 2;                        // no margin: the page's blank right border
  else if (padL >= w + 8) { x = pg.left + (padL - w) / 2; left = true; }
  else x = vr.right - w - 18;
  if (!left && x + w + sideW > Math.min(innerWidth, vr.right + 400)) left = true;   // the note and the revise box open to whichever side has room
  aiBarEl.classList.toggle("left", left);
  aiBarEl.style.visibility = (last.bottom < vr.top || first.top > vr.bottom) ? "hidden" : "visible";
  aiBarEl.style.left = clamp(x, 4, innerWidth - w - 4) + "px"; aiBarEl.style.top = clamp(first.top - 4, vr.top + 4, Math.max(vr.top + 4, vr.bottom - h - 4)) + "px";
  aiBarEl.dataset.placed = "1";
}
aiBarEl.addEventListener("mouseleave", () => setTimeout(placeBar, 250));
viewer.addEventListener("scroll", () => requestAnimationFrame(placeBar), { passive: true });
addEventListener("resize", debounce(placeBar, 80));
flowEl.addEventListener("click", e => { const c = e.target.closest(".ai-chg"); if (c && c.dataset.ai) { const h = e.target.closest(".ai-h"); if (h) aiSetHunk(h); else aiSetActive(c.dataset.ai); aiRenderChat(); } });
flowEl.addEventListener("input", debounce(() => { if (aiActive && !aiSpan(aiActive)) aiSetHunk(null); else placeBar(); }, 150));

/* keys: Tab accepts and Esc rejects the change at hand, Alt+↓/↑ move between changes, Alt+A asks */
document.addEventListener("keydown", e => {
  if (!S.doc || S.doc.kind !== "flow" || S.webview) return;
  const inField = e.target.closest("input,textarea,select") || (e.target.closest("[contenteditable=true]") && !e.target.closest("#flow"));
  if (e.altKey && !e.ctrlKey && !e.metaKey && e.code === "KeyA" && !inField) { e.preventDefault(); e.stopPropagation(); aiAskOpen(); return; }
  if (inField || aiAskEl || !$("#modalBack").hidden || !$("#menu").hidden || !$("#pop").hidden) return;
  if (e.altKey && !e.ctrlKey && !e.metaKey && !e.shiftKey && e.code === "KeyM" && aiRoots().some(r => $(".ai-chg", r))) { e.preventDefault(); e.stopPropagation(); aiMarkup(!Prefs.get("aiMarkup", true)); aiBar(); toast(Prefs.get("aiMarkup", true) ? "Showing the changes in colour." : "Showing the changed version only."); return; }
  if (e.altKey && !e.ctrlKey && !e.metaKey && !e.shiftKey && (e.key === "ArrowDown" || e.key === "ArrowUp") && allHunks().length) { e.preventDefault(); e.stopPropagation(); aiStep(e.key === "ArrowDown" ? 1 : -1); return; }
  if (!aiHunk || !aiHunk.isConnected) return;
  if (e.key === "Tab" && !e.shiftKey && !e.ctrlKey && !e.altKey && !e.metaKey) { e.preventDefault(); e.stopPropagation(); aiDecide(aiHunk, true); }
  else if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); aiDecide(aiHunk, false); }
}, true);

/* ---- the conversation with the AI ---- */
function aiPaperText() { let md = flowToMarkdown({}); md = md.replace(/^<!-- source:.*?-->\s*/, ""); return md; }
const wordCount = s => (s.match(/[\p{L}\p{N}]+/gu) || []).length;
/* one user turn + the answer; the thread only grows (earlier turns are never edited), so the cache keeps working */
async function aiTurn(text) {
  const ai = aiState(), c = aiCfg(), key = aiKey(c.provider);
  if (!key && c.provider !== "custom") { aiSettings("Add your API key to use " + AI_PROVIDERS[c.provider].label + ", or pick Demo."); throw new Error("no API key yet"); }
  if (!aiModel(c)) { aiSettings("Choose a model first."); throw new Error("no model chosen"); }
  const content = [], paper = aiPaperText(), words = wordCount(paper); let paperNow = null;
  if (!ai.paper || ai.paper.stale || Math.abs(words - ai.paper.words) > Math.max(40, ai.paper.words * 0.15)) {
    content.push({ type: "text", text: `${ai.paper ? "An updated copy of the manuscript (it has changed since the last copy)" : "The manuscript I am working on, for reference during this session"}:\n<manuscript title="${esc(S.doc.name)}">\n${paper}\n</manuscript>` });
    paperNow = { words, at: Date.now() };
  }
  const fb = ai.feedback.length ? `(Since the last request the author ${ai.feedback.join("; ")}.)\n\n` : "";
  content.push({ type: "text", text: fb + text });
  const user = { role: "user", content }, res = await aiCall([...ai.thread, user], c, key);
  ai.thread.push(user, { role: "assistant", content: res.content }); ai.feedback = [];
  if (paperNow) { ai.paper = paperNow; ai.log.push({ t: "info", at: Date.now(), text: (ai.thread.length > 2 ? "Sent an updated copy of the paper" : "Sent the paper to start this chat") + ` (${words.toLocaleString("en")} words).` }); }
  const u = ai.usage; u.calls++; u.in += res.usage.in || 0; u.out += res.usage.out || 0; u.cacheRead += res.usage.cacheRead || 0; u.cacheWrite += res.usage.cacheWrite || 0; u.last = res.usage.total || 0;
  const rev = res.text.match(/<revision>([\s\S]*?)<\/revision>/i), note = res.text.match(/<note>([\s\S]*?)<\/note>/i);
  return { text: res.text.replace(/<\/?(revision|note)>/gi, "").trim(), revision: rev ? rev[1] : null, note: note ? note[1].trim() : "" };
}
const textOf = content => typeof content === "string" ? content : content.filter(b => b.type === "text").map(b => b.text).join("\n\n");
async function aiCall(messages, c, key) {
  const model = aiModel(c);
  try {
    if (c.provider === "claude") {
      const headers = { "content-type": "application/json", "x-api-key": key, "anthropic-version": "2026-10-21", "anthropic-dangerous-direct-browser-access": "true" };
      const body = { model, max_tokens: 16000, system: AI_SYSTEM, messages: messages.map(m => ({ role: m.role, content: m.content })), cache_control: { type: "ephemeral" } };
      if (c.effort && !NO_EFFORT.has(model)) body.output_config = { effort: c.effort === "xhigh" && NO_XHIGH.has(model) ? "high" : c.effort };
      if (AI_FALLBACK_MODELS.has(model)) { headers["anthropic-beta"] = "server-side-fallback-2026-07-01"; body.fallbacks = "default"; }
      let r = await fetch("https://api.anthropic.com/v1/messages", { method: "POST", headers, body: JSON.stringify(body) }), data = await r.json().catch(() => ({}));
      if (r.status === 400 && body.fallbacks && /fallback/i.test(data.error?.message || "")) {   // an account without the fallback option: ask once more without it
        delete body.fallbacks; delete headers["anthropic-beta"]; r = await fetch("https://api.anthropic.com/v1/messages", { method: "POST", headers, body: JSON.stringify(body) }); data = await r.json().catch(() => ({}));
      }
      if (!r.ok) throw aiHttpErr(r.status, data.error?.message);
      if (data.stop_reason === "refusal") throw new Error("the model declined this request" + (data.stop_details?.category ? ` (${data.stop_details.category})` : "") + ". Rephrase it, or try another model.");
      const text = (data.content || []).filter(b => b.type === "text").map(b => b.text).join("");
      if (!text.trim()) throw new Error(data.stop_reason === "max_tokens" ? "the answer was cut off (too long)" : "the answer was empty");
      const u = data.usage || {};
      return { text, content: data.content, usage: { in: u.input_tokens || 0, out: u.output_tokens || 0, cacheRead: u.cache_read_input_tokens || 0, cacheWrite: u.cache_creation_input_tokens || 0, total: (u.input_tokens || 0) + (u.cache_read_input_tokens || 0) + (u.cache_creation_input_tokens || 0) } };
    }
    const base = aiBase(c); if (!base) throw new Error("set the server address in AI settings");
    const headers = { "content-type": "application/json" }; if (key) headers.authorization = "Bearer " + key;
    const r = await fetch(base + "/chat/completions", { method: "POST", headers, body: JSON.stringify({ model, messages: [{ role: "system", content: AI_SYSTEM }, ...messages.map(m => ({ role: m.role, content: textOf(m.content) }))] }) });
    const data = await r.json().catch(() => ({})); if (!r.ok) throw aiHttpErr(r.status, data.error?.message || data.message);
    const text = data.choices?.[0]?.message?.content || ""; if (!text.trim()) throw new Error("the answer was empty");
    const u = data.usage || {}, cached = u.prompt_tokens_details?.cached_tokens || 0;
    return { text, content: text, usage: { in: (u.prompt_tokens || 0) - cached, out: u.completion_tokens || 0, cacheRead: cached, cacheWrite: 0, total: u.prompt_tokens || 0 } };
  } catch (e) {
    if (e instanceof TypeError) throw new Error(`could not reach ${c.provider === "claude" ? "api.anthropic.com" : aiBase(c) || "the server"} (offline, blocked, or the server does not accept calls from a browser)`);
    throw e;
  }
}
function aiHttpErr(status, msg) {
  const hint = status === 401 || status === 403 ? "the key was not accepted" : status === 404 ? "model or address not found" : status === 429 ? "rate limited: wait a moment and try again" : status >= 500 ? "the service is busy or down: try again shortly" : "request refused";
  return new Error(hint + (msg ? ` (${status}: ${msg})` : ` (${status})`));
}
async function aiListModels(p, key, base) {
  if (p === "claude") {
    const r = await fetch("https://api.anthropic.com/v1/models?limit=100", { headers: { "x-api-key": key, "anthropic-version": "2026-10-21", "anthropic-dangerous-direct-browser-access": "true" } });
    const d = await r.json().catch(() => ({})); if (!r.ok) throw aiHttpErr(r.status, d.error?.message); return (d.data || []).map(m => m.id);
  }
  const r = await fetch(base.replace(/\/+$/, "") + "/models", { headers: key ? { authorization: "Bearer " + key } : {} });
  const d = await r.json().catch(() => ({})); if (!r.ok) throw aiHttpErr(r.status, d.error?.message); return (d.data || d.models || []).map(m => (m.id || m.name || "").replace(/^models\//, "")).filter(Boolean);
}

/* a free question about the paper, answered in the chat panel */
async function aiQuestion(q) {
  const ai = aiState(); if (!ai || !q) return;
  ai.log.push({ t: "you", at: Date.now(), text: q }); const wait = { t: "info", at: Date.now(), text: "Thinking…", wait: true }; ai.log.push(wait); aiRenderChat();
  try {
    const ans = aiCfg().provider === "demo" ? await aiDemoAnswer(q) : (await aiTurn("QUESTION: " + q)).text;
    ai.log.splice(ai.log.indexOf(wait), 1); ai.log.push({ t: "ans", at: Date.now(), text: ans });
  } catch (e) { ai.log.splice(ai.log.indexOf(wait), 1); ai.log.push({ t: "err", at: Date.now(), text: "Could not ask: " + (e.message || e) }); }
  markDirty(); aiRenderChat();
}

/* ---- demo mode: edits made by simple rules, so every control can be tried without a key ---- */
const sleep = ms => new Promise(r => setTimeout(r, ms));
const DEMO = {
  concise: [[/\bin order to\b/gi, "to"], [/\bdue to the fact that\b/gi, "because"], [/\bit is (?:important|worth) (?:to note|noting) that\s*/gi, ""], [/\ba (?:large|great) number of\b/gi, "many"], [/\bis able to\b/gi, "can"], [/\bare able to\b/gi, "can"], [/\bhas the ability to\b/gi, "can"], [/\bat this point in time\b/gi, "now"], [/\bfor the purpose of\b/gi, "for"], [/\ba majority of\b/gi, "most"], [/\bprior to\b/gi, "before"], [/\bsubsequent to\b/gi, "after"], [/\bwith regard to\b/gi, "regarding"], [/\bin the case of\b/gi, "for"], [/\butili[sz]ed\b/gi, "used"], [/\butili[sz]e\b/gi, "use"], [/\b(?:very|really|basically|quite) /gi, ""], [/\bin fact, /gi, ""], [/\bthe fact that\b/gi, "that"], [/\bit can be seen that\s*/gi, ""], [/\bwas found to be\b/gi, "was"], [/\bwere found to be\b/gi, "were"], [/\ba(?= [aeiou])/g, "an"]],
  formal: [[/\bdon't\b/gi, "do not"], [/\bdoesn't\b/gi, "does not"], [/\bdidn't\b/gi, "did not"], [/\bcan't\b/gi, "cannot"], [/\bisn't\b/gi, "is not"], [/\baren't\b/gi, "are not"], [/\bwon't\b/gi, "will not"], [/\bit's\b/gi, "it is"], [/\ba lot of\b/gi, "considerable"], [/\blots of\b/gi, "many"], [/\bbig\b/gi, "large"], [/\bhuge\b/gi, "substantial"], [/\bgot\b/gi, "obtained"], [/\bget\b/gi, "obtain"], [/\bseems\b/gi, "appears"], [/\bpretty\b/gi, "fairly"], [/\bkind of\b/gi, "somewhat"], [/^So, /, "Therefore, "], [/^But /, "However, "], [/^Also, /, "In addition, "], [/\bthings\b/gi, "factors"], [/\blooked at\b/gi, "examined"], [/\bfound out\b/gi, "determined"]],
  hedge: [[/\bproves\b/gi, "suggests"], [/\bproved\b/gi, "indicated"], [/\bshows that\b/gi, "suggests that"], [/\bshowed that\b/gi, "indicated that"], [/\bdemonstrates that\b/gi, "indicates that"], [/\bclearly /gi, ""], [/\bobviously /gi, ""], [/\balways\b/gi, "generally"], [/\bnever\b/gi, "rarely"], [/\bis the cause of\b/gi, "may contribute to"], [/\bcauses\b/gi, "may cause"], [/\bwill\b/gi, "may"]],
  grammar: [[/ {2,}/g, " "], [/ ([,.;:])/g, "$1"], [/\b(\w+) \1\b/gi, "$1"], [/\ba(?= [aeiou])/g, "an"], [/\balot\b/gi, "a lot"], [/\bseperate/gi, "separate"], [/\brecieve/gi, "receive"], [/\boccured\b/gi, "occurred"], [/\bteh\b/gi, "the"], [/\bdont\b/gi, "do not"], [/\bthier\b/gi, "their"], [/\bwich\b/gi, "which"]]
};
const LINKS = [["Moreover, ", "As a result, ", "In addition, ", "Consequently, "], ["Furthermore, ", "Therefore, ", "Notably, ", "Accordingly, "], ["In turn, ", "Thus, ", "Likewise, ", "Hence, "]];
function swaps(s, list) { for (const [re, to] of list) s = s.replace(re, (m, ...g) => { const out = to.replace(/\$1/g, g[0]); return m[0] === m[0].toUpperCase() && m[0] !== m[0].toLowerCase() && out ? out[0].toUpperCase() + out.slice(1) : out; }); return s; }
const sentences = s => s.split(/(?<=[.!?])\s+(?=[A-Z<])/);
const lowerFirst = s => s.replace(/^(<[^>]+>)*([A-Z])(?=[a-z])/, (m, t, c) => (t || "") + c.toLowerCase());
const upperFirst = s => s.replace(/^(<[^>]+>)*([a-z])/, (m, t, c) => (t || "") + c.toUpperCase());
function demoKind(instr) { const i = instr.toLowerCase(); return /flow|logic|transition|link|connect/.test(i) ? "flow" : /concise|short|tight|wordy|trim|cut/.test(i) ? "concise" : /formal|academic|tone|register/.test(i) ? "formal" : /grammar|spell|typo|proofread/.test(i) ? "grammar" : /hedg|cautio|overclaim|soften/.test(i) ? "hedge" : "rewrite"; }
function demoRevise(light, instr, attempt) {
  const kind = demoKind(instr); let s = light, note = "";
  if (kind === "flow") {
    const ss = sentences(s), links = LINKS[attempt % LINKS.length]; let k = 0;
    s = ss.map((x, i) => i > 0 && !/^(<[^>]+>)*(However|Moreover|Thus|Therefore|In |As |Furthermore|Notably|Consequently|Accordingly|Hence|Likewise|Finally|First|Second|Third|Together|Here|Overall)\b/.test(x) && (i % 2 === 1 || ss.length === 2) ? links[k++ % links.length] + lowerFirst(x) : x).join(" ");
    s = swaps(s, DEMO.concise); note = "Added linking words between sentences and removed filler phrases.";
    if (s === light && ss.length < 2) { s = swaps(s, DEMO.formal); note = "One sentence: little to link; tightened the wording instead."; }
  } else if (kind === "concise") { s = swaps(s, DEMO.concise); note = "Cut filler phrases and wordy constructions."; }
  else if (kind === "formal") { s = swaps(swaps(s, DEMO.formal), DEMO.concise); note = "Replaced informal words and contractions with formal equivalents."; }
  else if (kind === "grammar") { s = upperFirst(swaps(s, DEMO.grammar)); note = "Fixed spacing, doubled words, articles and common misspellings."; }
  else if (kind === "hedge") { s = swaps(s, DEMO.hedge); note = "Softened claims that the data may not fully support."; }
  else {
    let ss = sentences(swaps(swaps(s, DEMO.formal), DEMO.concise));
    if (ss.length > 1) ss = attempt % 2 ? [...ss.slice(1), ss[0]] : ss.slice().reverse();
    else { const p = ss[0].split(/,\s+/); if (p.length > 1) ss = [upperFirst(p.slice(1).join(", ").replace(/[.!?]?$/, "")) + ", " + lowerFirst(p[0]) + "."]; }
    s = (attempt % 2 ? "Taken together, " : "In brief, ") + lowerFirst(ss.join(" ")); note = "Restructured the passage (demo: sentences reordered, not truly rewritten).";
  }
  if (attempt > 0 && kind !== "flow" && kind !== "rewrite") { s = swaps(s, DEMO.formal); note += " Second pass also formalised the wording."; }
  return { revision: s, note: "Demo: " + note };
}
/* demo: redo one part. Short parts: tidy the wording, or go back to the author's own words */
function demoPart(part, orig, instr) {
  const src = part || orig, out = swaps(swaps(src, DEMO.concise), DEMO.formal);
  if (out !== src && out.trim()) return { revision: out, note: "Demo: tightened the wording of this part." };
  return { revision: orig || "", note: orig ? "Demo: went back to your original words for this part." : "Demo: dropped this addition." };
}
async function aiDemoRevise(ch, o) {
  await sleep(500 + Math.random() * 700);
  const instr = o.retry && o.extra ? o.extra + " " + ch.instr : ch.instr;
  return demoRevise(ch.oldLight, instr, ch.sugg.length);
}
async function aiDemoAnswer() {
  await sleep(600); const md = aiPaperText(), ss = md.replace(/^#.*$/gm, "").split(/(?<=[.!?])\s+/).map(s => s.trim()).filter(s => wordCount(s) > 3);
  const long = ss.slice().sort((a, b) => wordCount(b) - wordCount(a))[0] || "", passive = (md.match(/\b(?:is|are|was|were|been|being)\s+\w+ed\b/gi) || []).length;
  return `Demo mode cannot read your question (no AI is connected; open AI settings to add a key). What it can tell you about the paper:\n\n• ${wordCount(md).toLocaleString("en")} words, ${ss.length} sentences, ${(wordCount(md) / Math.max(1, ss.length)).toFixed(1)} words per sentence on average.\n• About ${passive} passive constructions.\n• Longest sentence (${wordCount(long)} words): “${long.slice(0, 160)}${long.length > 160 ? "…" : ""}”`;
}

/* ---- chat panel ---- */
const aiPanel = $("#aiPanel");
function aiTogglePanel(on) { const open = on ?? aiPanel.classList.contains("closed"); aiPanel.classList.toggle("closed", !open); $("#aiPanelBtn")?.classList.toggle("on", open); Prefs.set("aiPanel", open); if (open) { aiRenderChat(); if (innerWidth < 1500) $("#right").classList.add("closed"); } setTimeout(() => { layoutMargin(); placeBar(); }, 200); }
function aiStatus(ch) { return aiSpan(ch.id) ? (aiSpan(ch.id).classList.contains("busy") ? "busy" : "pending") : ch.status === "busy" || ch.status === "pending" ? "removed" : ch.status; }
function aiRenderChat() {
  const ai = S.doc ? aiState() : null, c = aiCfg(); if (!ai) return;
  const who = $("#aiWho"); who.textContent = aiWho(c); who.classList.toggle("demo", c.provider === "demo");
  const u = ai.usage, k = n => n >= 1e4 ? (n / 1e3).toFixed(0) + "k" : n >= 1e3 ? (n / 1e3).toFixed(1) + "k" : String(n);
  const pend = $$(".ai-chg[data-ai]", flowEl).length;
  $("#aiStats").innerHTML = (ai.paper ? `Paper in this chat: ${ai.paper.words.toLocaleString("en")} words, sent ${fmtTime(ai.paper.at)}.` : c.provider === "demo" ? "Demo mode: nothing is sent anywhere." : "The paper is sent with your first request.") +
    (u.calls ? ` ${u.calls} request${u.calls === 1 ? "" : "s"}` + (u.in || u.cacheRead ? `, tokens in ${k(u.in + u.cacheRead + u.cacheWrite)} (${k(u.cacheRead)} from cache), out ${k(u.out)}.` : ".") : "") + (pend ? ` <b>${pend} suggestion${pend === 1 ? "" : "s"} to review.</b>` : "") +
    (u.last > 150000 ? ` The chat is getting long: consider <button data-aiact="newchat">a new chat</button>.` : "") +
    ` <button data-aiact="where">Where is this chat?</button>`;
  const log = $("#aiLog"); log.innerHTML = "";
  if (!ai.log.length) log.innerHTML = `<div class="empty"><b>One chat for this document.</b> Select words in a paragraph, then press <b>Ask AI</b> (or Alt+A) and pick a request. The answer appears in the text as tracked changes: <b>Tab</b> accepts, <b>Esc</b> rejects, <b>Ask again</b> sends it back.<br><br>The AI receives the whole paper once, then each request with its paragraph, so it keeps the full paper as reference. You can also ask questions about the paper below.<br><br><b>Where the chat is kept:</b> with this document, in this browser (and inside a saved .lpdoc project). Requests go to the AI's own API with your key, so they do not appear on claude.ai; <b>⋯ → Download the chat</b> keeps a copy.</div>`;
  for (const e of ai.log) {
    if (e.t === "req") {
      const ch = ai.changes[e.id]; if (!ch) continue; const st = aiStatus(ch), sg = ch.sugg[ch.cur];
      const m = EL("div", { class: "ai-msg req", title: st === "pending" ? "Show this change in the text" : "" });
      m.append(EL("div", { class: "mh" }, EL("span", {}, "#" + ch.n), EL("span", { class: "ai-st " + st }, { busy: "thinking", pending: "to review", accepted: "accepted", partly: "partly accepted", rejected: "rejected", unchanged: "no change", failed: "failed", removed: "removed" }[st] || st), EL("span", { class: "sp" }), EL("span", {}, fmtTime(ch.at))));
      m.append(EL("div", { class: "in" }, ch.instr), EL("div", { class: "q" }, lightText(ch.oldLight).trim().slice(0, 200)));
      if (ch.error && st === "failed") m.append(EL("div", { class: "nt" }, ch.error));
      else if (sg?.note) m.append(EL("div", { class: "nt" }, (ch.sugg.length > 1 ? `v${ch.cur + 1}/${ch.sugg.length}: ` : "") + sg.note));
      m.addEventListener("click", () => { const s = aiSpan(ch.id); if (!s) return; s.scrollIntoView({ block: "center", behavior: "smooth" }); aiSetActive(ch.id); afterScroll(viewer, placeBar); });
      log.append(m);
    } else log.append(EL("div", { class: "ai-msg " + e.t }, e.text));
  }
  log.scrollTop = log.scrollHeight;
}
function aiChatMenu(anchor) {
  menu([
    { label: "AI settings…", icon: "i-ai", fn: () => aiSettings() },
    { label: "Send the paper again", sub: "Gives the AI the current text before your next request", fn: () => { const ai = aiState(); if (ai.paper) ai.paper.stale = true; toast("The current paper goes with your next request."); } },
    { label: "Where is this chat?", sub: "Kept with this document in this browser, not on claude.ai", fn: aiWhere },
    { label: "Continue on claude.ai ↗", sub: "Copies the paper and this chat, opens a new claude.ai chat to paste into", fn: aiToClaudeAi },
    { label: "Download the chat (.md)", sub: "Requests, the AI's versions and notes, questions and answers", fn: () => download(new Blob([aiChatMarkdown()], { type: "text/markdown" }), baseName(S.doc.name) + "-ai-chat.md") },
    { label: "Copy the chat", fn: () => { navigator.clipboard.writeText(aiState().log.map(e => e.t === "req" ? (c => `#${c.n} ${c.instr}\n> ${lightText(c.oldLight).trim()}\n${c.sugg[c.cur] ? "→ " + lightText(c.sugg[c.cur].light).trim() + (c.sugg[c.cur].note ? `\n(${c.sugg[c.cur].note})` : "") : ""}`)(aiState().changes[e.id] || { sugg: [], oldLight: "" }) : e.text).join("\n\n")); toast("Copied the chat."); } },
    { sep: true },
    { label: "Start a new chat", danger: true, sub: "The AI forgets this chat; suggestions in the text stay", fn: aiNewChat }
  ], anchor, { right: true });
}
/* where the chat lives, said plainly, with what was actually sent */
function aiWhere() {
  const ai = aiState(), c = aiCfg(), P = AI_PROVIDERS[c.provider], kb = Math.max(1, Math.round(JSON.stringify(ai).length / 1024));
  const sent = ai.thread.length / 2, where = c.provider === "claude" ? "Anthropic's API" : c.provider === "demo" ? "" : P.label + "'s API";
  const usage = c.provider === "claude" ? `Usage and cost appear on <a href="https://platform.claude.com/" target="_blank" rel="noopener">platform.claude.com</a> (the Claude Console), as token counts, not as conversations.` : c.provider === "openai" ? `Usage and cost appear in your OpenAI account, not as conversations.` : c.provider === "gemini" ? `Usage appears in Google AI Studio, not as conversations.` : "";
  const v = modal(`<h3>Where is this chat?</h3>
    <div class="where-map"><div class="wm-box on"><b>This document</b><span>in this browser${S.doc.handle || S.fileHandle ? ", and your autosave file" : ""}</span><small>${ai.log.length} entries · ${kb} KB</small></div>
      <div class="wm-arrow">${c.provider === "demo" ? "✕" : "⇄"}</div>
      <div class="wm-box">${c.provider === "demo" ? "<b>Nothing is sent</b><span>Demo mode works in the browser</span>" : `<b>${esc(where)}</b><span>your key · ${esc(aiWho(c))}</span><small>${sent} request${sent === 1 ? "" : "s"} in this chat</small>`}</div>
      <div class="wm-arrow">✕</div><div class="wm-box off"><b>claude.ai</b><span>chats there are separate</span></div></div>
    <ul class="where-list">
      <li><b>Kept with this document, in this browser.</b> The chat is saved in the browser's storage for this site, together with the document, and inside an .lpdoc project file if you save one (Save menu). Open the document on another computer or browser and the chat is not there unless you bring the .lpdoc.</li>
      ${c.provider === "demo" ? "" : `<li><b>Sent to ${esc(where)} with your key, one request at a time.</b> The API answers and keeps no chat history you can open later, so the chat never appears on claude.ai, which only lists conversations made in the claude.ai app. ${usage}</li>`}
      <li><b>Lost if you clear this site's data</b> in the browser (or use a private window). Keep a copy with <b>Download the chat</b> below, or save the project file.</li>
      <li><b>Want it on claude.ai?</b> claude.ai has no way for other apps to add chats to your account. <b>Continue on claude.ai</b> below copies the paper and this chat and opens a new claude.ai chat: paste (Ctrl+V) and send, and it is a claude.ai chat from then on (a copy: what you write there does not come back here). For a lasting place, make a claude.ai Project for the paper and add the downloaded chat and the paper as project files.</li>
      <li><b>Start a new chat</b> (⋯ menu) to make the AI forget it; the document keeps the suggestions already in the text.</li>
    </ul>
    <div class="mrow"><button class="btn" data-where="sent"${ai.thread.length ? "" : " disabled"}>See exactly what was sent</button><button class="btn" data-where="dl">Download the chat (.md)</button><button class="btn" data-where="claude">Continue on claude.ai ↗</button><span class="sp"></span><button class="btn primary" data-cancel>Close</button></div>`);
  $$("#modal [data-where]").forEach(b => { b.onclick = () => { const w = b.dataset.where; if (w === "dl") download(new Blob([aiChatMarkdown()], { type: "text/markdown" }), baseName(S.doc.name) + "-ai-chat.md"); else if (w === "claude") { closeModal(null); aiToClaudeAi(); } else { closeModal(null); aiSentView(); } }; });
  return v;
}
/* the conversation exactly as the AI receives it: every request and reply, the paper copies folded */
function aiSentView() {
  const ai = aiState(), msgs = ai.thread.map((m, i) => {
    const blocks = typeof m.content === "string" ? [{ type: "text", text: m.content }] : m.content.filter(b => b.type === "text");
    const body = blocks.map(b => b.text.startsWith("The manuscript") || b.text.startsWith("An updated copy of the manuscript") ? `<details><summary>${esc(b.text.split("\n")[0])} (${wordCount(b.text).toLocaleString("en")} words)</summary><pre>${esc(b.text)}</pre></details>` : `<pre>${esc(b.text)}</pre>`).join("");
    return `<div class="sent-msg ${m.role}"><div class="sent-who">${m.role === "user" ? "Sent by Doc Reader" : "The AI's reply"} · message ${i + 1}</div>${body}</div>`;
  }).join("");
  modal(`<h3>What was sent to the AI</h3><p>Every message in this document's chat, in order. Each request also carries the editing instructions shown first (the system prompt).</p><details class="sent-sys"><summary>System prompt</summary><pre>${esc(AI_SYSTEM)}</pre></details><div class="sent-list">${msgs || "<p>Nothing sent yet.</p>"}</div><div class="mrow"><button class="btn primary" data-cancel>Close</button></div>`);
  $("#modal").classList.add("sent-modal"); const off = () => { if ($("#modalBack").hidden) $("#modal").classList.remove("sent-modal"); else setTimeout(off, 300); }; setTimeout(off, 300);
}
/* claude.ai has no way for other apps to add chats, so: copy the paper and this chat, open a new claude.ai chat, paste */
async function aiToClaudeAi() {
  const text = `I am writing this paper and used an AI editor (Lab Potato Doc Reader) on it. Below are the current manuscript and our editing chat. Please read both and continue as my editor; I will ask follow-up questions here.\n\n<manuscript>\n${aiPaperText()}\n</manuscript>\n\n<editing_chat>\n${aiChatMarkdown()}</editing_chat>\n`;
  let copied = true; try { await navigator.clipboard.writeText(text); } catch (e) { copied = false; }
  window.open("https://claude.ai/new", "_blank", "noopener");
  if (copied) toast("Copied the paper and this chat. In the new claude.ai chat, press Ctrl+V (⌘V) to paste it, then send.");
  else { download(new Blob([text], { type: "text/markdown" }), baseName(S.doc.name) + "-for-claude.md"); toast("Saved the paper and this chat as a file: attach it in the new claude.ai chat."); }
}
function aiChatMarkdown() {
  const ai = aiState(), c = aiCfg();
  return `# AI chat: ${S.doc.name}\n\n_${aiWho(c)} · kept with this document in Doc Reader (not on claude.ai)_\n\n` + ai.log.map(e => {
    if (e.t !== "req") return (e.t === "you" ? "**You:** " : e.t === "ans" ? "**AI:** " : "_") + e.text + (e.t === "info" || e.t === "err" ? "_" : "");
    const ch = ai.changes[e.id]; if (!ch) return "";
    return `### #${ch.n} ${ch.instr} (${aiStatus(ch)})\n\n> ${lightText(ch.oldLight).trim()}\n\n` + ch.sugg.map((v, i) => `**Version ${i + 1}:** ${lightText(v.light).trim()}${v.note ? `\n\n_${v.note}_` : ""}`).join("\n\n");
  }).filter(Boolean).join("\n\n") + "\n";
}
async function aiNewChat() {
  if (!(await modal(`<h3>Start a new chat?</h3><p>The AI forgets the requests so far and gets a fresh copy of the paper with your next request. Suggestions still in the text stay there to accept or reject.</p><div class="mrow"><button class="btn" data-cancel>Keep this chat</button><button class="btn danger" data-ok="ok">New chat</button></div>`))) return;
  const ai = aiState(); ai.thread = []; ai.paper = null; ai.feedback = []; ai.usage = { in: 0, out: 0, cacheRead: 0, cacheWrite: 0, calls: 0 };
  ai.log = ai.log.filter(e => e.t === "req" && aiSpan(e.id)); ai.log.push({ t: "info", at: Date.now(), text: "New chat started." }); markDirty(); aiRenderChat();
}
aiPanel.addEventListener("click", e => {
  const a = e.target.closest("[data-aiact]")?.dataset.aiact; if (!a) return;
  if (a === "settings") aiModelMenu(e.target.closest("button")); else if (a === "menu") aiChatMenu(e.target.closest("button")); else if (a === "newchat") aiNewChat(); else if (a === "where") aiWhere(); else if (a === "close") aiTogglePanel(false);
  else if (a === "send") { const ta = $("#aiQ"); const q = ta.value.trim(); if (!q) return ta.focus(); ta.value = ""; aiQuestion(q); }
});
$("#aiQ").addEventListener("keydown", e => { e.stopPropagation(); if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); $("[data-aiact=send]", aiPanel).click(); } });

/* ---- settings ---- */
async function aiSettings(msg) {
  const c = aiCfg(), p0 = c.provider;
  const provs = Object.entries(AI_PROVIDERS).map(([k, v]) => `<label class="opt"><input type="radio" name="provider" value="${k}"${k === p0 ? " checked" : ""}><div><b>${esc(v.label)}</b><span>${esc(v.sub)}</span></div></label>`).join("");
  const pr = modal(`<div class="ai-set-wrap"><h3>AI for this editor</h3>${msg ? `<p class="ai-msgline err">${esc(msg)}</p>` : `<p>Pick the AI that answers your requests. Keys stay in this browser and are sent only to that provider.</p>`}
    <div class="ai-provs">${provs}</div>
    <div class="ai-f" data-for="key"><label for="aiKeyIn">API key</label><div class="inrow"><input type="password" id="aiKeyIn" name="key" autocomplete="off" spellcheck="false"><button class="btn small" type="button" data-aitest>Check key, load models</button></div>
      <small data-keyhelp></small><label class="chk" style="margin-top:5px"><input type="checkbox" name="remember"${c.remember ? " checked" : ""}> Remember the key in this browser (otherwise it is forgotten when you close the tab)</label></div>
    <div class="ai-f" data-for="base"><label for="aiBaseIn">Server address</label><input type="text" id="aiBaseIn" name="base" placeholder="https://openrouter.ai/api/v1  or  http://localhost:11434/v1" value="${esc(c.base)}"><small>The part before /chat/completions. The server must accept calls from a web page (CORS); Ollama needs OLLAMA_ORIGINS=*.</small></div>
    <div class="ai-grid2"><div class="ai-f" data-for="model"><label for="aiModelIn">Model</label><select id="aiModelSel" aria-label="Claude model"></select><input type="text" id="aiModelIn" name="model" list="aiModelList" spellcheck="false"><datalist id="aiModelList"></datalist><small data-modelhelp></small></div>
      <div class="ai-f" data-for="effort"><label for="aiEffortIn">Effort (Claude)</label><select id="aiEffortIn" name="effort">${["", "low", "medium", "high", "xhigh", "max"].map(x => `<option value="${x}"${x === c.effort ? " selected" : ""}>${x ? x[0].toUpperCase() + x.slice(1) : "Model default"}</option>`).join("")}</select><small>How hard the model thinks; lower is faster and cheaper.</small></div></div>
    <div class="ai-f"><label for="aiPresetsIn">Quick requests in the menu (one per line)</label><textarea class="presets" id="aiPresetsIn" name="presets">${esc(c.presets.join("\n"))}</textarea></div>
    <p class="ai-msgline" data-aimsg></p>
    <div class="mrow"><button class="btn" data-cancel>Cancel</button><button class="btn primary" data-ok="ok">Save</button></div></div>`, { focus: msg ? "#aiKeyIn" : "button[data-ok]" });
  const m = $("#modal"); m.classList.add("ai-set");
  const val = () => $("input[name=provider]:checked", m).value, keys = {}, models = { ...c.models }; let shown = null;
  const line = (t, cls = "") => { const l = $("[data-aimsg]", m); l.textContent = t; l.className = "ai-msgline " + cls; };
  function show() {
    const p = val(), P = AI_PROVIDERS[p];
    if (shown) { keys[shown] = $("#aiKeyIn").value; models[shown] = $("#aiModelIn").value.trim(); } shown = p;
    $("#aiKeyIn").value = keys[p] ?? aiKey(p); $("#aiModelIn").value = models[p] ?? P.def ?? "";
    $(".ai-f[data-for=key]", m).hidden = p === "demo"; $(".ai-f[data-for=model]", m).hidden = p === "demo"; $(".ai-f[data-for=base]", m).hidden = p !== "custom"; $(".ai-f[data-for=effort]", m).hidden = p !== "claude";
    $("[data-keyhelp]", m).innerHTML = p === "claude" ? 'From <a href="https://platform.claude.com/settings/keys" target="_blank" rel="noopener">platform.claude.com → API keys</a>. Usage is billed to your Anthropic account.' : p === "openai" ? 'From <a href="https://platform.openai.com/api-keys" target="_blank" rel="noopener">platform.openai.com → API keys</a>.' : p === "gemini" ? 'From <a href="https://aistudio.google.com/apikey" target="_blank" rel="noopener">aistudio.google.com → API key</a>.' : "Leave empty if the server needs none.";
    $("[data-modelhelp]", m).textContent = p === "claude" ? "Price per million tokens in / out. A paragraph request is usually a few thousand tokens in (mostly cached) and a few hundred out." : "Type the model ID, or load the list with your key.";
    $("#aiModelList").innerHTML = ""; line(""); claudeSel(p === "claude" ? [] : null);
  }
  function claudeSel(extra) {
    const sel = $("#aiModelSel"), inp = $("#aiModelIn"); if (!extra) { sel.hidden = true; inp.hidden = false; return; }
    const more = extra.filter(id => !CLAUDE_MODELS.some(x => x[0] === id) && /^claude/.test(id));
    sel.innerHTML = `<optgroup label="Current">${CLAUDE_MODELS.slice(0, 4).map(([id, n, d, pr]) => `<option value="${id}">Claude ${n}: ${d} (${pr})</option>`).join("")}</optgroup><optgroup label="Earlier">${CLAUDE_MODELS.slice(4).map(([id, n, d, pr]) => `<option value="${id}">Claude ${n} (${pr})</option>`).join("")}</optgroup>${more.length ? `<optgroup label="Also on your account">${more.map(id => `<option value="${esc(id)}">${esc(id)}</option>`).join("")}</optgroup>` : ""}<option value="__other">Other: type a model ID…</option>`;
    const v = inp.value.trim() || AI_PROVIDERS.claude.def; sel.value = [...sel.options].some(o => o.value === v) ? v : "__other"; sel.hidden = false; inp.hidden = sel.value !== "__other";
  }
  $("#aiModelSel").addEventListener("change", e => { const v = e.target.value, inp = $("#aiModelIn"); if (v === "__other") { inp.hidden = false; inp.value = ""; inp.focus(); } else { inp.hidden = true; inp.value = v; } });
  $$("input[name=provider]", m).forEach(r => r.addEventListener("change", show)); show();
  $("[data-aitest]", m).addEventListener("click", async () => {
    const p = val(); line("Checking…");
    try { const ids = await aiListModels(p, $("#aiKeyIn").value.trim(), p === "custom" ? $("#aiBaseIn").value.trim() : AI_PROVIDERS[p].base || ""); if (p === "claude") claudeSel(ids); $("#aiModelList").innerHTML = ids.map(x => `<option value="${esc(x)}">`).join(""); line(`Key works. ${ids.length} models available: pick one in the Model box.`, "ok"); }
    catch (e) { line("Did not work: " + (e instanceof TypeError ? "could not reach the server" : e.message), "err"); }
  });
  const v = await pr; m.classList.remove("ai-set"); if (!v) return;
  keys[shown] = v.key; models[shown] = (v.model || "").trim();
  for (const [p, k] of Object.entries(keys)) if (p !== "demo") aiSetKey(p, (k || "").trim(), v.remember);
  aiSetCfg({ provider: v.provider, models: Object.fromEntries(Object.entries(models).filter(([, x]) => x)), base: (v.base || "").trim(), effort: v.effort, remember: v.remember, presets: (() => { const l = (v.presets || "").split("\n").map(x => x.trim()).filter(Boolean).slice(0, 16); return l.length ? l : AI_PRESETS; })() });
  aiHome(); if (S.doc) aiRenderChat(); toast("AI: " + aiWho());
}

function aiReviewMenu(anchor) {
  const n = $$(".ai-chg[data-ai]:not(.busy)", flowEl).length, h = allHunks().length;
  menu([{ head: n ? `${h} change${h === 1 ? "" : "s"} in ${n} AI suggestion${n === 1 ? "" : "s"}` : "No AI suggestions to review" },
    { label: (Prefs.get("aiMarkup", true) ? "✓ " : "") + "Show changes", sub: "Off: the text reads as if every change were accepted", fn: () => aiMarkup(!Prefs.get("aiMarkup", true)) },
    { sep: true }, { label: "Next change", k: "Alt+↓", fn: () => aiStep(1) }, { label: "Previous change", k: "Alt+↑", fn: () => aiStep(-1) },
    { label: "Accept change", k: "Tab", fn: () => aiDecide(aiHunk, true) }, { label: "Reject change", k: "Esc", fn: () => aiDecide(aiHunk, false) },
    { sep: true }, { label: "Accept all changes in the document", fn: () => aiDecideAll(true) }, { label: "Reject all changes in the document", fn: () => aiDecideAll(false) },
    { sep: true }, { label: "Ask AI about the selection", k: "Alt+A", fn: () => { useRange?.(); aiAskOpen(); } }, { label: "AI chat panel", fn: () => aiTogglePanel() }, { label: "AI model…", sub: aiWho(), fn: () => aiModelMenu(anchor) }, { label: "AI settings…", fn: () => aiSettings() }], anchor);
}
function aiHome() { const w = $("#aiHomeWho"); if (w) w.textContent = aiWho(); }

/* ---- keep exports, the web view and undo honest about pending suggestions ---- */
/* exports and saves write the text without unreviewed suggestions (their original text), like Word's "Original" view */
function withOriginals(fn) {
  return function (...args) {
    const chg = S.doc?.kind === "flow" ? $$(".ai-chg[data-ai]", flowEl) : []; if (!chg.length) return fn.apply(this, args);
    const saved = chg.map(el => { const f = aiChange(el.dataset.ai) ? aiOrigFrag(el) : document.createTextNode(el.textContent), nodes = f.nodeType === 11 ? [...f.childNodes] : [f]; if (!nodes.length) nodes.push(document.createTextNode("")); el.replaceWith(...nodes); return { el, nodes }; });
    const back = () => { for (const { el, nodes } of saved) { nodes[0].before(el); nodes.forEach(n => n.remove()); } };
    let r; try { r = fn.apply(this, args); } catch (e) { back(); throw e; }
    if (r && typeof r.then === "function") return r.finally(back);
    back(); return r;
  };
}
flowToMarkdown = withOriginals(flowToMarkdown); exportHtmlString = withOriginals(exportHtmlString); printFlow = withOriginals(printFlow);
{ const sb = sourceBlob; sourceBlob = async function (ext) { if (S.doc?.kind === "flow" && $(".ai-chg", flowEl)) toast("Suggestions you have not reviewed are saved as the original text."); return withOriginals(sb)(ext); }; }
{ const ew = enterWebView; enterWebView = function () { if (S.doc?.kind === "flow" && $(".ai-chg", flowEl)) return toast("Accept or reject the AI suggestions first (Tab or Esc on each), then open the web view."); return ew(); }; }
{ const rs = restore; restore = function (s) { rs(s); aiSync(); }; }
{ const sp = showSelPop; showSelPop = function () {
    sp(); const p = $(".selpop"); if (!p || S.doc?.kind !== "flow" || S.webview) return;
    const b = EL("button", { class: "ai-sp", title: "Ask AI about the selection (Alt+A)", onpointerdown: e => e.preventDefault(), onclick: e => { e.preventDefault(); aiAskOpen(); } }); b.append(ICON("i-ai")); b.append(" Ask AI"); b.querySelector("svg").style.cssText = "width:13px;height:13px;vertical-align:-2px";
    p.prepend(b);
  }; }
/* a change still marked busy in a saved copy (closed mid-request) goes back to its original text */
function aiSync() {
  if (S.doc?.kind !== "flow") { aiActive = null; aiBar(); return; }
  for (const s of $$(".ai-chg", flowEl)) { const ch = aiChange(s.dataset.ai); if (!ch || s.classList.contains("busy") || !ch.sugg[ch.cur]) { s.replaceWith(ch ? lightOrHtml(ch.oldHtml) : document.createTextNode(s.textContent)); continue; } if (ch.status !== "pending") ch.status = "pending"; }
  if (aiActive && !aiSpan(aiActive)) aiActive = null; aiSetActive(aiActive || $(".ai-chg[data-ai]", flowEl)?.dataset.ai || null); aiRenderChat();
}
{ const sd = showDoc; showDoc = async function () {
    aiActive = null; aiHunk = null; aiAskClose();
    if (S.doc?.kind === "flow" && /ai-chg/.test(S.doc.html || "")) { const t = EL("div", { html: S.doc.html }); for (const s of t.querySelectorAll(".ai-chg")) { const ch = S.doc.ai?.changes?.[s.dataset.ai]; if (!ch || s.classList.contains("busy") || !ch.sugg?.[ch.cur]) s.replaceWith(ch ? lightOrHtml(ch.oldHtml) : document.createTextNode(s.textContent)); else s.classList.remove("on"); } S.doc.html = t.innerHTML; }
    const r = await sd(); aiMarkup(); aiSync(); return r;
  }; }
{ const gh = goHome; goHome = function () { aiActive = null; aiHunk = null; aiBar(); aiAskClose(); return gh(); }; }

/* ---- the sample paper (made up, for trying the tools) ---- */
const AI_SAMPLE = `<h1>Sub-inhibitory ciprofloxacin and biofilm formation in <i>Pseudomonas aeruginosa</i></h1>
<p><i>A made-up draft for trying the AI tools. The study, numbers and wording are invented, and the prose is deliberately rough.</i></p>
<h2>Abstract</h2>
<p>Biofilms are a big problem in hospitals. Bacteria in biofilms are very hard to kill with antibiotics. We looked at what happens to <i>P. aeruginosa</i> PAO1 when it is grown with low doses of ciprofloxacin. It is important to note that we used doses below the MIC. Biofilm biomass went up by 2.1-fold at 0.25× MIC (p &lt; 0.01). This proves that low antibiotic levels cause biofilm formation and it will make infections worse.</p>
<h2>Introduction</h2>
<p><i>Pseudomonas aeruginosa</i> is an opportunistic pathogen. It causes a lot of infections in people with cystic fibrosis. It forms biofilms on surfaces like catheters. Biofilms are communities of cells in a matrix of polysaccharides, proteins and eDNA. Cells in biofilms are up to 1000 times more tolerant to antibiotics than planktonic cells. In order to treat these infections, doctors use high doses of antibiotics for a long time.</p>
<p>Antibiotic concentrations are not the same everywhere in the body. Some bacteria see concentrations below the minimum inhibitory concentration (MIC). Sub-MIC antibiotics don't kill bacteria, but they can change gene expression. Previous work has shown that some antibiotics increase biofilm formation at low doses. The effect of ciprofloxacin is not clear. Some studies found more biofilm and some found less. Due to the fact that results are mixed we wanted to test it again with a better method.</p>
<h2>Methods</h2>
<p>PAO1 was grown overnight in LB at 37 °C with shaking. Cultures were diluted 1:100 into fresh medium with ciprofloxacin at 0, 0.0625, 0.125 and 0.25× MIC (MIC = 0.125 µg mL<sup>−1</sup>). Biofilms were grown in 96-well plates for 24 h. Biomass was measured with crystal violet staining at OD<sub>595</sub>. Each condition had six wells and the experiment was done three times on different days.</p>
<h2>Results</h2>
<p>Ciprofloxacin at sub-MIC levels increased biofilm biomass. The increase was dose-dependent. At 0.25× MIC biomass was 2.1-fold higher than the control (p &lt; 0.01, one-way ANOVA with Dunnett's test). At 0.0625× MIC there was no significant difference. Planktonic growth was not changed at any concentration, so the effect is not due to differences in cell number. We also saw that the biofilms looked thicker under the microscope but we did not measure this.</p>
<h2>Discussion</h2>
<p>Our results show clearly that ciprofloxacin at low doses causes <i>P. aeruginosa</i> to make more biofilm. This is a really important finding. It means that patients who get low doses of antibiotics will always get worse infections. One possible mechanism is the SOS response, which is induced by DNA damage from fluoroquinolones. The SOS response may increase the release of eDNA, which is part of the biofilm matrix. However we did not test this. Future work should look at other strains and also use flow cells to look at biofilm structure.</p>`;

/* ---- wiring ---- */
document.addEventListener("click", e => {
  const b = e.target.closest("[data-act]"); if (!b) return; const a = b.dataset.act;
  if (a === "aiAsk") { e.preventDefault(); aiAskOpen(); }
  else if (a === "aiPanel") aiTogglePanel();
  else if (a === "aiSettings") aiSettings();
  else if (a === "aiMarkup") aiMarkup(!Prefs.get("aiMarkup", true));
  else if (a === "wReview") aiReviewMenu(b);
  else if (a === "aiSample") openDoc(newDoc("flow", "Sample paper (made up)", { html: AI_SAMPLE }));
});
$("[data-act=aiAsk]")?.addEventListener("pointerdown", e => e.preventDefault());
{ const bs = buildSwatches; let once = false; buildSwatches = function () { bs(); if (once) return; once = true; aiHome(); if (!Prefs.get("aiPanel", false)) aiTogglePanel(false); else { $("#aiPanelBtn")?.classList.add("on"); if (innerWidth < 1500) $("#right").classList.add("closed"); } }; }
Object.assign(window, { aiAskOpen, aiRequest, aiAccept, aiReject, aiAgain, aiSettings, aiDiff, aiState, aiTarget, demoRevise });

/* ---------- Doc Reader: Word-style editing for documents ----------
   Fonts and sizes, page width and margins, an offline spell checker (nspell + Hunspell en-GB / en-US),
   footnotes, table of contents, symbols, page breaks, change case, spacing, format painter, word count,
   and Word / Google Docs keyboard shortcuts. Runs inside Doc Reader's scope like ai.js. */

const W = { range: null, painter: null, painterArmed: false };
const flowOn = () => S.doc?.kind === "flow" && !S.webview;
function saveRange() { const s = getSelection(); if (s.rangeCount && flowEl.contains(s.anchorNode)) W.range = s.getRangeAt(0).cloneRange(); }
function useRange() {
  flowEl.focus({ preventScroll: true }); const s = getSelection();
  if (W.range && flowEl.contains(W.range.commonAncestorContainer) && !(s.rangeCount && flowEl.contains(s.anchorNode) && s.getRangeAt(0).compareBoundaryPoints(Range.START_TO_START, W.range) === 0 && s.getRangeAt(0).compareBoundaryPoints(Range.END_TO_END, W.range) === 0)) { s.removeAllRanges(); s.addRange(W.range); }
  return s;
}
const WORDCH = /[\p{L}\p{N}\p{M}'’-]/u;
function wordAtCaret(sel) {
  const n = sel.anchorNode, o = sel.anchorOffset; if (!n || n.nodeType !== 3) return null;
  const t = n.data; let a = o, b = o; while (a > 0 && WORDCH.test(t[a - 1])) a--; while (b < t.length && WORDCH.test(t[b])) b++;
  if (a === b) return null; const r = document.createRange(); r.setStart(n, a); r.setEnd(n, b); return r;
}
/* the selection, or the word at the caret, like Word */
function targetSel() { const sel = useRange(); if (!sel.rangeCount || !flowEl.contains(sel.anchorNode)) return null; if (sel.isCollapsed) { const r = wordAtCaret(sel); if (!r) return null; sel.removeAllRanges(); sel.addRange(r); } return sel; }
function done() { const s = getSelection(); if (s.rangeCount && flowEl.contains(s.anchorNode)) W.range = s.getRangeAt(0).cloneRange(); flowChanged(); syncFontUI(); }
const C = name => () => { useRange(); cmd(name); };

/* zoom multiplies sizes (font sizes, page width, padding) by --z instead of using CSS zoom on the text,
   so writing extensions that copy the editor's styles to measure it (Grammarly) see the real sizes */
const zf = () => S.flowZoom || 1;
const zsize = v => `calc(${v} * var(--z, 1))`;
const ZRE = /calc\(\s*([\d.]+(?:pt|px))\s*\*\s*var\(--z(?:,\s*1)?\)\s*\)/g;
function zoomifySizes(root = flowEl) { for (const el of $$("[style*='font-size']", root)) { const v = el.style.fontSize; if (v && !v.includes("--z") && /^[\d.]+(pt|px)$/.test(v)) el.style.fontSize = zsize(v); } }

/* ---- fonts and sizes ---- */
const FONTS = [["", "Default"], ["Calibri, Carlito, 'Segoe UI', sans-serif", "Calibri"], ["Arial, Helvetica, sans-serif", "Arial"], ["'Helvetica Neue', Helvetica, Arial, sans-serif", "Helvetica"], ["'Times New Roman', Times, serif", "Times New Roman"], ["Georgia, serif", "Georgia"], ["Cambria, Caladea, Georgia, serif", "Cambria"], ["Charter, 'Iowan Old Style', Georgia, serif", "Charter"], ["Garamond, 'EB Garamond', 'Times New Roman', serif", "Garamond"], ["'Palatino Linotype', Palatino, 'Book Antiqua', serif", "Palatino"], ["Verdana, sans-serif", "Verdana"], ["Tahoma, sans-serif", "Tahoma"], ["'Trebuchet MS', sans-serif", "Trebuchet MS"], ["'Segoe UI', system-ui, sans-serif", "Segoe UI"], ["system-ui, sans-serif", "System sans"], ["'Courier New', Courier, monospace", "Courier New"], ["Consolas, Menlo, monospace", "Consolas"]];
const SIZES = [8, 9, 10, 10.5, 11, 12, 14, 16, 18, 20, 22, 24, 28, 32, 36, 48, 60, 72];
const firstFam = f => String(f || "").split(",")[0].trim().replace(/^["']|["']$/g, "").toLowerCase();
const fontSel = $("#fontSel"), sizeSel = $("#sizeSel");
fontSel.innerHTML = FONTS.map(([v, n]) => `<option value="${esc(v)}" style="font-family:${esc(v || "inherit")}">${esc(n)}</option>`).join("");
sizeSel.innerHTML = SIZES.map(s => `<option value="${s}">${s}</option>`).join("");
for (const el of [fontSel, sizeSel]) { el.addEventListener("pointerdown", saveRange); el.addEventListener("keydown", e => { if (e.key === "Escape") { e.preventDefault(); useRange(); } }); }
fontSel.addEventListener("change", () => setFont(fontSel.value));
sizeSel.addEventListener("change", () => setSize(+sizeSel.value));
function tidySpans(root = flowEl) { for (const s of $$("span[style=''],span:not([class]):not([style]):not([data-id]):not([data-ai])", root)) { if (!s.attributes.length || (s.attributes.length === 1 && s.getAttribute("style") === "")) s.replaceWith(...s.childNodes); } }
function inlineStyle(prop, value) {
  const sel = targetSel(); if (!sel) { toast("Select text first, or put the cursor in a word."); return false; }
  const range = sel.getRangeAt(0), camel = prop === "font-family" ? "fontFamily" : "fontSize";
  document.execCommand("styleWithCSS", false, true);
  if (prop === "font-family") document.execCommand("fontName", false, "lp-mark-font"); else document.execCommand("fontSize", false, "7");
  document.execCommand("styleWithCSS", false, false);
  const marked = prop === "font-family" ? $$('[style*="lp-mark-font"], font[face="lp-mark-font"]', flowEl) : $$('[style*="xxx-large"], font[size="7"]', flowEl);
  let first = null, last = null;
  for (let el of marked) {
    if (el.tagName === "FONT") { const sp = EL("span"); while (el.firstChild) sp.append(el.firstChild); el.replaceWith(sp); el = sp; }
    let v = value || ""; if (!v && prop === "font-family") { const anc = el.parentElement?.closest("[style*='font-family']"); if (anc && anc !== flowEl && flowEl.contains(anc)) v = getComputedStyle(flowEl).fontFamily; }
    el.style[camel] = camel === "fontSize" && v ? zsize(v) : v; $$("[style]", el).forEach(c => { c.style[camel] = ""; });
    if (!el.getAttribute("style")) el.removeAttribute("style");
    first = first || el; last = el;
  }
  tidySpans();
  if (first && first.isConnected && last.isConnected) { const r = document.createRange(); r.setStart(first, 0); r.setEnd(last, last.childNodes.length); sel.removeAllRanges(); sel.addRange(r); }
  done(); return true;
}
function setFont(v) { inlineStyle("font-family", v); }
function setSize(pt) { if (pt > 0) inlineStyle("font-size", pt + "pt"); }
function curSize() { const s = getSelection(); const el = s.rangeCount && flowEl.contains(s.anchorNode) ? elOf(s.anchorNode) : flowEl; return Math.round(parseFloat(getComputedStyle(el).fontSize) * 0.75 / zf() * 2) / 2; }
function stepSize(d) { saveRange(); const c = curSize(); const n = d > 0 ? SIZES.find(s => s > c + 0.01) || c + 12 : [...SIZES].reverse().find(s => s < c - 0.01) || Math.max(1, c - 1); setSize(n); }
function bumpSize(d) { saveRange(); setSize(Math.max(1, curSize() + d)); }
function syncFontUI() {
  if (!flowOn()) return; const s = getSelection();
  const el = s.rangeCount && flowEl.contains(s.anchorNode) ? elOf(s.anchorNode) : flowEl, cs = getComputedStyle(el), pt = Math.round(parseFloat(cs.fontSize) * 0.75 / zf() * 2) / 2;
  if (![...sizeSel.options].some(o => +o.value === pt)) { $$("option.tmp", sizeSel).forEach(o => o.remove()); sizeSel.prepend(EL("option", { class: "tmp", value: pt }, String(pt))); }
  sizeSel.value = String(pt);
  const fam = firstFam(cs.fontFamily), base = firstFam(getComputedStyle(flowEl).fontFamily), own = el.closest("[style*='font-family']");
  let opt = !own || !flowEl.contains(own) || fam === base ? "" : (FONTS.find(([v]) => v && firstFam(v) === fam) || [])[0];
  if (opt == null) { $$("option.tmp", fontSel).forEach(o => o.remove()); fontSel.prepend(EL("option", { class: "tmp", value: cs.fontFamily }, fam)); opt = cs.fontFamily; }
  fontSel.value = opt;
}
{ const uft = updateFlowToolbar; updateFlowToolbar = function () { uft(); syncFontUI(); }; }

/* ---- paragraphs: spacing, indent, move, clear ---- */
const PBLOCK = "p,h1,h2,h3,h4,h5,h6,li,blockquote,pre,figcaption,dd,dt,td,th";
function selBlocks() {
  const sel = useRange(); if (!sel.rangeCount) return []; const r = sel.getRangeAt(0);
  let bs = $$(PBLOCK, flowEl).filter(b => r.intersectsNode(b) && !b.querySelector(PBLOCK) && !b.closest("nav.toc"));
  if (!bs.length) { let n = elOf(r.startContainer); while (n && n.parentElement !== flowEl) n = n.parentElement; if (n && n !== flowEl) bs = [n]; }
  return bs;
}
function blockStyle(prop, val) { const bs = selBlocks(); if (!bs.length) return toast("Put the cursor in a paragraph first."); bs.forEach(b => { b.style[prop] = typeof val === "function" ? val(b) : val; if (!b.getAttribute("style")) b.removeAttribute("style"); }); done(); }
const lineSpacing = v => blockStyle("lineHeight", v);
/* v8: indent like Word. Tab (or Ctrl+M) at the very start of a paragraph gives it a first-line indent; again,
   or anywhere else, moves the whole paragraph in by a step; Shift+Tab (Ctrl+Shift+M) takes a step back.
   Lists still nest as before. (Older versions wrapped the paragraph in a quote block.) */
/* the paragraphs under the cursor now (not a selection saved earlier by a toolbar menu) */
function liveBlocks() {
  const s = getSelection(); if (!s.rangeCount || !flowEl.contains(s.anchorNode)) return selBlocks(); const r = s.getRangeAt(0);
  let bs = $$(PBLOCK, flowEl).filter(b => r.intersectsNode(b) && !b.querySelector(PBLOCK) && !b.closest("nav.toc"));
  if (!bs.length) { let n = elOf(r.startContainer); while (n && n.parentElement !== flowEl) n = n.parentElement; if (n && n !== flowEl) bs = [n]; }
  return bs;
}
function indentBlocks(d) {
  const sel = getSelection(), bs = liveBlocks().filter(b => !b.closest("li,td,th,pre")); if (!bs.length) return false;
  const r = sel.rangeCount ? sel.getRangeAt(0) : null;
  const atStart = b => { if (!r || !r.collapsed) return false; const x = document.createRange(); x.setStart(b, 0); x.setEnd(r.startContainer, r.startOffset); return !x.toString().length; };
  const em = b => { const m = b.style.marginLeft || ""; return m.endsWith("em") ? parseFloat(m) : m.endsWith("px") ? parseFloat(m) / 16 : 0; };
  for (const b of bs) {
    if (d > 0) { if (bs.length === 1 && atStart(b) && !b.style.textIndent) b.style.textIndent = "2em"; else b.style.marginLeft = (em(b) + 2) + "em"; }
    else { const m = em(b); if (m > 0) b.style.marginLeft = m - 2 > 0 ? (m - 2) + "em" : ""; else b.style.textIndent = ""; }
    if (!b.getAttribute("style")) b.removeAttribute("style");
  }
  flowChanged(); return true;
}
{ const c0 = cmd; cmd = function (name) { if ((name === "indent" || name === "outdent") && flowOn() && !liveBlocks().some(b => b.closest("li")) && indentBlocks(name === "indent" ? 1 : -1)) return; return c0.apply(this, arguments); }; }
function clearParagraph() { const bs = selBlocks(); bs.forEach(b => { b.removeAttribute("style"); b.removeAttribute("align"); }); done(); }
function moveBlock(d) {
  const sel = getSelection(); if (!sel.rangeCount) return; let b = elOf(sel.anchorNode).closest("li") || elOf(sel.anchorNode);
  if (!b.closest("li")) while (b && b.parentElement !== flowEl) b = b.parentElement;
  if (!b || b === flowEl) return; const sib = d < 0 ? b.previousElementSibling : b.nextElementSibling; if (!sib || sib.matches("ol.footnotes,hr.fn-sep")) return;
  const r = sel.getRangeAt(0).cloneRange(); d < 0 ? sib.before(b) : sib.after(b); sel.removeAllRanges(); sel.addRange(r); b.scrollIntoView({ block: "nearest" }); done();
}
function spacingMenu(anchor) {
  saveRange(); const cur = (() => { const b = selBlocks()[0]; return b ? b.style.lineHeight : ""; })();
  menu([{ head: "Line spacing" }, ...[["1", "Single", "Ctrl+1"], ["1.15", "1.15", ""], ["1.5", "1.5 lines", "Ctrl+5"], ["2", "Double", "Ctrl+2"], ["", "Document default", ""]].map(([v, l, k]) => ({ label: l, k, on: cur === v, fn: () => lineSpacing(v) })),
    { sep: true }, { head: "Paragraph" },
    { label: "No space after paragraphs", fn: () => blockStyle("marginBottom", "0") }, { label: "Add space after paragraphs", fn: () => blockStyle("marginBottom", "1.2em") },
    { label: "First-line indent on / off", fn: () => blockStyle("textIndent", b => b.style.textIndent ? "" : "2em") },
    { label: "Increase indent", k: "Ctrl+M", fn: C("indent") }, { label: "Decrease indent", k: "Ctrl+Shift+M", fn: C("outdent") },
    { label: "Clear paragraph formatting", k: "Ctrl+Q", fn: clearParagraph }], anchor);
}

/* ---- change case ---- */
const SMALL = new Set("a an and as at but by for in nor of on or per the to vs via with".split(" "));
const titleCase = s => s.toLowerCase().replace(/[\p{L}][\p{L}'’]*/gu, (w, i) => i > 0 && SMALL.has(w) ? w : w[0].toUpperCase() + w.slice(1));
const sentenceCase = s => s.toLowerCase().replace(/(^\s*|[.!?]\s+)(\p{L})/gu, (m, a, c) => a + c.toUpperCase());
function changeCase(mode) {
  const sel = targetSel(); if (!sel) return toast("Select text first.");
  const r = sel.getRangeAt(0), nodes = rangeTextNodes(r); if (!nodes.length) return; const all = nodes.map(n => n.data).join("");
  if (mode === "cycle") mode = all === all.toUpperCase() ? "lower" : all === all.toLowerCase() ? "title" : "upper";
  const fn = { upper: s => s.toUpperCase(), lower: s => s.toLowerCase(), title: titleCase, sentence: sentenceCase }[mode];
  const out = fn(all); let i = 0; for (const n of nodes) { n.data = out.slice(i, i + n.data.length); i += n.data.length; }
  const nr = document.createRange(); nr.setStart(nodes[0], 0); nr.setEnd(nodes.at(-1), nodes.at(-1).data.length); sel.removeAllRanges(); sel.addRange(nr); done();
}
function smallCaps() { const sel = targetSel(); if (!sel) return toast("Select text first."); const r = sel.getRangeAt(0); const on = getComputedStyle(elOf(r.startContainer)).fontVariantCaps === "small-caps"; const sp = EL("span", { style: on ? "font-variant:normal" : "font-variant:small-caps" }); sp.append(r.extractContents()); r.insertNode(sp); $$("[style*='font-variant']", sp).forEach(c => c.style.fontVariant = ""); tidySpans(); const nr = document.createRange(); nr.selectNodeContents(sp); sel.removeAllRanges(); sel.addRange(nr); done(); }

/* ---- format painter ---- */
function copyFormat() {
  const s = getSelection(); if (!s.rangeCount || !flowEl.contains(s.anchorNode)) return toast("Put the cursor in the text whose look you want to copy.");
  const el = elOf(s.getRangeAt(0).startContainer), cs = getComputedStyle(el), fcs = getComputedStyle(flowEl);
  W.painter = { b: +cs.fontWeight >= 600, i: cs.fontStyle === "italic", u: !!el.closest("u"), s: !!el.closest("s,strike,del:not(.ai-d)"), sup: !!el.closest("sup"), sub: !!el.closest("sub"), color: cs.color !== fcs.color ? cs.color : "", family: cs.fontFamily !== fcs.fontFamily ? cs.fontFamily : "", size: cs.fontSize !== fcs.fontSize ? Math.round(parseFloat(cs.fontSize) * 0.75 / zf() * 2) / 2 : 0, caps: cs.fontVariantCaps === "small-caps" };
  W.painterArmed = true; $("[data-act=wPainter]")?.classList.add("on"); toast("Format copied: select text to paint it (or Ctrl+Alt+V).");
}
function pasteFormat() {
  const p = W.painter; if (!p) return toast("Copy a format first (Ctrl+Alt+C or the brush)."); const sel = targetSel(); if (!sel) return toast("Select text to paint.");
  W.painterArmed = false; $("[data-act=wPainter]")?.classList.remove("on");
  document.execCommand("removeFormat"); for (const [k, c] of [["b", "bold"], ["i", "italic"], ["u", "underline"], ["s", "strikeThrough"], ["sup", "superscript"], ["sub", "subscript"]]) if (p[k]) document.execCommand(c);
  if (p.color) document.execCommand("foreColor", false, p.color);
  saveRange(); if (p.family) inlineStyle("font-family", p.family); if (p.size) inlineStyle("font-size", p.size + "pt"); if (p.caps) smallCaps(); done();
}
flowEl.addEventListener("mouseup", () => { if (W.painterArmed && !getSelection().isCollapsed) setTimeout(pasteFormat, 0); });

/* ---- insert: page break, footnotes, contents, symbols, date ---- */
function pageBreak() { useRange(); insertHtml('<hr class="page-break"><p><br></p>'); }
function insertFootnote() {
  const sel = useRange(); if (!sel.rangeCount || !flowEl.contains(sel.anchorNode)) return toast("Put the cursor where the footnote mark goes.");
  if (elOf(sel.anchorNode).closest("ol.footnotes")) return toast("Footnotes go in the text, not in the footnote list.");
  const id = uid(), r = sel.getRangeAt(0); r.collapse(false);
  const ref = EL("sup", { class: "fn-ref", "data-fn": id, contenteditable: "false", title: "Footnote: click to edit" }, "?"); r.insertNode(ref);
  fnRenumber(); const li = $(`ol.footnotes li[data-fn="${id}"]`, flowEl); const nr = document.createRange(); nr.selectNodeContents(li); nr.collapse(false); sel.removeAllRanges(); sel.addRange(nr);
  li.scrollIntoView({ block: "center" }); flowChanged();
}
function fnRenumber() {
  const refs = $$("sup.fn-ref[data-fn]", flowEl).filter(r => !r.closest("ol.footnotes")); let list = $("ol.footnotes", flowEl), ch = false;
  if (!refs.length) { if (list) { list.previousElementSibling?.matches("hr.fn-sep") && list.previousElementSibling.remove(); list.remove(); return true; } return false; }
  if (!list) { list = EL("ol", { class: "footnotes" }); flowEl.append(EL("hr", { class: "fn-sep" }), list); ch = true; }
  if (list.nextElementSibling) { const sep = list.previousElementSibling?.matches("hr.fn-sep") ? list.previousElementSibling : null; flowEl.append(...(sep ? [sep] : []), list); ch = true; }
  refs.forEach((r, i) => { const n = String(i + 1); if (r.textContent !== n) { r.textContent = n; ch = true; } });
  const order = refs.map(r => r.dataset.fn), lis = new Map();
  for (const li of [...list.children]) { if (li.tagName !== "LI") { li.remove(); ch = true; continue; } if (!li.dataset.fn) { const prev = li.previousElementSibling; if (prev) { prev.append(EL("br"), ...li.childNodes); } li.remove(); ch = true; continue; } lis.set(li.dataset.fn, li); }
  for (const [id, li] of lis) if (!order.includes(id)) { li.remove(); ch = true; }
  let prev = null; for (const id of order) { let li = lis.get(id); if (!li) { li = EL("li", { "data-fn": id }); li.innerHTML = "<br>"; ch = true; } const want = prev ? prev.nextSibling : list.firstChild; if (want !== li) { list.insertBefore(li, want); ch = true; } prev = li; }
  return ch;
}
const slug = s => s.toLowerCase().replace(/[^\p{L}\p{N}]+/gu, "-").replace(/^-|-$/g, "").slice(0, 40) || "section";
function tocHtml() {
  const hs = $$("h2,h3,h4", flowEl).filter(h => !h.closest("nav.toc") && h.textContent.trim()); const used = new Set();
  hs.forEach(h => { let id = h.id || "h-" + slug(h.textContent); while (used.has(id)) id += "-2"; used.add(id); if (h.id !== id) h.id = id; });
  return `<p class="toc-h">Contents</p><ol>${hs.map(h => `<li class="toc-${h.tagName.toLowerCase()}"><a href="#${h.id}">${esc(h.textContent.trim())}</a></li>`).join("") || "<li>Add headings (Heading 1-3) to fill the contents.</li>"}</ol>`;
}
function insertToc() { useRange(); insertHtml(`<nav class="toc" contenteditable="false" data-toc>${tocHtml()}</nav><p><br></p>`); }
function tocUpdate() { const t = $("nav.toc", flowEl); if (!t) return false; const h = tocHtml(); if (t.innerHTML === h) return false; t.innerHTML = h; return true; }
flowEl.addEventListener("click", e => {
  const a = e.target.closest("nav.toc a"); if (a) { e.preventDefault(); $(a.getAttribute("href"), flowEl)?.scrollIntoView({ block: "start", behavior: "smooth" }); return; }
  const f = e.target.closest("sup.fn-ref"); if (f) { const li = $(`ol.footnotes li[data-fn="${f.dataset.fn}"]`, flowEl); if (li) { li.scrollIntoView({ block: "center", behavior: "smooth" }); const r = document.createRange(); r.selectNodeContents(li); r.collapse(false); getSelection().removeAllRanges(); getSelection().addRange(r); flashEl(li); } }
});
flowEl.addEventListener("dblclick", e => { const li = e.target.closest("ol.footnotes li[data-fn]"); if (li && e.offsetX < 0) { const f = $(`sup.fn-ref[data-fn="${li.dataset.fn}"]`, flowEl); f?.scrollIntoView({ block: "center", behavior: "smooth" }); } });
const SYMBOLS = [["Greek", "α β γ δ ε ζ η θ ι κ λ μ ν ξ π ρ σ τ υ φ χ ψ ω Γ Δ Θ Λ Ξ Π Σ Φ Ψ Ω"], ["Maths", "± × ÷ · ≈ ≠ ≡ ≤ ≥ ≪ ≫ ∝ ∞ √ ∑ ∏ ∫ ∂ ∇ ∆ ∈ ∉ ∩ ∪ ⊂ ⊆ ∀ ∃ ¬ ∧ ∨ ′ ″ ‰ ‱"], ["Units and science", "µ ° ℃ ℉ Å Ω ℓ ⁻ ⁺ ⁰ ¹ ² ³ ⁴ ⁵ ⁶ ⁷ ⁸ ⁹ ₀ ₁ ₂ ₃ ₄ ₅ ₆ ₇ ₈ ₉ ½ ⅓ ¼ ¾ ♀ ♂ ☐ ☑"], ["Arrows", "→ ← ↑ ↓ ↔ ⇌ ⇄ ⇒ ⇐ ⇔ ↗ ↘ ⟶"], ["Punctuation", "– — … ‐ • · § ¶ † ‡ © ® ™ “ ” ‘ ’ « » ‹ › ¿ ¡ №"]];
function symbolDialog() {
  saveRange(); const recent = Prefs.get("recentSym", []);
  const grid = (t, s) => `<div class="sym-g"><div class="sym-t">${t}</div><div class="sym-row">${s.map(c => `<button type="button" data-sym="${esc(c)}" title="U+${c.codePointAt(0).toString(16).toUpperCase().padStart(4, "0")}">${esc(c)}</button>`).join("")}</div></div>`;
  modal(`<h3>Insert a symbol</h3><p>Click to insert at the cursor; the dialog stays open. Non-breaking space: Ctrl+Shift+Space.</p>${recent.length ? grid("Recently used", recent) : ""}${SYMBOLS.map(([t, s]) => grid(t, s.split(" "))).join("")}<div class="mrow"><button class="btn primary" data-cancel>Done</button></div>`);
  $$("#modal [data-sym]").forEach(b => b.onclick = () => { const c = b.dataset.sym; useRange(); document.execCommand("insertText", false, c); saveRange(); Prefs.set("recentSym", [c, ...Prefs.get("recentSym", []).filter(x => x !== c)].slice(0, 16)); });
}
const insertDate = () => { useRange(); document.execCommand("insertText", false, new Date().toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" })); };

/* ---- page: width (A4, Letter, wide, fill the stage, any width by dragging the edge), margins, defaults ---- */
const PAGE_W = { a4: 794, letter: 816, wide: 1150 };
const paper = $(".flow-paper"), grip = EL("div", { class: "page-grip", title: "Drag to change the page width · double-click: fill the stage / back to A4" }); paper.append(grip);
function pageCfg() { return { w: "a4", px: 900, m: "normal", font: "", size: 12, lh: "", ...(Prefs.get("pageDefaults", {}) || {}), ...(S.doc?.meta?.page || {}) }; }
function applyPage() {
  if (S.doc?.kind !== "flow") return; const p = pageCfg();
  paper.dataset.w = p.w; paper.style.setProperty("--pw", (p.w === "custom" ? p.px : PAGE_W[p.w] || 794) + "px"); flowEl.dataset.m = p.m;
  flowEl.style.fontFamily = p.font || ""; flowEl.style.fontSize = ""; flowEl.style.setProperty("--fs", p.size ? p.size + "pt" : ""); flowEl.style.lineHeight = p.lh || "";
  requestAnimationFrame(() => { placeGrip(); layoutMargin(); placeBar?.(); nudgeOverlays(); });
}
function setPage(patch, asDefault) { if (!S.doc) return; S.doc.meta = S.doc.meta || {}; S.doc.meta.page = { ...pageCfg(), ...patch }; if (asDefault) Prefs.set("pageDefaults", { ...S.doc.meta.page }); applyPage(); markDirty(); }
function placeGrip() { const pr = paper.getBoundingClientRect(), fr = flowEl.getBoundingClientRect(); grip.style.left = (fr.right - pr.left - 5) + "px"; grip.style.top = (fr.top - pr.top) + "px"; grip.style.height = fr.height + "px"; }
grip.addEventListener("pointerdown", e => {
  e.preventDefault(); grip.setPointerCapture(e.pointerId); const z = S.flowZoom || 1, x0 = e.clientX, w0 = flowEl.getBoundingClientRect().width / z; grip.classList.add("on");
  const mv = ev => { const w = Math.round(clamp(w0 + (ev.clientX - x0) * 2 / z, 420, 4000)); S.doc.meta.page = { ...pageCfg(), w: "custom", px: w }; applyPage(); status(`Page width ${w}px (${(w / 37.8).toFixed(1)} cm)`); };
  const up = () => { grip.classList.remove("on"); grip.removeEventListener("pointermove", mv); grip.removeEventListener("pointerup", up); markDirty(); };
  grip.addEventListener("pointermove", mv); grip.addEventListener("pointerup", up);
});
grip.addEventListener("dblclick", () => setPage({ w: pageCfg().w === "fill" ? "a4" : "fill" }));
addEventListener("resize", debounce(placeGrip, 100));
function pageMenu(anchor) {
  const p = pageCfg();
  menu([{ head: "Page width" }, ...[["a4", "A4 (21 cm)"], ["letter", "US Letter (21.6 cm)"], ["wide", "Wide"], ["fill", "Fill the stage", "No page edges: the text uses the whole window"]].map(([w, l, sub]) => ({ label: l, sub, on: p.w === w, fn: () => setPage({ w }) })),
    { label: p.w === "custom" ? `Custom: ${p.px}px` : "Custom width", sub: "Drag the right edge of the page", on: p.w === "custom", fn: () => toast("Drag the right edge of the page to any width; double-click it to fill the stage.") },
    { sep: true }, { head: "Margins" }, ...[["narrow", "Narrow"], ["normal", "Normal"], ["wide", "Wide"]].map(([m, l]) => ({ label: l, on: p.m === m, fn: () => setPage({ m }) })),
    { sep: true }, { label: "Page setup…", sub: "Default font, size and line spacing; keep as default for new documents", fn: pageSetup }], anchor, { right: true });
}
async function pageSetup() {
  const p = pageCfg();
  const v = await modal(`<h3>Page setup</h3><p>For this document. Tick the box to use it for new documents too.</p>
    <div class="ai-grid2"><div class="ai-f"><label>Page width</label><select name="w">${[["a4", "A4"], ["letter", "US Letter"], ["wide", "Wide"], ["fill", "Fill the stage"], ["custom", "Custom"]].map(([k, l]) => `<option value="${k}"${p.w === k ? " selected" : ""}>${l}</option>`).join("")}</select></div>
    <div class="ai-f"><label>Custom width (px)</label><input type="text" name="px" value="${p.px}" inputmode="numeric"></div>
    <div class="ai-f"><label>Margins</label><select name="m">${[["narrow", "Narrow"], ["normal", "Normal"], ["wide", "Wide"]].map(([k, l]) => `<option value="${k}"${p.m === k ? " selected" : ""}>${l}</option>`).join("")}</select></div>
    <div class="ai-f"><label>Line spacing</label><select name="lh">${[["", "Default"], ["1", "Single"], ["1.15", "1.15"], ["1.5", "1.5"], ["2", "Double"]].map(([k, l]) => `<option value="${k}"${String(p.lh) === k ? " selected" : ""}>${l}</option>`).join("")}</select></div>
    <div class="ai-f"><label>Font</label><select name="font">${FONTS.map(([k, l]) => `<option value="${esc(k)}"${p.font === k ? " selected" : ""}>${esc(l)}</option>`).join("")}</select></div>
    <div class="ai-f"><label>Size (pt)</label><select name="size"><option value="0">Default</option>${SIZES.map(s => `<option value="${s}"${+p.size === s ? " selected" : ""}>${s}</option>`).join("")}</select></div></div>
    <div class="chkrow"><label><input type="checkbox" name="def"> Use for new documents</label></div>
    <div class="mrow"><button class="btn" data-cancel>Cancel</button><button class="btn primary" data-ok="ok">Apply</button></div>`);
  if (!v) return; setPage({ w: v.w, px: clamp(+v.px || 900, 420, 4000), m: v.m, lh: v.lh, font: v.font, size: +v.size }, v.def);
}

/* ---- zoom: sizes scale through --z (see zsize); only the comment margin and pictures use CSS zoom, never the text ---- */
{ const sz = setZoom; setZoom = async function (mode, val) {
    if (S.doc?.kind !== "flow") return sz(mode, val);
    S.flowZoom = mode === "custom" ? clamp(val, .4, 3) : 1; S.zoomMode = mode === "custom" ? "custom" : "width"; const z = S.flowZoom;
    paper.style.zoom = ""; flowEl.style.zoom = ""; marginEl.style.zoom = z === 1 ? "" : z; paper.style.setProperty("--z", z);
    $("#zoomVal").textContent = Math.round(z * 100) + "%"; layoutMargin(); placeGrip(); nudgeOverlays();
  }; }
/* tell spelling and grammar extensions (Grammarly and the like) that the text moved, so they re-measure their underlines */
const nudgeOverlays = debounce(() => { dispatchEvent(new Event("resize")); viewer.dispatchEvent(new Event("scroll")); placeBar(); }, 60);

/* ---- word count ---- */
const wcPill = EL("button", { class: "wc-pill", type: "button", title: "Word count (Ctrl+Shift+G)", onclick: () => wordCountDialog() }); viewer.append(wcPill);
function textOfNode(root) { let s = ""; const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT, { acceptNode: n => n.nodeType === 1 ? (n.matches("del.ai-d,.ai-old,sup.fn-ref,nav.toc") ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_SKIP) : NodeFilter.FILTER_ACCEPT }); let n; while ((n = w.nextNode())) s += n.data + (/^(P|LI|H\d|TD|TH|BLOCKQUOTE|FIGCAPTION|PRE)$/.test(n.parentElement.tagName) && !n.nextSibling ? "\n" : ""); return s; }
const countWords = s => (s.match(/[\p{L}\p{N}]+(?:['’\-.][\p{L}\p{N}]+)*/gu) || []).length;
function wcUpdate() {
  if (!flowOn()) { wcPill.hidden = true; return; } wcPill.hidden = false;
  const total = countWords(textOfNode(flowEl)), s = getSelection();
  const selW = s.rangeCount && !s.isCollapsed && flowEl.contains(s.anchorNode) ? countWords(s.toString()) : 0;
  wcPill.textContent = (selW ? `${selW.toLocaleString("en")} of ` : "") + `${total.toLocaleString("en")} word${total === 1 ? "" : "s"}`;
}
const wcSoon = debounce(wcUpdate, 300);
function wordCountDialog() {
  const t = textOfNode(flowEl), s = getSelection(), sel = s.rangeCount && !s.isCollapsed && flowEl.contains(s.anchorNode) ? s.toString() : "";
  const st = x => ({ w: countWords(x), c: x.replace(/\s/g, "").length, cs: x.replace(/\n/g, "").length, p: x.split(/\n+/).filter(l => l.trim()).length, sn: (x.match(/[^.!?]+[.!?]+(\s|$)/g) || []).length });
  const a = st(t), b = sel ? st(sel) : null, fn = $$("ol.footnotes li", flowEl).length, mins = Math.max(1, Math.round(a.w / 238));
  const row = (l, k) => `<tr><td>${l}</td><td>${a[k].toLocaleString("en")}</td>${b ? `<td>${b[k].toLocaleString("en")}</td>` : ""}</tr>`;
  modal(`<h3>Word count</h3><table class="wc-t"><tr><th></th><th>Document</th>${b ? "<th>Selection</th>" : ""}</tr>${row("Words", "w")}${row("Characters (no spaces)", "c")}${row("Characters (with spaces)", "cs")}${row("Paragraphs", "p")}${row("Sentences", "sn")}</table><p>Footnotes: ${fn}. Reading time about ${mins} min (238 words per minute). Counts include footnotes and leave out the contents list and suggestions not yet accepted.</p><div class="mrow"><button class="btn primary" data-cancel>Close</button></div>`);
}

/* ---- spelling: offline Hunspell dictionaries (SCOWL, en-GB / en-US) with nspell ---- */
const SCI = ($("#sci-words")?.textContent || "").split(/\s+/).filter(Boolean);
const SP = { eng: {}, ranges: [], cache: new Map(), ignore: new Set() };
function spellCfg() { return { mode: "en-GB", italic: true, ...(Prefs.get("spell", {}) || {}) }; }
function spellEngine() {
  const lang = spellCfg().mode; if (lang !== "en-GB" && lang !== "en-US") return null;
  if (!SP.eng[lang]) { const id = lang === "en-US" ? "us" : "gb"; const sp = nspell($(`#dic-${id}-aff`).textContent, $(`#dic-${id}-dic`).textContent); SCI.forEach(w => sp.add(w)); (Prefs.get("userDict", []) || []).forEach(w => sp.add(w)); SP.eng[lang] = sp; SP.cache.clear(); }
  return SP.eng[lang];
}
function spellApplyMode() { const m = spellCfg().mode; flowEl.spellcheck = m === "browser"; if (m === "browser" || m === "off") { SP.ranges = []; try { CSS.highlights.delete("lp-spell"); } catch (e) { /* no highlight API */ } } else spellSoon(); }
const SKIP_SPELL = "pre,code,a,.ai-chg,sup.fn-ref,nav.toc,[data-nospell],script,style";
function wordOk(w, sp) {
  if (w.length < 2 || /\d/.test(w) || /\p{Lu}.*\p{Lu}/u.test(w) || /\p{Ll}\p{Lu}/u.test(w)) return true;
  const k = w.replace(/’/g, "'"); if (SP.ignore.has(k.toLowerCase()) || (S.doc?.meta?.spellIgnore || []).includes(k.toLowerCase())) return true;
  if (SP.cache.has(k)) return SP.cache.get(k);
  const base = k.replace(/'s$/i, "").replace(/^'+|'+$/g, ""), lower = base.toLowerCase();
  const ok = !base || sp.correct(base) || sp.correct(lower) || (base[0] === base[0].toUpperCase() && sp.correct(base.toLowerCase()));
  SP.cache.set(k, ok); return ok;
}
function spellRun() {
  const sp = flowOn() && spellEngine(); if (!sp) return; const cfg = spellCfg(), out = [];
  const w = document.createTreeWalker(flowEl, NodeFilter.SHOW_TEXT, { acceptNode: n => { const p = n.parentElement; if (!p || p.closest(SKIP_SPELL) || (cfg.italic && p.closest("i,em"))) return NodeFilter.FILTER_REJECT; return NodeFilter.FILTER_ACCEPT; } });
  let n; while ((n = w.nextNode())) {
    for (const m of n.data.matchAll(/[\p{L}\p{M}][\p{L}\p{M}'’-]*[\p{L}\p{M}]|[\p{L}]/gu)) {
      let off = m.index; for (const part of m[0].split("-")) { if (part && !wordOk(part, sp)) { const r = document.createRange(); r.setStart(n, off); r.setEnd(n, off + part.length); out.push(r); } off += part.length + 1; }
    }
  }
  SP.ranges = out; try { CSS.highlights.set("lp-spell", new Highlight(...out)); } catch (e) { /* no highlight API: the F7 panel still works */ }
  if (spPanel && !spPanel.hidden) spShow();
}
const spellSoon = debounce(() => { const m = spellCfg().mode; if (m === "en-GB" || m === "en-US") spellRun(); }, 450);
function spellAt(x, y) {
  let node, off; if (document.caretPositionFromPoint) { const p = document.caretPositionFromPoint(x, y); node = p?.offsetNode; off = p?.offset; } else if (document.caretRangeFromPoint) { const r = document.caretRangeFromPoint(x, y); node = r?.startContainer; off = r?.startOffset; }
  if (!node) return null; return SP.ranges.find(r => r.startContainer === node && r.startOffset <= off && off <= r.endOffset) || null;
}
/* nspell misses swapped letters ("teh"): try those first */
function suggest(word) {
  const sp = spellEngine(), out = [], lw = word.toLowerCase(), cap = word[0] !== lw[0];
  for (let i = 0; i < lw.length - 1; i++) { const t = lw.slice(0, i) + lw[i + 1] + lw[i] + lw.slice(i + 2); if (sp.correct(t)) out.push(cap ? t[0].toUpperCase() + t.slice(1) : t); }
  return [...new Set([...out, ...sp.suggest(word)])];
}
function spellReplace(r, word) { const s = getSelection(); s.removeAllRanges(); s.addRange(r); flowEl.focus({ preventScroll: true }); s.removeAllRanges(); s.addRange(r); document.execCommand("insertText", false, word); spellRun(); }
function spellIgnoreAll(word) { const k = word.replace(/’/g, "'").toLowerCase(); S.doc.meta = S.doc.meta || {}; S.doc.meta.spellIgnore = [...new Set([...(S.doc.meta.spellIgnore || []), k])]; SP.cache.clear(); markDirty(); spellRun(); }
function spellAdd(word) { const k = word.replace(/’/g, "'"); Prefs.set("userDict", [...new Set([...(Prefs.get("userDict", []) || []), k])]); Object.values(SP.eng).forEach(e => e.add(k)); SP.cache.clear(); spellRun(); toast(`Added “${k}” to your dictionary (this browser).`); }
flowEl.addEventListener("contextmenu", e => {
  if (!flowOn() || e.ctrlKey || e.shiftKey) return; const r = spellAt(e.clientX, e.clientY); if (!r) return; e.preventDefault();
  const word = r.toString(), sug = suggest(word).slice(0, 6);
  menu([{ head: `Not in the dictionary: “${word}”` }, ...(sug.length ? sug.map(s => ({ label: s, fn: () => spellReplace(r, s) })) : [{ label: "No suggestions", fn: () => {} }]), { sep: true },
    { label: "Ignore all", sub: "In this document", fn: () => spellIgnoreAll(word) }, { label: "Add to dictionary", sub: "For every document in this browser", fn: () => spellAdd(word) }, { sep: true },
    { label: "Spelling panel…", k: "F7", fn: () => spellPanel() }, { label: "Browser menu", sub: "Shift+right-click shows it any time", fn: () => {} }], e);
});
/* the F7 panel: step through the document like Word's Spelling pane */
let spPanel = null, spIdx = 0, spSkip = new Set();
function spellPanel() {
  const m = spellCfg().mode; if (m !== "en-GB" && m !== "en-US") { spellMenuSet("en-GB"); }
  spellRun(); spIdx = 0; spSkip = new Set();
  if (!spPanel) { spPanel = EL("div", { class: "sp-panel", role: "dialog", "aria-label": "Spelling" }); document.body.append(spPanel); }
  spPanel.hidden = false; spShow();
}
function spCur() { const list = SP.ranges.filter(r => !spSkip.has(r.startContainer.data + "@" + r.startOffset + ":" + r.toString())); return list[Math.min(spIdx, list.length - 1)] || null; }
function spShow() {
  const r = spCur(), lang = spellCfg().mode === "en-US" ? "English (US)" : "English (UK)"; spPanel.innerHTML = "";
  const head = EL("div", { class: "sp-h" }, EL("b", {}, "Spelling"), EL("span", { class: "sp-lang" }, lang), EL("span", { style: "flex:1" }), EL("button", { class: "ibtn", title: "Close (Esc)", onclick: () => { spPanel.hidden = true; } }, ICON("i-x")));
  spPanel.append(head);
  if (!r) { spPanel.append(EL("p", { class: "sp-ok" }, "✓ No spelling issues found."), EL("div", { class: "sp-btns" }, EL("button", { class: "btn small", onclick: () => { spPanel.hidden = true; } }, "Close"))); return; }
  const word = r.toString(), sug = suggest(word).slice(0, 8);
  const sel = getSelection(); sel.removeAllRanges(); sel.addRange(r); elOf(r.startContainer).scrollIntoView({ block: "center", behavior: "smooth" });
  const ctx = r.startContainer.data, a = Math.max(0, r.startOffset - 50), b = Math.min(ctx.length, r.endOffset + 50);
  spPanel.append(EL("div", { class: "sp-ctx", html: (a ? "…" : "") + esc(ctx.slice(a, r.startOffset)) + `<mark>${esc(word)}</mark>` + esc(ctx.slice(r.endOffset, b)) + (b < ctx.length ? "…" : "") }), EL("div", { class: "sp-n" }, `${SP.ranges.length} word${SP.ranges.length === 1 ? "" : "s"} not in the dictionary`));
  let pick = sug[0] || ""; const list = EL("div", { class: "sp-sug" });
  sug.forEach((s, i) => list.append(EL("button", { class: i === 0 ? "on" : "", onclick: e => { pick = s; $$("button", list).forEach(x => x.classList.toggle("on", x === e.currentTarget)); }, ondblclick: () => change() }, s)));
  if (!sug.length) list.append(EL("span", { class: "muted" }, "No suggestions"));
  spPanel.append(list);
  const change = () => { if (pick) spellReplace(r, pick); };
  const changeAll = () => { if (!pick) return; for (const x of [...SP.ranges].reverse()) if (x.toString() === word) { x.deleteContents(); x.insertNode(document.createTextNode(pick)); } flowEl.normalize(); flowChanged(); spellRun(); };
  const B = (l, fn, cls = "btn small") => EL("button", { class: cls, onclick: fn }, l);
  spPanel.append(EL("div", { class: "sp-btns" }, B("Change", change, "btn small primary"), B("Change all", changeAll), B("Ignore once", () => { spSkip.add(r.startContainer.data + "@" + r.startOffset + ":" + word); spShow(); }), B("Ignore all", () => spellIgnoreAll(word)), B("Add to dictionary", () => spellAdd(word))));
}
document.addEventListener("keydown", e => { if (e.key === "Escape" && spPanel && !spPanel.hidden && e.target.closest?.(".sp-panel,#flow,body")) { if (!$("#menu").hidden || !$("#modalBack").hidden) return; spPanel.hidden = true; } });
function spellMenuSet(mode) { Prefs.set("spell", { ...spellCfg(), mode }); SP.cache.clear(); spellApplyMode(); }

/* ---- menus: Edit, Insert, Format, Tools, Help ---- */
function editMenu(a) { saveRange(); menu([{ label: "Undo", k: "Ctrl+Z", fn: undo }, { label: "Redo", k: "Ctrl+Y", fn: redo }, { sep: true }, { label: "Cut", k: "Ctrl+X", fn: () => { useRange(); document.execCommand("cut"); } }, { label: "Copy", k: "Ctrl+C", fn: () => { useRange(); document.execCommand("copy"); } }, { label: "Paste", k: "Ctrl+V", sub: "Use the keys: browsers block pasting from a menu", fn: () => toast("Press Ctrl+V (⌘V) to paste.") }, { label: "Select all", k: "Ctrl+A", fn: () => { flowEl.focus(); document.execCommand("selectAll"); } }, { sep: true }, { label: "Find", k: "Ctrl+F", fn: () => { showLeft("find"); $("#findIn").focus(); } }, { label: "Find and replace", k: "Ctrl+H", fn: () => { showLeft("find"); $("#replIn").focus(); } }], a); }
function insertMenu(a) { saveRange(); menu([{ label: "Table", icon: "i-table", fn: () => tableMenu(a) }, { label: "Image…", icon: "i-image", fn: () => $("[data-act=insertImage]").click() }, { label: "Link…", icon: "i-link", k: "Ctrl+K", fn: () => { useRange(); linkPrompt(); } }, { sep: true },
  { label: "Footnote", k: "Ctrl+Alt+F", fn: insertFootnote }, { label: "Page break", k: "Ctrl+Enter", fn: pageBreak }, { label: "Table of contents", sub: "Updates itself from the headings", fn: insertToc }, { label: "Horizontal line", icon: "i-hr", fn: C("insertHorizontalRule") }, { sep: true },
  { label: "Symbol…", sub: "Greek letters, ± µ ° → and more", fn: symbolDialog }, { label: "Today's date", fn: insertDate }, { label: "Comment", icon: "i-comment", k: "Ctrl+Alt+M", fn: () => { useRange(); flowComment(); } }], a); }
function formatMenu(a) { saveRange(); menu([{ head: "Text" }, { label: "Bold", k: "Ctrl+B", fn: C("bold") }, { label: "Italic", k: "Ctrl+I", fn: C("italic") }, { label: "Underline", k: "Ctrl+U", fn: C("underline") }, { label: "Strikethrough", k: "Ctrl+Shift+X", fn: C("strikeThrough") }, { label: "Superscript", k: "Ctrl+Shift+=", fn: C("superscript") }, { label: "Subscript", k: "Ctrl+=", fn: C("subscript") }, { label: "Small caps", k: "Ctrl+Shift+K", fn: smallCaps },
  { label: "Bigger", k: "Ctrl+Shift+>", fn: () => stepSize(1) }, { label: "Smaller", k: "Ctrl+Shift+<", fn: () => stepSize(-1) },
  { sep: true }, { head: "Change case" }, { label: "UPPERCASE", k: "Shift+F3 cycles", fn: () => changeCase("upper") }, { label: "lowercase", fn: () => changeCase("lower") }, { label: "Title Case", fn: () => changeCase("title") }, { label: "Sentence case", fn: () => changeCase("sentence") },
  { sep: true }, { head: "Paragraph" }, { label: "Line and paragraph spacing…", fn: () => spacingMenu(a) }, { label: "Align left / centre / right / justify", sub: "Ctrl+L, Ctrl+E, Ctrl+R, Ctrl+J", fn: () => alignMenu(a) }, { label: "Bulleted list", k: "Ctrl+Shift+8", fn: C("insertUnorderedList") }, { label: "Numbered list", k: "Ctrl+Shift+7", fn: C("insertOrderedList") },
  { sep: true }, { label: "Copy formatting", k: "Ctrl+Alt+C", fn: copyFormat }, { label: "Paste formatting", k: "Ctrl+Alt+V", fn: pasteFormat }, { label: "Clear formatting", k: "Ctrl+Space", fn: C("removeFormat") }, { sep: true }, { label: "Page setup…", fn: pageSetup }], a); }
function toolsMenu(a) {
  const m = spellCfg();
  menu([{ head: "Spelling" }, { label: "Check spelling…", k: "F7", fn: () => spellPanel() }, ...[["en-GB", "English (UK)", "Offline dictionary, red wavy underlines"], ["en-US", "English (US)", "Offline dictionary"], ["browser", "Browser's own checker", "Your browser's languages"], ["off", "Off", ""]].map(([k, l, sub]) => ({ label: l, sub, on: m.mode === k, fn: () => spellMenuSet(k) })),
    { label: (m.italic ? "✓ " : "") + "Skip words in italics", sub: "Species names such as Escherichia coli", fn: () => { Prefs.set("spell", { ...m, italic: !m.italic }); spellRun(); } },
    { label: "Personal dictionary…", fn: personalDict }, { sep: true }, { label: "Word count", k: "Ctrl+Shift+G", fn: wordCountDialog }, { label: "Ask AI about the selection", k: "Alt+A", fn: () => { useRange(); aiAskOpen(); } }, { label: "AI settings…", fn: () => aiSettings() }, { sep: true }, { label: "Keyboard shortcuts", k: "Ctrl+/", fn: shortcutsHelp }], a);
}
async function personalDict() {
  const v = await modal(`<h3>Personal dictionary</h3><p>Words you added, one per line. They are kept in this browser and used by every document.</p><textarea name="w" style="min-height:220px">${esc((Prefs.get("userDict", []) || []).join("\n"))}</textarea><div class="mrow"><button class="btn" data-cancel>Cancel</button><button class="btn primary" data-ok="ok">Save</button></div>`);
  if (!v) return; Prefs.set("userDict", [...new Set(v.w.split(/\n/).map(x => x.trim()).filter(Boolean))]); SP.eng = {}; SP.cache.clear(); spellRun();
}

/* ---- keyboard shortcuts (Word, and Google Docs where a browser keeps Word's key for itself) ---- */
const SHORTCUTS = [
  ["Text", [["Ctrl+B / I / U", "Bold, italic, underline"], ["Ctrl+Shift+X or Alt+Shift+5", "Strikethrough"], ["Ctrl+=", "Subscript"], ["Ctrl+Shift+=", "Superscript"], ["Ctrl+Shift+K", "Small caps"], ["Shift+F3", "Change case (UPPER, lower, Title)"], ["Ctrl+Shift+> / <", "Font size up / down a step"], ["Ctrl+] / Ctrl+[", "Font size up / down 1 pt"], ["Ctrl+Shift+F or Ctrl+D", "Font box"], ["Ctrl+Shift+P", "Size box"], ["Ctrl+Space or Ctrl+\\", "Clear character formatting"], ["Ctrl+Alt+C / Ctrl+Alt+V", "Copy / paste formatting"], ["Ctrl+Shift+H", "Highlight"], ["Ctrl+K", "Link"]]],
  ["Paragraph", [["Ctrl+Alt+1 / 2 / 3", "Heading 1 / 2 / 3"], ["Ctrl+Alt+0", "Normal text"], ["Ctrl+L / E / R / J", "Align left, centre, right, justify (also Ctrl+Shift+L/E/R/J)"], ["Ctrl+1 / Ctrl+5 / Ctrl+2", "Line spacing single / 1.5 / double"], ["Ctrl+M / Ctrl+Shift+M", "Indent / outdent (also Tab / Shift+Tab)"], ["Ctrl+Shift+8 / 7", "Bulleted / numbered list"], ["Alt+Shift+↑ / ↓", "Move paragraph up / down"], ["Ctrl+Q", "Clear paragraph formatting"], ["Shift+Enter", "Line break in the same paragraph"]]],
  ["Insert", [["Ctrl+Enter", "Page break"], ["Ctrl+Alt+F", "Footnote"], ["Ctrl+Alt+M", "Comment"], ["Ctrl+Shift+Space", "Non-breaking space"]]],
  ["AI", [["Alt+A", "Ask AI about the selection"], ["Tab", "Accept the AI suggestion"], ["Esc", "Reject the AI suggestion"]]],
  ["Document", [["Ctrl+S", "Save"], ["Ctrl+O", "Open"], ["Ctrl+P", "Print / save as PDF"], ["Ctrl+Z / Ctrl+Y", "Undo / redo"], ["Ctrl+F / Ctrl+H", "Find / replace"], ["F7", "Spelling"], ["Ctrl+Shift+G", "Word count"], ["Ctrl+/", "This list"], ["Ctrl+wheel, Ctrl+−", "Zoom (Ctrl+= is subscript in the text)"]]]
];
function shortcutsHelp() {
  const mac = /Mac|iPhone|iPad/.test(navigator.platform), k = s => esc(mac ? s.replace(/Ctrl\+/g, "⌘").replace(/Alt\+/g, "⌥").replace(/Shift\+/g, "⇧") : s);
  modal(`<h3>Keyboard shortcuts</h3><p>Word's keys work in the text. Where a browser keeps one of Word's keys for itself, the Google Docs key works instead.</p><div class="kb-grid">${SHORTCUTS.map(([g, list]) => `<div><div class="kb-h">${g}</div><table class="kb-t">${list.map(([a, b]) => `<tr><td><kbd>${k(a)}</kbd></td><td>${esc(b)}</td></tr>`).join("")}</table></div>`).join("")}</div><div class="mrow"><button class="btn primary" data-cancel>Close</button></div>`);
  $("#modal").classList.add("kb-modal"); const off = () => { if ($("#modalBack").hidden) { $("#modal").classList.remove("kb-modal"); } else setTimeout(off, 300); }; setTimeout(off, 300);
}
document.addEventListener("keydown", e => {
  if (!flowOn() || !$("#modalBack").hidden) return;
  const t = e.target, inFlow = !!t.closest?.("#flow"), inField = !inFlow && !!t.closest?.("input,textarea,select,[contenteditable=true]");
  const mod = e.ctrlKey || e.metaKey, L = e.code.startsWith("Key") ? e.code.slice(3).toLowerCase() : "", sh = e.shiftKey, al = e.altKey;
  const go = fn => { e.preventDefault(); e.stopPropagation(); fn(); };
  if (!inField) {
    if (mod && !al && (e.code === "Slash" || e.key === "/")) return go(shortcutsHelp);
    if (mod && sh && !al && L === "g") return go(wordCountDialog);
    if (e.key === "F7" && !mod && !al) return go(() => spellPanel());
    if (mod && !sh && !al && L === "p") return go(() => printFlow());
    if (mod && !sh && !al && L === "o") return go(() => $("[data-act=openFile]").click());
    if (mod && !sh && !al && L === "h") return go(() => { showLeft("find"); $("#replIn").focus(); });
  }
  if (!inFlow) return;
  if (e.key === "Enter" && !mod && !sh && t.closest && elOf(getSelection().anchorNode)?.closest("ol.footnotes")) return go(() => document.execCommand("insertLineBreak"));
  if (!mod && !(al && sh) && !(sh && e.key === "F3")) return;
  saveRange();
  if (mod && al && !sh && /^Digit[0-3]$/.test(e.code)) return go(() => setBlock(e.code === "Digit0" ? "p" : "h" + (+e.code.slice(5) + 1)));
  if (mod && !al && e.code === "Equal") return go(() => cmd(sh ? "superscript" : "subscript"));
  if (mod && sh && !al && (e.key === ">" || e.code === "Period")) return go(() => stepSize(1));
  if (mod && sh && !al && (e.key === "<" || e.code === "Comma")) return go(() => stepSize(-1));
  if (mod && !sh && !al && e.code === "BracketRight") return go(() => bumpSize(1));
  if (mod && !sh && !al && e.code === "BracketLeft") return go(() => bumpSize(-1));
  if (mod && !al && "lerj".includes(L) && L) return go(() => cmd({ l: "justifyLeft", e: "justifyCenter", r: "justifyRight", j: "justifyFull" }[L]));
  if (mod && !al && L === "m") return go(() => cmd(sh ? "outdent" : "indent"));
  if (mod && sh && !al && e.code === "Digit7") return go(() => cmd("insertOrderedList"));
  if (mod && sh && !al && e.code === "Digit8") return go(() => cmd("insertUnorderedList"));
  if ((mod && sh && !al && L === "x") || (al && sh && !mod && e.code === "Digit5")) return go(() => cmd("strikeThrough"));
  if (mod && sh && !al && L === "k") return go(smallCaps);
  if (mod && sh && !al && e.code === "Space") return go(() => document.execCommand("insertText", false, " "));
  if (mod && !sh && !al && (e.code === "Space" || e.code === "Backslash")) return go(() => cmd("removeFormat"));
  if (mod && !sh && !al && L === "q") return go(clearParagraph);
  if (mod && al && !sh && L === "c") return go(copyFormat);
  if (mod && al && !sh && L === "v") return go(pasteFormat);
  if (mod && al && !sh && L === "f") return go(insertFootnote);
  if (mod && !sh && !al && e.key === "Enter") return go(pageBreak);
  if (sh && !mod && !al && e.key === "F3") return go(() => changeCase("cycle"));
  if (al && sh && !mod && (e.key === "ArrowUp" || e.key === "ArrowDown")) return go(() => moveBlock(e.key === "ArrowUp" ? -1 : 1));
  if (mod && !sh && !al && ["Digit1", "Digit2", "Digit5"].includes(e.code)) return go(() => lineSpacing({ Digit1: "1", Digit2: "2", Digit5: "1.5" }[e.code]));
  if (mod && ((sh && !al && L === "f") || (!sh && !al && L === "d"))) return go(() => fontSel.focus());
  if (mod && sh && !al && L === "p") return go(() => sizeSel.focus());
}, true);

/* ---- upkeep after every change: footnote numbers, contents, spelling, word count ---- */
let wBusy = false;
const upkeep = debounce(() => { if (!flowOn() || wBusy) return; wBusy = true; try { zoomifySizes(); const a = fnRenumber(), b = tocUpdate(); if (a || b) flowChanged(); } finally { wBusy = false; } placeGrip(); wcUpdate(); spellSoon(); }, 350);
new MutationObserver(() => { if (!wBusy) upkeep(); }).observe(flowEl, { childList: true, characterData: true, subtree: true });
document.addEventListener("selectionchange", () => { if (flowOn()) { wcSoon(); const s = getSelection(); if (s.rangeCount && flowEl.contains(s.anchorNode)) syncFontUISoon(); } });
const syncFontUISoon = debounce(syncFontUI, 120);
{ const sd2 = showDoc; showDoc = async function () { const r = await sd2(); if (S.doc?.kind === "flow") { wBusy = true; zoomifySizes(); wBusy = false; applyPage(); spellApplyMode(); requestAnimationFrame(syncFontUI); } wcUpdate(); return r; }; }
{ const ew2 = exitWebView; exitWebView = function () { const r = ew2(); applyPage(); wcUpdate(); return r; }; }
/* exports carry the page font, size and line spacing */
{ const eh = exportHtmlString; exportHtmlString = async function (o) { const h = (await eh(o)).replace(ZRE, "$1"), p = pageCfg(); if (S.doc?.kind !== "flow" || !(p.font || p.size || p.lh)) return h; return h.replace("</head>", `<style>body{${p.font ? `font-family:${p.font};` : ""}${p.size ? `font-size:${p.size}pt;` : ""}${p.lh ? `line-height:${p.lh};` : ""}}</style>\n</head>`); }; }

/* ---- toolbar and menu bar wiring ---- */
document.addEventListener("click", e => {
  const b = e.target.closest("[data-act]"); if (!b) return; const a = b.dataset.act;
  const A = { wEdit: () => editMenu(b), wInsert: () => insertMenu(b), wFormat: () => formatMenu(b), wTools: () => toolsMenu(b), wHelp: shortcutsHelp, wPage: () => pageMenu(b), wSpacing: () => spacingMenu(b), wGrow: () => stepSize(1), wShrink: () => stepSize(-1), wPainter: () => { if (W.painterArmed) { W.painterArmed = false; b.classList.remove("on"); } else { saveRange(); copyFormat(); } }, wCase: () => { saveRange(); changeCase("cycle"); } };
  if (A[a]) { e.preventDefault(); A[a](); }
});
$$(".menubar button, #flowTools [data-act^=w]").forEach(b => b.addEventListener("pointerdown", e => { saveRange(); e.preventDefault(); }));
/* ---- inserting HTML: Chrome sometimes adds inline styles of its own to what it inserts; keep only the content's own ---- */
{ const ih = insertHtml; insertHtml = function (html) {
    const t = document.createElement("template"); t.innerHTML = html; t.content.querySelectorAll("[style]").forEach(e => e.setAttribute("data-pwk", ""));
    const had = new Set($$("[style]", flowEl)); ih(t.innerHTML);
    for (const el of $$("[style]", flowEl)) { if (had.has(el)) continue; if (el.hasAttribute("data-pwk")) continue; el.removeAttribute("style"); if ((el.tagName === "SPAN" || el.tagName === "FONT") && !el.attributes.length) el.replaceWith(...el.childNodes); }
    $$("[data-pwk]", flowEl).forEach(e => e.removeAttribute("data-pwk")); S.doc && (S.doc.html = flowEl.innerHTML);
  }; }
/* ---- links: Enter applies, a bare address gets https://, an e-mail gets mailto:, a click shows Open / Edit / Remove ---- */
function normUrl(u) { u = String(u || "").trim(); if (!u) return ""; if (/^[\w.+-]+@[\w-]+(\.[\w-]+)+$/.test(u)) return "mailto:" + u; if (/^(#|\/|\.\/|\.\.\/)/.test(u) || /^[a-z][\w+.-]*:/i.test(u)) return u; return "https://" + u; }
linkPrompt = async function () {
  const sel = getSelection(), inFlow = sel.rangeCount && flowEl.contains(sel.anchorNode); if (!inFlow) useRange();
  const a = elOf(sel.anchorNode)?.closest("#flow a"), saved = sel.rangeCount ? sel.getRangeAt(0).cloneRange() : null, collapsed = !saved || saved.collapsed;
  const v = await modal(`<h3>${a ? "Edit link" : "Insert link"}</h3><div class="ai-f"><label>Web address, e-mail or #heading</label><input type="text" name="url" value="${esc(a?.getAttribute("href") || "")}" placeholder="example.org/page" spellcheck="false" autocomplete="url"></div>${collapsed && !a ? `<div class="ai-f"><label>Text to show (optional)</label><input type="text" name="text" placeholder="the address"></div>` : ""}<div class="mrow">${a ? '<button class="btn danger" data-ok="unlink">Remove link</button>' : ""}<span class="sp"></span><button class="btn" data-cancel>Cancel</button><button class="btn primary" data-ok="ok">Apply</button></div>`, { select: true });
  if (!v) return; flowEl.focus({ preventScroll: true }); if (saved) { sel.removeAllRanges(); sel.addRange(saved); }
  if (v.btn === "unlink") { if (a) { a.replaceWith(...a.childNodes); flowChanged(); } return; }
  const url = normUrl(v.url); if (!url) return;
  if (a) { a.setAttribute("href", url); flowChanged(); }
  else if (collapsed) insertHtml(`<a href="${esc(url)}">${esc(v.text?.trim() || v.url.trim())}</a>`);
  else cmd("createLink", url);
};
$("#modal").addEventListener("keydown", e => { if (e.key === "Enter" && !e.shiftKey && e.target.matches("input:not([type=checkbox]):not([type=radio])")) { const ok = $("#modal [data-ok='ok']") || $("#modal [data-ok]"); if (ok) { e.preventDefault(); ok.click(); } } });
let linkCard = null;
function closeLinkCard() { linkCard?.remove(); linkCard = null; }
flowEl.addEventListener("click", e => {
  const a = e.target.closest("a[href]"); closeLinkCard(); if (!a || a.closest("nav.toc") || e.ctrlKey || e.metaKey) return;
  const r = a.getBoundingClientRect(), href = a.getAttribute("href");
  linkCard = EL("div", { class: "imgtools link-card", style: `position:fixed;left:${clamp(r.left, 8, innerWidth - 340)}px;top:${r.bottom + 6}px` });
  const B = (l, fn, t) => linkCard.append(EL("button", { title: t || "", onpointerdown: ev => ev.preventDefault(), onclick: ev => { ev.preventDefault(); closeLinkCard(); fn(); } }, l));
  linkCard.append(EL("span", { class: "lc-url", title: href }, href.length > 42 ? href.slice(0, 40) + "…" : href));
  B("Open ↗", () => { if (href.startsWith("#")) $(href, flowEl)?.scrollIntoView({ behavior: "smooth" }); else window.open(a.href, "_blank", "noopener"); }, "Open (or Ctrl+click the link)");
  B("Edit", () => { const rg = document.createRange(); rg.selectNodeContents(a); getSelection().removeAllRanges(); getSelection().addRange(rg); saveRange(); linkPrompt(); });
  B("Remove", () => { a.replaceWith(...a.childNodes); flowChanged(); });
  document.body.append(linkCard);
});
document.addEventListener("pointerdown", e => { if (linkCard && !e.target.closest(".link-card")) closeLinkCard(); }, true);
viewer.addEventListener("scroll", closeLinkCard, { passive: true });

/* ---- paste keeps the source's look (fonts, sizes, bold, colours), like Word's "Keep source formatting";
   the options chip switches to the document's own look or plain text; Ctrl+Shift+V pastes plain text ---- */
const KEEP_TAGS = new Set(["P", "H1", "H2", "H3", "H4", "H5", "H6", "UL", "OL", "LI", "TABLE", "THEAD", "TBODY", "TFOOT", "TR", "TD", "TH", "CAPTION", "BLOCKQUOTE", "PRE", "CODE", "A", "IMG", "BR", "SUP", "SUB", "FIGURE", "FIGCAPTION", "HR", "B", "STRONG", "I", "EM", "U", "S"]);
const BLOCKS = new Set(["P", "H1", "H2", "H3", "H4", "H5", "H6", "LI", "TD", "TH", "BLOCKQUOTE", "PRE", "FIGCAPTION", "CAPTION", "DIV"]);
function pasteSandbox(html) {
  const dom = new DOMParser().parseFromString(html, "text/html");
  const css = [...dom.querySelectorAll("style")].map(x => x.textContent).join("\n").replace(/@import[^;]+;/g, "");
  const body = DOMPurify.sanitize(dom.body.innerHTML, { ADD_ATTR: ["style", "colspan", "rowspan"], FORBID_TAGS: ["style", "script", "iframe", "form", "input", "button", "select", "textarea", "object", "embed", "video", "audio", "canvas", "svg"] });
  const fr = EL("iframe", { sandbox: "allow-same-origin", style: "position:fixed;left:-10000px;top:0;width:900px;height:400px;border:0;visibility:hidden", "aria-hidden": "true" });
  document.body.append(fr); const d = fr.contentDocument; d.open(); d.write(`<!doctype html><html><head><style>body{margin:0}${css.replace(/<\//g, "")}</style></head><body>${body}</body></html>`); d.close();
  return { fr, d };
}
const isDarkGrey = c => { const m = c.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/); if (!m) return false; const [r, g, b] = m.slice(1).map(Number); return Math.max(r, g, b) < 80 && Math.max(r, g, b) - Math.min(r, g, b) < 24; };
/* mode: "keep" (source look as inline styles), "match" (structure, bold, italic only) */
function pasteConvert(html, mode) {
  const { fr, d } = pasteSandbox(html), win = fr.contentWindow, base = win.getComputedStyle(d.body);
  const props = ["fontFamily", "fontSize", "fontWeight", "fontStyle", "color", "backgroundColor", "textDecorationLine", "verticalAlign", "fontVariantCaps"];
  function styleFor(el, parentCs) {
    const cs = win.getComputedStyle(el), out = [];
    if (mode === "keep") {
      if (cs.fontFamily !== parentCs.fontFamily && cs.fontFamily !== base.fontFamily) out.push(`font-family:${cs.fontFamily}`);
      if (cs.fontSize !== parentCs.fontSize && cs.fontSize !== base.fontSize) out.push(`font-size:${zsize(Math.round(parseFloat(cs.fontSize) * 0.75 * 2) / 2 + "pt")}`);
      if (cs.color !== parentCs.color && !isDarkGrey(cs.color)) out.push(`color:${cs.color}`);
      if (cs.backgroundColor !== parentCs.backgroundColor && !/rgba\(0, 0, 0, 0\)|transparent|rgb\(255, 255, 255\)/.test(cs.backgroundColor)) out.push(`background-color:${cs.backgroundColor}`);
      if (cs.fontVariantCaps === "small-caps" && parentCs.fontVariantCaps !== "small-caps") out.push("font-variant:small-caps");
      if (BLOCKS.has(el.tagName) && cs.textAlign && /center|right|justify/.test(cs.textAlign) && cs.textAlign !== parentCs.textAlign) out.push(`text-align:${cs.textAlign}`);
    }
    return { cs, out };
  }
  function walk(src, parentCs, dst) {
    for (const n of src.childNodes) {
      if (n.nodeType === 3) { dst.append(n.data.replace(/ /g, " ").replace(/[\r\n]+/g, " ")); continue; }
      if (n.nodeType !== 1) continue;
      const tag = n.tagName; if (/^(SCRIPT|STYLE|META|LINK|TITLE|O:P)$/.test(tag)) continue;
      const { cs, out } = styleFor(n, parentCs);
      const bold = +cs.fontWeight >= 600, pBold = +parentCs.fontWeight >= 600, ital = cs.fontStyle === "italic", pItal = parentCs.fontStyle === "italic";
      const und = /underline/.test(cs.textDecorationLine) && !/underline/.test(parentCs.textDecorationLine), str = /line-through/.test(cs.textDecorationLine) && !/line-through/.test(parentCs.textDecorationLine);
      const sup = cs.verticalAlign === "super" && parentCs.verticalAlign !== "super", sub = cs.verticalAlign === "sub" && parentCs.verticalAlign !== "sub";
      let el;
      if (tag === "A" && n.getAttribute("href")) el = EL("a", { href: n.getAttribute("href") });
      else if (tag === "IMG") { const src2 = n.getAttribute("src"); if (src2 && !/^(file|cid):/i.test(src2)) dst.append(EL("img", { src: src2, alt: n.getAttribute("alt") || "" })); continue; }
      else if (tag === "BR" || tag === "HR") { dst.append(EL(tag.toLowerCase())); continue; }
      else if (/^(TD|TH)$/.test(tag)) { el = EL(tag.toLowerCase()); for (const at of ["colspan", "rowspan"]) if (n.getAttribute(at)) el.setAttribute(at, n.getAttribute(at)); }
      else if (mode === "match" && /^H[1-6]$/.test(tag)) el = EL("p");   // v8: pasted headings become ordinary text in the document's size
      else if (KEEP_TAGS.has(tag) && !/^(B|STRONG|I|EM|U|S|SUP|SUB)$/.test(tag)) el = EL(tag.toLowerCase());
      else if (tag === "DIV" && [...n.childNodes].some(c => c.nodeType === 3 && c.data.trim())) el = EL("p");
      else if (BLOCKS.has(tag) || /^(DIV|SECTION|ARTICLE|MAIN|HEADER|FOOTER|ASIDE|NAV|CENTER)$/.test(tag)) { walk(n, cs, dst); continue; }
      else el = null;   // inline wrapper (span, font, b, i…): its look goes on a span or tags
      let inner = el || document.createDocumentFragment(), leaf = inner;
      const wrap = t => { const w = EL(t); leaf.append(w); leaf = w; };
      // headings keep their tag; with "keep" their source size and weight go inline so they look as they did
      if (el && /^H[1-6]$/.test(tag) && mode === "keep") { out.push(`font-size:${zsize(Math.round(parseFloat(cs.fontSize) * 0.75 * 2) / 2 + "pt")}`, `font-weight:${cs.fontWeight}`); if (cs.fontFamily !== base.fontFamily) out.push(`font-family:${cs.fontFamily}`); }
      if (out.length) { const st = [...new Map(out.map(x => [x.split(":")[0], x])).values()].join(";"); out.length = 0; out.push(st); if (el && (BLOCKS.has(tag) || /^H[1-6]$/.test(tag))) el.setAttribute("style", out.join(";")); else { const sp = EL("span", { style: out.join(";") }); leaf.append(sp); leaf = sp; } }
      if (!/^H[1-6]$/.test(tag) || mode !== "keep") { if (bold && !pBold && !/^H[1-6]$|^TH$/.test(tag)) wrap("b"); }
      if (ital && !pItal) wrap("i"); if (und) wrap("u"); if (str) wrap("s"); if (sup) wrap("sup"); if (sub) wrap("sub");
      if (!bold && pBold && mode === "keep") { leaf.setAttribute?.("style", ((leaf.getAttribute?.("style") || "") + ";font-weight:normal").replace(/^;/, "")); }
      walk(n, cs, leaf); dst.append(inner);
    }
  }
  const out = document.createElement("div"); walk(d.body, base, out); fr.remove();
  $$("p,li,h1,h2,h3,h4,h5,h6", out).forEach(x => { if (!x.textContent.trim() && !x.querySelector("img")) x.remove(); });
  $$("span:not([style])", out).forEach(x => x.replaceWith(...x.childNodes));
  return out.innerHTML;
}
function textOffset(node, off) { let n = 0; const w = document.createTreeWalker(flowEl, NodeFilter.SHOW_TEXT); let t; while ((t = w.nextNode())) { if (t === node) return n + off; n += t.data.length; } if (node.nodeType === 1) { const r = document.createRange(); r.setStart(flowEl, 0); r.setEnd(node, off); return r.toString().length; } return n; }
function pointAt(off) { const w = document.createTreeWalker(flowEl, NodeFilter.SHOW_TEXT); let t, n = 0; while ((t = w.nextNode())) { if (n + t.data.length >= off) return [t, off - n]; n += t.data.length; } return [flowEl, flowEl.childNodes.length]; }
let pasteChip = null;
function closePasteChip() { pasteChip?.remove(); pasteChip = null; }
function doPaste(data, mode) {
  if (mode === "text") { const paras = data.text.replace(/\r/g, "").split(/\n{2,}|\n/).map(x => x.trim()); if (paras.length > 1) insertHtml(paras.map(x => `<p>${esc(x) || "<br>"}</p>`).join("")); else document.execCommand("insertText", false, data.text); flowChanged(); return; }
  if (!data.html) { if (/^(#|\*|-|\d+\.|>|\|)/m.test(data.text) && data.text.includes("\n")) insertHtml(mdToHtml(data.text)); else doPaste(data, "text"); return; }
  let h = pasteConvert(data.html, mode);
  // one pasted paragraph joins the paragraph it lands in, instead of starting a new one
  const t = EL("div", { html: h }); if (t.children.length === 1 && t.firstElementChild.tagName === "P" && ![...t.childNodes].some(n => n.nodeType === 3 && n.data.trim())) h = t.firstElementChild.innerHTML;
  insertHtml(h);
}
document.addEventListener("paste", e => {
  if (!flowOn() || !e.target.closest?.("#flow") || e.target.closest(".ai-chg")) return;
  const cd = e.clipboardData; if (!cd) return; const items = [...cd.items]; if (items.some(i => i.type.startsWith("image/")) && !cd.getData("text/html")) return;   // pictures: the editor's own paste
  const data = { html: cd.getData("text/html"), text: cd.getData("text/plain") };
  if (!data.html && !data.text) return;
  e.preventDefault(); e.stopPropagation(); closePasteChip();
  const sel = getSelection(), r = sel.getRangeAt(0), before = flowEl.innerHTML, a = textOffset(r.startContainer, r.startOffset), b = textOffset(r.endContainer, r.endOffset);
  const mode = W.plainPaste ? "text" : (Prefs.get("pasteMode2", "match"));   // v8: by default pasted text takes the document's own font and size W.plainPaste = false;
  doPaste(data, data.html ? mode : "text");
  if (!data.html) return;
  const rr = getSelection().rangeCount ? getSelection().getRangeAt(0).getBoundingClientRect() : null;
  pasteChip = EL("div", { class: "imgtools paste-chip", style: `position:fixed;left:${clamp(rr?.left || 200, 8, innerWidth - 360)}px;top:${clamp((rr?.bottom || 200) + 8, 60, innerHeight - 50)}px` });
  pasteChip.append(EL("span", { class: "lc-url" }, "Paste:"));
  for (const [m, l, t] of [["keep", "Keep source formatting", "Fonts, sizes, bold and colours as in the source"], ["match", "Match this document", "Headings, lists, bold and italic; the document's own font and size"], ["text", "Plain text", "Ctrl+Shift+V"]]) {
    pasteChip.append(EL("button", { class: m === mode ? "on" : "", title: t, onpointerdown: ev => ev.preventDefault(), onclick: ev => {
      ev.preventDefault(); flowEl.innerHTML = before; const [n1, o1] = pointAt(a), [n2, o2] = pointAt(b), rg = document.createRange(); rg.setStart(n1, o1); rg.setEnd(n2, o2);
      flowEl.focus({ preventScroll: true }); getSelection().removeAllRanges(); getSelection().addRange(rg); doPaste(data, m); if (m !== "text") Prefs.set("pasteMode2", m); $$("button", pasteChip).forEach(x => x.classList.toggle("on", x === ev.currentTarget)); } }, l));
  }
  document.body.append(pasteChip); const chip = pasteChip; setTimeout(() => document.addEventListener("keydown", closePasteChip, { once: true }), 0); setTimeout(() => { if (pasteChip === chip) closePasteChip(); }, 15000);
}, true);
document.addEventListener("pointerdown", e => { if (pasteChip && !e.target.closest(".paste-chip")) closePasteChip(); }, true);
document.addEventListener("keydown", e => { if (flowOn() && (e.ctrlKey || e.metaKey) && e.shiftKey && e.code === "KeyV" && e.target.closest?.("#flow")) W.plainPaste = true; }, true);

/* ---- page width in the toolbar; wide pages fold the side panels so there is room; the web view follows the page ---- */
const pwSel = $("#pageWSel");
pwSel.innerHTML = [["a4", "A4"], ["letter", "Letter"], ["wide", "Wide"], ["fill", "Fill the stage"], ["custom", "Custom"]].map(([k, l]) => `<option value="${k}">${l}</option>`).join("");
pwSel.addEventListener("change", () => { if (pwSel.value === "custom") { toast("Drag the right edge of the page to any width."); pwSel.value = pageCfg().w; return; } setPage({ w: pwSel.value }); });
function makeRoom() {
  const p = pageCfg(), need = p.w === "fill" ? Infinity : (p.w === "custom" ? p.px : PAGE_W[p.w] || 794) + 60; let folded = [];
  if (need > viewer.clientWidth) for (const id of ["left", "right"]) { const el = $("#" + id); if (!el.classList.contains("closed") && need > viewer.clientWidth) { el.classList.add("closed"); folded.push(id === "left" ? "Pages" : "Notes"); } }
  if (folded.length) toast(`Folded the ${folded.join(" and ")} panel${folded.length > 1 ? "s" : ""} to make room for the page.`);
}
{ const sp = setPage; setPage = function (patch, asDefault) { sp(patch, asDefault); if (patch.w && patch.w !== "a4" && patch.w !== "letter") setTimeout(() => { makeRoom(); applyPage(); }, 30); pwSel.value = pageCfg().w; wvPage(); }; }
{ const ap = applyPage; applyPage = function () { ap(); if (S.doc?.kind === "flow") pwSel.value = pageCfg().w; }; }
function wvPage() {
  const d = S.webview && wvDoc(); if (!d || S.doc?.meta?.head) return; const p = pageCfg(), w = p.w === "fill" ? "none" : (p.w === "custom" ? p.px : PAGE_W[p.w] || 794) + "px";
  let st = d.getElementById("lp-pw"); if (!st) { st = d.createElement("style"); st.id = "lp-pw"; d.head.append(st); }
  st.textContent = `body{max-width:${w}!important;${p.w === "fill" ? "margin:24px!important;" : ""}${p.font ? `font-family:${p.font}!important;` : ""}${p.size ? `font-size:${p.size}pt!important;` : ""}${p.lh ? `line-height:${p.lh}!important;` : ""}}`;
}
$("#wvFrame").addEventListener("load", wvPage);

Object.assign(window, { setFont, setSize, setPage, pageCfg, spellRun, spellPanel, insertFootnote, insertToc, changeCase, wordCountDialog, shortcutsHelp, SP });

/* ---------- Paper Writer is now part of Doc Reader: bring its documents and settings over ----------
   Paper Writer (v1-v5) kept its documents in its own browser database, "lp-paperwriter", on the same site.
   Each start copies any Paper Writer document (with its AI chat) that was never brought over before, so
   documents made later with an old Paper Writer link still arrive, and one deleted here does not come back.
   The AI, spelling and page settings come over the first time. The old database is left as it was. */
async function importPaperWriter() {
  if (IS_EXT) return;
  try {
    if (indexedDB.databases && !(await indexedDB.databases()).some(d => d.name === "lp-paperwriter")) return;
    // open it without creating it: a missing database asks for an upgrade, which is cancelled
    const old = await new Promise(res => { const r = indexedDB.open("lp-paperwriter"); r.onupgradeneeded = () => r.transaction.abort(); r.onsuccess = () => res(r.result); r.onerror = () => res(null); });
    if (!old) return;
    const read = (store, key) => new Promise(res => { try { const t = old.transaction(store, "readonly").objectStore(store); const q = key === undefined ? t.getAll() : t.get(key); q.onsuccess = () => res(q.result); q.onerror = () => res(null); } catch (e) { res(null); } });
    const docs = (await read("docs")) || [], prefs = (await read("kv", "prefs")) || {}; old.close();
    const have = new Set(((await DB.all("docs")) || []).map(d => d.id)), done = new Set(Prefs.get("pwIds", [])); let n = 0;
    for (const d of docs) { if (done.has(d.id)) continue; if (!have.has(d.id)) { await DB.put("docs", d); n++; } done.add(d.id); }
    Prefs.set("pwIds", [...done]);
    if (!Prefs.get("pwImported")) { for (const k of ["ai", "aiKeys", "userDict", "spell", "pageDefaults", "aiMarkup", "pasteMode", "recentSym", "aiPanelSeen"]) if (prefs[k] != null && Prefs.get(k) == null) Prefs.set(k, prefs[k]); Prefs.set("pwImported", Date.now()); }
    if (n) toast(`Paper Writer is now part of Doc Reader: brought over ${n} document${n === 1 ? "" : "s"} with their AI chats.`);
  } catch (e) { console.warn("Paper Writer import", e); }
}
{ const lr = listRecent; let first = true; listRecent = async function () { if (first) { first = false; await importPaperWriter(); } return lr(); }; }

/* ---------- v4: a web page opened in the editor can't take over Doc Reader ----------
   A page's body is shown inside #flow, in Doc Reader's own document, so before v4 its ids and classes
   met Doc Reader's: a page with <ul id="menu" class="menu">, <aside id="right"> or <div class="toast">
   got Doc Reader's menu, notes panel or toast styling, and Doc Reader drew its menus and toasts into
   the page. Now (1) Doc Reader's own style rules skip everything inside #flow (except the rules written
   for documents, which name .flow), (2) its lookups by id ($("#menu")) skip the page's copies,
   (3) the page's linked stylesheets are loaded for the editor too, not only for web view, and
   (4) <style> blocks in the page's body move to its head, so they can't restyle Doc Reader. */
(function guardReaderCss() {
  const G = ":where(:not(#flow *))";   // no specificity: the cascade between Doc Reader's rules is unchanged
  const splitTop = sel => { const out = []; let d = 0, q = null, cur = "";
    for (const ch of sel) { if (q) { cur += ch; if (ch === q) q = null; continue; }
      if (ch === '"' || ch === "'") q = ch; else if (ch === "(" || ch === "[") d++; else if (ch === ")" || ch === "]") d--;
      else if (ch === "," && !d) { out.push(cur.trim()); cur = ""; continue; } cur += ch; }
    out.push(cur.trim()); return out.filter(Boolean); };
  const guard = s => {
    if (/flow/i.test(s) || /^(\*|\[hidden\]|html|body|:root[^\s>+~]*|::?[\w-]+(\(.*\))?)$/.test(s)) return s;
    const pe = s.match(/(::?(?:before|after|first-line|first-letter)|::[\w-]+(?:\([^)]*\))?)$/);
    return pe ? s.slice(0, pe.index) + G + pe[0] : s + G;
  };
  const walk = rules => { for (const r of rules) {
    if (r.type === 7) continue;   // @keyframes
    if (r.selectorText != null) { const n = splitTop(r.selectorText).map(guard).join(", "); if (n !== r.selectorText) r.selectorText = n; }
    else if (r.cssRules) walk(r.cssRules); } };
  for (const sh of [...document.styleSheets]) { try { walk(sh.cssRules); } catch (e) { /* not ours */ } }
})();

/* a page shown in the editor stays inside the paper: its fixed banners and z-indexes can't cover Doc Reader */
document.head.append(EL("style", { id: "lp-isolate" }, `.flow.faithful{contain:layout;isolation:isolate}`));

/* addresses in a style sheet, made absolute so they still work from here */
function absCssUrls(css, base) {
  if (!base) return css;
  return css.replace(/url\(\s*(['"]?)([^'")]+)\1\s*\)/g, (m, q, u) => { if (/^(data:|blob:|https?:|#|about:)/i.test(u.trim())) return m; try { return `url("${new URL(u.trim(), base).href}")`; } catch (e) { return m; } });
}
/* a linked style sheet with its @imports (works in the extension for any site; the web page can
   only read sheets the site serves to everyone, so others stay unstyled in the editor) */
async function fetchCss(url, depth = 0) {
  let t; try { const r = await fetch(url, { credentials: "omit" }); if (!r.ok) return ""; t = await r.text(); } catch (e) { return ""; }
  if (/^\s*</.test(t)) return "";   // an error page, not CSS
  const imports = [];
  t = t.replace(/@import\s+(?:url\(\s*)?['"]?([^'")\s;]+)['"]?\s*\)?\s*([^;]*);/g, (m, u, media) => { try { imports.push([new URL(u, url).href, media.trim()]); } catch (e) { /* skip */ } return ""; });
  t = absCssUrls(t, url);
  let pre = "";
  if (depth < 3) for (const [u, media] of imports) { const c = await fetchCss(u, depth + 1); if (c) pre += media && !/^(all|screen)$/i.test(media) ? `@media ${media}{\n${c}\n}\n` : c + "\n"; }
  return pre + t;
}
async function loadLinkedCss(d) {
  const t = document.createElement("template"); t.innerHTML = d.meta.head || "";
  const links = [...t.content.querySelectorAll("link[href]")].filter(l => /stylesheet/i.test(l.rel) && /^https?:/i.test(l.getAttribute("href")) && !/^(print|speech)$/i.test(l.media || ""));
  if (!links.length) { d.meta.linkCss = ""; return; }
  const parts = await Promise.all(links.map(async l => { const c = await fetchCss(l.getAttribute("href")); return c && l.media && !/^(all|screen)$/i.test(l.media) ? `@media ${l.media}{\n${c}\n}` : c; }));
  d.meta.linkCss = parts.filter(Boolean).join("\n");
  if (S.doc === d) applyPageCss();
  if (d.meta.linkCss) saveSoon();
}
function applyPageCss() {
  $("#flow-filecss")?.remove(); const m = S.doc?.meta; if (!m || S.doc.kind === "pdf") return;
  const css = (m.linkCss || "") + "\n" + (m.css || ""); if (!css.trim()) return;
  const sc = scopeCss(css); if (sc) document.head.append(EL("style", { id: "flow-filecss" }, sc));
}
/* <style> blocks in the page's body would apply to all of Doc Reader: they go to the page's head
   (web view still has them; the editor gets them limited to the page, through meta.css) */
function liftBodyStyles(d) {
  if (!d?.meta?.faithful || !/<style[\s>]/i.test(d.html || "")) return;
  const t = document.createElement("template"); t.innerHTML = d.html; const st = [...t.content.querySelectorAll("style")]; if (!st.length) return;
  d.meta.head = (d.meta.head || "") + "\n" + st.map(s => s.outerHTML).join("\n");
  if (!d.meta.css) d.meta.css = st.map(s => s.textContent).join("\n");
  st.forEach(s => s.remove()); d.html = t.innerHTML; if (d.origHtml) d.origHtml = d.html;
}

/* the page's CSS, limited to the document. v4: rules written for the page's <html> or <body>
   ("html.dark .x", "body.article p") apply only if the page's own <html>/<body> match them;
   @supports, @layer, @container and @keyframes are kept; addresses are made absolute. */
scopeCss = function (css) {
  try {
    const m = S.doc?.meta || {}, base = m.sourceUrl || "";
    const doc = document.implementation.createHTMLDocument(""), st = doc.createElement("style"); st.textContent = css; doc.head.append(st);
    const probe = document.implementation.createHTMLDocument(""), setA = (el, s) => { const t = probe.createElement("template"); t.innerHTML = `<i ${s || ""}></i>`; for (const a of t.content.firstChild.attributes) el.setAttribute(a.name, a.value); };
    try { setA(probe.documentElement, m.htmlAttr); setA(probe.body, m.bodyAttr); } catch (e) { /* plain */ }
    const fits = (el, c) => { try { return el.matches(c); } catch (e) { return false; } };
    const one = s => {
      s = s.trim(); let mm;
      if ((mm = s.match(/^((?:html|:root)(?![\w-])[^\s>+~]*)\s*>?\s*/i))) { if (!fits(probe.documentElement, mm[1])) return null; s = s.slice(mm[0].length); }
      if ((mm = s.match(/^(body(?![\w-])[^\s>+~]*)\s*>?\s*/i))) { if (!fits(probe.body, mm[1])) return null; s = s.slice(mm[0].length); }
      return s ? "#flow " + s : "#flow";
    };
    const out = [];
    const walk = rules => { for (const r of rules) {
      if (r.selectorText != null) { const sel = r.selectorText.split(/,(?![^(]*\))/).map(one).filter(Boolean); if (sel.length) out.push(sel.join(", ") + r.cssText.slice(r.cssText.indexOf("{"))); }
      else if (r.type === 7 || !r.cssRules) out.push(r.cssText);   // @keyframes, @font-face, @import…
      else { out.push(r.cssText.slice(0, r.cssText.indexOf("{")) + "{"); walk(r.cssRules); out.push("}"); } } };
    walk(st.sheet.cssRules); return absCssUrls(out.join("\n"), base);
  } catch (e) { return ""; }
};

{ const sd = showDoc; showDoc = async function () {
  const d = S.doc; liftBodyStyles(d);
  const r = await sd.apply(this, arguments);
  if (S.doc === d && d.kind !== "pdf") { applyPageCss(); if (d.meta?.faithful && d.meta.linkCss == null && /<link/i.test(d.meta.head || "")) loadLinkedCss(d); }
  return r;
}; }

/* ---------- v4 (extension 3): documents follow you to every computer through Google Drive ----------
   The extension's Google sign-in (library page) already syncs the highlights made on web pages.
   With it on, each Doc Reader document is also kept as one file, lpdoc-<id>.json, in the hidden app
   folder of your own Google Drive (scope drive.appdata: the extension sees only its own files).
   A sync runs on start, a few seconds after a save, when the tab comes back into view and every 5 minutes:
   for each document the newer copy wins; one removed here is removed there too (and the other way round).
   The web page version has no Google sign-in, so this is the extension only. */
const DSYNC = { busy: null, last: 0, state: "" };
async function dsToken(fresh) {
  const r = await chrome.runtime.sendMessage({ t: "driveToken", fresh: !!fresh }).catch(e => ({ ok: false, error: String(e.message || e) }));
  if (!r || !r.ok) throw Object.assign(new Error(r?.off ? "off" : (r?.error || "no Google sign-in")), { off: !!r?.off });
  return r;
}
async function dsFetch(path, opts = {}) {
  let t = await dsToken(); const go = () => fetch(t.api + path, { ...opts, headers: { ...(opts.headers || {}), Authorization: "Bearer " + t.token } });
  let r = await go(); if (r.status === 401) { t = await dsToken(true); r = await go(); }
  if (!r.ok) throw new Error("Google Drive answered " + r.status); return r;
}
async function dsPack(d) {
  const { handle, srcHandle, src, _page, ...doc } = d;
  return JSON.stringify({ format: "lpdoc", v: 1, kind: d.kind, name: d.name, app: "Lab Potato Doc Reader", doc, srcB64: src ? b64.enc(await src.arrayBuffer()) : null });
}
function dsUnpack(txt) {
  const p = JSON.parse(txt); if (p.format !== "lpdoc" || !p.doc?.id) throw new Error("not a Doc Reader document");
  return { ...p.doc, saved: true, src: p.srcB64 ? new Blob([b64.dec(p.srcB64)], { type: "application/pdf" }) : null };
}
/* resumable upload: any size, one file per document */
async function dsUpload(d, fileId) {
  const meta = { appProperties: { lpdoc: d.id, mod: String(d.modified || 0) }, ...(fileId ? {} : { name: `lpdoc-${d.id}.json`, parents: ["appDataFolder"] }) };
  const start = await dsFetch(fileId ? `/upload/drive/v3/files/${fileId}?uploadType=resumable` : "/upload/drive/v3/files?uploadType=resumable", { method: fileId ? "PATCH" : "POST", headers: { "Content-Type": "application/json; charset=UTF-8" }, body: JSON.stringify(meta) });
  const loc = start.headers.get("Location"); if (!loc) throw new Error("Google Drive gave no upload address");
  const r = await fetch(loc, { method: "PUT", headers: { "Content-Type": "application/json" }, body: await dsPack(d) });
  if (!r.ok) throw new Error("upload failed (" + r.status + ")");
}
async function docSync(why) {
  if (!IS_EXT) return { ok: false };
  if (DSYNC.busy) return DSYNC.busy;
  DSYNC.busy = (async () => {
    let got = 0, sent = 0, gone = 0;
    try {
      if (S.dirty) await saveNow();
      const files = (await (await dsFetch(`/drive/v3/files?spaces=appDataFolder&pageSize=1000&fields=files(id,name,appProperties)&q=${encodeURIComponent("name contains 'lpdoc-'")}`)).json()).files || [];
      const remote = new Map(files.filter(f => f.appProperties?.lpdoc).map(f => [f.appProperties.lpdoc, f]));
      const local = new Map(((await DB.all("docs")) || []).map(d => [d.id, d])), seen = Prefs.get("syncSeen", {}), next = {};
      for (const [id, d] of local) {
        const f = remote.get(id), rm = f ? +f.appProperties.mod || 0 : 0, lm = d.modified || 0;
        if (!f && seen[id] && lm <= seen[id]) { if (S.doc?.id !== id) { await DB.del("docs", id); gone++; } continue; }   // removed on another computer
        if (!f || lm > rm) { await dsUpload(d, f?.id); sent++; next[id] = lm; }
        else if (rm > lm) { if (await dsGet(f, d)) got++; next[id] = rm; }
        else next[id] = lm;
      }
      for (const [id, f] of remote) {
        if (local.has(id)) continue;
        if (seen[id]) { await dsFetch(`/drive/v3/files/${f.id}`, { method: "DELETE" }).catch(() => {}); gone++; continue; }   // removed here
        if (await dsGet(f, null)) { got++; next[id] = +f.appProperties.mod || 0; }
      }
      Prefs.set("syncSeen", next); DSYNC.last = Date.now(); DSYNC.state = "ok";
      if (got || gone) { if ($("#home") && !$("#home").hidden) listRecent(); }
      if (why === "button") toast(`Synced with Google Drive: ${sent} sent, ${got} received${gone ? `, ${gone} removed` : ""}.`);
      dsShow(); return { ok: true, got, sent, gone };
    } catch (e) {
      DSYNC.state = e.off ? "off" : "err:" + (e.message || e); dsShow();
      if (why === "button") toast(e.off ? "Sign in with Google first: press Google sign-in… on the start page." : "Sync failed: " + (e.message || e));
      return { ok: false, error: String(e.message || e) };
    }
  })();
  try { return await DSYNC.busy; } finally { DSYNC.busy = null; }
}
/* bring one document in; the open one is refreshed only if it has no unsaved changes */
async function dsGet(f, cur) {
  const d = dsUnpack(await (await dsFetch(`/drive/v3/files/${f.id}?alt=media`)).text());
  if (cur) { d.handle = cur.handle || null; d.srcHandle = cur.srcHandle || null; }
  if (S.doc?.id === d.id) { if (S.dirty) return false; await DB.put("docs", d); S.doc = null; await (d.kind === "pdf" ? openPdfDoc(d) : openDoc(d)); toast("This document was updated from another computer."); return true; }
  await DB.put("docs", d); return true;
}
/* a line on the start page: what is synced, and a button */
function dsShow() {
  if (!IS_EXT) return; let box = $("#syncCard");
  if (!box) { const side = $("#extCard")?.parentElement; if (!side) return;
    box = EL("div", { class: "home-card", id: "syncCard" }, EL("h3", {}, "Sync between computers"), EL("p", { class: "ds-line" }), EL("div", {}, EL("button", { class: "btn small", onclick: () => docSync("button") }, "Sync now"), " ", EL("button", { class: "btn small ghost", onclick: () => chrome.runtime.openOptionsPage() }, "Google sign-in…")));
    side.insertBefore(box, $("#extCard")); }
  const st = DSYNC.state, line = box.querySelector(".ds-line");
  line.textContent = st === "ok" ? `Your documents and page highlights are saved in your Google Drive (last synced ${fmtTime(DSYNC.last)}). Sign in with the same Google account on another computer to see them there.`
    : st === "off" || !st ? "Sign in with Google once to see your documents and page highlights on every computer you use."
    : "Last sync failed: " + st.slice(4);
  gdShow();
}
if (IS_EXT) {
  const later = debounce(() => docSync("save"), 8000);
  { const sn = saveNow; saveNow = async function () { const r = await sn.apply(this, arguments); if (!DSYNC.busy) later(); return r; }; }
  setTimeout(() => { dsShow(); docSync("start"); }, 2500);
  setInterval(() => docSync("timer"), 5 * 60000);
  document.addEventListener("visibilitychange", () => { if (!document.hidden && Date.now() - DSYNC.last > 60000) docSync("focus"); });
}

/* ---------- v5: save each written document as a Google Doc as well ----------
   Turned on in the "Sync between computers" card or the Export menu (extension only, needs Google sign-in).
   The first time, Google asks once more for permission to create files (scope drive.file: the extension can
   open only the files it made, nothing else in your Drive). Each written document then becomes one Google Doc
   in a "Lab Potato Doc Reader" folder in My Drive, updated about 15 seconds after you stop typing.
   The Google Doc gets the text as it reads now: AI suggestions not yet accepted are left out. */
const GD = { last: 0, err: "", busy: false };
const gdOn = () => IS_EXT && Prefs.get("gdocs", false);
const gdMap = () => Prefs.get("gdocMap", {});
async function gdFolder() {
  let id = Prefs.get("gdocsFolder", "");
  if (id) { const r = await dsFetch(`/drive/v3/files/${id}?fields=id,trashed`).catch(() => null); if (r && !(await r.json()).trashed) return id; }
  const r = await dsFetch("/drive/v3/files?fields=id", { method: "POST", headers: { "Content-Type": "application/json; charset=UTF-8" }, body: JSON.stringify({ name: "Lab Potato Doc Reader", mimeType: "application/vnd.google-apps.folder" }) });
  id = (await r.json()).id; Prefs.set("gdocsFolder", id); return id;
}
async function gdSave(why) {
  if (!gdOn() || GD.busy || !S.doc || S.doc.kind !== "flow") return;
  GD.busy = true; const d = S.doc;
  try {
    const html = await exportHtmlString({ appendComments: false }), map = gdMap(), have = map[d.id], name = baseName(d.name) || "Untitled";
    const b = "lpgd" + Date.now(), body = meta => `--${b}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${JSON.stringify(meta)}\r\n--${b}\r\nContent-Type: text/html; charset=UTF-8\r\n\r\n${html}\r\n--${b}--`;
    const hdr = { "Content-Type": "multipart/related; boundary=" + b };
    let f = null;
    if (have) f = await dsFetch(`/upload/drive/v3/files/${have.id}?uploadType=multipart&fields=id,webViewLink`, { method: "PATCH", headers: hdr, body: body({ name }) }).then(r => r.json()).catch(e => /40[34]/.test(e.message) ? null : Promise.reject(e));
    if (!f) f = await (await dsFetch("/upload/drive/v3/files?uploadType=multipart&fields=id,webViewLink", { method: "POST", headers: hdr, body: body({ name, mimeType: "application/vnd.google-apps.document", parents: [await gdFolder()] }) })).json();
    map[d.id] = { id: f.id, link: f.webViewLink || `https://docs.google.com/document/d/${f.id}/edit`, at: Date.now() }; Prefs.set("gdocMap", map);
    if (!have) toast("Saved as a Google Doc, in the Lab Potato Doc Reader folder of your Google Drive.");
    GD.last = Date.now(); GD.err = "";
  } catch (e) {
    GD.err = /403/.test(e.message) ? "Google did not allow it: turn Google Docs saving off and on again to give permission." : (e.off ? "Sign in with Google first." : String(e.message || e));
    if (why === "button") toast("Google Docs: " + GD.err);
  } finally { GD.busy = false; gdShow(); }
}
async function gdToggle(on) {
  if (!IS_EXT) return;
  if (on) {
    const r = await chrome.runtime.sendMessage({ t: "driveDocs", on: true }).catch(e => ({ ok: false, error: String(e.message || e) }));
    if (!r || !r.ok) { toast(r?.off ? "Sign in with Google first: press Google sign-in… on the start page." : "Google Docs saving was not turned on: " + (r?.error || "no answer")); gdShow(); return; }
    Prefs.set("gdocs", true); gdShow(); gdSave("button");
  } else { await chrome.runtime.sendMessage({ t: "driveDocs", on: false }).catch(() => {}); Prefs.set("gdocs", false); gdShow(); toast("Google Docs saving is off. Google Docs already saved stay in your Drive."); }
}
function gdShow() {
  const box = $("#syncCard"); if (!box) return;
  let row = box.querySelector(".gd-row");
  if (!row) { row = EL("div", { class: "gd-row" }, EL("label", { class: "gd-sw" }, EL("input", { type: "checkbox", onchange: e => gdToggle(e.target.checked) }), " Also save each written document as a Google Doc"), EL("p", { class: "gd-line muted" })); box.append(row); }
  row.querySelector("input").checked = !!gdOn();
  const n = Object.keys(gdMap()).length;
  row.querySelector(".gd-line").textContent = !gdOn() ? "They go to a \u201cLab Potato Doc Reader\u201d folder in your Google Drive and update as you write."
    : GD.err ? "Not saved: " + GD.err : GD.last ? `Last saved ${fmtTime(GD.last)}. ${n} document${n === 1 ? "" : "s"} in the \u201cLab Potato Doc Reader\u201d folder of your Drive.` : "On: each written document is saved to the \u201cLab Potato Doc Reader\u201d folder of your Drive as you write.";
}
if (IS_EXT) {
  const soon = debounce(() => gdSave("save"), 15000);
  { const sn = saveNow; saveNow = async function () { const r = await sn.apply(this, arguments); if (gdOn() && S.doc?.kind === "flow") soon(); return r; }; }
  /* Export menu: the switch, and a link to the open document's Google Doc */
  { const em = exportMenu; exportMenu = function (anchor) {
      if (S.doc?.kind !== "flow") return em.apply(this, arguments);
      const g = gdMap()[S.doc.id], m0 = menu;
      menu = (items, ...rest) => { menu = m0; return m0([...items, { sep: true }, { head: "Google Docs" },
        { label: (gdOn() ? "✓ " : "") + "Save as a Google Doc as I write", sub: gdOn() ? "On: updates about 15 s after you stop typing" : "Needs Google sign-in (start page)", fn: () => gdToggle(!gdOn()) },
        ...(g ? [{ label: "Open this document in Google Docs", sub: "Saved " + fmtTime(g.at), fn: () => window.open(g.link, "_blank", "noopener") }] : []),
        ...(gdOn() ? [{ label: "Save to Google Docs now", fn: () => { if (S.dirty) saveNow(); gdSave("button"); } }] : [])], ...rest); };
      try { return em.apply(this, arguments); } finally { menu = m0; } }; }
}

/* ---------- v6: safety nets ----------
   Recently removed: a document removed from the list (here, or on another computer through sync) is kept for
   30 days in this browser's storage (kv "trash:<id>") and can be restored from the start page.
   Earlier versions: while you write, a copy of the text is kept every 10 minutes (kv "snap:<id>", the last 40),
   and always before big one-shot changes (accept or reject every AI change, revert to the original).
   File menu → Earlier versions… shows them; restoring one first keeps the current text as a version too. */
const TRASH_DAYS = 30, SNAP_EVERY = 10 * 60000, SNAP_MAX = 40;
const kvKeys = () => DB.tx("kv", "readonly", s => s.getAllKeys());

/* --- recently removed --- */
{ const del0 = DB.del.bind(DB);
  DB.del = async function (store, k) {
    if (store === "docs") { try { const d = await DB.get("docs", k); if (d) { await DB.put("kv", { doc: d, at: Date.now() }, "trash:" + k); trashSoon(); } } catch (e) { console.warn("trash", e); } }
    return del0(store, k);
  }; }
const trashSoon = debounce(() => { drawTrashLink(); toast("Moved to Recently removed on the start page. You can restore it for " + TRASH_DAYS + " days."); }, 300);
async function trashList() {
  const keys = (await kvKeys()).filter(k => String(k).startsWith("trash:")), out = [], cut = Date.now() - TRASH_DAYS * 864e5;
  for (const k of keys) { const t = await DB.get("kv", k); if (!t || !t.doc || t.at < cut) { await DB.del("kv", k); continue; } out.push({ key: k, ...t }); }
  return out.sort((a, b) => b.at - a.at);
}
async function drawTrashLink() {
  const head = $(".recent-h"); if (!head) return;
  let a = $("#trashLink"); const n = (await trashList()).length;
  if (!a) { a = EL("button", { class: "btn small ghost", id: "trashLink", onclick: openTrash }); head.append(a); }
  a.hidden = !n; a.textContent = `Recently removed (${n})`;
}
async function openTrash() {
  const list = await trashList();
  const rows = list.map(t => `<div class="tr-row" data-k="${esc(t.key)}"><div class="tr-t"><b>${esc(t.doc.name || "Untitled")}</b><span class="muted">Removed ${fmtTime(t.at)} · kept until ${new Date(t.at + TRASH_DAYS * 864e5).toLocaleDateString()}</span></div><button class="btn small" data-tr="restore">Restore</button><button class="btn small ghost danger" data-tr="purge">Delete forever</button></div>`).join("");
  const p = modal(`<h3>Recently removed</h3><p class="muted">Documents removed in the last ${TRASH_DAYS} days, from this computer or from another one through sync. After that they are deleted for good.</p>
    <div class="tr-list">${rows || '<p class="muted">Nothing here.</p>'}</div><div class="mrow"><button class="btn" data-cancel>Close</button></div>`);
  $("#modal .tr-list")?.addEventListener("click", async e => {
    const b = e.target.closest("[data-tr]"); if (!b) return; const row = b.closest(".tr-row"), k = row.dataset.k, t = await DB.get("kv", k); if (!t) return row.remove();
    if (b.dataset.tr === "restore") { await DB.put("docs", { ...t.doc, modified: Date.now() }); await DB.del("kv", k); row.remove(); toast(`Restored "${t.doc.name}".`); listRecent(); }
    else if (confirm(`Delete "${t.doc.name}" for good? This cannot be undone.`)) { await DB.del("kv", k); row.remove(); }
    drawTrashLink();
  });
  await p; drawTrashLink();
}

/* --- earlier versions of a written document --- */
async function snapList(id) { return (await DB.get("kv", "snap:" + id)) || []; }
async function snapTake(why, force) {
  const d = S.doc; if (!d || d.kind !== "flow" || S.webview) return;
  // the text without unreviewed AI suggestions (their original words), as exports and saves write it
  const html = withOriginals(() => flowEl.innerHTML)().replace(/ class="(on|sel)"/g, ""), list = await snapList(d.id), last = list[0];
  if (last && last.html === html) return;
  if (!force && last && Date.now() - last.at < SNAP_EVERY) return;
  list.unshift({ at: Date.now(), why: why || "autosave", html, words: (EL("div", { html }).textContent.match(/\S+/g) || []).length });
  await DB.put("kv", list.slice(0, SNAP_MAX), "snap:" + d.id);
}
{ const sn = saveNow; saveNow = async function () { const r = await sn.apply(this, arguments); snapTake("autosave").catch(() => {}); return r; }; }
/* before the big one-shot changes, always */
{ const da = aiDecideAll; aiDecideAll = async function () { await snapTake("before accepting or rejecting every AI change", true).catch(() => {}); return da.apply(this, arguments); }; }
async function openVersions() {
  const d = S.doc; if (!d || d.kind !== "flow") return toast("Earlier versions are kept for written documents.");
  await snapTake("now", true);
  const list = await snapList(d.id);
  const rows = list.map((v, i) => `<div class="tr-row"><div class="tr-t"><b>${fmtTime(v.at)}</b><span class="muted">${v.words} words · ${esc(v.why === "autosave" ? "kept while you wrote" : v.why === "now" ? "the text as it is now" : v.why)}</span></div>${i ? `<button class="btn small ghost" data-v="${i}" data-a="peek">Preview</button><button class="btn small" data-v="${i}" data-a="use">Restore</button>` : '<span class="muted">current</span>'}</div>`).join("");
  const p = modal(`<h3>Earlier versions</h3><p class="muted">A copy of the text is kept every ${SNAP_EVERY / 60000} minutes while you write (the last ${SNAP_MAX}), and before big changes. Restoring keeps the current text as a version too, so nothing is lost.</p>
    <div class="tr-list">${rows}</div><div class="tr-peek" hidden></div><div class="mrow"><button class="btn" data-cancel>Close</button></div>`);
  $("#modal .tr-list")?.addEventListener("click", async e => {
    const b = e.target.closest("[data-v]"); if (!b) return; const v = list[+b.dataset.v]; if (!v) return;
    if (b.dataset.a === "peek") { const pk = $("#modal .tr-peek"); pk.hidden = false; pk.innerHTML = v.html; return; }
    await snapTake("before restoring the version of " + fmtTime(v.at), true);
    flowEl.innerHTML = v.html; S.dirty = true; await saveNow(); closeModal(null); toast("Restored the version of " + fmtTime(v.at) + ". The text before it is kept under Earlier versions.");
  });
  await p;
}
{ const sm = saveMenu; saveMenu = function (anchor) {
    if (S.doc?.kind !== "flow") return sm.apply(this, arguments);
    const m0 = menu; menu = (items, ...rest) => { menu = m0; const i = items.findIndex(x => x && x.sep); const add = { label: "Earlier versions…", sub: "Every 10 minutes while you write, and before big changes", fn: openVersions };
      return m0(i < 0 ? [...items, add] : [...items.slice(0, i), add, ...items.slice(i)], ...rest); };
    try { return sm.apply(this, arguments); } finally { menu = m0; } }; }

/* --- start --- */
{ const lr = listRecent; listRecent = async function () { const r = await lr.apply(this, arguments); drawTrashLink(); return r; }; }
setTimeout(() => { trashList().catch(() => {}); drawTrashLink(); }, 1500);
Object.assign(window, { snapTake, snapList, openVersions, trashList, openTrash, drawTrashLink, DB });   // for the tests and the console

/* ---------- v8: revision marks and the AI stage ----------
   Mark the text up in place: cross out (Alt+X, "remove this"), cross out for better wording (Alt+W,
   "replace this"), or a note to the AI (Alt+C). Select the passage and send it to the stage (Alt+S): a second
   pane on the right where the AI's version shows as tracked changes with the review strip, while the original
   stays untouched on the left. When every change is decided, Send back puts the result where the passage was.
   If the passage on the left was edited by hand in the meantime, both versions are shown and the author
   chooses; the AI's version never overwrites hand edits on its own. */
const RV = { X: ["rv-x", "Remove"], W: ["rv-w", "Replace with better wording"], C: ["rv-c", "Note to the AI"] };
/* a note to the AI is an ordinary comment (Alt+C, the Comment button): the stage reads the comments in the passage */
let stage = null;   // the open stage: { id, srcLight, instr }
const stageEl = $("#aiStage"), stageBody = EL("div", { class: "flow st-body", id: "stBody" });
aiExtraRoot = stageBody;

/* --- marks on the left --- */
async function rvMark(kind) {
  if (!S.doc || S.doc.kind !== "flow" || S.webview) return;
  const sel = getSelection(); if (!sel || sel.isCollapsed || !sel.rangeCount || !flowEl.contains(sel.anchorNode)) return toast("Select the words first.");
  const r = sel.getRangeAt(0).cloneRange(); if (!r.toString().trim()) return toast("Select some words first.");
  const sb = elOf(r.startContainer).closest(AI_BLOCK), eb = elOf(r.endContainer).closest(AI_BLOCK);
  if (!sb || sb !== eb) return toast("Mark inside one paragraph at a time.");
  if (elOf(r.commonAncestorContainer).closest(".ai-chg,.rv") || r.cloneContents().querySelector?.(".ai-chg,.rv")) return toast("That text is already marked.");
  let note = "";
  if (kind === "C") return flowComment();
  if (kind === "C_") { const v = await modal(`<h3>Note to the AI</h3><p class="muted">About: <i>${esc(r.toString().trim().slice(0, 160))}</i></p><textarea name="note" rows="3" placeholder="What should change here? e.g. make this the topic sentence, cite the control experiment, too strong a claim"></textarea><div class="mrow"><button class="btn" data-cancel>Cancel</button><button class="btn ai" data-ok>Add note</button></div>`); if (!v || !v.note?.trim()) return; note = v.note.trim(); }
  const id = uid(), span = EL("span", { class: "rv " + RV[kind][0], "data-rv": id, title: RV[kind][1] + (note ? ": " + note : "") + " · click to change" });
  if (note) span.dataset.note = note;
  try { span.append(r.extractContents()); r.insertNode(span); } catch (e) { return toast("Could not mark that: select whole words."); }
  sel.removeAllRanges(); flowEl.normalize(); aiCommit();
  if (!Prefs.get("rvSeen")) { Prefs.set("rvSeen", 1); toast("Marked. Select the passage and press Alt+S to send it, with its marks, to the AI stage."); }
}
function rvUnwrap(el) { el.replaceWith(...el.childNodes); flowEl.normalize(); }
flowEl.addEventListener("click", e => {
  const m = e.target.closest(".rv"); if (!m || !flowEl.contains(m)) return; const s = getSelection(); if (s && !s.isCollapsed) return;
  e.preventDefault(); e.stopPropagation();
  menu([{ head: RV[m.classList.contains("rv-x") ? "X" : m.classList.contains("rv-w") ? "W" : "C"][1] + (m.dataset.note ? ": " + m.dataset.note : "") },
    ...(m.classList.contains("rv-c") ? [{ label: "Change the note…", fn: async () => { const v = await modal(`<h3>Note to the AI</h3><textarea name="note" rows="3">${esc(m.dataset.note || "")}</textarea><div class="mrow"><button class="btn" data-cancel>Cancel</button><button class="btn ai" data-ok>Save</button></div>`); if (v && v.note?.trim()) { m.dataset.note = v.note.trim(); m.title = "Note to the AI: " + m.dataset.note + " · click to change"; aiCommit(); } } }] : []),
    { label: "Send this paragraph to the AI stage", k: "Alt+S", fn: () => { const r = document.createRange(); r.selectNodeContents(m.closest(AI_BLOCK) || m.parentElement); const g = getSelection(); g.removeAllRanges(); g.addRange(r); stageSend(""); } },
    { sep: true }, { label: "Remove this mark", sub: "The words stay", fn: () => { rvUnwrap(m); aiCommit(); } },
    { label: "Remove every mark in the document", fn: () => { $$(".rv", flowEl).forEach(rvUnwrap); aiCommit(); } }], m);
}, true);
/* the marks as instructions for the AI */
function rvInstructions(root) {
  const out = [], T = m => m.textContent.replace(/\s+/g, " ").trim();
  for (const m of $$(".rv, .cmt[data-id], s, strike, del:not(.ai-d):not(.ai-old)", root)) { const t = T(m); if (!t) continue;
    if (m.classList.contains("rv-w")) out.push(`Replace «${t}» with better wording`);
    else if (m.classList.contains("rv-x") || /^(S|STRIKE|DEL)$/.test(m.tagName)) out.push(`Remove: «${t}»`);
    else if (m.classList.contains("cmt")) { const c = S.doc.comments?.[m.dataset.id], note = (c && (c.text || c.note)) || m.dataset.note || ""; if (note.trim()) out.push(`About «${t}»: ${note.trim()}`); }
    else if (m.classList.contains("rv-c")) out.push(`About «${t}»: ${m.dataset.note || "see the note"}`); }
  return [...new Set(out)];
}
/* the bar that appears on a selection, for written documents: highlight and comment, the two marks, the AI.
   Each button is an icon with a short word; the key is in the tooltip. PDFs keep their own bar. */
{ const sp = showSelPop; showSelPop = function () {
    if (!S.doc || S.doc.kind !== "flow" || S.webview) return sp.apply(this, arguments);
    closeSelPop(); const sel = getSelection(); if (!sel || sel.isCollapsed || !sel.rangeCount) return;
    const r = sel.getRangeAt(0).getBoundingClientRect(); if (!r.width) return;
    const p = EL("div", { class: "imgtools selpop selpro", role: "toolbar", "aria-label": "Selection" });
    const B = (icon, lbl, fn, title, cls = "") => p.append(EL("button", { type: "button", class: cls, title, "aria-label": title, onclick: e => { e.preventDefault(); closeSelPop(); fn(); }, onpointerdown: e => e.preventDefault() }, ICON(icon), EL("span", { class: "lbl" }, lbl)));
    const sep = () => p.append(EL("span", { class: "sp-sep", "aria-hidden": "true" }));
    B("i-hl", "Highlight", () => flowHighlight(), "Highlight in the current colour");
    B("i-comment", "Comment", () => flowComment(), "Comment: a note on these words, which the AI reads too (Alt+C)");
    sep();
    B("i-strike", "Cross out", () => rvMark("X"), "Cross out: tell the AI to remove these words (Alt+X)", "rvx");
    B("i-rotate", "Reword", () => rvMark("W"), "Cross out for better wording: tell the AI to replace these words (Alt+W)", "rvw");
    sep();
    B("i-ai", "Ask AI", () => aiAskOpen(), "Ask the AI about these words, in place (Alt+A)", "ai");
    B("i-next", "AI stage", () => stageSend(""), "Send the passage, with its marks and comments, to the AI stage beside the text (Alt+S)", "ai stage");
    document.body.append(p);
    const w = p.offsetWidth, h = p.offsetHeight, x = clamp(r.left + r.width / 2 - w / 2, 8, innerWidth - w - 8), y = r.top - h - 10 > 56 ? r.top - h - 10 : r.bottom + 10;
    p.style.cssText = `position:fixed;left:${x}px;top:${y}px`;
  }; }
if (typeof SHORTCUTS !== "undefined") SHORTCUTS.push(["Revision marks and the AI stage", [["Alt+X", "Cross out (remove)"], ["Alt+W", "Cross out for better wording (replace)"], ["Alt+C", "Comment, which the AI reads as a note"], ["Alt+S", "Send the selection to the AI stage"], ["Alt+Enter", "Send back"], ["Alt+M", "Changes in colour / the changed version"], ["Alt+A", "Ask AI in place"]]], ["On the AI stage", [["Tab / Esc", "Accept / roll back the change at hand (a rewrite goes sentence by sentence)"], ["Select + Tab", "Accept just the selected words, then edit them"], ["Select + Esc", "Roll back the changes the selection touches"], ["Select + Alt+A", "Redo the selection with the AI"]]]);

/* --- the stage --- */
const aiRequestRaw = aiRequest;   // the in-place request, used only inside the stage
function stageDraw() {
  stageEl.innerHTML = "";
  stageEl.append(EL("div", { class: "st-head" }, ICON("i-ai"), EL("b", {}, "AI stage"), EL("span", { class: "muted st-n" }), EL("span", { style: "flex:1" }),
    EL("button", { class: "tb", id: "stFold", title: "Fold the other panels away", onclick: () => stageFold(!stage?.folded) }, "⇔"),
    EL("button", { class: "tb", title: "Hide the stage; the AI stage button in the toolbar brings it back", onclick: () => stageHide() }, ICON("i-x"))));
  stageEl.append(EL("div", { class: "st-instr", id: "stInstr" }));
  stageEl.append(stageBody);
  stageEl.append(EL("div", { class: "st-foot" }, EL("span", { class: "st-status", id: "stStatus" }),
    EL("button", { class: "btn ai st-back", id: "stBack", disabled: "", onclick: stageBack, title: "Put the result where the passage was (Alt+Enter)" }, "← Send back"),
    EL("span", { class: "st-foot-r" }, EL("button", { class: "btn small", onclick: () => stageClose(true), title: "Throw the AI's version away and keep the original" }, "Discard"))));
}
/* the stage shows the whole document, greyed, with the passage's block in focus: lines can be compared side by side */
function stageContext(id, srcLight) {
  const c = flowEl.cloneNode(true);
  $$("[id]", c).forEach(e => e.removeAttribute("id")); $$("[contenteditable]", c).forEach(e => e.removeAttribute("contenteditable"));
  $$(".ai-chg", c).forEach(x => x.replaceWith(aiOrigFrag(x)));
  const src = c.querySelector(`.rv-src[data-stage="${id}"]`); if (!src) return null;
  const block = src.closest(AI_BLOCK) || src.parentElement; block.classList.add("st-p");
  const focus = EL("span", { class: "st-focus", contenteditable: "true", spellcheck: "true" }); focus.append(lightFrag(srcLight)); src.replaceWith(focus);
  stageBody.className = "flow st-body " + [...flowEl.classList].filter(x => x !== "flow").join(" "); stageBody.id = "stBody";
  stageBody.style.cssText = flowEl.style.cssText; stageBody.style.padding = "";
  [...stageBody.attributes].filter(a => a.name.startsWith("data-")).forEach(a => stageBody.removeAttribute(a.name));
  [...flowEl.attributes].filter(a => a.name.startsWith("data-")).forEach(a => stageBody.setAttribute(a.name, a.value));
  stageBody.innerHTML = ""; stageBody.append(...c.childNodes);
  stageMatch(); return focus;
}
function stageSend(extra) {
  if (!S.doc || S.doc.kind !== "flow" || S.webview) return toast("The AI stage works in the Editor view of a written document.");
  const t = aiTarget(); if (t.err) return toast(t.err);
  closeSelPop(); aiAskClose();
  return stageSendRange(t.range, extra);
}
async function stageSendRange(range, extra) {
  if (stage && flowEl.querySelector(`.rv-src[data-stage="${stage.id}"]`)) { stageShow(); return toast("Finish the open stage first: Send back or Discard."); }
  const y0 = (() => { const e = elOf(range.startContainer); return (e.closest(AI_BLOCK) || e).getBoundingClientRect().top; })();   // where you were working, on screen
  $$(".rv-src", flowEl).forEach(rvUnwrap);
  const id = uid(), src = EL("span", { class: "rv-src", "data-stage": id, title: "On the AI stage. Edit it here if you like: your edits win over the AI's version." });
  src.append(range.extractContents()); range.insertNode(src); getSelection().removeAllRanges(); flowEl.normalize();
  const srcLight = toLight(src), marks = rvInstructions(src);
  const instr = [extra && extra.trim(), ...marks].filter(Boolean).join("\n") || "Improve the wording and the logical flow; keep the meaning, the facts and the citations.";
  stage = { id, srcLight, instr, y0 };
  stageDraw(); $(".st-n", stageEl).textContent = marks.length ? `${marks.length} mark${marks.length === 1 ? "" : "s"}` : "";
  $("#stInstr").innerHTML = instr.split("\n").map(l => `<div>${esc(l)}</div>`).join("");
  const focus = stageContext(id, srcLight); if (!focus) { stage = null; return toast("Could not open the stage for that passage."); }
  stageShow(); Prefs.set("aiPanelSeen", 1); stageFold(true); aiCommit();
  const r = document.createRange(); r.selectNodeContents(focus);
  stageAlign("viewer");
  await aiRequestRaw(r, instr);
  stageStatus(); stageAlign("viewer", true); setTimeout(() => stageAlign("viewer", true), 150); setTimeout(() => stageAlign("viewer", true), 600);   // once the fonts and the strip have settled
}
/* every AI request from the text opens on the stage; requests made inside the stage (revise a part, ask again) stay there */
aiRequest = async function (range, instr) {
  if (range && flowEl.contains(range.commonAncestorContainer) && !stageBody.contains(range.commonAncestorContainer)) return stageSendRange(range, instr);
  return aiRequestRaw.apply(this, arguments);
};
function stageShow() { stageEl.classList.remove("closed"); $(".work")?.classList.add("has-stage"); stageBtn(); if (stage && stage.folded) stageFold(true); stageMatch(); placeBar(); stageAlign("viewer", true); }
function stageHide() { stageEl.classList.add("closed"); $(".work")?.classList.remove("has-stage"); if (stage) { const f = stage.folded; stageFold(false); stage.folded = f; } stageBtn(); placeBar(); }
/* the toolbar button: open or hide the stage, with a dot while one is waiting */
function stageBtn() {
  let b = $("#stageBtn"); const anchor = $("#aiPanelBtn"); if (!b && anchor) { b = EL("button", { class: "tb flow-only ai-btn", id: "stageBtn", title: "AI stage (Alt+S on a selection)", onclick: () => { if (!stage) return toast("Select text and press AI stage on the bar, or Alt+S."); stageEl.classList.contains("closed") ? stageShow() : stageHide(); } }, ICON("i-next"), EL("span", { class: "lbl" }, "Stage")); anchor.after(b); }
  if (!b) return; b.classList.toggle("on", !!stage && !stageEl.classList.contains("closed")); b.classList.toggle("waiting", !!stage && stageEl.classList.contains("closed"));
}
/* the stage's text is set exactly like the original: the same font, size, spacing and the same width of
   text column, so every line breaks at the same word and the two can be read across */
function stageMatch() {
  if (!stage || stageEl.classList.contains("closed")) return;
  const cs = getComputedStyle(flowEl), col = flowEl.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight);
  for (const k of ["fontFamily", "fontSize", "lineHeight", "letterSpacing", "wordSpacing", "fontWeight", "fontStyle", "textAlign", "hyphens", "fontFeatureSettings", "fontKerning", "fontVariantLigatures", "textRendering", "color"]) stageBody.style[k] = cs[k];
  stageBody.style.setProperty("--z", cs.getPropertyValue("--z") || "1");
  const side = Math.max(14, (stageBody.clientWidth - col) / 2) + "px";
  if (stageBody.style.paddingLeft !== side) { stageBody.style.paddingLeft = side; stageBody.style.paddingRight = side; }
}
/* the two panes scroll together: the passage's block on the stage stays level with the original on the left */
let stageSyncing = false;
function stageAlign(from, force) {
  if (!stage || stageEl.classList.contains("closed") || stageSyncing) return;
  const L = flowEl.querySelector(`.rv-src[data-stage="${stage.id}"]`), R = stageBody.querySelector(".st-p"); if (!L || !R) return;
  // the same height on screen, so the eye moves straight across
  const lb = (L.closest(AI_BLOCK) || L).getBoundingClientRect(), rb = R.getBoundingClientRect();
  const d = rb.top - lb.top; if (Math.abs(d) < 1) return;
  stageSyncing = true;
  if (from === "stage") viewer.scrollTop -= d; else stageBody.scrollTop += d;
  // the stage could not move that far (it is at its top or bottom): on opening, the text pane gives way instead
  if (force) { let rem = R.getBoundingClientRect().top - (L.closest(AI_BLOCK) || L).getBoundingClientRect().top; if (Math.abs(rem) > 1) viewer.scrollTop += rem;
    // both panes already at their top and the stage's block still higher: push the stage's content down instead
    rem = R.getBoundingClientRect().top - (L.closest(AI_BLOCK) || L).getBoundingClientRect().top;
    if (rem < -1 && stageBody.scrollTop === 0) stageBody.style.paddingTop = (parseFloat(getComputedStyle(stageBody).paddingTop) - rem) + "px"; }
  requestAnimationFrame(() => { stageSyncing = false; });
}
viewer.addEventListener("scroll", () => stageAlign("viewer"), { passive: true });
stageBody.addEventListener("scroll", () => stageAlign("stage"), { passive: true });
addEventListener("resize", debounce(() => stageAlign("viewer"), 80));
/* either pane reflowing (panels folding, fonts arriving, the AI's answer) nudges the stage back level */
{ const ro = new ResizeObserver(debounce(() => { stageMatch(); stageAlign("viewer", true); }, 40)); [flowEl, stageBody, viewer].forEach(x => ro.observe(x)); }
/* fold: the Pages, Notes and chat panels go away so only the text and the stage are on screen; unfold brings
   back the ones that were open. The button in the stage's header switches between the two. */
function stageFold(on) {
  if (!stage) return; const L = $("#left"), R = $("#right"), C = $(".ai-panel");
  if (on && stageEl.classList.contains("closed")) { stage.folded = true; return; }
  if (on) { if (!stage.panels) stage.panels = { left: L && !L.classList.contains("closed"), right: R && !R.classList.contains("closed"), chat: C && !C.classList.contains("closed") };
    L?.classList.add("closed"); R?.classList.add("closed"); if (C && !C.classList.contains("closed")) aiTogglePanel(false); stage.folded = true; }
  else { const p = stage.panels || {}; if (p.left) L?.classList.remove("closed"); if (p.right) R?.classList.remove("closed"); if (p.chat) aiTogglePanel(true); stage.folded = false; stage.panels = null; }
  const b = $("#stFold"); if (b) { b.classList.toggle("on", !!stage.folded); b.title = stage.folded ? "Show the Pages, Notes and chat panels again" : "Fold the other panels away: only the text and the stage"; }
  placeBar(); stageAlign("viewer");
}
/* show changes / the changed version: the stage follows the switch too */
{ const am = aiMarkup; aiMarkup = function (on) { const r = am.apply(this, arguments); stageBody.classList.toggle("markup-off", !Prefs.get("aiMarkup", true)); return r; }; }
function stageStatus() {
  if (!stage) return; const busy = !!stageBody.querySelector(".busy"), open = $$(".ai-h", stageBody).length, back = $("#stBack"), st = $("#stStatus");
  if (!back) return;
  back.disabled = busy || open > 0;
  st.textContent = busy ? "The AI is working…" : open ? `${open} change${open === 1 ? "" : "s"} to review · Tab accepts, Esc rolls back · select part of a change to take just that and edit it` : stageBody.querySelector(".ai-chg") ? "" : "All decided. Send back puts this where the passage was.";
  stageBtn();
}
new MutationObserver(debounce(() => { stageStatus(); stageAlign("viewer"); }, 60)).observe(stageBody, { childList: true, subtree: true, attributes: true });
stageBody.addEventListener("click", e => { const c = e.target.closest(".ai-chg"); if (c && c.dataset.ai) { const h = e.target.closest(".ai-h"); if (h) aiSetHunk(h); else aiSetActive(c.dataset.ai); aiRenderChat(); } });
stageBody.addEventListener("scroll", () => requestAnimationFrame(placeBar), { passive: true });
/* the result, as clean html for the document: only the passage, not the greyed context */
function stageResultHtml() { const f = stageBody.querySelector(".st-focus"); if (!f) return ""; const c = f.cloneNode(true); $$(".ai-chg", c).forEach(x => x.replaceWith(...x.childNodes)); aiUnwrapOk(c); c.querySelectorAll("[contenteditable]").forEach(e => e.removeAttribute("contenteditable")); return c.innerHTML; }
async function stageBack() {
  if (!stage) return; stageShow(); if (stageBody.querySelector(".busy, .ai-h")) return toast("Decide every change first (Tab accepts, Esc rejects).");
  const src = flowEl.querySelector(`.rv-src[data-stage="${stage.id}"]`), html = stageResultHtml();
  if (!src) { await modal(`<h3>The passage is no longer in the document</h3><p>It was removed or undone while the stage was open. Copy the result below if you still want it.</p><div class="tr-peek">${html}</div><div class="mrow"><button class="btn" data-cancel>Close</button></div>`); return stageClose(false); }
  const now = toLight(src);
  if (now !== stage.srcLight) {   // edited by hand on the left: the author decides, nothing is overwritten
    const v = await modal(`<h3>You changed this passage yourself</h3><p class="muted">While the AI worked, the passage on the left was edited by hand, so the AI's version is not put in by itself.</p>
      <p><b>Yours now</b></p><div class="tr-peek">${src.innerHTML}</div><p><b>The AI's version</b></p><div class="tr-peek">${html}</div>
      <div class="mrow"><button class="btn" data-cancel>Keep mine</button><button class="btn" data-ok name="both" value="1">Keep both, the AI's after mine</button><button class="btn ai" data-ok name="ai" value="1">Use the AI's</button></div>`);
    if (!v) { stageClose(false); return toast("Kept your version. The AI's version is gone with the stage."); }
    if (v.both) { src.after(document.createTextNode(" "), lightOrHtml(html)); } else { src.innerHTML = ""; src.append(lightOrHtml(html)); }
  } else { src.innerHTML = ""; src.append(lightOrHtml(html)); }
  const kids = [...src.childNodes], y0 = stage.y0, anchor = src.closest(AI_BLOCK) || src.parentElement; src.replaceWith(...kids); flowEl.normalize(); aiCommit();
  kids.filter(n => n.nodeType === 1).forEach(flashEl); stageClose(false); stageReturn(anchor, y0); toast("Sent back: the passage now reads as the AI's version.");
}
/* after Send back or Discard the text comes back to where you were working: the passage at the same height on
   screen as when you sent it, whatever the stage and the folded panels did to the layout meanwhile */
function stageReturn(el, y0) {
  if (!el || y0 == null) return;
  const go = () => { if (!el.isConnected) return; const d = el.getBoundingClientRect().top - y0; if (Math.abs(d) > 1) viewer.scrollTop += d; };
  requestAnimationFrame(() => { go(); setTimeout(go, 120); setTimeout(go, 400); });
}
function stageClose(keepMarks) {
  const src = stage && flowEl.querySelector(`.rv-src[data-stage="${stage.id}"]`), back = src && (src.closest(AI_BLOCK) || src.parentElement), y0 = stage?.y0; if (src) rvUnwrap(src);
  setTimeout(() => stageReturn(back, y0), 0);
  $$(".ai-chg[data-ai]", stageBody).forEach(x => { const ch = aiChange(x.dataset.ai); if (ch && ch.status === "pending") ch.status = "discarded"; });
  if (stage) stageFold(false);
  stageBody.innerHTML = ""; stageEl.classList.add("closed"); $(".work")?.classList.remove("has-stage"); stage = null; stageBtn();
  if (aiActive && !aiSpan(aiActive)) aiSetHunk(null); aiCommit(); aiRenderChat();
}
/* a stage left in a saved document is stale: the source marker goes, the marks stay */
{ const od = openDoc; openDoc = async function () { const r = await od.apply(this, arguments); $$(".rv-src", flowEl).forEach(rvUnwrap); stageBody.innerHTML = ""; stageEl.classList.add("closed"); $(".work")?.classList.remove("has-stage"); stage = null; stageBtn(); return r; }; }
{ const gh = goHome; goHome = function () { stageBody.innerHTML = ""; stageEl.classList.add("closed"); $(".work")?.classList.remove("has-stage"); stage = null; stageBtn(); return gh.apply(this, arguments); }; }

/* --- the ask box gets a "to the stage" button; the AI menu gets the marks --- */
{ const ao = aiAskOpen; aiAskOpen = function () { const r = ao.apply(this, arguments); if (!aiAskEl) return r;
    const ta = aiAskEl.querySelector("textarea"), row = aiAskEl.querySelector(".arow");
    if (row) row.insertBefore(EL("button", { class: "btn small", title: "Open the AI's version on a stage beside the text instead of in place (Alt+S)", onclick: () => stageSend(ta.value.trim()) }, "On the stage →"), row.lastChild);
    return r; }; }
/* demo mode honours the marks, so the stage can be tried without a key */
{ const dr = aiDemoRevise; aiDemoRevise = async function (ch, o) { const res = await dr.apply(this, arguments);
    const take = re => [...ch.instr.matchAll(re)].map(m => m[1]); let t = res.revision ?? res.text ?? "";
    for (const x of take(/^Remove: «(.+?)»$/gm)) t = t.replace(x, "").replace(/\s{2,}/g, " ").replace(/\s+([,.;:])/g, "$1");
    for (const x of take(/^Replace «(.+?)» with better wording$/gm)) { let y = x.replace(/\bvery\s+/gi, "").replace(/\bin order to\b/gi, "to").replace(/\ba large number of\b/gi, "many").replace(/\bdue to the fact that\b/gi, "because").replace(/\bis able to\b/gi, "can"); if (y === x) y = x.replace(/^(\w+)/, (m, w) => ({ big: "substantial", good: "effective", bad: "poor", shows: "demonstrates", got: "obtained", used: "employed", examined: "scrutinised" })[w.toLowerCase()] || w) ; if (y === x) y = "notably, " + x; t = t.replace(x, y); }
    if (res.revision != null) res.revision = t; else res.text = t; return res; }; }
{ const am = aiChatMenu; aiChatMenu = function (anchor) { const m0 = menu; menu = (items, ...rest) => { menu = m0; return m0([
    { head: "Revision marks → AI stage" },
    { label: "Cross out", k: "Alt+X", sub: "Tell the AI to remove these words", fn: () => rvMark("X") },
    { label: "Cross out for better wording", k: "Alt+W", sub: "Tell the AI to replace these words", fn: () => rvMark("W") },
    { label: "Comment, as a note to the AI", k: "Alt+C", sub: "The AI reads the comments in the passage you send", fn: () => flowComment() },
    { label: "Send the selection to the AI stage", k: "Alt+S", sub: "The AI's version beside the text; Send back when decided", fn: () => stageSend("") },
    { sep: true }, ...items], ...rest); }; try { return am.apply(this, arguments); } finally { menu = m0; } }; }

/* --- take part of the AI's version: select inside it on the stage, then
   Accept & edit: the selected words are yours now (editable at once), the rest of that change stays to review;
   Roll back: the changes the selection touches go back to your words;
   Redo with AI: those changes (joined into one) are written again, with an optional note. On text already
   decided, Redo asks the AI for a new version of just that selection. */
const stHunks = range => $$(".ai-h", stageBody).filter(h => !h.classList.contains("busy") && range.intersectsNode(h));
const stHasText = f => /\S/.test(f.textContent);
function stCaretAfter(node) {
  if (!node || !node.isConnected) return; const host = node.parentElement?.closest("[contenteditable=true]"); host?.focus({ preventScroll: true });
  const r = document.createRange(); r.setStartAfter(node); r.collapse(true); const sel = getSelection(); sel.removeAllRanges(); sel.addRange(r);
}
function stagePartAccept(range) {
  const hs = stHunks(range); if (!hs.length) return false;
  const spans = new Set(); let last = null;
  for (const h of hs) {
    const s = h.closest(".ai-chg"), ins = h.querySelector("ins"), del = h.querySelector("del"); spans.add(s);
    if (!ins) { h.remove(); s.dataset.acc = "1"; continue; }   // a sentence the AI dropped: taking the selection over it takes the removal
    const r = document.createRange(); r.selectNodeContents(ins);
    if (range.compareBoundaryPoints(Range.START_TO_START, r) > 0) r.setStart(range.startContainer, range.startOffset);
    if (range.compareBoundaryPoints(Range.END_TO_END, r) < 0) r.setEnd(range.endContainer, range.endOffset);
    if (r.collapsed || !stHasText(r.cloneContents())) continue;
    const piece = (a, b) => { const x = document.createRange(); x.setStart(...a); x.setEnd(...b); return x.cloneContents(); };
    const bef = piece([ins, 0], [r.startContainer, r.startOffset]), aft = piece([r.endContainer, r.endOffset], [ins, ins.childNodes.length]), mid = r.cloneContents();
    // once part of a sentence is taken, your sentence is replaced: rolling back the rest drops the AI's leftover
    // words instead of putting your whole sentence back beside the part you kept. It stays readable on hover.
    const was = (del ? del.textContent.trim() : "") || (h.title || "").replace(/^Your sentence: /, "");
    const keepB = stHasText(bef), keepA = stHasText(aft), mk = f => { const n = EL("span", { class: "ai-h part", title: was ? "Your sentence was: " + was : "Added by the AI" }); const i2 = EL("ins", { class: ins.className }); i2.append(f); n.append(i2); return n; };
    const ok = EL("span", { class: "ai-ok", contenteditable: "true", spellcheck: "true" });
    if (!keepB) ok.append(bef); ok.append(mid); if (!keepA) ok.append(aft);
    const nodes = []; if (keepB) nodes.push(mk(bef)); nodes.push(ok); if (keepA) nodes.push(mk(aft));
    h.replaceWith(...nodes); s.dataset.acc = "1"; last = ok.lastChild;
  }
  for (const s of spans) if (s.isConnected && !hunksIn(s).length) aiFinish(s, aiChange(s.dataset.ai));
  stageBody.querySelector(".st-focus")?.normalize(); aiCommit();
  const rest = allHunks().filter(h => stageBody.contains(h)); aiSetHunk(rest.find(h => last && last.isConnected && (last.compareDocumentPosition(h) & Node.DOCUMENT_POSITION_FOLLOWING)) || rest[0] || null); aiRenderChat();
  stCaretAfter(last); return true;
}
function stagePartReject(range) { const hs = stHunks(range); hs.forEach(h => h.isConnected && aiDecide(h, false)); return hs.length > 0; }
/* the changes a selection touches, with the unchanged words between them, joined into one change */
function stJoin(hs) {
  const s = hs[0].closest(".ai-chg"); hs = hs.filter(h => h.closest(".ai-chg") === s); if (hs.length === 1) return hs[0];
  const n = EL("span", { class: "ai-h" }), d = EL("del", { class: "ai-d ai-old" }), i = EL("ins", { class: "ai-i ai-new" }), first = hs[0], lastH = hs[hs.length - 1];
  let x = first; const gone = [];
  while (x) { gone.push(x);
    if (x.nodeType === 1 && x.classList.contains("ai-h")) { const xd = x.querySelector("del"), xi = x.querySelector("ins"); if (xd) d.append(...xd.cloneNode(true).childNodes); if (xi) i.append(...xi.cloneNode(true).childNodes); }
    else if (x.nodeType === 1 && x.classList.contains("ai-ok")) { d.append(...x.cloneNode(true).childNodes); i.append(...x.cloneNode(true).childNodes); }
    else { d.append(x.cloneNode(true)); i.append(x.cloneNode(true)); }
    if (x === lastH) break; x = x.nextSibling; }
  if (d.textContent) n.append(d); if (i.textContent) n.append(i);
  first.before(n); gone.forEach(g => g.remove()); return n;
}
function stagePartRedo(range, extra) {
  const hs = stHunks(range);
  if (hs.length) { const h = stJoin(hs); aiSetHunk(h); return aiReviseHunk(h, extra); }
  return aiRequestRaw(range, extra || "Write this part differently; keep the meaning, the facts and the citations.");
}
function stageSelPop() {
  closeSelPop(); $$(".st-pop").forEach(x => x.remove()); if (!stage) return; const sel = getSelection(); if (!sel || sel.isCollapsed || !sel.rangeCount) return;
  const range = sel.getRangeAt(0), focus = stageBody.querySelector(".st-focus"); if (!focus || !focus.contains(range.commonAncestorContainer) && !range.intersectsNode(focus)) return;
  const r = range.getBoundingClientRect(); if (!r.width) return;
  const keep = range.cloneRange(), hs = stHunks(keep), p = EL("div", { class: "imgtools selpop selpro st-pop", role: "toolbar", "aria-label": "Part of the AI's version" });
  const B = (icon, lbl, fn, title, cls = "") => p.append(EL("button", { type: "button", class: cls, title, "aria-label": title, onclick: e => { e.preventDefault(); fn(); }, onpointerdown: e => e.preventDefault() }, icon === "tick" ? lightOrHtml('<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>') : ICON(icon), EL("span", { class: "lbl" }, lbl)));
  // the note box survives the selection going away (focus moves into it); it closes itself
  const redoBox = () => { p.classList.remove("selpop"); p.innerHTML = ""; const inp = EL("input", { type: "text", placeholder: "What should change? (optional) Enter sends", "aria-label": "Instructions for the AI" });
    const shut = () => p.remove(), go = () => { const x = inp.value.trim(); shut(); stagePartRedo(keep, x); };
    inp.addEventListener("keydown", e => { if (e.key === "Enter") { e.preventDefault(); go(); } else if (e.key === "Escape") { e.preventDefault(); shut(); } e.stopPropagation(); });
    p.addEventListener("focusout", () => setTimeout(() => { if (!p.contains(document.activeElement)) shut(); }, 150));
    p.append(ICON("i-ai"), inp, EL("button", { type: "button", class: "ai stage", onclick: e => { e.preventDefault(); go(); } }, EL("span", { class: "lbl" }, "Redo"))); inp.focus(); };
  if (hs.length) {
    B("tick", "Accept & edit", () => { closeSelPop(); stagePartAccept(keep); }, "Take the selected words; you can edit them straight away. The rest of the change stays to review (Tab)", "ok");
    B("i-undo", "Roll back", () => { closeSelPop(); stagePartReject(keep); }, "Put your own words back for the changes the selection touches (Esc)", "rvx");
    p.append(EL("span", { class: "sp-sep", "aria-hidden": "true" }));
  }
  B("i-ai", "Redo with AI", redoBox, hs.length ? "Ask the AI to write the selected change(s) again, optionally saying what is wrong (Alt+A)" : "Ask the AI for a new version of just these words (Alt+A)", "ai");
  document.body.append(p);
  const w = p.offsetWidth, h = p.offsetHeight, x = clamp(r.left + r.width / 2 - w / 2, 8, innerWidth - w - 8), y = r.top - h - 10 > 56 ? r.top - h - 10 : r.bottom + 10;
  p.style.cssText = `position:fixed;left:${x}px;top:${y}px`; p._range = keep; p._redo = redoBox; p._hunks = hs.length;
}
stageBody.addEventListener("mouseup", () => setTimeout(stageSelPop, 10));
stageBody.addEventListener("keyup", e => { if (e.shiftKey && /^(Arrow|Home|End)/.test(e.key)) stageSelPop(); });
stageBody.addEventListener("mousedown", () => { closeSelPop(); $$(".st-pop").forEach(x => x.remove()); });
stageBody.addEventListener("input", () => { closeSelPop(); stageStatus(); });
/* the passage on the stage is one editing area: no locked islands inside it (a drag that starts on a locked
   island selects nothing once the passage has the focus). Changes still under review are guarded instead:
   typing into one, or deleting across one, is stopped with a hint. Everything else, the accepted words
   included, edits freely. */
const stUnlock = () => $$(".st-focus [contenteditable]", stageBody).forEach(e => e.removeAttribute("contenteditable"));
new MutationObserver(stUnlock).observe(stageBody, { childList: true, subtree: true, attributes: true, attributeFilter: ["contenteditable"] });
let stHintAt = 0;
stageBody.addEventListener("beforeinput", e => {
  const f = stageBody.querySelector(".st-focus"); if (!f || !f.contains(e.target === f ? f : e.target)) return;
  const pend = $$(".ai-h, .ai-chg.busy", f); if (!pend.length) return;
  const rs = e.getTargetRanges ? e.getTargetRanges() : []; const ranges = rs.length ? rs : (getSelection().rangeCount ? [getSelection().getRangeAt(0)] : []);
  const hit = ranges.some(sr => { const r = document.createRange(); try { r.setStart(sr.startContainer, sr.startOffset); r.setEnd(sr.endContainer, sr.endOffset); } catch (x) { return false; }
    if (r.collapsed) return !!elOf(r.startContainer)?.closest(".ai-h, .ai-chg.busy");
    return pend.some(h => r.intersectsNode(h)); });
  if (!hit) return;
  e.preventDefault();
  if (Date.now() - stHintAt > 2500) { stHintAt = Date.now(); toast("That part is still a suggestion: Tab or Accept & edit takes it, then you can change it."); }
});
/* keys on the stage, before the in-place review keys: with the bar up, Tab takes the selection, Esc rolls it
   back, Alt+A redoes it. While you type in accepted words, Tab moves on to the next change and Esc stops editing. */
addEventListener("keydown", e => {
  if (!stage || !$("#modalBack").hidden || e.ctrlKey || e.metaKey) return;
  const p = $(".st-pop"); if (p && e.target.closest?.(".st-pop")) return;
  if (p && p._range) {
    if (e.key === "Tab" && !e.altKey && !e.shiftKey && p._hunks) { e.preventDefault(); e.stopPropagation(); closeSelPop(); stagePartAccept(p._range); return; }
    if (e.key === "Escape" && !e.altKey && p._hunks) { e.preventDefault(); e.stopPropagation(); closeSelPop(); stagePartReject(p._range); return; }
    if (e.altKey && !e.shiftKey && e.code === "KeyA") { e.preventDefault(); e.stopPropagation(); p._redo(); return; }
  }
  if (!stageBody.contains(e.target) || e.altKey || e.shiftKey) return;
  if (e.key !== "Tab" && e.key !== "Escape") return;
  const editing = getSelection().anchorNode && elOf(getSelection().anchorNode)?.closest?.(".ai-ok");
  const next = () => { const rest = allHunks().filter(h => stageBody.contains(h)); return rest.find(h => !aiHunk || h === aiHunk) || rest[0] || null; };
  e.preventDefault(); e.stopPropagation();
  if (editing || !aiHunk || !aiHunk.isConnected) { e.target.blur?.(); getSelection().removeAllRanges(); if (e.key === "Tab") { const h = next(); if (h) { aiSetHunk(h); h.scrollIntoView({ block: "nearest" }); } } return; }
  aiDecide(aiHunk, e.key === "Tab");
}, true);

/* --- Web layout: the document as a web page. It is the editor itself, so every tool, the AI and the stage
   work as in the page view; only the paper sheet goes: the text runs the whole width of the window.
   A page saved with its own styles can still be seen exactly as the site drew it ("Original page look",
   the older web view with its floating bar). --- */
const webOn = () => document.body.classList.contains("weblayout");
function webLayout(on, save = true) {
  on = on == null ? !webOn() : !!on;
  if (S.webview) exitWebView();
  document.body.classList.toggle("weblayout", on); if (save) Prefs.set("webLayout", on);
  const b = $('.tbar [data-act="webView"]');
  if (b) { b.classList.toggle("on", on); b.title = on ? "Web layout is on: click for the page view (paper sheet, print layout)" : "Web layout: the document as a web page across the whole window, with every tool"; }
  try { layoutMargin(); } catch (e) { /* no margin yet */ }
  placeBar(); stageMatch(); stageAlign("viewer", true);
}
const enterWebViewExact = enterWebView; let wvExact = false;
enterWebView = function () { if (S.doc?.kind === "flow" && !wvExact) return webLayout(true, false); wvExact = false; return enterWebViewExact.apply(this, arguments); };
function originalLook() { wvExact = true; return enterWebView(); }
document.addEventListener("click", e => {
  const b = e.target.closest?.('.tbar [data-act="webView"]'); if (!b) return;
  e.preventDefault(); e.stopImmediatePropagation();
  if (S.doc?.meta?.head && !webOn()) return menu([
    { label: "Web layout", sub: "The whole width of the window, with every tool", fn: () => webLayout(true) },
    { label: "Original page look", sub: "Exactly as the site drew it, with a small floating toolbar", fn: originalLook }], b);
  webLayout();
}, true);
{ const b = $('.tbar [data-act="webView"]'); if (b) b.title = "Web layout: the document as a web page across the whole window, with every tool"; }
/* v8: no way home by mistake while a document is open: the Documents button, the All tools link, the web view's
   home button and the Lab Potato link are hidden or inert. Save → Close document… goes back, after asking. */
{ const od = openDoc; openDoc = async function () { const r = await od.apply(this, arguments); document.body.classList.toggle("doc-open", !!S.doc); return r; }; }
{ const gh = goHome; goHome = function () { document.body.classList.remove("doc-open"); return gh.apply(this, arguments); }; }
{ const sm = saveMenu; saveMenu = function (anchor) {
    const m0 = menu; menu = (items, ...rest) => { menu = m0; return m0([...items, { sep: true }, { label: "Close document…", sub: "Back to your documents; it stays saved", fn: () => { if (confirm("Close this document and go back to your documents? It stays saved.")) goHome(); } }], ...rest); };
    try { return sm.apply(this, arguments); } finally { menu = m0; } }; }
/* the choice is remembered: each document opens in the layout used last (the settings are loaded by then) */
{ const od = openDoc; openDoc = async function () { const r = await od.apply(this, arguments); if (S.doc?.kind === "flow" && !S.webview) webLayout(Prefs.get("webLayout", false), false); return r; }; }

/* keys (before the Word layer): Alt+X / W / C mark, Alt+S sends, Alt+Enter sends back */
document.addEventListener("keydown", e => {
  if (!S.doc || S.doc.kind !== "flow" || S.webview || !e.altKey || e.ctrlKey || e.metaKey || e.shiftKey) return;
  if (e.target.closest("input,textarea,select") || !$("#modalBack").hidden) return;
  const k = e.code;
  if (k === "KeyX") { e.preventDefault(); e.stopPropagation(); rvMark("X"); }
  else if (k === "KeyW") { e.preventDefault(); e.stopPropagation(); rvMark("W"); }
  else if (k === "KeyC") { e.preventDefault(); e.stopPropagation(); flowComment(); }
  else if (k === "KeyS") { e.preventDefault(); e.stopPropagation(); stageSend(""); }
  else if (e.key === "Enter" && stage) { e.preventDefault(); e.stopPropagation(); stageBack(); }
}, true);
Object.assign(window, { webLayout, originalLook, stageMatch, aiChange, aiPaint, aiSetActive, stagePartAccept, stagePartReject, stagePartRedo, stageSelPop, aiSentenceHunks, rvMark, stageSend, stageBack, stageClose, stageHide, stageShow, stageAlign, showSelPop, closeSelPop, get stage() { return stage; } });
setTimeout(stageBtn, 0);   // for the tests and the console

/* a few names on window, for the tests and the console */
Object.assign(window, { S, exportPdf, exportMarkdown, saveProjectFile, saveNow, goHome, convertToFlow, insertTable, insertImageFile, rotatePage, insertBlank, deletePage, setTheme, openUrl, openFile, flowHighlight, flowComment, saveToSource, exportHtmlString, pdfToHtml, pdfToMarkdown, setZoom, editImage, sourceBlob, flowChanged, redrawAllAnnots, selectAnnot, normRect, enterWebView, exitWebView, wvDoc, wvPull, openLightbox, Prefs });

})();
