/* Lab Potato Doc Reader v3: the extension's background worker.
   The tools now work on top of the page itself (content.js). The toolbar icon (or Alt+Shift+R) opens
   and folds them; on pages where an extension can't run (the Web Store, chrome:// pages, the PDF viewer)
   it opens Doc Reader instead. "Open in Doc Reader" copies the page as it is shown, with your marks. */
const isPdf = url => /\.pdf($|[?#])/i.test(url || "") || /^chrome-extension:\/\/mhjfbmdgcfjbbpaeojofohoefgiehjai\//.test(url || "");
const reader = q => chrome.tabs.create({ url: chrome.runtime.getURL("reader.html" + (q || "")) });
const library = () => chrome.tabs.create({ url: chrome.runtime.getURL("library.html") });

/* the tools on this tab: ask the page; if the page was open before the extension was installed, add them first */
async function onPage(tab, msg) {
  const url = tab.url || "";
  if (!/^(https?|file):/i.test(url) || /^https:\/\/chrome(webstore)?\.google\.com\/(webstore|extensions)/i.test(url)) return false;
  if (isPdf(url)) return false;
  try { await chrome.tabs.sendMessage(tab.id, msg); return true; }
  catch (e) {
    try { await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] }); await new Promise(r => setTimeout(r, 300)); await chrome.tabs.sendMessage(tab.id, msg); return true; }
    catch (e2) { return false; }
  }
}
async function toggle(tab) {
  if (await onPage(tab, { t: "toggle" })) return;
  const url = tab.url || "";
  if (isPdf(url)) reader("?file=" + encodeURIComponent(url)); else if (/^https?:/i.test(url)) openPage(tab, false); else reader();
}

async function openPage(tab, selectionOnly) {
  const url = tab.url || "";
  if (!url || /^(chrome|edge|about|devtools):/i.test(url)) return reader();
  if (isPdf(url) && !selectionOnly) return reader("?file=" + encodeURIComponent(url));
  try {
    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: sel => {
        let selection = "";
        if (sel) { const s = getSelection(); if (s && !s.isCollapsed) { const d = document.createElement("div"); for (let i = 0; i < s.rangeCount; i++) d.append(s.getRangeAt(i).cloneContents()); selection = d.innerHTML; } }
        // styles the page added from script (CSS-in-JS, adopted sheets) are not in any <style> text: copy their rules
        let extra = "";
        for (const sh of [...document.styleSheets, ...(document.adoptedStyleSheets || [])]) {
          try { const own = sh.ownerNode; if (own && own.tagName === "LINK") continue; if (own && own.textContent.trim()) continue; extra += [...sh.cssRules].map(r => r.cssText).join("\n") + "\n"; } catch (e) { /* another site's sheet */ }
        }
        const doc = document.documentElement.cloneNode(true);
        doc.querySelectorAll("script,noscript,#lp-dr-host").forEach(e => e.remove());
        doc.querySelector("body")?.removeAttribute("contenteditable");
        // lazy pictures: use the real address
        doc.querySelectorAll("img").forEach(im => { const ds = im.getAttribute("data-src") || im.getAttribute("data-lazy-src") || im.getAttribute("data-original"); if (ds && (!im.getAttribute("src") || /^data:/.test(im.getAttribute("src")))) im.setAttribute("src", ds); im.removeAttribute("loading"); });
        // your highlights and comments travel as Doc Reader marks
        const comments = {}, LP = window.__lpDR?.data;
        const byId = LP ? Object.fromEntries(LP.marks.map(m => [m.id, m])) : {};
        doc.querySelectorAll("lp-hl").forEach(w => { const m = byId[w.dataset.id] || { color: "#ffe066", note: "", at: Date.now() };
          const n = document.createElement(m.note ? "span" : "mark"); if (m.note) n.className = "cmt"; n.dataset.id = w.dataset.id; n.style.setProperty(m.note ? "--c" : "--hl", m.color);
          while (w.firstChild) n.append(w.firstChild); w.replaceWith(n);
          comments[w.dataset.id] = { at: m.at || Date.now(), color: m.color, t: m.note ? "cmt" : "mark", text: m.note || "" }; });
        if (extra) { const st = document.createElement("style"); st.textContent = extra; doc.querySelector("head")?.append(st); }
        if (Object.keys(comments).length) { const j = document.createElement("script"); j.type = "application/json"; j.id = "lp-comments"; j.textContent = JSON.stringify(comments); doc.querySelector("body")?.append(j); }
        return { html: "<!doctype html>" + doc.outerHTML, url: location.href, title: document.title, selection };
      },
      args: [!!selectionOnly]
    });
    if (selectionOnly && !result.selection) return reader("?url=" + encodeURIComponent(url));
    const key = "cap-" + Date.now();
    await chrome.storage.local.set({ [key]: result });
    reader("?cap=" + key);
  } catch (e) {
    // pages that refuse scripts (the Web Store, some PDFs): fetch by address instead
    reader("?url=" + encodeURIComponent(url));
  }
}

chrome.action.onClicked.addListener(tab => toggle(tab));
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({ id: "lp-hl", title: "Highlight (Lab Potato)", contexts: ["selection"] });
    chrome.contextMenus.create({ id: "lp-tools", title: "Lab Potato tools on this page", contexts: ["page"] });
    chrome.contextMenus.create({ id: "lp-page", title: "Open this page in Doc Reader", contexts: ["page"] });
    chrome.contextMenus.create({ id: "lp-sel", title: "Open the selection in Doc Reader", contexts: ["selection"] });
    chrome.contextMenus.create({ id: "lp-link", title: "Open this link in Doc Reader", contexts: ["link"] });
    chrome.contextMenus.create({ id: "lp-lib", title: "All my marked pages", contexts: ["action"] });
    chrome.contextMenus.create({ id: "lp-new", title: "New blank document in Doc Reader", contexts: ["action"] });
  });
});
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  const id = info.menuItemId;
  if (id === "lp-hl") { if (!(await onPage(tab, { t: "highlight" }))) openPage(tab, true); }
  else if (id === "lp-tools") toggle(tab);
  else if (id === "lp-page") openPage(tab, false);
  else if (id === "lp-sel") openPage(tab, true);
  else if (id === "lp-link") reader(isPdf(info.linkUrl) ? "?file=" + encodeURIComponent(info.linkUrl) : "?url=" + encodeURIComponent(info.linkUrl));
  else if (id === "lp-lib") library();
  else if (id === "lp-new") reader();
});
chrome.runtime.onMessage.addListener((msg, sender) => {
  if (msg.t === "reader" && sender.tab) openPage(sender.tab, false);
  else if (msg.t === "library") library();
});
