/* every page with highlights, comments or edits, newest first; open, export or remove */
const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
let PAGES = [];
const md = p => `# ${p.title || p.url}\n\n<${p.url}>\n\n` + p.marks.map(m => `> ${m.quote.exact}\n${m.note ? `\n${m.note}\n` : ""}`).join("\n") + (p.edits.length ? `\n_${p.edits.length} paragraph(s) edited on the page._\n` : "");
function download(text, name) { const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([text], { type: "text/markdown" })); a.download = name; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 3000); }
async function load() {
  const all = await chrome.storage.local.get(null);
  PAGES = Object.entries(all).filter(([k, v]) => k.startsWith("lp:") && k !== "lp:settings" && v && v.url).map(([k, v]) => ({ key: k, ...v, marks: v.marks || [], edits: v.edits || [] })).sort((a, b) => (b.updated || 0) - (a.updated || 0));
  document.getElementById("btnOn").checked = (all["lp:settings"] || {}).button !== false;
  draw();
}
function draw() {
  const q = document.getElementById("q").value.toLowerCase().trim(), box = document.getElementById("list");
  const list = PAGES.filter(p => !q || (p.title + " " + p.url + " " + p.marks.map(m => m.quote.exact + " " + m.note).join(" ")).toLowerCase().includes(q));
  box.innerHTML = list.length ? list.map(p => `<div class="page" data-k="${esc(p.key)}"><h2><a href="${esc(p.url)}" target="_blank">${esc(p.title || p.url)}</a></h2><div class="url">${esc(p.url)}</div>
    <div class="meta">${p.marks.length} highlight${p.marks.length === 1 ? "" : "s"}${p.edits.length ? ` · ${p.edits.length} edit${p.edits.length === 1 ? "" : "s"}` : ""} · ${new Date(p.updated || p.created).toLocaleString()}</div>
    ${p.marks.slice(0, 4).map(m => `<div class="q" style="--c:${esc(m.color)}">${esc(m.quote.exact.slice(0, 200))}${m.note ? `<div class="n">💬 ${esc(m.note)}</div>` : ""}</div>`).join("")}${p.marks.length > 4 ? `<div class="meta">and ${p.marks.length - 4} more</div>` : ""}
    <div class="row"><a class="btn" href="${esc(p.url)}" target="_blank">Open the page</a><button data-a="md">Export Markdown</button><button data-a="del" class="danger">Remove</button></div></div>`).join("")
    : `<p class="empty">${PAGES.length ? "Nothing matches." : "Nothing yet. On any page, select text and press Highlight."}</p>`;
}
document.getElementById("list").addEventListener("click", async e => {
  const b = e.target.closest("button[data-a]"); if (!b) return; const k = b.closest(".page").dataset.k, p = PAGES.find(x => x.key === k);
  if (b.dataset.a === "md") download(md(p), (p.title || "page").replace(/[\\/:*?"<>|]+/g, " ").trim().slice(0, 60) + "_notes.md");
  if (b.dataset.a === "del" && confirm("Remove the highlights, comments and edits kept for this page?")) { await chrome.storage.local.remove(k); load(); }
});
document.getElementById("q").addEventListener("input", draw);
document.getElementById("allMd").addEventListener("click", () => download(PAGES.map(md).join("\n---\n\n"), "lab_potato_highlights.md"));
document.getElementById("btnOn").addEventListener("change", async e => { const s = (await chrome.storage.local.get("lp:settings"))["lp:settings"] || {}; s.button = e.target.checked; await chrome.storage.local.set({ "lp:settings": s }); });
chrome.storage.onChanged.addListener(() => load());
load();
