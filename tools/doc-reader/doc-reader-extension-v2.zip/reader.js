window.PDF_WORKER_SRC = "pdf.worker.min.js";
(function(){
/* Lab Potato Doc Reader v1
   Read, mark up and edit PDFs, Markdown, web pages and images. Everything stays in the browser
   (IndexedDB) unless you export or save a project file. */
"use strict";
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const debounce = (fn, ms) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };
const fmtTime = d => new Date(d).toLocaleString("en", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
const IS_EXT = typeof chrome !== "undefined" && !!(chrome.runtime && chrome.runtime.id);
const COLORS = [["#ffe066", "Yellow"], ["#a8e6a1", "Green"], ["#9ecbff", "Blue"], ["#ffb3c7", "Pink"], ["#d9b8ff", "Purple"], ["#ffbe76", "Orange"]];
const INK_COLORS = ["#d1495b", "#0a5fd0", "#0f9d76", "#c9800f", "#16181d", "#ffffff"];
const EL = (tag, attrs = {}, ...kids) => {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === "class") e.className = v; else if (k === "style") e.style.cssText = v; else if (k === "html") e.innerHTML = v;
    else if (k.startsWith("on")) e.addEventListener(k.slice(2), v); else if (v != null) e.setAttribute(k, v);
  }
  for (const k of kids.flat()) if (k != null) e.append(k.nodeType ? k : document.createTextNode(String(k)));
  return e;
};
const ICON = (id, cls = "") => { const s = document.createElementNS("http://www.w3.org/2000/svg", "svg"); if (cls) s.setAttribute("class", cls); s.innerHTML = `<use href="#${id}"/>`; return s; };

/* ---------- state ---------- */
const S = {
  doc: null,            // the open document record (see newDoc)
  pdf: null,            // pdf.js document, when kind === "pdf" and a source PDF exists
  pages: [],            // virtual pages in display order: {id, src (0-based index in the PDF) | img {data,w,h} | blank {w,h}, rot}
  views: new Map(),     // page id -> {el, canvas, vp, page, rendered, textDivs}
  pageCache: new Map(), // src index -> pdf.js page proxy
  scale: 1, zoomMode: "width",
  tool: "select", color: COLORS[0][0], inkColor: INK_COLORS[0], inkWidth: 2.5, shapeKind: "rect", fontSize: 12,
  sel: null,            // selected annotation id (pdf mode)
  hist: [], hi: -1, histLock: false,
  dirty: false, saving: false, fileHandle: null,
  current: 1, speaking: false,
  findRanges: [], findIdx: -1
};
const work = $("#work"), viewer = $("#viewer"), pagesEl = $("#pages"), flowEl = $("#flow"), flowWrap = $("#flowWrap"), marginEl = $("#margin");

/* ---------- small UI ---------- */
let toastT;
function toast(msg, action) {
  const t = $("#toast"); t.innerHTML = ""; t.append(msg);
  if (action) t.append(EL("button", { onclick: () => { action.fn(); t.hidden = true; } }, action.label));
  t.hidden = false; clearTimeout(toastT); toastT = setTimeout(() => { t.hidden = true; }, action ? 8000 : 3200);
}
function status(msg, cls = "") { const s = $("#status"); s.textContent = msg; s.className = "status " + cls; }
function closeMenu() { const m = $("#menu"); m.hidden = true; m.innerHTML = ""; }
/* items: {label, icon, k (shortcut), on, sub, danger, sep:true, head:"..."} */
function menu(items, anchor, opts = {}) {
  closeMenu(); const m = $("#menu");
  for (const it of items) {
    if (it.sep) { m.append(EL("div", { class: "msep" })); continue; }
    if (it.head) { m.append(EL("div", { class: "mh" }, it.head)); continue; }
    if (it.node) { m.append(it.node); continue; }
    const b = EL("button", { type: "button", class: (it.on ? "on " : "") + (it.danger ? "danger" : ""), onclick: () => { closeMenu(); it.fn && it.fn(); } });
    if (it.icon) b.append(ICON(it.icon));
    const lbl = EL("span", {}, it.label); if (it.sub) lbl.append(EL("span", { class: "sub" }, it.sub)); b.append(lbl);
    if (it.k) b.append(EL("span", { class: "k" }, it.k));
    m.append(b);
  }
  m.hidden = false;
  let x, y;
  if (anchor instanceof Event) { x = anchor.clientX; y = anchor.clientY; }
  else { const r = anchor.getBoundingClientRect(); x = opts.right ? r.right - m.offsetWidth : r.left; y = r.bottom + 4; }
  if (x + m.offsetWidth > innerWidth - 8) x = Math.max(8, innerWidth - m.offsetWidth - 8);
  if (y + m.offsetHeight > innerHeight - 8) y = Math.max(8, innerHeight - m.offsetHeight - 8);
  m.style.left = x + "px"; m.style.top = y + "px";
  setTimeout(() => $("button", m)?.focus({ preventScroll: true }), 0);
}
document.addEventListener("pointerdown", e => { if (!e.target.closest("#menu")) closeMenu(); if (!e.target.closest("#pop") && !e.target.closest(".bubble,.mnote,.note,.cmt,mark,.mk")) closePop(); }, true);
document.addEventListener("keydown", e => { if (e.key === "Escape") { closeMenu(); closePop(); closeModal(false); } });
/* modal(html) → promise resolving with the form's values when a [data-ok] button is pressed, or null */
let modalResolve = null;
function modal(html, opts = {}) {
  return new Promise(res => {
    modalResolve = res; const m = $("#modal"); m.innerHTML = html; $("#modalBack").hidden = false;
    m.onclick = e => {
      const b = e.target.closest("[data-ok],[data-cancel]"); if (!b) return;
      if (b.dataset.cancel != null) return closeModal(false);
      const vals = {}; $$("input,select,textarea", m).forEach(i => { if (!i.name) return; vals[i.name] = i.type === "checkbox" ? i.checked : i.type === "radio" ? (i.checked ? i.value : vals[i.name]) : i.value; });
      vals.btn = b.dataset.ok; closeModal(vals);
    };
    setTimeout(() => { const f = $(opts.focus || "input:not([type=hidden]):not([type=radio]):not([type=checkbox]),textarea,button[data-ok]", m); f && f.focus(); if (f && f.select && opts.select) f.select(); }, 30);
  });
}
function closeModal(v) { if (modalResolve) { const r = modalResolve; modalResolve = null; $("#modalBack").hidden = true; $("#modal").innerHTML = ""; r(v); } }
$("#modalBack").addEventListener("pointerdown", e => { if (e.target === e.currentTarget) closeModal(null); });

/* ---------- storage (IndexedDB) ---------- */
const DB = {
  _p: null,
  open() {
    if (this._p) return this._p;
    return (this._p = new Promise((res, rej) => {
      const r = indexedDB.open("lp-docreader", 1);
      r.onupgradeneeded = () => { const d = r.result; if (!d.objectStoreNames.contains("docs")) d.createObjectStore("docs", { keyPath: "id" }); if (!d.objectStoreNames.contains("kv")) d.createObjectStore("kv"); };
      r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error);
    }));
  },
  async tx(store, mode, fn) { const d = await this.open(); return new Promise((res, rej) => { const t = d.transaction(store, mode), s = t.objectStore(store); const q = fn(s); t.oncomplete = () => res(q && q.result); t.onerror = () => rej(t.error); }); },
  get(store, k) { return this.tx(store, "readonly", s => s.get(k)); },
  put(store, v, k) { return this.tx(store, "readwrite", s => k === undefined ? s.put(v) : s.put(v, k)); },
  del(store, k) { return this.tx(store, "readwrite", s => s.delete(k)); },
  all(store) { return this.tx(store, "readonly", s => s.getAll()); }
};
const Prefs = { data: {}, async load() { try { this.data = (await DB.get("kv", "prefs")) || {}; } catch (e) { this.data = {}; } }, get(k, d) { return this.data[k] ?? d; }, set(k, v) { this.data[k] = v; DB.put("kv", this.data, "prefs").catch(() => {}); } };

/* ---------- history (undo/redo) ---------- */
function snapshot() {
  return JSON.stringify({ annots: S.doc.annots, pages: S.pages.map(p => ({ id: p.id, src: p.src, blank: p.blank, img: p.img, rot: p.rot })), comments: S.doc.comments, html: S.doc.kind === "flow" ? flowEl.innerHTML : null });
}
function pushHistory() {
  if (S.histLock || !S.doc) return;
  const s = snapshot(); if (S.hist[S.hi] === s) return;
  S.hist = S.hist.slice(0, S.hi + 1); S.hist.push(s); if (S.hist.length > 80) S.hist.shift(); S.hi = S.hist.length - 1;
  updateUndo();
}
const pushHistorySoon = debounce(pushHistory, 500);
function updateUndo() { $("#undoBtn").disabled = S.hi <= 0; $("#redoBtn").disabled = S.hi >= S.hist.length - 1; }
function restore(s) {
  const o = JSON.parse(s); S.histLock = true;
  S.doc.annots = o.annots; S.doc.comments = o.comments || {};
  const changedPages = JSON.stringify(S.pages.map(p => [p.id, p.rot])) !== JSON.stringify(o.pages.map(p => [p.id, p.rot]));
  S.pages = o.pages;
  if (S.doc.kind === "flow") { flowEl.innerHTML = o.html; S.doc.html = o.html; layoutMargin(); }
  else if (changedPages) buildPages(); else redrawAllAnnots();
  S.histLock = false; refreshNotes(); markDirty();
}
function undo() { if (S.hi > 0) { S.hi--; restore(S.hist[S.hi]); updateUndo(); } }
function redo() { if (S.hi < S.hist.length - 1) { S.hi++; restore(S.hist[S.hi]); updateUndo(); } }
/* call after any change: records history and schedules the autosave */
function changed(opts = {}) { if (opts.soon) pushHistorySoon(); else pushHistory(); markDirty(); if (!opts.quiet) refreshNotes(); }

/* ---------- viewport math (same as pdf.js PageViewport) ----------
   Annotation geometry is stored in PDF user space (points, y up), so a page can be rotated
   or exported without touching the marks. A viewport converts between that space and
   screen pixels for a given scale and rotation. */
function makeViewport(viewBox, scale, rotation) {
  const [x1, y1, x2, y2] = viewBox, cx = (x1 + x2) / 2, cy = (y1 + y2) / 2;
  rotation = ((rotation % 360) + 360) % 360;
  let a, b, c, d;
  if (rotation === 180) { a = -1; b = 0; c = 0; d = 1; } else if (rotation === 90) { a = 0; b = 1; c = 1; d = 0; } else if (rotation === 270) { a = 0; b = -1; c = -1; d = 0; } else { a = 1; b = 0; c = 0; d = -1; }
  let ox, oy, width, height;
  if (a === 0) { ox = Math.abs(cy - y1) * scale; oy = Math.abs(cx - x1) * scale; width = Math.abs(y2 - y1) * scale; height = Math.abs(x2 - x1) * scale; }
  else { ox = Math.abs(cx - x1) * scale; oy = Math.abs(cy - y1) * scale; width = Math.abs(x2 - x1) * scale; height = Math.abs(y2 - y1) * scale; }
  const t = [a * scale, b * scale, c * scale, d * scale, ox - a * scale * cx - c * scale * cy, oy - b * scale * cx - d * scale * cy];
  return {
    width, height, scale, rotation, transform: t, viewBox,
    convertToViewportPoint(x, y) { return [t[0] * x + t[2] * y + t[4], t[1] * x + t[3] * y + t[5]]; },
    convertToPdfPoint(x, y) { const det = t[0] * t[3] - t[1] * t[2]; return [(x * t[3] - y * t[2] + t[2] * t[5] - t[4] * t[3]) / det, (-x * t[1] + y * t[0] + t[4] * t[1] - t[5] * t[0]) / det]; },
    convertToViewportRectangle(r) { const p1 = this.convertToViewportPoint(r[0], r[1]), p2 = this.convertToViewportPoint(r[2], r[3]); return [p1[0], p1[1], p2[0], p2[1]]; }
  };
}
/* a page that is an image or blank paper; behaves like a pdf.js page for the parts we use */
class ImgPage {
  constructor(w, h, img) { this.w = w; this.h = h; this.img = img || null; this.rotate = 0; this.view = [0, 0, w, h]; this._im = null; }
  getViewport({ scale = 1, rotation = 0 } = {}) { return makeViewport(this.view, scale, rotation); }
  async image() { if (!this.img) return null; if (!this._im) this._im = await loadImage(this.img); return this._im; }
  render({ canvasContext: ctx, viewport: vp }) {
    const promise = (async () => {
      ctx.save(); ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, vp.width, vp.height);
      const im = await this.image();
      if (im) { ctx.setTransform(...vp.transform); ctx.transform(1, 0, 0, -1, 0, this.h); ctx.drawImage(im, 0, 0, this.w, this.h); }
      ctx.restore();
    })();
    return { promise, cancel() {} };
  }
  async getTextContent() { return { items: [], styles: {} }; }
}
function loadImage(src) { return new Promise((res, rej) => { const im = new Image(); im.onload = () => res(im); im.onerror = rej; im.src = src; }); }
/* normalise a rectangle to [minx, miny, maxx, maxy] */
const normRect = r => [Math.min(r[0], r[2]), Math.min(r[1], r[3]), Math.max(r[0], r[2]), Math.max(r[1], r[3])];
/* page-local pixel point -> PDF point, via the page's current viewport */
function toPdf(view, x, y) { return view.vp.convertToPdfPoint(x, y); }
function pdfRectToPx(view, r) { return normRect(view.vp.convertToViewportRectangle(r)); }
function pxRectToPdf(view, r) { const a = toPdf(view, r[0], r[1]), b = toPdf(view, r[2], r[3]); return normRect([a[0], a[1], b[0], b[1]]); }
/* a point in page pixels, from a mouse event */
function pagePoint(e, el) { const r = el.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; }

/* ---------- PDF / page view ---------- */
const RENDER_MARGIN = "900px";
let io = null, thumbIO = null, buildToken = 0;

async function getPage(entry) {
  if (entry.src != null) {
    if (!S.pageCache.has(entry.src)) S.pageCache.set(entry.src, await S.pdf.getPage(entry.src + 1));
    return S.pageCache.get(entry.src);
  }
  if (!entry._page) entry._page = entry.img ? new ImgPage(entry.img.w, entry.img.h, entry.img.data) : new ImgPage(entry.blank.w, entry.blank.h);
  return entry._page;
}
function pageRotation(entry, page) { return ((page.rotate || 0) + (entry.rot || 0)) % 360; }

/* (re)build every page element at the current scale; rendering itself is lazy */
async function buildPages() {
  const token = ++buildToken;   // a newer build (zoom, rotate) wins over one still running
  if (io) io.disconnect();
  pagesEl.innerHTML = ""; S.views.clear();
  io = new IntersectionObserver(ents => { for (const en of ents) { const v = S.views.get(en.target.dataset.id); if (!v) continue; if (en.isIntersecting) renderPage(v); else unrenderPage(v); } }, { root: viewer, rootMargin: RENDER_MARGIN });
  let n = 0;
  for (const entry of S.pages) {
    const page = await getPage(entry); if (token !== buildToken) return;
    const vp = page.getViewport({ scale: S.scale, rotation: pageRotation(entry, page) });
    const el = EL("div", { class: "page lazy", "data-id": entry.id, style: `width:${vp.width}px;height:${vp.height}px` });
    el.style.setProperty("--scale-factor", S.scale);
    el.append(EL("div", { class: "pnum" }, String(++n)));
    pagesEl.append(el);
    S.views.set(entry.id, { el, entry, page, vp, rendered: false, textDivs: [], n });
    io.observe(el);
  }
  $("#pageOf").textContent = "/ " + S.pages.length;
  buildThumbs(); updateCurrent();
}
async function renderPage(v) {
  if (v.rendered || v.rendering) return;
  v.rendering = true;
  const dpr = Math.min(3, devicePixelRatio || 1), vp = v.vp;
  const canvas = EL("canvas", { class: "pg", width: Math.floor(vp.width * dpr), height: Math.floor(vp.height * dpr) });
  const ctx = canvas.getContext("2d", { alpha: false }); ctx.scale(dpr, dpr);
  try { await v.page.render({ canvasContext: ctx, viewport: vp }).promise; } catch (e) { if (e && e.name === "RenderingCancelledException") { v.rendering = false; return; } console.warn(e); }
  if (!S.views.has(v.entry.id) || v.vp !== vp) { v.rendering = false; return; }   // zoomed meanwhile
  v.el.querySelector("canvas.pg")?.remove(); v.el.prepend(canvas); v.el.classList.remove("lazy");
  // text layer (selectable, searchable text)
  v.el.querySelector(".textLayer")?.remove();
  if (v.entry.src != null) {
    const tl = EL("div", { class: "textLayer" }); tl.style.setProperty("--scale-factor", S.scale); v.el.append(tl);
    try {
      const tc = await getTextContent(v); v.textDivs = [];
      await pdfjsLib.renderTextLayer({ textContentSource: tc, container: tl, viewport: vp, textDivs: v.textDivs }).promise;
      tl.append(EL("div", { class: "endOfContent" }));
    } catch (e) { console.warn("text layer", e); }
  }
  drawAnnots(v);
  v.rendered = true; v.rendering = false;
  if (S.findQuery) highlightFindOnPage(v);
}
function unrenderPage(v) {
  if (!v.rendered) return;
  v.el.querySelector("canvas.pg")?.remove(); v.el.querySelector(".textLayer")?.remove(); v.el.querySelector(".annots")?.remove(); v.el.classList.add("lazy"); v.rendered = false; v.textDivs = [];
}
const textCache = new Map();
async function getTextContent(v) {
  const k = v.entry.src; if (k == null) return { items: [], styles: {} };
  if (!textCache.has(k)) textCache.set(k, await v.page.getTextContent());
  return textCache.get(k);
}
async function pageText(entry) { if (entry.src == null) return ""; const tc = await getTextContent({ entry, page: await getPage(entry) }); let s = ""; for (const it of tc.items) { s += it.str; if (it.hasEOL) s += "\n"; } return s; }

/* zoom */
async function firstPageSize() { if (!S.pages.length) return [612, 792]; const e = S.pages[0], pg = await getPage(e), vp = pg.getViewport({ scale: 1, rotation: pageRotation(e, pg) }); return [vp.width, vp.height]; }
async function setZoom(mode, val) {
  if (S.doc?.kind === "flow") {   // documents zoom as a whole (CSS zoom), fit width = 100%
    S.flowZoom = mode === "custom" ? clamp(val, .4, 3) : 1; S.zoomMode = mode === "custom" ? "custom" : "width";
    $(".flow-paper").style.zoom = S.flowZoom; $("#zoomVal").textContent = Math.round(S.flowZoom * 100) + "%"; layoutMargin(); return;
  }
  S.zoomMode = mode; Prefs.set("zoomMode", mode);
  const old = S.scale, keep = viewer.scrollTop / Math.max(1, viewer.scrollHeight), [w0, h0] = await firstPageSize();
  if (mode === "width") S.scale = clamp((viewer.clientWidth - 44) / w0, .2, 6); else if (mode === "page") S.scale = clamp((viewer.clientHeight - 50) / h0, .2, 6); else { S.scale = clamp(val, .2, 6); Prefs.set("zoom", S.scale); }
  if (Math.abs(S.scale - old) < .001 && S.views.size) return;
  $("#zoomVal").textContent = Math.round(S.scale * 100) + "%";
  await buildPages(); viewer.scrollTop = keep * viewer.scrollHeight;
}
function zoomBy(f) { setZoom("custom", (S.doc?.kind === "flow" ? (S.flowZoom || 1) : S.scale) * f); }

/* current page from scroll position */
function updateCurrent() {
  if (S.doc?.kind !== "pdf") return;
  const vr = viewer.getBoundingClientRect(); let best = null, bestV = -1;
  for (const v of S.views.values()) { const r = v.el.getBoundingClientRect(); const vis = Math.min(r.bottom, vr.bottom) - Math.max(r.top, vr.top); if (vis > bestV) { bestV = vis; best = v; } }
  if (best && best.n !== S.current) { S.current = best.n; $$(".thumb").forEach(t => t.classList.toggle("on", +t.dataset.n === S.current)); }
  $("#pageIn").value = S.current;
}
function goToPage(n, opts = {}) {
  n = clamp(n, 1, S.pages.length); const v = [...S.views.values()][n - 1]; if (!v) return;
  v.el.scrollIntoView({ block: "start", behavior: opts.smooth ? "smooth" : "auto" }); viewer.scrollTop -= 12;
  S.current = n; $("#pageIn").value = n;
}
viewer.addEventListener("scroll", debounce(updateCurrent, 60));

/* thumbnails: click to go, drag to reorder, right-click for page actions */
function buildThumbs() {
  const box = $("#thumbs"); box.innerHTML = ""; if (thumbIO) thumbIO.disconnect();
  thumbIO = new IntersectionObserver(ents => { for (const en of ents) if (en.isIntersecting) { renderThumb(en.target); thumbIO.unobserve(en.target); } }, { root: box.parentElement, rootMargin: "300px" });
  S.pages.forEach((p, i) => {
    const t = EL("div", { class: "thumb" + (i + 1 === S.current ? " on" : ""), "data-id": p.id, "data-n": i + 1, draggable: "true", title: "Page " + (i + 1) + " · right-click for page options" });
    t.append(EL("canvas"), EL("div", { class: "tn" }, String(i + 1)));
    t.addEventListener("click", () => goToPage(i + 1));
    t.addEventListener("contextmenu", e => { e.preventDefault(); pageMenu(p.id, e); });
    t.addEventListener("dragstart", e => { e.dataTransfer.setData("text/lp-page", p.id); t.classList.add("drag"); });
    t.addEventListener("dragend", () => t.classList.remove("drag"));
    t.addEventListener("dragover", e => { if (e.dataTransfer.types.includes("text/lp-page")) e.preventDefault(); });
    t.addEventListener("drop", e => { const from = e.dataTransfer.getData("text/lp-page"); if (!from || from === p.id) return; e.preventDefault(); movePage(from, p.id); });
    box.append(t); thumbIO.observe(t);
  });
}
async function renderThumb(t) {
  const entry = S.pages.find(p => p.id === t.dataset.id); if (!entry) return;
  const page = await getPage(entry), vp0 = page.getViewport({ scale: 1, rotation: pageRotation(entry, page) }), sc = 170 / vp0.width, vp = page.getViewport({ scale: sc, rotation: vp0.rotation });
  const c = $("canvas", t); c.width = Math.floor(vp.width * 1.5); c.height = Math.floor(vp.height * 1.5); const ctx = c.getContext("2d"); ctx.scale(1.5, 1.5);
  try { await page.render({ canvasContext: ctx, viewport: vp }).promise; } catch (e) { /* cancelled */ }
}
function pageMenu(id, ev) {
  const i = S.pages.findIndex(p => p.id === id);
  menu([
    { head: "Page " + (i + 1) },
    { label: "Rotate right", icon: "i-rotate", fn: () => rotatePage(id, 90) },
    { label: "Rotate left", fn: () => rotatePage(id, -90) },
    { sep: true },
    { label: "Insert blank page after", icon: "i-pageadd", fn: () => insertBlank(i + 1) },
    { label: "Insert image as a page after…", icon: "i-image", fn: () => pickImage(src => insertImagePage(i + 1, src)) },
    { label: "Duplicate page", fn: () => duplicatePage(id) },
    { label: "Save page as PNG", fn: () => savePagePng(id) },
    { sep: true },
    { label: "Delete page", icon: "i-trash", danger: true, fn: () => deletePage(id) }
  ], ev);
}
function rotatePage(id, d) { const p = S.pages.find(x => x.id === id); p.rot = ((p.rot || 0) + d + 360) % 360; buildPages(); changed(); }
function deletePage(id) { if (S.pages.length < 2) return toast("A document needs at least one page."); S.pages = S.pages.filter(p => p.id !== id); S.doc.annots = S.doc.annots.filter(a => a.p !== id); buildPages(); changed(); }
async function insertBlank(at) { const ref = S.pages[Math.max(0, at - 1)], pg = await getPage(ref), vp = pg.getViewport({ scale: 1 }); const w = ref.rot % 180 ? vp.height : vp.width, h = ref.rot % 180 ? vp.width : vp.height; S.pages.splice(at, 0, { id: uid(), blank: { w: w / 1, h: h / 1 }, rot: 0 }); buildPages(); changed(); }
async function insertImagePage(at, src) { const im = await loadImage(src); const w = 612, h = Math.max(100, 612 * im.naturalHeight / im.naturalWidth); S.pages.splice(at, 0, { id: uid(), img: { data: src, w, h }, rot: 0 }); buildPages(); changed(); }
function duplicatePage(id) { const i = S.pages.findIndex(p => p.id === id), p = S.pages[i], np = { ...p, id: uid(), _page: undefined }; S.pages.splice(i + 1, 0, np); S.doc.annots.push(...S.doc.annots.filter(a => a.p === id).map(a => ({ ...a, id: uid(), p: np.id }))); buildPages(); changed(); }
function movePage(fromId, toId) { const a = S.pages.findIndex(p => p.id === fromId), b = S.pages.findIndex(p => p.id === toId); const [p] = S.pages.splice(a, 1); S.pages.splice(b, 0, p); buildPages(); changed(); }
async function savePagePng(id) { const entry = S.pages.find(p => p.id === id), page = await getPage(entry), vp = page.getViewport({ scale: 2, rotation: pageRotation(entry, page) }); const c = EL("canvas", { width: vp.width, height: vp.height }); await page.render({ canvasContext: c.getContext("2d"), viewport: vp }).promise; c.toBlob(b => download(b, (S.doc.name.replace(/\.[^.]+$/, "")) + "-page" + (S.pages.indexOf(entry) + 1) + ".png")); }

/* outline (bookmarks) */
async function buildOutline() {
  const box = $("#outline"); box.innerHTML = "";
  if (S.doc.kind === "flow") {
    const hs = $$("h1,h2,h3,h4", flowEl); if (!hs.length) { box.append(EL("div", { class: "empty" }, "No headings yet. Headings you add appear here.")); return; }
    hs.forEach(h => box.append(EL("button", { class: "l" + h.tagName[1], onclick: () => h.scrollIntoView({ block: "start", behavior: "smooth" }) }, h.textContent.trim() || "(empty heading)")));
    return;
  }
  let items = []; try { items = S.pdf ? (await S.pdf.getOutline()) || [] : []; } catch (e) { /* none */ }
  if (!items.length) { box.append(EL("div", { class: "empty" }, "This PDF has no bookmarks.")); return; }
  const add = async (list, lvl) => { for (const it of list) { const b = EL("button", { class: "l" + Math.min(4, lvl) }, it.title || "(untitled)"); b.addEventListener("click", async () => { const n = await outlinePage(it); if (n) goToPage(n, { smooth: true }); }); box.append(b); if (it.items?.length) await add(it.items, lvl + 1); } };
  await add(items, 1);
}
async function outlinePage(it) {
  try { let d = it.dest; if (typeof d === "string") d = await S.pdf.getDestination(d); if (!Array.isArray(d)) return 0; const ref = d[0]; const idx = typeof ref === "object" ? await S.pdf.getPageIndex(ref) : ref; const vi = S.pages.findIndex(p => p.src === idx); return vi + 1; } catch (e) { return 0; }
}

/* ---------- annotations on pages (PDF and image documents) ----------
   Every mark is one object in S.doc.annots:
     {id, p: pageId, t: "hl"|"ul"|"st" (text marks: rects[] + quote), "area", "note", "text", "ink", "shape", "image", "edit",
      color, text (the comment), replies[], resolved, at}
   Geometry is in PDF points (see 10-viewport.js). */
const NS = "http://www.w3.org/2000/svg";
const annotsOf = pid => S.doc.annots.filter(a => a.p === pid);
const annotById = id => S.doc.annots.find(a => a.id === id);

function redrawAllAnnots() { for (const v of S.views.values()) if (v.rendered) drawAnnots(v); }
function drawAnnots(v) {
  v.el.querySelector(".annots")?.remove();
  const layer = EL("div", { class: "annots" }), svg = document.createElementNS(NS, "svg"); layer.append(svg); v.el.append(layer);
  for (const a of annotsOf(v.entry.id)) drawOne(v, a, svg, layer);
  // the draw/interaction layer catches pointer events for area, pen, shapes, comment and text tools
  const dl = EL("div", { class: "drawlayer" }); layer.append(dl); bindDrawLayer(v, dl);
}
function svgEl(tag, attrs) { const e = document.createElementNS(NS, tag); for (const [k, val] of Object.entries(attrs)) e.setAttribute(k, val); return e; }
function drawOne(v, a, svg, layer) {
  const sel = a.id === S.sel, cls = "mk" + (sel ? " sel" : "");
  const onClick = e => { e.stopPropagation(); if (S.tool === "erase") return removeAnnot(a.id); selectAnnot(a.id); if (a.t !== "text" && a.t !== "image") openPop(a, e); };
  if (a.t === "hl" || a.t === "ul" || a.t === "st" || a.t === "area") {
    const g = svgEl("g", { class: cls, "data-id": a.id });
    const rects = a.t === "area" ? [a.rect] : a.rects;
    for (const r of rects) {
      const [x1, y1, x2, y2] = pdfRectToPx(v, r), w = x2 - x1, h = y2 - y1;
      if (a.t === "hl" || a.t === "area") g.append(svgEl("rect", { x: x1, y: y1, width: w, height: h, fill: a.color, "fill-opacity": a.t === "area" ? .35 : .45, rx: 1.5, style: "mix-blend-mode:multiply" }));
      else if (a.t === "ul") g.append(svgEl("rect", { x: x1, y: y2 - Math.max(1.5, h * .08), width: w, height: Math.max(1.5, h * .08), fill: a.color, "fill-opacity": .95 }), svgEl("rect", { x: x1, y: y1, width: w, height: h, fill: "transparent" }));
      else g.append(svgEl("rect", { x: x1, y: y1 + h * .5 - Math.max(1, h * .06), width: w, height: Math.max(1.5, h * .1), fill: a.color, "fill-opacity": .95 }), svgEl("rect", { x: x1, y: y1, width: w, height: h, fill: "transparent" }));
    }
    if (sel) { const bb = boundsPx(v, rects); g.append(svgEl("rect", { class: "selbox", x: bb[0] - 2, y: bb[1] - 2, width: bb[2] - bb[0] + 4, height: bb[3] - bb[1] + 4 })); }
    g.addEventListener("click", onClick); svg.append(g);
    if (a.text || a.replies?.length) layer.append(bubbleEl(v, a, boundsPx(v, rects)));
  } else if (a.t === "ink") {
    const g = svgEl("g", { class: cls, "data-id": a.id });
    for (const path of a.paths) { const pts = path.map(([x, y]) => v.vp.convertToViewportPoint(x, y)); g.append(svgEl("path", { d: "M" + pts.map(p => p[0].toFixed(1) + " " + p[1].toFixed(1)).join("L"), stroke: a.color, "stroke-width": a.width * S.scale, fill: "none", "stroke-linecap": "round", "stroke-linejoin": "round", "stroke-opacity": a.opacity ?? 1 })); }
    if (sel) { const bb = inkBounds(v, a); g.append(svgEl("rect", { class: "selbox", x: bb[0] - 3, y: bb[1] - 3, width: bb[2] - bb[0] + 6, height: bb[3] - bb[1] + 6 })); }
    g.addEventListener("click", onClick); svg.append(g);
  } else if (a.t === "shape") {
    const [x1, y1, x2, y2] = pdfRectToPx(v, a.rect), w = x2 - x1, h = y2 - y1, sw = a.width * S.scale, g = svgEl("g", { class: cls, "data-id": a.id });
    if (a.kind === "rect") g.append(svgEl("rect", { x: x1, y: y1, width: w, height: h, stroke: a.color, "stroke-width": sw, fill: a.fill || "none", "fill-opacity": .25, rx: 2 }));
    else if (a.kind === "whiteout") g.append(svgEl("rect", { x: x1, y: y1, width: w, height: h, fill: "var(--page-bg)", stroke: sel ? "var(--line-2)" : "none", "stroke-dasharray": "3 2" }));
    else if (a.kind === "ellipse") g.append(svgEl("ellipse", { cx: x1 + w / 2, cy: y1 + h / 2, rx: w / 2, ry: h / 2, stroke: a.color, "stroke-width": sw, fill: "none" }));
    else {
      const [sx, sy] = v.vp.convertToViewportPoint(a.pts[0][0], a.pts[0][1]), [ex, ey] = v.vp.convertToViewportPoint(a.pts[1][0], a.pts[1][1]);
      g.append(svgEl("line", { x1: sx, y1: sy, x2: ex, y2: ey, stroke: a.color, "stroke-width": sw, "stroke-linecap": "round" }));
      if (a.kind === "arrow") { const ang = Math.atan2(ey - sy, ex - sx), L = 6 + sw * 3; g.append(svgEl("path", { d: `M${ex} ${ey}L${ex - L * Math.cos(ang - .45)} ${ey - L * Math.sin(ang - .45)}M${ex} ${ey}L${ex - L * Math.cos(ang + .45)} ${ey - L * Math.sin(ang + .45)}`, stroke: a.color, "stroke-width": sw, fill: "none", "stroke-linecap": "round" })); }
      g.append(svgEl("line", { x1: sx, y1: sy, x2: ex, y2: ey, stroke: "transparent", "stroke-width": 12 }));
    }
    if (sel) g.append(svgEl("rect", { class: "selbox", x: x1 - 3, y: y1 - 3, width: w + 6, height: h + 6 }));
    g.addEventListener("click", onClick); svg.append(g);
    if (a.text) layer.append(bubbleEl(v, a, [x1, y1, x2, y2]));
  } else if (a.t === "note") {
    const [x, y] = v.vp.convertToViewportPoint(a.pt[0], a.pt[1]); layer.append(bubbleEl(v, a, [x, y, x, y], true));
  } else if (a.t === "text" || a.t === "image" || a.t === "edit") {
    layer.append(nodeEl(v, a));
    if (a.text && a.t !== "edit") { const r = pdfRectToPx(v, a.rect); layer.append(bubbleEl(v, a, r)); }
  }
}
function boundsPx(v, rects) { let b = [1e9, 1e9, -1e9, -1e9]; for (const r of rects) { const p = pdfRectToPx(v, r); b = [Math.min(b[0], p[0]), Math.min(b[1], p[1]), Math.max(b[2], p[2]), Math.max(b[3], p[3])]; } return b; }
function inkBounds(v, a) { let b = [1e9, 1e9, -1e9, -1e9]; for (const path of a.paths) for (const [x, y] of path) { const p = v.vp.convertToViewportPoint(x, y); b = [Math.min(b[0], p[0]), Math.min(b[1], p[1]), Math.max(b[2], p[2]), Math.max(b[3], p[3])]; } return b; }
function bubbleEl(v, a, px, standalone) {
  const b = EL("div", { class: "bubble" + (a.resolved ? " resolved" : "") + (a.id === S.sel ? " on" : ""), style: `left:${standalone ? px[0] : px[2]}px;top:${px[1]}px;background:${bubbleColor(a)}`, title: (a.text || "Comment").slice(0, 120) });
  b.append(ICON("i-comment"));
  b.addEventListener("click", e => { e.stopPropagation(); if (S.tool === "erase" && standalone) return removeAnnot(a.id); selectAnnot(a.id); openPop(a, e); });
  if (standalone) makeDraggable(b, v, a, "pt");
  return b;
}
function bubbleColor(a) { const c = a.color || "#ffe066"; return (a.t === "note" || a.t === "hl" || a.t === "area") ? darken(c) : c; }
function darken(hex) { const n = parseInt(hex.slice(1), 16), r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255; const f = .62; return `rgb(${r * f | 0},${g * f | 0},${b * f | 0})`; }
/* text boxes, placed images and text edits are HTML nodes positioned over the page */
function nodeEl(v, a) {
  const [x1, y1, x2, y2] = pdfRectToPx(v, a.rect), sel = a.id === S.sel;
  let n;
  if (a.t === "image") { n = EL("div", { class: "anode imgbox" + (sel ? " sel" : ""), style: `left:${x1}px;top:${y1}px;width:${x2 - x1}px;height:${y2 - y1}px` }); n.append(EL("img", { src: a.data, draggable: "false" })); }
  else if (a.t === "edit") { n = EL("div", { class: "anode textbox editnode" + (sel ? " sel" : ""), style: `left:${x1}px;top:${y1}px;min-width:${x2 - x1}px;height:${y2 - y1}px;font-size:${a.size * S.scale}px;font-family:${a.font || "serif"};color:${a.color || "#111"};background:var(--page-bg);padding:0;line-height:${y2 - y1}px;white-space:pre` }); n.textContent = a.text; }
  else { n = EL("div", { class: "anode textbox" + (sel ? " sel" : ""), style: `left:${x1}px;top:${y1}px;width:${x2 - x1}px;font-size:${a.size * S.scale}px;color:${a.color};font-family:${a.font || "inherit"};background:${a.bg || "transparent"};text-align:${a.align || "left"}` }); if (a.html) n.innerHTML = a.html; else n.textContent = a.body || ""; }
  n.dataset.id = a.id;
  n.addEventListener("pointerdown", e => { if (S.tool === "erase") { e.stopPropagation(); return removeAnnot(a.id); } });
  n.addEventListener("click", e => { e.stopPropagation(); if (!n.isContentEditable) selectAnnot(a.id); });
  n.addEventListener("dblclick", e => { e.stopPropagation(); if (a.t === "image") return editImageAnnot(a); editTextNode(v, a, n); });
  makeDraggable(n, v, a, "rect");
  if (a.t !== "edit") { const h = EL("div", { class: "hdl" }); n.append(h); makeResizable(h, n, v, a); }
  return n;
}
function makeDraggable(n, v, a, kind) {
  n.addEventListener("pointerdown", e => {
    if (e.button !== 0 || n.isContentEditable || e.target.classList.contains("hdl")) return;
    if (S.tool === "erase") return;
    const wasSel = S.sel === a.id;
    e.preventDefault(); e.stopPropagation(); selectAnnot(a.id);
    const start = pagePoint(e, v.el), orig = kind === "pt" ? a.pt.slice() : a.rect.slice(); let moved = false;
    const mv = ev => {
      const p = pagePoint(ev, v.el), dx = p[0] - start[0], dy = p[1] - start[1]; if (Math.abs(dx) + Math.abs(dy) > 2) moved = true; if (!moved) return;
      const p0 = toPdf(v, 0, 0), p1 = toPdf(v, dx, dy), ddx = p1[0] - p0[0], ddy = p1[1] - p0[1];
      if (kind === "pt") a.pt = [orig[0] + ddx, orig[1] + ddy]; else a.rect = [orig[0] + ddx, orig[1] + ddy, orig[2] + ddx, orig[3] + ddy];
      drawAnnots(v);
    };
    const up = () => { document.removeEventListener("pointermove", mv); document.removeEventListener("pointerup", up); if (moved) changed({ quiet: true }); else if (wasSel && a.t === "text") { const node = v.el.querySelector(`.anode[data-id="${a.id}"]`); if (node) editTextNode(v, a, node); } };
    document.addEventListener("pointermove", mv); document.addEventListener("pointerup", up);
  });
}
function makeResizable(h, n, v, a) {
  h.addEventListener("pointerdown", e => {
    e.preventDefault(); e.stopPropagation(); const start = pagePoint(e, v.el), orig = a.rect.slice(), px0 = pdfRectToPx(v, orig);
    const ratio = a.t === "image" ? (px0[2] - px0[0]) / (px0[3] - px0[1]) : 0;
    const mv = ev => { const p = pagePoint(ev, v.el); let w = Math.max(16, px0[2] - px0[0] + p[0] - start[0]), hh = Math.max(12, px0[3] - px0[1] + p[1] - start[1]); if (ratio && !ev.shiftKey) hh = w / ratio; a.rect = pxRectToPdf(v, [px0[0], px0[1], px0[0] + w, px0[1] + hh]); drawAnnots(v); };
    const up = () => { document.removeEventListener("pointermove", mv); document.removeEventListener("pointerup", up); changed({ quiet: true }); };
    document.addEventListener("pointermove", mv); document.addEventListener("pointerup", up);
  });
}
/* text boxes are edited in place with Word-style formatting (bold, italic, size, colour, alignment, line breaks) */
function editTextNode(v, a, n) {
  n.contentEditable = "true"; n.focus(); if (!a.body && !a.html) document.execCommand("selectAll", false, null); else { const r = document.createRange(); r.selectNodeContents(n); r.collapse(false); getSelection().removeAllRanges(); getSelection().addRange(r); }
  S.editingText = a.id; showCtx();
  const done = () => {
    if (!n.isConnected) return; n.contentEditable = "false"; S.editingText = null;
    a.html = DOMPurify.sanitize(n.innerHTML, { ALLOWED_TAGS: ["b", "strong", "i", "em", "u", "s", "strike", "br", "div", "span", "font", "sup", "sub"], ALLOWED_ATTR: ["style", "color", "size", "face"] }); a.body = n.innerText.replace(/\n+$/, "");
    const r = n.getBoundingClientRect(), pr = v.el.getBoundingClientRect(); a.rect = pxRectToPdf(v, [r.left - pr.left, r.top - pr.top, r.right - pr.left, r.bottom - pr.top]);
    if (!a.body.trim()) removeAnnot(a.id); else { drawAnnots(v); showCtx(); changed(); }
  };
  n.addEventListener("blur", () => setTimeout(() => { if (!document.activeElement?.closest("#ctxbar")) done(); else n.focus(); }, 0), { once: false });
  n.addEventListener("keydown", e => { if (e.key === "Escape") { e.preventDefault(); n.blur(); } if ((e.ctrlKey || e.metaKey) && /^[biu]$/i.test(e.key)) { e.preventDefault(); document.execCommand({ b: "bold", i: "italic", u: "underline" }[e.key.toLowerCase()]); } e.stopPropagation(); });
}
async function editImageAnnot(a) { const out = await editImage(a.data); if (!out) return; const im = await loadImage(out); const [x1, y1, x2, y2] = normRect(a.rect); const w = x2 - x1, h = w * im.naturalHeight / im.naturalWidth; a.data = out; a.rect = [x1, y2 - h, x2, y2]; redrawAllAnnots(); changed(); }
function selectAnnot(id) { S.sel = id; redrawAllAnnots(); showCtx(); $$(".note").forEach(n => n.classList.toggle("on", n.dataset.id === id)); }
function removeAnnot(id) { S.doc.annots = S.doc.annots.filter(a => a.id !== id); if (S.sel === id) S.sel = null; closePop(); redrawAllAnnots(); showCtx(); changed(); }
function addAnnot(a) { a.id = a.id || uid(); a.at = a.at || Date.now(); S.doc.annots.push(a); const v = S.views.get(a.p); if (v) drawAnnots(v); changed(); return a; }

/* the small context bar under the toolbar: tool options and the selected mark */
function showCtx() {
  const c = $("#ctxbar"); c.innerHTML = ""; c.hidden = true;
  if (S.doc?.kind !== "pdf") return;
  const a = S.sel && annotById(S.sel);
  if (S.editingText && a && a.id === S.editingText) {   // formatting bar for the text box being typed in
    c.hidden = false; const X = (lbl, fn, title) => c.append(EL("button", { class: "btn small", title, onpointerdown: e => e.preventDefault(), onclick: fn }, lbl));
    c.append(EL("span", {}, "Text box:")); X(EL("b", {}, "B"), () => document.execCommand("bold"), "Bold (Ctrl+B)"); X(EL("i", {}, "I"), () => document.execCommand("italic"), "Italic (Ctrl+I)"); X(EL("u", {}, "U"), () => document.execCommand("underline"), "Underline (Ctrl+U)");
    X("A−", () => { a.size = Math.max(4, a.size - 1); const n = $(`.anode[data-id="${a.id}"]`); if (n) n.style.fontSize = a.size * S.scale + "px"; }, "Smaller"); X("A+", () => { a.size = Math.min(96, a.size + 1); const n = $(`.anode[data-id="${a.id}"]`); if (n) n.style.fontSize = a.size * S.scale + "px"; }, "Larger");
    X("⇤", () => { a.align = "left"; $(`.anode[data-id="${a.id}"]`).style.textAlign = "left"; }, "Align left"); X("↔", () => { a.align = "center"; $(`.anode[data-id="${a.id}"]`).style.textAlign = "center"; }, "Centre"); X("⇥", () => { a.align = "right"; $(`.anode[data-id="${a.id}"]`).style.textAlign = "right"; }, "Align right");
    const sw = EL("span", { class: "ctx-sw" }); INK_COLORS.forEach(col => sw.append(EL("i", { class: "sw", style: "background:" + col, onpointerdown: e => e.preventDefault(), onclick: () => document.execCommand("foreColor", false, col) }))); c.append(sw);
    c.append(EL("label", { onpointerdown: e => e.preventDefault() }, EL("input", { type: "checkbox", checked: a.bg ? "" : null, onchange: e => { a.bg = e.target.checked ? "rgba(255,255,255,.92)" : ""; $(`.anode[data-id="${a.id}"]`).style.background = a.bg || "transparent"; } }), " White background"));
    X("Done", () => $(`.anode[data-id="${a.id}"]`)?.blur(), "Finish editing (Esc)"); return;
  }
  if (a) {
    c.hidden = false;
    c.append(EL("span", {}, { hl: "Highlight", ul: "Underline", st: "Strikethrough", area: "Area highlight", note: "Comment", text: "Text box", ink: "Drawing", shape: "Shape", image: "Image", edit: "Text edit" }[a.t]));
    const sw = EL("span", { class: "ctx-sw" }); (a.t === "ink" || a.t === "shape" || a.t === "text" || a.t === "edit" ? INK_COLORS : COLORS.map(x => x[0])).forEach(col => sw.append(EL("i", { class: "sw" + (a.color === col ? " on" : ""), style: "background:" + col, onclick: () => { a.color = col; redrawAllAnnots(); showCtx(); changed(); } }))); c.append(sw);
    if (a.t === "ink" || a.t === "shape") c.append(EL("label", {}, "Width ", EL("input", { type: "range", min: 1, max: 12, step: .5, value: a.width, oninput: e => { a.width = +e.target.value; redrawAllAnnots(); changed({ soon: true, quiet: true }); } })));
    if (a.t === "text" || a.t === "edit") c.append(EL("label", {}, "Size ", EL("input", { type: "number", min: 4, max: 96, value: a.size, oninput: e => { a.size = +e.target.value || 12; redrawAllAnnots(); changed({ soon: true, quiet: true }); } })));
    if (a.t === "text") c.append(EL("button", { class: "btn small", onclick: () => { const v = S.views.get(a.p), n = v?.el.querySelector(`.anode[data-id="${a.id}"]`); if (n) editTextNode(v, a, n); } }, "Edit text"));
    if (a.t === "image") c.append(EL("button", { class: "btn small", onclick: () => editImageAnnot(a) }, "Edit image… (crop, rotate, light)"));
    if (a.t !== "note" && a.t !== "edit") c.append(EL("button", { class: "btn small", onclick: e => openPop(a, e) }, a.text ? "Edit comment" : "Add comment"));
    if (a.t === "hl" || a.t === "ul" || a.t === "st") { const sel2 = EL("select", { class: "tsel", onchange: e => { a.t = e.target.value; redrawAllAnnots(); changed(); } }); [["hl", "Highlight"], ["ul", "Underline"], ["st", "Strikethrough"]].forEach(([k, l]) => sel2.append(EL("option", { value: k, selected: a.t === k ? "" : null }, l))); c.append(sel2); c.append(EL("button", { class: "btn small", onclick: () => { navigator.clipboard.writeText(a.quote || ""); toast("Copied the text."); } }, "Copy text")); }
    c.append(EL("button", { class: "btn small danger", onclick: () => removeAnnot(a.id) }, "Delete"));
    c.append(EL("button", { class: "btn small ghost", onclick: () => { S.sel = null; redrawAllAnnots(); showCtx(); } }, "Done"));
    return;
  }
  const t = S.tool; if (t === "select") return;
  c.hidden = false;
  if (t === "highlight" || t === "underline" || t === "strike" || t === "area") { c.append(EL("span", {}, { highlight: "Drag over text to highlight it.", underline: "Drag over text to underline it.", strike: "Drag over text to strike it through.", area: "Drag a box around a figure, table or any part of the page." }[t])); }
  if (t === "comment") c.append(EL("span", {}, "Click where the comment belongs."));
  if (t === "text") { c.append(EL("span", {}, "Click to place a text box.")); c.append(EL("label", {}, "Size ", EL("input", { type: "number", min: 4, max: 96, value: S.fontSize, oninput: e => { S.fontSize = +e.target.value || 12; } }))); inkColorRow(c); }
  if (t === "pen") { c.append(EL("span", {}, "Draw with the mouse or a pen.")); inkColorRow(c); c.append(EL("label", {}, "Width ", EL("input", { type: "range", min: 1, max: 12, step: .5, value: S.inkWidth, oninput: e => { S.inkWidth = +e.target.value; } }))); }
  if (t === "shape") { const sel2 = EL("select", { class: "tsel", onchange: e => { S.shapeKind = e.target.value; } }); [["rect", "Box"], ["ellipse", "Circle"], ["arrow", "Arrow"], ["line", "Line"], ["whiteout", "White-out (cover something)"]].forEach(([k, l]) => sel2.append(EL("option", { value: k, selected: S.shapeKind === k ? "" : null }, l))); c.append(sel2); inkColorRow(c); c.append(EL("label", {}, "Width ", EL("input", { type: "range", min: 1, max: 12, step: .5, value: S.inkWidth, oninput: e => { S.inkWidth = +e.target.value; } }))); }
  if (t === "image") c.append(EL("span", {}, "Click where the image should go, or drag a box for its size."));
  if (t === "edit") c.append(EL("span", {}, "Click a line of the PDF's text to retype it. The original is covered and your text drawn on top; use the Shape tool's white-out to remove things."));
  if (t === "erase") c.append(EL("span", {}, "Click any mark to remove it."));
}
function inkColorRow(c) { const sw = EL("span", { class: "ctx-sw" }); INK_COLORS.forEach(col => sw.append(EL("i", { class: "sw" + (S.inkColor === col ? " on" : ""), style: "background:" + col, onclick: () => { S.inkColor = col; showCtx(); } }))); c.append(sw); }

/* ---- the draw layer: area, pen, shapes, comment, text, image placement ---- */
function bindDrawLayer(v, dl) {
  dl.addEventListener("pointerdown", e => {
    if (e.button !== 0) return;
    const t = S.tool;
    if (t === "select" || t === "highlight" || t === "underline" || t === "strike" || t === "edit" || t === "erase") { if (S.sel) { S.sel = null; redrawAllAnnots(); showCtx(); } return; }
    e.preventDefault(); dl.setPointerCapture(e.pointerId);
    const p0 = pagePoint(e, v.el);
    if (t === "comment") { const pt = toPdf(v, p0[0], p0[1]); const a = addAnnot({ t: "note", p: v.entry.id, pt, color: S.color, text: "" }); selectAnnot(a.id); openPop(a, e, true); setTool("select"); return; }
    if (t === "text") { setTool("select"); const pt = toPdf(v, p0[0], p0[1]), pt2 = toPdf(v, p0[0] + 160, p0[1] + S.fontSize * S.scale * 1.4); const a = addAnnot({ t: "text", p: v.entry.id, rect: normRect([pt[0], pt[1], pt2[0], pt2[1]]), size: S.fontSize, color: S.inkColor, body: "" }); selectAnnot(a.id); const n = v.el.querySelector(`.anode[data-id="${a.id}"]`); if (n) editTextNode(v, a, n); return; }
    if (t === "pen") {
      const pts = [toPdf(v, p0[0], p0[1])], svg = v.el.querySelector(".annots svg"), path = svgEl("path", { stroke: S.inkColor, "stroke-width": S.inkWidth * S.scale, fill: "none", "stroke-linecap": "round", "stroke-linejoin": "round" }); svg.append(path);
      let d = "M" + p0[0] + " " + p0[1];
      const mv = ev => { const p = pagePoint(ev, v.el); pts.push(toPdf(v, p[0], p[1])); d += "L" + p[0].toFixed(1) + " " + p[1].toFixed(1); path.setAttribute("d", d); };
      const up = () => { dl.removeEventListener("pointermove", mv); dl.removeEventListener("pointerup", up); path.remove(); if (pts.length > 1) addAnnot({ t: "ink", p: v.entry.id, paths: [pts], color: S.inkColor, width: S.inkWidth }); };
      dl.addEventListener("pointermove", mv); dl.addEventListener("pointerup", up); return;
    }
    // drag a rectangle: area, shape, image
    const box = EL("div", { class: "sel-rect", style: `left:${p0[0]}px;top:${p0[1]}px;width:0;height:0` }); v.el.append(box); let p1 = p0;
    const mv = ev => { p1 = pagePoint(ev, v.el); const r = normRect([p0[0], p0[1], p1[0], p1[1]]); box.style.left = r[0] + "px"; box.style.top = r[1] + "px"; box.style.width = (r[2] - r[0]) + "px"; box.style.height = (r[3] - r[1]) + "px"; };
    const up = () => {
      dl.removeEventListener("pointermove", mv); dl.removeEventListener("pointerup", up); box.remove();
      const r = normRect([p0[0], p0[1], p1[0], p1[1]]), tiny = (r[2] - r[0]) < 6 && (r[3] - r[1]) < 6;
      if (t === "area") { if (tiny) return; addAnnot({ t: "area", p: v.entry.id, rect: pxRectToPdf(v, r), color: S.color, text: "" }); }
      else if (t === "shape") { if (tiny) return; const a = { t: "shape", p: v.entry.id, kind: S.shapeKind, rect: pxRectToPdf(v, r), color: S.inkColor, width: S.inkWidth, text: "" }; if (S.shapeKind === "arrow" || S.shapeKind === "line") a.pts = [toPdf(v, p0[0], p0[1]), toPdf(v, p1[0], p1[1])]; addAnnot(a); }
      else if (t === "image") pickImage(async src => { const im = await loadImage(src); let rr = r; if (tiny) { const w = Math.min(v.vp.width * .4, im.naturalWidth), h = w * im.naturalHeight / im.naturalWidth; rr = [p0[0], p0[1], p0[0] + w, p0[1] + h]; } const a = addAnnot({ t: "image", p: v.entry.id, rect: pxRectToPdf(v, rr), data: src }); selectAnnot(a.id); setTool("select"); });
    };
    dl.addEventListener("pointermove", mv); dl.addEventListener("pointerup", up);
  });
}
function pickImage(cb) { const inp = $("#imgIn"); inp.value = ""; inp.onchange = () => { const f = inp.files[0]; if (!f) return; fileToDataUrl(f).then(cb); }; inp.click(); }
function fileToDataUrl(f) { return new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = rej; r.readAsDataURL(f); }); }
/* shrink big images so a document with many of them stays small */
async function shrinkImage(dataUrl, max = 1800) {
  try { const im = await loadImage(dataUrl); if (im.naturalWidth <= max && im.naturalHeight <= max && dataUrl.length < 1.5e6) return dataUrl; const f = Math.min(1, max / Math.max(im.naturalWidth, im.naturalHeight)); const c = EL("canvas", { width: Math.round(im.naturalWidth * f), height: Math.round(im.naturalHeight * f) }); c.getContext("2d").drawImage(im, 0, 0, c.width, c.height); return c.toDataURL(/png/.test(dataUrl.slice(0, 20)) ? "image/png" : "image/jpeg", .88); } catch (e) { return dataUrl; }
}

/* ---- text marks from a selection (highlight / underline / strike) ---- */
function selectionMarks() {
  const sel = getSelection(); if (!sel || sel.isCollapsed || !sel.rangeCount) return null;
  const range = sel.getRangeAt(0), out = new Map(), quote = sel.toString().replace(/\s+/g, " ").trim();
  for (const v of S.views.values()) {
    const tl = v.el.querySelector(".textLayer"); if (!tl || !range.intersectsNode(tl)) continue;
    const pr = v.el.getBoundingClientRect(), rects = [];
    for (const r of range.getClientRects()) {
      if (r.width < 1 || r.height < 1) continue;
      const cx = r.left + r.width / 2, cy = r.top + r.height / 2; if (cx < pr.left || cx > pr.right || cy < pr.top || cy > pr.bottom) continue;
      rects.push([r.left - pr.left, r.top - pr.top, r.right - pr.left, r.bottom - pr.top]);
    }
    if (rects.length) out.set(v, mergeRects(rects));
  }
  return out.size ? { byView: out, quote } : null;
}
/* join rects that sit on the same line into one, so a highlight is one clean band */
function mergeRects(rs) {
  rs = rs.slice().sort((a, b) => a[1] - b[1] || a[0] - b[0]); const out = [];
  for (const r of rs) { const last = out[out.length - 1]; if (last && Math.abs(last[1] - r[1]) < (r[3] - r[1]) * .5 && Math.abs(last[3] - r[3]) < (r[3] - r[1]) * .5 && r[0] <= last[2] + 12) { last[0] = Math.min(last[0], r[0]); last[2] = Math.max(last[2], r[2]); last[1] = Math.min(last[1], r[1]); last[3] = Math.max(last[3], r[3]); } else out.push(r.slice()); }
  return out;
}
function markSelection(kind, opts = {}) {
  const m = selectionMarks(); if (!m) return null; let first = null;
  for (const [v, rects] of m.byView) { const a = addAnnot({ t: kind, p: v.entry.id, rects: rects.map(r => pxRectToPdf(v, r)), color: S.color, quote: m.quote, text: "" }); first = first || a; }
  getSelection().removeAllRanges(); closeSelPop();
  if (opts.comment && first) { selectAnnot(first.id); openPop(first, null, true); }
  return first;
}
/* a small floating bar when text is selected in Select mode */
function showSelPop() {
  closeSelPop(); const sel = getSelection(); if (!sel || sel.isCollapsed || !sel.rangeCount) return;
  const r = sel.getRangeAt(0).getBoundingClientRect(); if (!r.width) return;
  const p = EL("div", { class: "imgtools selpop", style: `position:fixed;left:${clamp(r.left, 8, innerWidth - 300)}px;top:${Math.max(60, r.top - 40)}px` });
  const mk = (lbl, fn, title) => p.append(EL("button", { onclick: e => { e.preventDefault(); fn(); }, onpointerdown: e => e.preventDefault(), title }, lbl));
  if (S.doc.kind === "pdf") { mk("Highlight", () => markSelection("hl")); mk("Underline", () => markSelection("ul")); mk("Strike", () => markSelection("st")); mk("Comment", () => markSelection("hl", { comment: true })); }
  else { mk("Highlight", () => flowHighlight()); mk("Comment", () => flowComment()); }
  mk("Copy", () => { navigator.clipboard.writeText(sel.toString()); toast("Copied."); closeSelPop(); });
  mk("Read aloud", () => speak(sel.toString()));
  document.body.append(p);
}
function closeSelPop() { $$(".selpop").forEach(p => p.remove()); }

/* ---- edit the PDF's own text: click a text span, retype it ---- */
function bindEditTool() {
  pagesEl.addEventListener("click", e => {
    if (S.tool !== "edit") return; const span = e.target.closest(".textLayer span"); if (!span || !span.textContent.trim()) return;
    const pageEl = span.closest(".page"), v = S.views.get(pageEl.dataset.id); if (!v) return;
    const r = span.getBoundingClientRect(), pr = pageEl.getBoundingClientRect(), px = [r.left - pr.left, r.top - pr.top, r.right - pr.left, r.bottom - pr.top];
    const size = parseFloat(getComputedStyle(span).fontSize) / S.scale, fam = /serif|times|georgia|book/i.test(span.style.fontFamily) && !/sans/i.test(span.style.fontFamily) ? "serif" : (/mono|courier/i.test(span.style.fontFamily) ? "monospace" : "sans-serif");
    const box = EL("div", { class: "editbox", contenteditable: "true", style: `left:${px[0]}px;top:${px[1]}px;height:${px[3] - px[1]}px;line-height:${px[3] - px[1]}px;font-size:${size * S.scale}px;font-family:${fam}` }); box.textContent = span.textContent;
    pageEl.append(box); box.focus(); document.execCommand("selectAll", false, null);
    const done = () => { const txt = box.textContent; if (box.isConnected) box.remove(); if (txt === span.textContent) return; addAnnot({ t: "edit", p: v.entry.id, rect: pxRectToPdf(v, px), text: txt, size, font: fam, color: "#111111", orig: span.textContent }); };
    box.addEventListener("blur", done, { once: true });
    box.addEventListener("keydown", ev => { ev.stopPropagation(); if (ev.key === "Escape") { box.textContent = span.textContent; box.blur(); } if (ev.key === "Enter") { ev.preventDefault(); box.blur(); } });
  });
}

/* ---- comment popup (shared by PDF marks and flow comments) ---- */
let popFor = null;
function openPop(a, ev, focusNew) {
  const pop = $("#pop"); pop.innerHTML = ""; popFor = a;
  const head = EL("div", { class: "ph" }, EL("span", { class: "dot", style: "background:" + (a.color || "#ffe066") }), EL("span", {}, { hl: "Highlight", ul: "Underline", st: "Strikethrough", area: "Area", note: "Comment", shape: "Shape", text: "Text box", image: "Image", ink: "Drawing", cmt: "Comment", mark: "Highlight" }[a.t] || "Note"), EL("span", { class: "sp" }), EL("span", {}, a.at ? fmtTime(a.at) : ""));
  pop.append(head);
  if (a.quote) pop.append(EL("div", { class: "quote" }, a.quote.slice(0, 400)));
  if (a.replies?.length) { const rs = EL("div", { class: "replies" }); a.replies.forEach((r, i) => rs.append(EL("div", { class: "reply" }, EL("div", { class: "who" }, EL("span", {}, "Reply"), EL("span", {}, fmtTime(r.at))), r.text, EL("button", { class: "ibtn", style: "float:right", title: "Delete reply", onclick: () => { a.replies.splice(i, 1); changed(); openPop(a, ev); } }, ICON("i-x"))))); pop.append(rs); }
  const ta = EL("textarea", { placeholder: a.text ? "Reply…" : "Write a comment… (Ctrl+Enter saves)" }); if (!a.text) ta.value = ""; pop.append(ta);
  if (a.text) { const cur = EL("div", { class: "reply", style: "margin-top:6px" }, EL("div", { class: "who" }, EL("span", {}, "Comment"), EL("button", { class: "ibtn", title: "Edit", onclick: () => { ta.value = a.text; ta.dataset.editing = "1"; ta.focus(); } }, ICON("i-edit"))), a.text); pop.insertBefore(cur, ta); }
  const btns = EL("div", { class: "pbtns" });
  const sw = EL("div", { class: "pswatches" }); const palette = (a.t === "ink" || a.t === "shape" || a.t === "text") ? INK_COLORS : COLORS.map(x => x[0]);
  palette.forEach(c => sw.append(EL("i", { class: "sw" + (a.color === c ? " on" : ""), style: "background:" + c, onclick: () => { a.color = c; applyColor(a); openPop(a, ev); changed(); } }))); btns.append(sw, EL("span", { class: "sp" }));
  btns.append(EL("button", { class: "ibtn", title: a.resolved ? "Reopen" : "Mark resolved", onclick: () => { a.resolved = !a.resolved; applyColor(a); changed(); openPop(a, ev); } }, a.resolved ? "↺" : "✓"));
  btns.append(EL("button", { class: "ibtn", title: "Delete", onclick: () => { if (S.doc.kind === "pdf") removeAnnot(a.id); else flowRemove(a); closePop(); } }, ICON("i-trash")));
  btns.append(EL("button", { class: "btn small primary", onclick: () => savePop(a, ta, ev) }, "Save"));
  pop.append(btns);
  ta.addEventListener("keydown", e => { e.stopPropagation(); if ((e.ctrlKey || e.metaKey) && e.key === "Enter") savePop(a, ta, ev); if (e.key === "Escape") closePop(); });
  pop.hidden = false;
  let x = 80, y = 120; if (ev && ev.clientX) { x = ev.clientX + 14; y = ev.clientY - 10; } else { const b = $(`.bubble.on, .cmt.on, mark.on`); if (b) { const r = b.getBoundingClientRect(); x = r.right + 10; y = r.top; } }
  if (x + 310 > innerWidth) x = Math.max(8, innerWidth - 318); if (y + pop.offsetHeight > innerHeight - 8) y = Math.max(8, innerHeight - pop.offsetHeight - 8);
  pop.style.left = x + "px"; pop.style.top = y + "px";
  if (focusNew || !a.text) setTimeout(() => ta.focus(), 20);
}
function savePop(a, ta, ev) { const t = ta.value.trim(); if (ta.dataset.editing) { a.text = t; delete ta.dataset.editing; } else if (!a.text) a.text = t; else if (t) { a.replies = a.replies || []; a.replies.push({ text: t, at: Date.now() }); } if (!a.text && a.t === "note") { if (S.doc.kind === "pdf") removeAnnot(a.id); closePop(); return; } applyColor(a); changed(); closePop(); }
function applyColor(a) { if (S.doc.kind === "pdf") redrawAllAnnots(); else { $$(`[data-id="${a.id}"]`, flowEl).forEach(el => { el.style.setProperty(el.tagName === "MARK" ? "--hl" : "--c", a.color); el.classList.toggle("resolved", !!a.resolved); }); layoutMargin(); } }
function closePop() { const p = $("#pop"); if (!p.hidden) { p.hidden = true; p.innerHTML = ""; popFor = null; } }

/* ---- notes panel (right side) ---- */
function noteItems() {
  if (!S.doc) return [];
  if (S.doc.kind === "pdf") {
    const order = new Map(S.pages.map((p, i) => [p.id, i]));
    return S.doc.annots.filter(a => a.t !== "image").map(a => ({ id: a.id, a, page: order.get(a.p) + 1, y: -(a.rects ? a.rects[0][3] : a.rect ? a.rect[3] : a.pt ? a.pt[1] : a.paths ? a.paths[0][0][1] : 0), kind: a.t === "note" ? "comment" : (a.t === "hl" || a.t === "ul" || a.t === "st" || a.t === "area") ? "highlight" : a.t === "edit" ? "edit" : "draw", quote: a.quote || (a.t === "edit" ? `"${a.orig}" → "${a.text}"` : a.t === "text" ? a.body : ""), text: a.t === "edit" ? "" : a.text, replies: a.replies || [], color: a.color, resolved: a.resolved })).sort((p, q) => p.page - q.page || p.y - q.y);
  }
  const out = []; const seen = new Set();
  $$("mark[data-id],.cmt[data-id]", flowEl).forEach(el => { const id = el.dataset.id; if (seen.has(id)) return; seen.add(id); const c = S.doc.comments[id] || {}; out.push({ id, el, page: 1, y: el.offsetTop, kind: el.tagName === "MARK" ? "highlight" : "comment", quote: $$(`[data-id="${id}"]`, flowEl).map(x => x.textContent).join(""), text: c.text || "", replies: c.replies || [], color: el.style.getPropertyValue("--hl") || el.style.getPropertyValue("--c") || c.color || "#ffe066", resolved: !!c.resolved }); });
  return out.sort((p, q) => p.y - q.y);
}
let noteColorsOff = new Set();
function refreshNotes() {
  const list = $("#notes"); list.innerHTML = ""; const items = noteItems(), f = $("#noteFilter").value, q = $("#noteSearch").value.trim().toLowerCase();
  $("#noteCount").textContent = items.length; if (S.webview) wvBarState();
  const rc = $("#rcolors"); rc.innerHTML = ""; COLORS.forEach(([c, n]) => rc.append(EL("i", { class: "sw" + (noteColorsOff.has(c) ? " off" : ""), style: "background:" + c, title: n + " (click to hide or show)", onclick: () => { noteColorsOff.has(c) ? noteColorsOff.delete(c) : noteColorsOff.add(c); refreshNotes(); } })));
  const shown = items.filter(it => (f === "all" || it.kind === f) && !noteColorsOff.has(it.color) && (!q || (it.quote + " " + it.text + " " + it.replies.map(r => r.text).join(" ")).toLowerCase().includes(q)));
  if (!shown.length) { list.append(EL("div", { class: "empty" }, items.length ? "Nothing matches the filter." : "No notes yet. Select text and pick Highlight or Comment, or use the tools above.")); return; }
  for (const it of shown) {
    const n = EL("div", { class: "note" + (it.resolved ? " resolved" : "") + (it.id === S.sel ? " on" : ""), "data-id": it.id, style: "--c:" + it.color });
    if (it.quote) n.append(EL("div", { class: "nq" }, it.kind === "highlight" ? EL("mark", {}, it.quote) : it.quote));
    if (it.text || it.replies.length) { const c = EL("div", { class: "nc" }, it.text); it.replies.forEach(r => c.append(EL("div", { class: "r" }, r.text))); n.append(c); }
    if (!it.quote && !it.text) n.append(EL("div", { class: "nq muted" }, { draw: "Drawing or shape", edit: "Edit", comment: "Empty comment" }[it.kind] || ""));
    n.append(EL("div", { class: "nm" }, EL("span", { class: "tag" }, it.kind + (S.doc.kind === "pdf" ? " · p. " + it.page : "")), EL("span", {}, it.a?.at ? fmtTime(it.a.at) : "")));
    n.addEventListener("click", e => { if (S.doc.kind === "pdf") { goToAnnot(it.a); openPop(it.a, null); } else if (S.webview) { S.sel = it.id; const at = wvFocus(it.id); openPop(flowAnnot(it.id), at); } else { it.el.scrollIntoView({ block: "center", behavior: "smooth" }); flowSelect(it.id); openPop(flowAnnot(it.id), null); } });
    list.append(n);
  }
}
async function goToAnnot(a) { const i = S.pages.findIndex(p => p.id === a.p); goToPage(i + 1); selectAnnot(a.id); await new Promise(r => setTimeout(r, 80)); const v = S.views.get(a.p); if (!v) return; const px = a.rects ? boundsPx(v, a.rects) : a.rect ? pdfRectToPx(v, a.rect) : a.pt ? (() => { const p = v.vp.convertToViewportPoint(a.pt[0], a.pt[1]); return [p[0], p[1], p[0], p[1]]; })() : inkBounds(v, a); viewer.scrollTop += (v.el.getBoundingClientRect().top + px[1]) - viewer.getBoundingClientRect().top - viewer.clientHeight * .35; }
function notesMarkdown() {
  const items = noteItems(); if (!items.length) return "";
  let md = `# Notes on ${S.doc.name}\n\n`; let lastPage = 0;
  for (const it of items) { if (S.doc.kind === "pdf" && it.page !== lastPage) { md += `\n## Page ${it.page}\n\n`; lastPage = it.page; } if (it.quote) md += `> ${it.quote.replace(/\n/g, "\n> ")}\n`; if (it.text) md += `\n${it.text}\n`; it.replies.forEach(r => md += `\n  - ${r.text}\n`); md += "\n"; }
  return md;
}

/* ---------- image editor: crop, rotate, flip, light and colour; returns a new data URL ----------
   editImage(dataUrl) → Promise<dataUrl | null>. Works on a canvas; nothing leaves the browser. */
async function editImage(src, opts = {}) {
  const im = await loadImage(src);
  const st = { rot: 0, flipH: false, flipV: false, bright: 100, contrast: 100, sat: 100, gray: 0, sharpen: false, crop: null, scale: 100 };
  return new Promise(resolve => {
    const back = $("#modalBack"), m = $("#modal"); m.innerHTML = ""; m.className = "modal imgedit"; back.hidden = false;
    const stage = EL("div", { class: "ie-stage" }), canvas = EL("canvas", { class: "ie-canvas" }), cropBox = EL("div", { class: "ie-crop", hidden: "" });
    const wrap = EL("div", { class: "ie-wrap" }); wrap.append(canvas, cropBox); stage.append(wrap);
    const row = (label, input) => EL("label", { class: "ie-row" }, EL("span", {}, label), input);
    const slider = (k, min, max) => { const i = EL("input", { type: "range", min, max, value: st[k] }); i.oninput = () => { st[k] = +i.value; draw(); }; return i; };
    const side = EL("div", { class: "ie-side" },
      EL("div", { class: "ie-btns" },
        EL("button", { class: "btn small", onclick: () => { st.rot = (st.rot + 90) % 360; st.crop = null; draw(); } }, ICON("i-rotate"), "Rotate"),
        EL("button", { class: "btn small", onclick: () => { st.flipH = !st.flipH; st.crop = null; draw(); } }, "Flip ↔"),
        EL("button", { class: "btn small", onclick: () => { st.flipV = !st.flipV; st.crop = null; draw(); } }, "Flip ↕")),
      EL("p", { class: "muted", style: "font-size:12px;margin:8px 0 4px" }, "Crop: drag on the picture. Click outside the box to clear."),
      row("Brightness", slider("bright", 20, 200)), row("Contrast", slider("contrast", 20, 200)), row("Colour", slider("sat", 0, 200)), row("Greyscale", slider("gray", 0, 100)),
      row("Size", (() => { const i = EL("input", { type: "range", min: 10, max: 100, value: 100 }); i.oninput = () => { st.scale = +i.value; sizeNote(); }; return i; })()),
      EL("div", { class: "ie-size muted", id: "ieSize" }),
      EL("button", { class: "btn small ghost", onclick: () => { Object.assign(st, { rot: 0, flipH: false, flipV: false, bright: 100, contrast: 100, sat: 100, gray: 0, crop: null, scale: 100 }); $$("input[type=range]", side).forEach(i => { i.value = i.max === "100" && i.min === "10" ? 100 : (i.min === "0" ? 0 : 100); }); $$("input[type=range]", side)[0].value = 100; $$("input[type=range]", side)[1].value = 100; $$("input[type=range]", side)[2].value = 100; draw(); } }, "Reset"));
    const btns = EL("div", { class: "mrow" }, EL("button", { class: "btn", onclick: () => finish(null) }, "Cancel"), EL("button", { class: "btn primary", onclick: () => finish(result()) }, "Apply"));
    m.append(EL("h3", {}, opts.title || "Edit image"), EL("div", { class: "ie-body" }, stage, side), btns);
    const ctx = canvas.getContext("2d");
    function baseSize() { return st.rot % 180 ? [im.naturalHeight, im.naturalWidth] : [im.naturalWidth, im.naturalHeight]; }
    function drawTo(c, cx, outW, outH, cropRect) {
      const [bw, bh] = baseSize(); const cr = cropRect || [0, 0, bw, bh];
      c.width = Math.max(1, Math.round(cr[2] * outW)); c.height = Math.max(1, Math.round(cr[3] * outH));
      cx.save(); cx.filter = `brightness(${st.bright}%) contrast(${st.contrast}%) saturate(${st.sat}%) grayscale(${st.gray}%)`;
      cx.scale(outW, outH); cx.translate(-cr[0], -cr[1]);
      cx.translate(bw / 2, bh / 2); cx.rotate(st.rot * Math.PI / 180); cx.scale(st.flipH ? -1 : 1, st.flipV ? -1 : 1);
      cx.drawImage(im, -im.naturalWidth / 2, -im.naturalHeight / 2); cx.restore();
    }
    function draw() {
      const [bw, bh] = baseSize(); const maxW = Math.min(560, innerWidth - 360), maxH = Math.min(440, innerHeight - 260), f = Math.min(maxW / bw, maxH / bh, 1);
      drawTo(canvas, ctx, f, f, null); canvas.style.width = Math.round(bw * f) + "px"; canvas.style.height = Math.round(bh * f) + "px"; canvas.dataset.f = f;
      if (st.crop) { const [x, y, w, h] = st.crop; cropBox.hidden = false; cropBox.style.cssText = `left:${x * f}px;top:${y * f}px;width:${w * f}px;height:${h * f}px`; } else cropBox.hidden = true;
      sizeNote();
    }
    function sizeNote() { const [bw, bh] = baseSize(); const cr = st.crop || [0, 0, bw, bh]; $("#ieSize").textContent = `Result: ${Math.round(cr[2] * st.scale / 100)} × ${Math.round(cr[3] * st.scale / 100)} px`; }
    function result() { const c = document.createElement("canvas"); drawTo(c, c.getContext("2d"), st.scale / 100, st.scale / 100, st.crop); return c.toDataURL(/png|gif|svg/.test(src.slice(0, 20)) ? "image/png" : "image/jpeg", .9); }
    // crop by dragging on the picture
    stage.addEventListener("pointerdown", e => {
      if (e.target !== canvas && e.target !== cropBox && e.target !== wrap) return; e.preventDefault(); const r = canvas.getBoundingClientRect(), f = +canvas.dataset.f, [bw, bh] = baseSize();
      const x0 = clamp((e.clientX - r.left) / f, 0, bw), y0 = clamp((e.clientY - r.top) / f, 0, bh); let moved = false;
      const mv = ev => { const x1 = clamp((ev.clientX - r.left) / f, 0, bw), y1 = clamp((ev.clientY - r.top) / f, 0, bh); if (Math.abs(x1 - x0) > 3 || Math.abs(y1 - y0) > 3) moved = true; if (moved) { st.crop = [Math.min(x0, x1), Math.min(y0, y1), Math.abs(x1 - x0), Math.abs(y1 - y0)]; draw(); } };
      const up = () => { document.removeEventListener("pointermove", mv); document.removeEventListener("pointerup", up); if (!moved) { st.crop = null; draw(); } else if (st.crop && (st.crop[2] < 4 || st.crop[3] < 4)) { st.crop = null; draw(); } };
      document.addEventListener("pointermove", mv); document.addEventListener("pointerup", up);
    });
    function finish(v) { back.hidden = true; m.innerHTML = ""; m.className = "modal"; resolve(v); }
    modalResolve = () => finish(null);
    draw();
  });
}

/* ---------- flow documents: Markdown, web pages, text, notes (a Word-like editor) ----------
   The document is the HTML in #flow. Highlights are <mark data-id style="--hl">, comments are
   <span class="cmt" data-id>; their text and replies live in S.doc.comments[id]. */
function flowAnnot(id) { const c = S.doc.comments[id] || (S.doc.comments[id] = { at: Date.now() }); const els = $$(`[data-id="${id}"]`, flowEl); c.id = id; c.t = els[0]?.tagName === "MARK" ? "mark" : "cmt"; c.quote = els.map(e => e.textContent).join("").slice(0, 400); c.color = c.color || els[0]?.style.getPropertyValue("--hl") || els[0]?.style.getPropertyValue("--c") || S.color; return c; }
function flowSelect(id) { S.sel = id; $$("mark.on,.cmt.on", flowEl).forEach(e => e.classList.remove("on")); $$(`[data-id="${id}"]`, flowEl).forEach(e => e.classList.add("on")); $$(".mnote").forEach(n => n.classList.toggle("on", n.dataset.id === id)); $$(".note").forEach(n => n.classList.toggle("on", n.dataset.id === id)); }
function flowRemove(a) { $$(`[data-id="${a.id}"]`, flowEl).forEach(el => { const p = el.parentNode; while (el.firstChild) p.insertBefore(el.firstChild, el); p.removeChild(el); p.normalize(); }); delete S.doc.comments[a.id]; S.sel = null; layoutMargin(); changed(); }

/* text nodes inside a range, split at its ends */
function rangeTextNodes(range) {
  if (range.startContainer.nodeType === 3 && range.startOffset > 0) { range.startContainer.splitText(range.startOffset); range.setStart(range.startContainer.nextSibling, 0); }
  if (range.endContainer.nodeType === 3 && range.endOffset < range.endContainer.length) range.endContainer.splitText(range.endOffset);
  // text nodes in the range, skipping the whitespace between tags (they would become empty marks)
  const cac = range.commonAncestorContainer, root = cac.nodeType === 3 ? cac.parentNode : cac;   // a walker never visits its own root
  const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, { acceptNode: n => range.intersectsNode(n) && n.data.length && (n.ownerDocument !== document || n.parentElement.closest("#flow")) && (n.data.trim() || n.parentElement.closest("pre")) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT });
  const out = []; let n; while ((n = w.nextNode())) { if (n === range.startContainer && range.startOffset >= n.length) continue; if (n === range.endContainer && range.endOffset === 0) continue; out.push(n); }
  return out;
}
function wrapSelection(tag, cls, id, color) {
  const sel = getSelection(); if (!sel || sel.isCollapsed || !sel.rangeCount) return null;
  const range = sel.getRangeAt(0); const r = wrapRange(range, tag, cls, id, color); if (r) sel.removeAllRanges(); return r;
}
function wrapRange(range, tag, cls, id, color) {
  if (!flowEl.contains(range.commonAncestorContainer)) return null;
  const nodes = rangeTextNodes(range); if (!nodes.length) return null;
  for (const n of nodes) { const w = EL(tag, { class: cls || null, "data-id": id }); w.style.setProperty(tag === "mark" ? "--hl" : "--c", color); n.parentNode.insertBefore(w, n); w.append(n); }
  return id;
}
function flowHighlight() { const id = wrapSelection("mark", "", uid(), S.color); if (!id) return toast("Select some text first."); S.doc.comments[id] = { at: Date.now(), color: S.color, t: "mark" }; closeSelPop(); layoutMargin(); changed(); }
function flowComment() {
  const sel = getSelection(); let id;
  if (sel && !sel.isCollapsed && flowEl.contains(sel.anchorNode)) id = wrapSelection("span", "cmt", uid(), S.color);
  else { // no selection: attach to the current block
    const n = sel?.anchorNode; const block = n && (n.nodeType === 1 ? n : n.parentElement)?.closest("#flow p,#flow h1,#flow h2,#flow h3,#flow h4,#flow li,#flow td,#flow th,#flow blockquote,#flow figure"); if (!block) return toast("Select text, or click into a paragraph, then add the comment.");
    id = uid(); const w = EL("span", { class: "cmt", "data-id": id }); w.style.setProperty("--c", S.color); while (block.firstChild) w.append(block.firstChild); block.append(w);
  }
  if (!id) return; S.doc.comments[id] = { at: Date.now(), color: S.color, t: "cmt", text: "" }; closeSelPop(); layoutMargin(); flowSelect(id); changed(); openPop(flowAnnot(id), null, true);
}
/* margin notes next to the text */
function layoutMargin() {
  if (S.doc?.kind !== "flow") return; marginEl.innerHTML = ""; const items = []; const seen = new Set();
  const z = S.flowZoom || 1;
  $$(".cmt[data-id]", flowEl).forEach(el => { const id = el.dataset.id; if (seen.has(id)) return; seen.add(id); const c = S.doc.comments[id]; if (!c || (!c.text && !c.replies?.length)) return; items.push({ id, el, c, top: (el.getBoundingClientRect().top - flowEl.getBoundingClientRect().top) / z }); });
  $("#margin").parentElement.classList.toggle("nomargin", !items.length && !$$("mark[data-id]", flowEl).length);
  items.sort((a, b) => a.top - b.top); let last = -1e9;
  for (const it of items) {
    const n = EL("div", { class: "mnote" + (it.c.resolved ? " resolved" : "") + (it.id === S.sel ? " on" : ""), "data-id": it.id, style: "--c:" + (it.c.color || "#ffd166") });
    n.append(EL("div", { class: "mq" }, it.el.textContent.slice(0, 60)), EL("div", { class: "mt" }, it.c.text || ""));
    if (it.c.replies?.length) n.append(EL("div", { class: "mr" }, it.c.replies.length + (it.c.replies.length === 1 ? " reply" : " replies")));
    n.addEventListener("click", e => { flowSelect(it.id); openPop(flowAnnot(it.id), e); });
    marginEl.append(n); let top = Math.max(it.top, last + 8); n.style.top = top + "px"; last = top + n.offsetHeight;
  }
}
const layoutMarginSoon = debounce(layoutMargin, 120);

/* editor commands */
function cmd(name, val = null) { flowEl.focus(); document.execCommand(name, false, val); flowChanged(); }
function flowChanged() { S.doc.html = flowEl.innerHTML; changed({ soon: true, quiet: true }); layoutMarginSoon(); refreshNotesSoon(); updateFlowToolbar(); }
const refreshNotesSoon = debounce(refreshNotes, 400);
function setBlock(tag) { if (tag === "pre") { cmd("formatBlock", "<pre>"); return; } cmd("formatBlock", "<" + tag + ">"); }
function currentBlock() { const n = getSelection()?.anchorNode; const el = n && (n.nodeType === 1 ? n : n.parentElement); return el && el.closest("#flow h1,#flow h2,#flow h3,#flow h4,#flow p,#flow blockquote,#flow pre,#flow li"); }
function updateFlowToolbar() {
  if (S.doc?.kind !== "flow") return;
  const b = currentBlock(); const tag = b ? (b.tagName === "LI" ? "p" : b.tagName.toLowerCase()) : "p"; $("#blockSel").value = ["p", "h1", "h2", "h3", "h4", "blockquote", "pre"].includes(tag) ? tag : "p";
  for (const btn of $$("#flowTools [data-cmd]")) { let on = false; try { on = document.queryCommandState(btn.dataset.cmd); } catch (e) { /* unsupported */ } btn.classList.toggle("on", !!on); }
  showTableCtx();
}
function insertHtml(html) { flowEl.focus(); document.execCommand("insertHTML", false, html); flowChanged(); }
function insertTable(r, c) {
  let h = '<table><thead><tr>' + '<th>Heading</th>'.repeat(c) + '</tr></thead><tbody>'; for (let i = 0; i < r; i++) h += "<tr>" + "<td><br></td>".repeat(c) + "</tr>"; h += "</tbody></table><p><br></p>"; insertHtml(h);
}
function tableMenu(anchor) {
  const grid = EL("div", { class: "tbl-pick" }), lbl = EL("div", { class: "tbl-lbl" }, "Pick a size"); let R = 0, C = 0;
  for (let r = 1; r <= 6; r++) for (let c = 1; c <= 8; c++) { const i = EL("i", { "data-r": r, "data-c": c }); i.addEventListener("mouseenter", () => { R = r; C = c; $$("i", grid).forEach(x => x.classList.toggle("on", +x.dataset.r <= r && +x.dataset.c <= c)); lbl.textContent = `${c} × ${r}`; }); i.addEventListener("click", () => { closeMenu(); insertTable(r, c); }); grid.append(i); }
  menu([{ node: grid }, { node: lbl }], anchor);
}
function tableCtx() { const n = getSelection()?.anchorNode; const el = n && (n.nodeType === 1 ? n : n.parentElement); return el && { cell: el.closest("#flow td,#flow th"), table: el.closest("#flow table") }; }
function showTableCtx() {
  const c = $("#ctxbar"); const t = tableCtx(); if (!t || !t.table) { if (c.dataset.kind === "table") { c.hidden = true; c.innerHTML = ""; delete c.dataset.kind; } return; }
  c.hidden = false; c.dataset.kind = "table"; c.innerHTML = ""; c.append(EL("span", {}, "Table:"));
  const row = t.cell?.parentElement, ri = row ? [...t.table.rows].indexOf(row) : 0, ci = t.cell ? [...row.cells].indexOf(t.cell) : 0;
  const B = (l, fn) => c.append(EL("button", { class: "btn small", onpointerdown: e => e.preventDefault(), onclick: () => { fn(); flowChanged(); } }, l));
  B("Row above", () => insertRow(t.table, ri)); B("Row below", () => insertRow(t.table, ri + 1)); B("Column left", () => insertCol(t.table, ci)); B("Column right", () => insertCol(t.table, ci + 1));
  B("Delete row", () => { if (t.table.rows.length > 1) row.remove(); }); B("Delete column", () => { for (const r of t.table.rows) if (r.cells[ci] && r.cells.length > 1) r.cells[ci].remove(); });
  B("Header row on/off", () => { const first = t.table.rows[0]; for (const cell of first.cells) { const nc = EL(cell.tagName === "TH" ? "td" : "th", { html: cell.innerHTML }); cell.replaceWith(nc); } });
  c.append(EL("button", { class: "btn small danger", onpointerdown: e => e.preventDefault(), onclick: () => { t.table.remove(); flowChanged(); } }, "Delete table"));
}
function insertRow(table, at) { const ref = table.rows[Math.min(at, table.rows.length - 1)]; const tr = EL("tr"); for (let i = 0; i < ref.cells.length; i++) tr.append(EL("td", { html: "<br>" })); if (at >= table.rows.length) ref.after(tr); else ref.before(tr); }
function insertCol(table, at) { for (const r of table.rows) { const cell = EL(r.cells[0]?.tagName === "TH" ? "th" : "td", { html: "<br>" }); if (at >= r.cells.length) r.append(cell); else r.cells[at].before(cell); } }
async function insertImageFile(f) { const src = await shrinkImage(await fileToDataUrl(f)); insertHtml(`<figure><img src="${src}" alt="${esc(f.name)}"><figcaption>${esc(f.name.replace(/\.[^.]+$/, ""))}</figcaption></figure><p><br></p>`); }
function imageTools(img) {
  $$(".imgtools:not(.selpop)").forEach(x => x.remove()); $$("img.sel", flowEl).forEach(i => i.classList.remove("sel")); img.classList.add("sel");
  const r = img.getBoundingClientRect(), t = EL("div", { class: "imgtools", style: `position:fixed;left:${Math.max(8, r.left)}px;top:${Math.max(60, r.top - 36)}px` });
  const B = (l, fn) => t.append(EL("button", { onpointerdown: e => e.preventDefault(), onclick: () => { fn(); flowChanged(); t.remove(); } }, l));
  B("25%", () => { img.style.width = "25%"; }); B("50%", () => { img.style.width = "50%"; }); B("100%", () => { img.style.width = "100%"; }); B("Original", () => { img.style.width = ""; });
  B("Left", () => { img.style.float = "left"; img.style.margin = "0 1em .5em 0"; }); B("Centre", () => { img.style.float = ""; img.style.display = "block"; img.style.margin = "0 auto"; });
  B("Caption", () => { let fig = img.closest("figure"); if (!fig) { fig = EL("figure"); img.replaceWith(fig); fig.append(img); } let cap = fig.querySelector("figcaption"); if (!cap) { cap = EL("figcaption", {}, "Caption"); fig.append(cap); } const rg = document.createRange(); rg.selectNodeContents(cap); getSelection().removeAllRanges(); getSelection().addRange(rg); });
  B("Enlarge", () => openLightbox(img, $$("img", flowEl), () => flowChanged()));
  B("Edit…", async () => { const out = await editImage(img.src); if (out) { img.src = out; flowChanged(); } });
  B("Remove", () => { (img.closest("figure") || img).remove(); });
  document.body.append(t);
  // a corner handle: drag to resize freely
  const z = S.flowZoom || 1, hd = EL("div", { class: "img-hdl", style: `position:fixed;left:${r.right - 7}px;top:${r.bottom - 7}px`, title: "Drag to resize" });
  hd.addEventListener("pointerdown", e => { e.preventDefault(); e.stopPropagation(); const w0 = img.getBoundingClientRect().width / z, x0 = e.clientX; const mv = ev => { img.style.width = Math.max(24, w0 + (ev.clientX - x0) / z) + "px"; img.style.height = "auto"; const rr = img.getBoundingClientRect(); hd.style.left = rr.right - 7 + "px"; hd.style.top = rr.bottom - 7 + "px"; }; const up = () => { document.removeEventListener("pointermove", mv); document.removeEventListener("pointerup", up); flowChanged(); }; document.addEventListener("pointermove", mv); document.addEventListener("pointerup", up); });
  document.body.append(hd);
}
document.addEventListener("pointerdown", e => { if (!e.target.closest(".imgtools,.img-hdl") && !(e.target.tagName === "IMG" && flowEl.contains(e.target))) { $$(".imgtools:not(.selpop),.img-hdl").forEach(x => x.remove()); $$("img.sel", flowEl).forEach(i => i.classList.remove("sel")); } }, true);
async function linkPrompt() {
  const sel = getSelection(); const a = sel?.anchorNode && (sel.anchorNode.nodeType === 1 ? sel.anchorNode : sel.anchorNode.parentElement)?.closest("a");
  const saved = sel.rangeCount ? sel.getRangeAt(0).cloneRange() : null;
  const v = await modal(`<h3>Link</h3><label>Web address</label><input type="url" name="url" value="${esc(a?.href || "https://")}"><div class="mrow">${a ? '<button class="btn danger" data-ok="unlink">Remove link</button>' : ""}<span class="sp"></span><button class="btn" data-cancel>Cancel</button><button class="btn primary" data-ok="ok">Apply</button></div>`, { select: true });
  if (!v) return; if (saved) { sel.removeAllRanges(); sel.addRange(saved); }
  if (v.btn === "unlink") return cmd("unlink"); if (!v.url) return;
  if (sel.isCollapsed && !a) insertHtml(`<a href="${esc(v.url)}">${esc(v.url)}</a>`); else cmd("createLink", v.url);
}
function toggleChecklist() {
  const b = currentBlock(); if (b && b.tagName === "LI") { b.classList.toggle("task"); if (b.classList.contains("task")) b.prepend(EL("input", { type: "checkbox" })); else b.querySelector("input[type=checkbox]")?.remove(); flowChanged(); return; }
  insertHtml('<ul><li class="task"><input type="checkbox"> </li></ul>');
}
function alignMenu(anchor) { menu([{ label: "Left", icon: "i-al", fn: () => cmd("justifyLeft") }, { label: "Centre", icon: "i-ac", fn: () => cmd("justifyCenter") }, { label: "Right", icon: "i-ar", fn: () => cmd("justifyRight") }, { sep: true }, { label: "Indent", fn: () => cmd("indent") }, { label: "Outdent", fn: () => cmd("outdent") }], anchor); }

/* flow editor events */
function bindFlow() {
  flowEl.addEventListener("input", flowChanged);
  flowEl.addEventListener("keyup", () => { updateFlowToolbar(); });
  flowEl.addEventListener("mouseup", () => { updateFlowToolbar(); setTimeout(showSelPop, 10); });
  flowEl.addEventListener("keydown", e => {
    if (e.key === "Tab" && tableCtx()?.cell) { e.preventDefault(); const cells = $$("td,th", tableCtx().table), i = cells.indexOf(tableCtx().cell); const next = cells[i + (e.shiftKey ? -1 : 1)]; if (next) { const r = document.createRange(); r.selectNodeContents(next); r.collapse(true); getSelection().removeAllRanges(); getSelection().addRange(r); } else if (!e.shiftKey) { insertRow(tableCtx().table, tableCtx().table.rows.length); flowChanged(); } return; }
    if (e.key === "Tab") { e.preventDefault(); cmd(e.shiftKey ? "outdent" : "indent"); }
  });
  flowEl.addEventListener("click", e => {
    const t = e.target;
    if (t.tagName === "IMG") { e.preventDefault(); imageTools(t); return; }
    if (t.tagName === "A" && (e.ctrlKey || e.metaKey)) { e.preventDefault(); window.open(t.href, "_blank", "noopener"); return; }
    if (t.type === "checkbox") { t.toggleAttribute("checked", t.checked); flowChanged(); return; }
    const m = t.closest("mark[data-id],.cmt[data-id]"); if (m && getSelection().isCollapsed) { flowSelect(m.dataset.id); openPop(flowAnnot(m.dataset.id), e); }
  });
  flowEl.addEventListener("paste", e => {
    const items = [...(e.clipboardData?.items || [])]; const img = items.find(i => i.type.startsWith("image/"));
    if (img) { e.preventDefault(); insertImageFile(img.getAsFile()); return; }
    const html = e.clipboardData.getData("text/html"), text = e.clipboardData.getData("text/plain");
    if (html) { e.preventDefault(); insertHtml(cleanHtml(html)); } else if (text && /^(#|\*|-|\d+\.|>|\|)/m.test(text) && text.includes("\n")) { e.preventDefault(); insertHtml(mdToHtml(text)); }
  });
  flowEl.addEventListener("drop", e => { const f = [...(e.dataTransfer?.files || [])].find(x => x.type.startsWith("image/")); if (f) { e.preventDefault(); insertImageFile(f); } });
  viewer.addEventListener("scroll", () => { $$(".imgtools:not(.selpop),.img-hdl").forEach(x => x.remove()); });
}
/* keep pasted HTML tidy: no scripts, styles, classes or ids from other sites */
function cleanHtml(html, base) {
  const doc = new DOMParser().parseFromString(html, "text/html");
  if (base) { const b = doc.createElement("base"); b.href = base; doc.head.prepend(b); $$("img[src],a[href]", doc).forEach(el => { try { if (el.tagName === "IMG") el.setAttribute("src", new URL(el.getAttribute("src"), base).href); else el.setAttribute("href", new URL(el.getAttribute("href"), base).href); } catch (e) { /* leave */ } }); }
  const clean = DOMPurify.sanitize(doc.body.innerHTML, { USE_PROFILES: { html: true }, FORBID_TAGS: ["style", "script", "iframe", "form", "input", "button", "svg", "canvas", "video", "audio", "noscript", "object", "embed", "select", "textarea"], FORBID_ATTR: ["class", "id", "style", "onclick", "width", "height", "srcset", "sizes", "loading", "decoding", "data-src"] });
  const d2 = new DOMParser().parseFromString(clean, "text/html");
  $$("span,div,section,article,header,footer,nav,aside,main,font,center", d2.body).forEach(el => { if (el.tagName === "DIV" && !el.querySelector("p,h1,h2,h3,h4,ul,ol,table,pre,blockquote,figure,img")) { const p = d2.createElement("p"); p.innerHTML = el.innerHTML; el.replaceWith(p); } else if (el.tagName !== "DIV" || el.parentElement === d2.body) { while (el.firstChild) el.parentNode.insertBefore(el.firstChild, el); el.remove(); } });
  $$("p,li,td,th,h1,h2,h3,h4", d2.body).forEach(el => { if (!el.textContent.trim() && !el.querySelector("img")) el.remove(); });
  return d2.body.innerHTML;
}
function mdToHtml(md) { marked.setOptions({ gfm: true, breaks: false }); let html = marked.parse(md); html = html.replace(/<li><input (?:checked="" )?disabled="" type="checkbox">/g, m => `<li class="task"><input type="checkbox"${/checked/.test(m) ? " checked" : ""}>`); return DOMPurify.sanitize(html, { USE_PROFILES: { html: true }, ADD_ATTR: ["class", "checked"] }); }

/* ---------- web view: the page exactly as a browser shows it, with a floating toolbar on top ----------
   The document is rendered in an iframe (its own head and styles, no scripts). One click on a link
   follows it, on a button presses it, on an image enlarges it; a double-click edits that element.
   While web view is open, the iframe's body is the live copy; wvPull() copies it back into #flow. */
const WV_CSS = `mark[data-id]{background:var(--hl,#ffe066);color:inherit;border-radius:2px;cursor:pointer}
.cmt[data-id]{background:color-mix(in srgb,var(--c,#ffd166) 45%,transparent);border-bottom:2px solid var(--c,#ffd166);cursor:pointer}
.lp-editing{outline:2px solid #0a5fd0!important;outline-offset:2px;cursor:text!important;background-clip:padding-box}
.lp-press{transform:scale(.95);filter:brightness(.9);transition:transform .08s,filter .08s}
.lp-flash{outline:3px solid #ff9f1c!important;outline-offset:3px;transition:outline-color .6s}
img{cursor:zoom-in}
body[contenteditable="true"] img{cursor:default}
a[href],button,[role=button],input[type=button],input[type=submit]{cursor:pointer}`;
let wvClickT = null, wvEditing = null;
const wvFrame = () => $("#wvFrame"), wvDoc = () => wvFrame()?.contentDocument;

function enterWebView() {
  if (S.doc?.kind !== "flow") return toast("Web view is for HTML, Markdown and web pages. PDFs already show as they print.");
  S.webview = true; S.wvZoom = S.wvZoom || 1; document.body.classList.add("webview");
  const wv = $("#webview"); wv.hidden = false;
  const base = S.doc.meta?.sourceUrl ? `<base href="${esc(S.doc.meta.sourceUrl)}">` : "";
  const head = S.doc.meta?.head || `<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><style>${DEFAULT_HEAD_CSS}</style>`;
  const fr = wvFrame(); fr.onload = bindFrame;
  fr.srcdoc = `<!doctype html><html><head>${base}${head}<style id="lp-wv">${WV_CSS}</style></head><body>${flowEl.innerHTML}</body></html>`;
  wv.append($("#right")); $("#right").classList.add("closed"); wvBarState(); closePop(); closeSelPop();
}
function exitWebView() {
  if (!S.webview) return; wvStopEdit(); wvPull(); S.webview = false; document.body.classList.remove("webview");
  $("#webview").hidden = true; closeLightbox(); $$(".wv-selpop").forEach(p => p.remove());
  const panes = $(".panes"); panes.append($("#right")); $("#right").classList.toggle("closed", Prefs.get("right", true) === false);
  wvFrame().srcdoc = "<!doctype html><title></title>"; layoutMargin(); buildOutline(); refreshNotes();
}
/* copy the live page back into the document (and so into autosave and the file) */
function wvPull(silent) {
  if (!S.webview) return; const d = wvDoc(); if (!d?.body) return;
  const b = d.body.cloneNode(true);
  b.querySelectorAll("[contenteditable]").forEach(e => e.removeAttribute("contenteditable"));
  b.querySelectorAll(".lp-editing,.lp-press,.lp-flash,mark.on,.cmt.on").forEach(e => { e.classList.remove("lp-editing", "lp-press", "lp-flash", "on"); if (!e.className) e.removeAttribute("class"); });
  b.removeAttribute("contenteditable");
  const h = b.innerHTML; if (h === flowEl.innerHTML) return;
  flowEl.innerHTML = h; S.doc.html = h; if (!silent) { changed({ soon: true, quiet: true }); refreshNotesSoon(); }
}
const wvPullSoon = debounce(() => wvPull(), 400);
/* the other way: after undo, a colour change or a removed note */
function wvPush() { const d = wvDoc(); if (!S.webview || !d?.body) return; wvEditing = null; d.body.innerHTML = flowEl.innerHTML; d.body.contentEditable = S.wvEditAll ? "true" : "inherit"; }
// keep the iframe in step when the shared functions change #flow
{ const o1 = applyColor; applyColor = a => { o1(a); if (S.webview && S.doc?.kind === "flow") wvPush(); };
  const o2 = flowRemove; flowRemove = a => { o2(a); if (S.webview) wvPush(); };
  const o3 = restore; restore = s => { o3(s); if (S.webview) wvPush(); }; }

function bindFrame() {
  const d = wvDoc(); if (!d || !S.webview) return;
  d.documentElement.style.zoom = S.wvZoom; d.body.contentEditable = S.wvEditAll ? "true" : "inherit";
  const off = () => wvFrame().getBoundingClientRect();
  const pos = e => ({ clientX: e.clientX * (S.wvZoom || 1) + off().left, clientY: e.clientY * (S.wvZoom || 1) + off().top });
  d.addEventListener("pointerdown", e => { closeMenu(); if (!e.target.closest?.(".lp-editing")) closePop(); $$(".wv-selpop").forEach(p => p.remove()); }, true);
  d.addEventListener("click", e => {
    const t = e.target; if (!t.closest) return;
    const a = t.closest("a[href]"), btn = t.closest("button,input[type=button],input[type=submit],input[type=reset],[role=button]"), img = t.tagName === "IMG" ? t : null;
    if (t.closest('[contenteditable="true"]')) { if (a || btn) e.preventDefault(); return; }   // editing: clicks place the caret
    if (img || a || btn) {
      e.preventDefault(); clearTimeout(wvClickT);
      // wait a moment so a double-click (edit) can cancel the single-click action
      wvClickT = setTimeout(() => { if (img) openLightbox(img, wvImages(), () => wvPull()); else if (a) wvFollow(a); else wvPress(btn); }, 260);
      return;
    }
    const m = t.closest("mark[data-id],.cmt[data-id]");
    if (m && d.getSelection().isCollapsed) { d.querySelectorAll("mark.on,.cmt.on").forEach(x => x.classList.remove("on")); d.querySelectorAll(`[data-id="${m.dataset.id}"]`).forEach(x => x.classList.add("on")); S.sel = m.dataset.id; openPop(flowAnnot(m.dataset.id), pos(e)); }
  });
  d.addEventListener("dblclick", e => {
    clearTimeout(wvClickT); const t = e.target; if (!t.closest) return;
    if (t.tagName === "IMG") { e.preventDefault(); return wvEditImage(t); }
    if (t.matches("input[type=button],input[type=submit],input[type=reset]")) { e.preventDefault(); return wvEditInput(t); }
    const el = t.closest("button,a,[role=button],summary,label,figcaption,h1,h2,h3,h4,h5,h6,p,li,td,th,dt,dd,blockquote,pre,caption,legend") || t.closest("span,div,section,article,header,footer,nav,aside,main");
    if (!el || el === d.body || el.closest('[contenteditable="true"]') === el) return;
    e.preventDefault(); wvStartEdit(el, e);
  });
  d.addEventListener("input", wvPullSoon);
  d.addEventListener("mouseup", e => setTimeout(() => wvSelPop(e), 10));
  d.addEventListener("submit", e => e.preventDefault(), true);
  d.addEventListener("keydown", e => {
    const mod = e.ctrlKey || e.metaKey, k = e.key.toLowerCase();
    if (mod && k === "s") { e.preventDefault(); wvPull(true); e.shiftKey ? saveAs() : saveToSource(); }
    else if (mod && (k === "=" || k === "+")) { e.preventDefault(); wvZoom(S.wvZoom * 1.15); }
    else if (mod && k === "-") { e.preventDefault(); wvZoom(S.wvZoom / 1.15); }
    else if (mod && k === "0") { e.preventDefault(); wvZoom(1); }
    else if (mod && e.shiftKey && k === "h") { e.preventDefault(); wvMark("mark"); }
    else if (mod && e.altKey && k === "m") { e.preventDefault(); wvMark("cmt"); }
    else if (e.key === "Escape") { if (!$("#lightbox").hidden) closeLightbox(); else if (wvEditing) wvStopEdit(); else closePop(); }
    else if (!$("#lightbox").hidden && (e.key === "ArrowRight" || e.key === "ArrowLeft")) { e.preventDefault(); lbStep(e.key === "ArrowRight" ? 1 : -1); }
  });
  d.addEventListener("wheel", e => { if (e.ctrlKey || e.metaKey) { e.preventDefault(); wvZoom(S.wvZoom * (e.deltaY < 0 ? 1.1 : 1 / 1.1)); } }, { passive: false });
  wvBarState();
}
const wvImages = () => [...wvDoc().images].filter(i => i.naturalWidth > 1 || i.width > 1);

/* links and buttons do what they look like they do */
function wvFollow(a) {
  const raw = a.getAttribute("href") || "", d = wvDoc();
  if (raw.startsWith("#")) { const id = decodeURIComponent(raw.slice(1)); const tgt = id ? (d.getElementById(id) || d.getElementsByName(id)[0]) : d.body; if (tgt) { tgt.scrollIntoView({ behavior: "smooth", block: "start" }); wvFlash(tgt); } else toast("No part of this page is called “" + id + "”."); return; }
  if (/^javascript:/i.test(raw)) return toast("That link runs a script, which a saved page doesn't keep.");
  if (!/^[a-z][a-z0-9+.-]*:/i.test(raw) && !S.doc.meta?.sourceUrl) return toast("That link points to “" + raw + "”, a file next to the original page; it can't be opened from here.");
  wvFlash(a); window.open(a.href, "_blank", "noopener");
}
function wvPress(btn) {
  btn.classList.add("lp-press"); setTimeout(() => btn.classList.remove("lp-press"), 160);
  const label = (btn.value || btn.textContent || "").trim().slice(0, 40) || "button";
  if (btn.tagName === "SUMMARY") return;
  const det = btn.closest("details"); if (det && btn.closest("summary")) { det.open = !det.open; return; }
  const href = btn.getAttribute("formaction") || btn.dataset.href || btn.dataset.url || btn.getAttribute("href") || btn.closest("form")?.getAttribute("action");
  if (href && !/^javascript:/i.test(href)) { try { window.open(new URL(href, S.doc.meta?.sourceUrl || location.href).href, "_blank", "noopener"); return; } catch (e) { /* fall through */ } }
  toast(`“${label}” is a button. What it did came from the page's scripts, which a saved page doesn't keep. Double-click it to change its text.`);
}
function wvFlash(el) { el.classList.add("lp-flash"); setTimeout(() => { el.classList.remove("lp-flash"); if (!el.className) el.removeAttribute("class"); }, 900); }

/* double-click editing of one element */
function wvStartEdit(el, e) {
  wvStopEdit(); const d = wvDoc(); wvEditing = el;
  el.contentEditable = "true"; el.classList.add("lp-editing"); el.focus();
  const r = d.caretRangeFromPoint ? d.caretRangeFromPoint(e.clientX, e.clientY) : null;
  if (r && el.contains(r.startContainer)) { const s = d.getSelection(); s.removeAllRanges(); s.addRange(r); }
  const isBtn = el.matches("button,a,[role=button],summary");
  el.addEventListener("keydown", ev => {
    if (ev.key === "Escape" || (ev.key === "Enter" && isBtn)) { ev.preventDefault(); wvStopEdit(); }
    else if (ev.key === " " && isBtn) { ev.preventDefault(); d.execCommand("insertText", false, " "); }   // a space would press the button
    ev.stopPropagation();
  });
  el.addEventListener("blur", () => setTimeout(() => { if (wvEditing === el && d.activeElement !== el) wvStopEdit(); }, 120), { once: true });
  wvBarState(); status("Editing: Esc or click elsewhere to finish");
}
function wvStopEdit() { const el = wvEditing; if (!el) return; wvEditing = null; el.removeAttribute("contenteditable"); el.classList.remove("lp-editing"); if (!el.className) el.removeAttribute("class"); wvPull(); wvBarState(); status(""); }
async function wvEditInput(inp) {
  const v = await modal(`<h3>Button text</h3><input type="text" name="v" value="${esc(inp.value)}"><div class="mrow"><button class="btn" data-cancel>Cancel</button><button class="btn primary" data-ok="ok">Change</button></div>`, { select: true });
  if (v) { inp.value = v.v; inp.setAttribute("value", v.v); wvPull(); }
}
async function wvEditImage(img) { const out = await editImage(img.src); if (out) { img.src = out; img.removeAttribute("srcset"); wvPull(); } }

/* highlight and comment on a selection in the page */
function wvMark(kind) {
  const d = wvDoc(), sel = d.getSelection(); let id = uid();
  if (sel && !sel.isCollapsed) {
    const range = sel.getRangeAt(0), nodes = rangeTextNodes(range); if (!nodes.length) return;
    for (const n of nodes) { const w = d.createElement(kind === "mark" ? "mark" : "span"); if (kind !== "mark") w.className = "cmt"; w.dataset.id = id; w.style.setProperty(kind === "mark" ? "--hl" : "--c", S.color); n.parentNode.insertBefore(w, n); w.append(n); }
    sel.removeAllRanges();
  } else if (kind === "cmt") {
    const n = sel?.anchorNode, block = n && (n.nodeType === 1 ? n : n.parentElement)?.closest("p,h1,h2,h3,h4,h5,h6,li,td,th,blockquote,figure,button,a,div"); if (!block || block === d.body) return toast("Select some text, or click into a paragraph, first.");
    const w = d.createElement("span"); w.className = "cmt"; w.dataset.id = id; w.style.setProperty("--c", S.color); while (block.firstChild) w.append(block.firstChild); block.append(w);
  } else return toast("Select some text first.");
  S.doc.comments[id] = { at: Date.now(), color: S.color, t: kind, text: "" };
  $$(".wv-selpop").forEach(p => p.remove()); wvPull(); changed();
  if (kind === "cmt") { const el = d.querySelector(`[data-id="${id}"]`), r = el.getBoundingClientRect(), o = wvFrame().getBoundingClientRect(); S.sel = id; openPop(flowAnnot(id), { clientX: r.right * S.wvZoom + o.left, clientY: r.top * S.wvZoom + o.top }, true); }
}
function wvSelPop(e) {
  $$(".wv-selpop").forEach(p => p.remove()); const d = wvDoc(), sel = d?.getSelection(); if (!sel || sel.isCollapsed || !sel.rangeCount || wvEditing) return;
  const r = sel.getRangeAt(0).getBoundingClientRect(), o = wvFrame().getBoundingClientRect(), z = S.wvZoom || 1; if (!r.width) return;
  const p = EL("div", { class: "imgtools wv-selpop", style: `position:fixed;z-index:340;left:${clamp(r.left * z + o.left, 8, innerWidth - 320)}px;top:${Math.max(8, r.top * z + o.top - 42)}px` });
  const B = (l, fn) => p.append(EL("button", { onpointerdown: ev => ev.preventDefault(), onclick: fn }, l));
  B("Highlight", () => wvMark("mark")); B("Comment", () => wvMark("cmt")); B("Copy", () => { navigator.clipboard.writeText(sel.toString()); toast("Copied."); p.remove(); }); B("Read aloud", () => speak(sel.toString()));
  document.body.append(p);
}
function wvFocus(id) { const d = wvDoc(), el = d?.querySelector(`[data-id="${id}"]`); if (!el) return null; el.scrollIntoView({ block: "center", behavior: "smooth" }); d.querySelectorAll("mark.on,.cmt.on").forEach(x => x.classList.remove("on")); d.querySelectorAll(`[data-id="${id}"]`).forEach(x => x.classList.add("on")); const r = el.getBoundingClientRect(), o = wvFrame().getBoundingClientRect(); return { clientX: r.right * S.wvZoom + o.left + 8, clientY: r.top * S.wvZoom + o.top }; }
function wvZoom(z) { S.wvZoom = clamp(z, .3, 3); const d = wvDoc(); if (d) d.documentElement.style.zoom = S.wvZoom; wvBarState(); }
function wvToggleEditAll() { S.wvEditAll = !S.wvEditAll; wvStopEdit(); const d = wvDoc(); d.body.contentEditable = S.wvEditAll ? "true" : "inherit"; if (S.wvEditAll) d.body.focus(); else wvPull(); wvBarState(); toast(S.wvEditAll ? "Edit page: type anywhere. Links and buttons don't open while editing." : "Reading: links and buttons work again; double-click to edit one thing."); }

/* the floating toolbar */
/* the bar can stand up along the left or right edge so it doesn't cover the page */
function wvSetVert(v, keepPlace) {
  const bar = $("#wvBar"), r = bar.getBoundingClientRect(); S.wvVert = v; Prefs.set("wvVert", v); bar.classList.toggle("vert", v);
  if (keepPlace) { bar.style.transform = "none"; bar.style.left = clamp(r.left, 4, innerWidth - bar.offsetWidth - 4) + "px"; bar.style.top = clamp(r.top, 4, innerHeight - bar.offsetHeight - 4) + "px"; Prefs.set("wvBarPos", [bar.style.left, bar.style.top]); }
  wvKeepBarOnScreen();
}
/* dropped near an edge: left/right edge → vertical against it; top/bottom edge → horizontal */
function wvSnap(x, y) {
  const bar = $("#wvBar"), E = 70;
  if (x < E || x > innerWidth - E) { wvSetVert(true); bar.style.left = (x < E ? 8 : innerWidth - bar.offsetWidth - 8) + "px"; bar.style.top = clamp(y - bar.offsetHeight / 2, 8, innerHeight - bar.offsetHeight - 8) + "px"; }
  else if (y < E || y > innerHeight - E) { wvSetVert(false); bar.style.left = clamp(x - bar.offsetWidth / 2, 8, innerWidth - bar.offsetWidth - 8) + "px"; bar.style.top = (y < E ? 8 : innerHeight - bar.offsetHeight - 8) + "px"; }
  bar.style.transform = "none";
}
/* a bar moved on a wide window must still be reachable on a narrow one */
function wvKeepBarOnScreen() {
  const bar = $("#wvBar"); if (!bar || bar.style.transform !== "none") return;
  const r = bar.getBoundingClientRect(); if (r.right > innerWidth - 4) bar.style.left = Math.max(4, innerWidth - r.width - 4) + "px"; if (r.bottom > innerHeight - 4) bar.style.top = Math.max(4, innerHeight - r.height - 4) + "px";
}
function wvBarState() {
  const bar = $("#wvBar"); if (!bar) return; requestAnimationFrame?.(wvKeepBarOnScreen);
  $("#wvZoomVal").textContent = Math.round((S.wvZoom || 1) * 100) + "%";
  $("#wvEditAll").classList.toggle("on", !!S.wvEditAll);
  $("#wvColor").style.background = S.color;
  $("#wvNoteCount").textContent = $("#noteCount").textContent;
  $("#wvNotes").classList.toggle("on", !$("#right").classList.contains("closed"));
  bar.classList.toggle("min", !!S.wvMin);
}
function bindWvBar() {
  const bar = $("#wvBar");
  bar.addEventListener("click", e => {
    const b = e.target.closest("[data-wv]"); if (!b) return; const a = b.dataset.wv;
    if (a === "hl") wvMark("mark"); else if (a === "cmt") wvMark("cmt");
    else if (a === "color") menu(COLORS.map(([c, n]) => ({ node: EL("button", { class: S.color === c ? "on" : "", onclick: () => { S.color = c; Prefs.set("color", c); buildSwatches(); closeMenu(); wvBarState(); } }, EL("i", { class: "sw", style: "background:" + c }), n) })), b);
    else if (a === "edit") wvToggleEditAll();
    else if (a === "zin") wvZoom(S.wvZoom * 1.15); else if (a === "zout") wvZoom(S.wvZoom / 1.15); else if (a === "z1") wvZoom(1);
    else if (a === "notes") { $("#right").classList.toggle("closed"); refreshNotes(); wvBarState(); }
    else if (a === "undo") { wvPull(true); undo(); } else if (a === "redo") { wvPull(true); redo(); }
    else if (a === "save") { wvPull(true); saveMenu(b); } else if (a === "export") { wvPull(true); exportMenu(b); }
    else if (a === "editor") exitWebView(); else if (a === "home") { exitWebView(); goHome(); }
    else if (a === "min") { S.wvMin = !S.wvMin; Prefs.set("wvMin", S.wvMin); wvBarState(); }
    else if (a === "turn") wvSetVert(!S.wvVert, true);
  });
  $$("button", bar).forEach(b => b.addEventListener("pointerdown", e => e.preventDefault()));   // keep the page's selection
  // drag the bar by its handle; remember where it was put
  const grip = $(".wv-grip", bar);
  // the grip captures the pointer, so the drag keeps going over the page's iframe
  grip.addEventListener("pointerdown", e => {
    e.preventDefault(); grip.setPointerCapture(e.pointerId); const r = bar.getBoundingClientRect(), dx = e.clientX - r.left, dy = e.clientY - r.top, x0 = e.clientX, y0 = e.clientY; let moved = false;
    const mv = ev => { if (!moved && Math.abs(ev.clientX - x0) + Math.abs(ev.clientY - y0) < 4) return; moved = true; bar.style.left = clamp(ev.clientX - dx, 4, innerWidth - bar.offsetWidth - 4) + "px"; bar.style.top = clamp(ev.clientY - dy, 4, innerHeight - bar.offsetHeight - 4) + "px"; bar.style.transform = "none"; };
    const up = ev => { grip.removeEventListener("pointermove", mv); grip.removeEventListener("pointerup", up); if (moved) { wvSnap(ev.clientX, ev.clientY); Prefs.set("wvBarPos", [bar.style.left, bar.style.top]); } else { S.wvMin = !S.wvMin; Prefs.set("wvMin", S.wvMin); wvBarState(); } };
    grip.addEventListener("pointermove", mv); grip.addEventListener("pointerup", up);
  });
  grip.addEventListener("click", e => e.stopPropagation());
  S.wvVert = Prefs.get("wvVert", false); bar.classList.toggle("vert", S.wvVert);
  const p = Prefs.get("wvBarPos", null); if (p) { bar.style.left = p[0]; bar.style.top = p[1]; bar.style.transform = "none"; } S.wvMin = Prefs.get("wvMin", false);
  addEventListener("resize", () => wvKeepBarOnScreen());
}

/* ---------- picture viewer: one image enlarged, with next/previous, actual size, edit, download ---------- */
let LB = null;
function openLightbox(img, list, onChange) {
  list = list?.length ? list : [img]; LB = { list, i: Math.max(0, list.indexOf(img)), onChange, actual: false };
  $("#lightbox").hidden = false; lbShow();
}
function lbShow() {
  const lb = $("#lightbox"), im = LB.list[LB.i], big = $(".lb-img", lb);
  big.src = im.currentSrc || im.src; lb.classList.toggle("actual", LB.actual);
  const cap = im.closest("figure")?.querySelector("figcaption")?.textContent || im.alt || im.title || "";
  $(".lb-cap", lb).textContent = cap; $(".lb-count", lb).textContent = LB.list.length > 1 ? `${LB.i + 1} / ${LB.list.length}` : "";
  $$(".lb-nav", lb).forEach(b => b.hidden = LB.list.length < 2);
  const a = im.closest("a[href]"); $("[data-lb=link]", lb).hidden = !a;
}
function lbStep(d) { LB.i = (LB.i + d + LB.list.length) % LB.list.length; LB.actual = false; lbShow(); }
function closeLightbox() { $("#lightbox").hidden = true; LB = null; }
function bindLightbox() {
  const lb = $("#lightbox");
  lb.addEventListener("click", async e => {
    const b = e.target.closest("[data-lb]"); const im = LB?.list[LB.i];
    if (e.target === lb || e.target.classList.contains("lb-stage")) return closeLightbox();
    if (e.target.classList.contains("lb-img")) { LB.actual = !LB.actual; lbShow(); return; }
    if (!b || !im) return; const a = b.dataset.lb;
    if (a === "close") closeLightbox(); else if (a === "prev") lbStep(-1); else if (a === "next") lbStep(1);
    else if (a === "actual") { LB.actual = !LB.actual; lbShow(); }
    else if (a === "edit") { const out = await editImage(im.src); if (out) { im.src = out; im.removeAttribute("srcset"); LB.onChange?.(); lbShow(); } }
    else if (a === "download") { try { const blob = await (await fetch(im.src)).blob(); download(blob, (im.alt || "image").replace(/[^\w.-]+/g, "_").slice(0, 40) + "." + (blob.type.split("/")[1] || "png").replace("jpeg", "jpg").replace("svg+xml", "svg")); } catch (er) { window.open(im.src, "_blank", "noopener"); } }
    else if (a === "link") { const ln = im.closest("a[href]"); if (ln) window.open(ln.href, "_blank", "noopener"); }
  });
  document.addEventListener("keydown", e => { if (!LB) return; if (e.key === "Escape") closeLightbox(); else if (e.key === "ArrowRight") lbStep(1); else if (e.key === "ArrowLeft") lbStep(-1); });
}

/* ---------- opening, saving, exporting ---------- */
function newDoc(kind, name, extra = {}) { return { id: uid(), kind, name, created: Date.now(), modified: Date.now(), annots: [], comments: {}, html: "", origHtml: "", pages: [], meta: {}, ...extra }; }
function download(blob, name) { const u = URL.createObjectURL(blob); const a = EL("a", { href: u, download: name }); document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(u), 4000); }
const baseName = n => String(n || "document").replace(/\.[^.]+$/, "");
const b64 = { enc(buf) { const u = new Uint8Array(buf); let s = ""; for (let i = 0; i < u.length; i += 8192) s += String.fromCharCode.apply(null, u.subarray(i, i + 8192)); return btoa(s); }, dec(s) { const b = atob(s), u = new Uint8Array(b.length); for (let i = 0; i < b.length; i++) u[i] = b.charCodeAt(i); return u; } };

/* ---- open things ---- */
/* open a file; `handle` (from the file picker or a drop) lets Save write back to the same file */
async function openFile(f, handle) {
  const name = f.name || "document", ext = (name.match(/\.([^.]+)$/) || [, ""])[1].toLowerCase();
  status("Opening " + name + "…");
  const src = d => { d.srcHandle = handle || null; d.meta.srcName = name; d.meta.srcExt = ext || (f.type.startsWith("image/") ? f.type.split("/")[1] : ""); return d; };
  try {
    if (ext === "lpdoc" || (ext === "json" && (await f.slice(0, 40).text()).includes("lpdoc"))) return openProject(JSON.parse(await f.text()), handle);
    if (ext === "pdf" || f.type === "application/pdf") return openPdfDoc(src(newDoc("pdf", name, { src: new Blob([await f.arrayBuffer()], { type: "application/pdf" }) })));
    if (f.type.startsWith("image/")) { const data = await shrinkImage(await fileToDataUrl(f), 2600); return openImageDoc(name, data, src); }
    const text = await f.text();
    if (ext === "html" || ext === "htm" || f.type === "text/html") return openHtmlFile(name, text, src);
    if (ext === "md" || ext === "markdown" || ext === "txt" || ext === "" || f.type.startsWith("text/")) return openDoc(src(newDoc("flow", name, { html: ext === "txt" ? textToHtml(text) : mdToHtml(text), orig: text })));
    toast("That file type isn't supported: " + name);
  } catch (e) { console.error(e); status("Could not open " + name, "err"); toast("Could not open " + name + ": " + (e.message || e)); }
}
function textToHtml(t) { return t.split(/\n{2,}/).map(p => "<p>" + esc(p).replace(/\n/g, "<br>") + "</p>").join(""); }
async function openImageDoc(name, src, attach) { const im = await loadImage(src); const w = 612, h = Math.max(100, 612 * im.naturalHeight / im.naturalWidth); let d = newDoc("pdf", name, { src: null, pages: [{ id: uid(), img: { data: src, w, h }, rot: 0 }] }); if (attach) d = attach(d); return openPdfDoc(d); }
/* an HTML file from disk: kept whole (its own styles scoped to the document), editable, and written back as a full page */
function openHtmlFile(name, html, attach, base) {
  const dom = new DOMParser().parseFromString(html, "text/html");
  if (base) {   // a web page: make its addresses absolute so pictures, styles and links still work here
    for (const [sel, at] of [["img[src]", "src"], ["a[href]", "href"], ["link[href]", "href"], ["source[srcset]", "srcset"], ["img[srcset]", "srcset"]]) dom.querySelectorAll(sel).forEach(el => { const v = el.getAttribute(at); if (!v || /^(data|blob|javascript|mailto|#)/i.test(v)) return; try { if (at === "srcset") el.setAttribute(at, v.split(",").map(p => { const [u, w] = p.trim().split(/\s+/); return new URL(u, base).href + (w ? " " + w : ""); }).join(", ")); else el.setAttribute(at, new URL(v, base).href); } catch (e) { /* leave */ } });
    dom.querySelectorAll("img[data-src]:not([src]),img[data-src][src^='data:']").forEach(el => { try { el.setAttribute("src", new URL(el.dataset.src, base).href); } catch (e) { /* leave */ } });
  }
  let comments = {}; const cj = dom.getElementById("lp-comments"); if (cj) { try { comments = JSON.parse(cj.textContent); } catch (e) { /* ignore */ } cj.remove(); }
  const head = [...dom.head.children].filter(e => /^(STYLE|TITLE|META)$/.test(e.tagName) || (e.tagName === "LINK" && /stylesheet/i.test(e.rel))).map(e => e.outerHTML).join("\n");
  const css = [...dom.querySelectorAll("style")].map(s => s.textContent).join("\n");
  dom.querySelectorAll("script,noscript,iframe,object,embed").forEach(e => e.remove());
  const body = DOMPurify.sanitize(dom.body.innerHTML, { USE_PROFILES: { html: true, svg: true, svgFilters: true }, ADD_ATTR: ["style", "class", "id", "width", "height", "colspan", "rowspan", "target", "checked", "srcset", "sizes", "role", "formaction", "value", "type", "name"], ADD_TAGS: ["mark", "button"] });
  let d = newDoc("flow", (dom.title || name).trim(), { html: body, comments, orig: html, meta: { faithful: true, head, css } }); if (attach) d = attach(d);
  return openDoc(d);
}
/* the file's own CSS, limited to the document so it can't restyle the app */
function scopeCss(css) {
  try {
    const doc = document.implementation.createHTMLDocument(""), st = doc.createElement("style"); st.textContent = css; doc.head.append(st); const out = [];
    const walk = rules => { for (const r of rules) { if (r.type === 1) { const sel = r.selectorText.split(",").map(s => { s = s.trim(); if (/^(html|body|:root)$/i.test(s)) return "#flow"; return "#flow " + s.replace(/^(html|body)\s+/i, ""); }).join(", "); out.push(sel + "{" + r.style.cssText + "}"); } else if (r.cssRules) { out.push("@media " + (r.conditionText || r.media?.mediaText || "all") + "{"); walk(r.cssRules); out.push("}"); } else if (r.type === 5) out.push(r.cssText); } };
    walk(st.sheet.cssRules); return out.join("\n");
  } catch (e) { return ""; }
}
function openHtmlDoc(name, html, url) {
  if (Prefs.get("webLayout", "original") === "original") return openHtmlFile(name, html, d => { d.meta.sourceUrl = url || ""; return d; }, url);
  const dom = new DOMParser().parseFromString(html, "text/html");
  if (url) { const b = dom.createElement("base"); b.href = url; dom.head.prepend(b); }
  let title = dom.title || name, body;
  try { const art = new Readability(dom.cloneNode(true), { keepClasses: false }).parse(); if (art && art.content && art.textContent.trim().length > 200) { body = art.content; title = art.title || title; if (art.byline) body = `<p><em>${esc(art.byline)}</em></p>` + body; } } catch (e) { /* fall back to the whole page */ }
  if (!body) body = dom.body.innerHTML;
  let out = cleanHtml(body, url); if (!/^\s*<h1/i.test(out)) out = `<h1>${esc(title)}</h1>` + out;
  if (url) out = `<p class="src-note">Source: <a href="${esc(url)}">${esc(url)}</a> · saved ${fmtTime(Date.now())}</p>` + out;
  return openDoc(newDoc("flow", title.replace(/[\\/:*?"<>|]/g, " ").trim() || name, { html: out, meta: { sourceUrl: url || "" } }));
}
async function openUrl(url) {
  url = url.trim(); if (!/^https?:\/\//i.test(url)) url = "https://" + url;
  const note = $("#urlNote"); note.className = "url-note"; note.textContent = "Loading " + url + " …"; status("Loading…");
  try {
    const r = await fetch(url, { mode: "cors", credentials: "omit" }); if (!r.ok) throw new Error("HTTP " + r.status);
    const ct = (r.headers.get("content-type") || "").toLowerCase(), fname = decodeURIComponent(url.split("?")[0].split("/").pop() || "page");
    if (ct.includes("pdf") || /\.pdf$/i.test(url.split("?")[0])) { const buf = await r.arrayBuffer(); note.textContent = ""; return openPdfDoc(newDoc("pdf", fname.endsWith(".pdf") ? fname : fname + ".pdf", { src: new Blob([buf], { type: "application/pdf" }), meta: { sourceUrl: url } })); }
    if (ct.startsWith("image/")) { const src = await shrinkImage(await fileToDataUrl(await r.blob()), 2600); note.textContent = ""; return openImageDoc(fname, src); }
    const text = await r.text(); note.textContent = "";
    if (ct.includes("markdown") || /\.(md|markdown)$/i.test(fname)) return openDoc(newDoc("flow", fname, { html: mdToHtml(text), meta: { sourceUrl: url } }));
    if (ct.includes("text/plain")) return openDoc(newDoc("flow", fname, { html: textToHtml(text), meta: { sourceUrl: url } }));
    return openHtmlDoc(fname, text, url);
  } catch (e) {
    console.warn(e); status("");
    if (IS_EXT) { note.className = "url-note err"; note.textContent = "Could not load that address (" + (e.message || e) + ")."; return; }
    note.className = "url-note err";
    note.innerHTML = `This page can't fetch <b>${esc(url)}</b> from here: most sites only let their own pages read them (the browser's cross-origin rule). Three ways round it: use the <b>Chrome extension</b> (right), or open the page in another tab, select all (Ctrl+A), copy, and press <b>Paste</b> here, or save the page as PDF from the browser's print dialog and drop it in.`;
    const v = await modal(`<h3>Can't fetch that page directly</h3><p>Websites usually block other pages from reading them. Pick one:</p><div class="opts">
      <label class="opt"><input type="radio" name="how" value="frame" checked><div><b>Show it in a frame (read only)</b><span>You can read and scroll it here, but not highlight it. Some sites refuse to be framed.</span></div></label>
      <label class="opt"><input type="radio" name="how" value="paste"><div><b>Paste the page</b><span>Open it in a tab, Ctrl+A, Ctrl+C, then paste here. Text, images and headings are kept, and you can mark it all up.</span></div></label>
      <label class="opt"><input type="radio" name="how" value="ext"><div><b>Use the Chrome extension</b><span>One click opens any page, including ones you are signed in to.</span></div></label></div>
      <div class="mrow"><button class="btn" data-cancel>Cancel</button><button class="btn primary" data-ok="ok">Continue</button></div>`);
    if (!v) return;
    if (v.how === "frame") return openDoc(newDoc("flow", url.replace(/^https?:\/\//, "").slice(0, 60), { html: `<p class="readonly-note">Read-only view of <a href="${esc(url)}">${esc(url)}</a>. Highlights and comments can't be placed on a framed page; paste the page instead to mark it up.</p><iframe src="${esc(url)}" sandbox="allow-scripts allow-same-origin allow-popups" referrerpolicy="no-referrer"></iframe>`, meta: { sourceUrl: url, frame: true } }));
    if (v.how === "paste") return pasteNew();
    $("#extCard")?.scrollIntoView({ behavior: "smooth" });
  }
}
async function pasteNew() {
  const v = await modal(`<h3>Paste</h3><p>Paste text, Markdown, or a copied web page (Ctrl+A, Ctrl+C on the page). Formatting and images come along when the page allows it.</p><div id="pasteBox" contenteditable="true" style="min-height:200px;max-height:50vh;overflow:auto;border:1px solid var(--line-2);border-radius:9px;padding:10px;background:var(--paper)"></div><input type="hidden" name="x"><div class="mrow"><button class="btn" data-cancel>Cancel</button><button class="btn primary" data-ok="ok">Open as a document</button></div>`, { focus: "#pasteBox" });
  if (!v) return; const box = $("#pasteBox"); const html = window._lastPaste?.html, text = window._lastPaste?.text || box?.textContent || "";
  if (html) return openHtmlDoc("Pasted page", html, window._lastPaste.url || null);
  if (!text.trim()) return toast("Nothing was pasted.");
  return openDoc(newDoc("flow", text.split("\n")[0].replace(/^#+\s*/, "").slice(0, 60) || "Pasted text", { html: /^(#|\*|-|\d+\.|>|\|)/m.test(text) ? mdToHtml(text) : textToHtml(text) }));
}
document.addEventListener("paste", e => { if (!e.target.closest("#pasteBox")) return; const html = e.clipboardData.getData("text/html"), text = e.clipboardData.getData("text/plain"); window._lastPaste = { html, text }; });
function openProject(p, handle) {
  if (p.format !== "lpdoc") throw new Error("Not a Doc Reader project file");
  const d = { ...newDoc(p.kind, p.name), ...p.doc, id: p.doc.id || uid() }; if (p.srcB64) d.src = new Blob([b64.dec(p.srcB64)], { type: "application/pdf" }); else d.src = null;
  if (handle) { S.fileHandle = handle; d.handle = handle; }
  return d.kind === "pdf" ? openPdfDoc(d) : openDoc(d);
}

/* ---- show a document ---- */
async function openPdfDoc(d) {
  d.kind = "pdf"; await closeDoc();
  S.doc = d; S.pdf = null; S.pageCache.clear(); textCache.clear();
  if (d.src) { const data = new Uint8Array(await d.src.arrayBuffer()); S.pdf = await pdfjsLib.getDocument({ data, cMapUrl: undefined }).promise; if (!d.pages?.length) d.pages = Array.from({ length: S.pdf.numPages }, (_, i) => ({ id: uid(), src: i, rot: 0 })); }
  S.pages = d.pages.map(p => ({ ...p })); return showDoc();
}
async function openDoc(d) { await closeDoc(); S.doc = d; S.pages = []; S.pdf = null; return showDoc(); }
async function showDoc() {
  const d = S.doc; $("#home").hidden = true; work.hidden = false; $("#homeBtn").hidden = false; $("#docActions").hidden = false; $("#docTitle").hidden = false; $("#docTitle").value = d.name;
  work.classList.remove("mode-pdf", "mode-flow"); work.classList.add("mode-" + d.kind, "loading");
  S.hist = []; S.hi = -1; S.sel = null; S.current = 1; closePop(); $("#ctxbar").hidden = true;
  if (d.kind === "pdf") {
    flowWrap.hidden = true; pagesEl.hidden = false; setTool("select"); S.scale = 0;
    await setZoom(Prefs.get("zoomMode", "width"), Prefs.get("zoom", 1));
    buildOutline(); if (!d.thumb) makeThumb();
  } else {
    pagesEl.hidden = true; flowWrap.hidden = false; flowEl.innerHTML = d.html || "<p><br></p>"; if (!d.origHtml) d.origHtml = d.html; flowEl.dataset.font = Prefs.get("flowFont", "serif"); flowEl.contentEditable = d.meta?.frame ? "false" : "true";
    flowEl.classList.toggle("faithful", !!d.meta?.faithful); $("#flow-filecss")?.remove(); if (d.meta?.css) { const sc = scopeCss(d.meta.css); if (sc) document.head.append(EL("style", { id: "flow-filecss" }, sc)); }
    S.flowZoom = 1; await setZoom("custom", 1);
    layoutMargin(); buildOutline(); updateFlowToolbar(); $("#thumbs").innerHTML = "";
    if (d.meta?.faithful && Prefs.get("htmlWebView", true)) enterWebView();   // HTML files open as the page looks
  }
  work.classList.remove("loading"); pushHistory(); refreshNotes(); status("");
  document.title = d.name + " · Doc Reader"; if (!d.saved) { markDirty(); } else status("Opened", "ok");
  d.opened = Date.now(); saveSoon();
}
async function closeDoc() { if (S.webview) exitWebView(); if (S.doc && S.dirty) await saveNow(); $("#flow-filecss")?.remove(); S.fileHandle = null; S.confirmedOverwrite = false; if (S.pdf) { try { await S.pdf.destroy(); } catch (e) { /* ignore */ } } S.pdf = null; S.doc = null; speechSynthesis?.cancel?.(); S.speaking = false; }
function goHome() { closeDoc().then(() => { work.hidden = true; $("#home").hidden = false; $("#homeBtn").hidden = true; $("#docActions").hidden = true; $("#docTitle").hidden = true; document.title = "Doc Reader · Lab Potato"; status(""); listRecent(); }); }
async function makeThumb() { try { const v = S.views.values().next().value; if (!v) return; const vp = v.page.getViewport({ scale: 120 / v.page.getViewport({ scale: 1 }).width }); const c = EL("canvas", { width: vp.width, height: vp.height }); await v.page.render({ canvasContext: c.getContext("2d"), viewport: vp }).promise; S.doc.thumb = c.toDataURL("image/jpeg", .7); } catch (e) { /* no thumb */ } }

/* ---- autosave (IndexedDB, and a file if one was chosen) ---- */
function markDirty() { S.dirty = true; S.doc && (S.doc.modified = Date.now()); status("Unsaved changes"); saveSoon(); }
const saveSoon = debounce(() => saveNow(), 1500);
async function saveNow() {
  if (!S.doc) return; if (S.webview) wvPull(true); const d = S.doc; d.pages = S.pages.map(p => ({ id: p.id, src: p.src, blank: p.blank, img: p.img, rot: p.rot })); if (d.kind === "flow") d.html = flowEl.innerHTML; d.saved = true;
  try { await DB.put("docs", recordOf(d)); S.dirty = false; status("Saved " + new Date().toLocaleTimeString("en", { hour: "2-digit", minute: "2-digit" }), "ok"); } catch (e) { console.warn(e); status("Could not autosave (" + (e.message || e) + ")", "err"); }
  if (S.fileHandle) writeFileHandle().catch(e => { console.warn(e); status("Could not write the file: " + (e.message || e), "err"); });
}
function recordOf(d) { const { _page, ...rest } = d; return { ...rest, annots: d.annots, comments: d.comments, pages: d.pages, src: d.src || null, handle: S.fileHandle || d.handle || null, srcHandle: d.srcHandle || null }; }
async function projectBlob() { const d = S.doc; d.pages = S.pages.map(p => ({ id: p.id, src: p.src, blank: p.blank, img: p.img, rot: p.rot })); if (d.kind === "flow") d.html = flowEl.innerHTML; const { src, handle, srcHandle, thumb, ...doc } = d; const out = { format: "lpdoc", v: 1, kind: d.kind, name: d.name, app: "Lab Potato Doc Reader v2", doc, srcB64: src ? b64.enc(await src.arrayBuffer()) : null }; return new Blob([JSON.stringify(out)], { type: "application/json" }); }
async function saveProjectFile() { download(await projectBlob(), baseName(S.doc.name) + ".lpdoc"); toast("Saved the project file. Open it here again any time to carry on."); }
async function chooseAutosaveFile() {
  if (!window.showSaveFilePicker) return toast("This browser can't keep a file updated automatically. Use Save → Project file instead.");
  try { S.fileHandle = await showSaveFilePicker({ suggestedName: baseName(S.doc.name) + ".lpdoc", types: [{ description: "Doc Reader project", accept: { "application/json": [".lpdoc"] } }] }); await writeFileHandle(); S.doc.handle = S.fileHandle; await saveNow(); toast("Autosaving to " + S.fileHandle.name + " from now on."); } catch (e) { if (e.name !== "AbortError") toast("Could not set that up: " + e.message); }
}
async function writeFileHandle() { const w = await S.fileHandle.createWritable(); await w.write(await projectBlob()); await w.close(); }
async function reconnectHandle(h) { try { if ((await h.queryPermission({ mode: "readwrite" })) === "granted" || (await h.requestPermission({ mode: "readwrite" })) === "granted") { S.fileHandle = h; return true; } } catch (e) { /* not available */ } return false; }

/* ---- recent list on the start page ---- */
async function listRecent() {
  const box = $("#recentList"); let docs = []; try { docs = await DB.all("docs"); } catch (e) { box.innerHTML = '<p class="muted">Saving in this browser is not available (private window?). You can still open files and save project files.</p>'; return; }
  docs.sort((a, b) => (b.opened || b.modified) - (a.opened || a.modified)); box.innerHTML = "";
  if (!docs.length) { box.innerHTML = '<p class="muted">Nothing yet. Open a file to start.</p>'; return; }
  for (const d of docs) {
    const kind = d.kind === "pdf" ? (d.src ? "pdf" : "img") : d.meta?.sourceUrl ? "html" : "md";
    const c = EL("button", { class: "rc", title: d.name }); const ic = EL("span", { class: "ic " + kind }); if (d.thumb) ic.style.cssText = `background:url(${d.thumb}) center/cover`; else ic.textContent = kind.toUpperCase(); c.append(ic);
    c.append(EL("span", { class: "t" }, EL("span", { class: "n" }, d.name), EL("span", { class: "m" }, `${fmtTime(d.modified)} · ${d.annots?.length || Object.keys(d.comments || {}).length || 0} notes`)));
    c.append(EL("span", { class: "x", title: "Remove from this browser", onclick: async e => { e.stopPropagation(); if (await modal(`<h3>Remove "${esc(d.name)}"?</h3><p>It is removed from this browser's list. Files on your computer are not touched.</p><div class="mrow"><button class="btn" data-cancel>Keep</button><button class="btn danger" data-ok="ok">Remove</button></div>`)) { await DB.del("docs", d.id); listRecent(); } } }, ICON("i-x")));
    c.addEventListener("click", async () => { if (d.handle) { if (await reconnectHandle(d.handle)) status("Autosaving to " + d.handle.name, "ok"); } d.kind === "pdf" ? openPdfDoc(d) : openDoc(d); });
    if (d.srcHandle) c.title += " · can save back to " + d.srcHandle.name;
    box.append(c);
  }
}

/* ---- export ---- */
function hexRgb(h) { const n = parseInt(h.slice(1), 16); return [((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255]; }
const winAnsi = s => s.replace(/[^\x20-\x7E\xA0-\xFF–—‘’“”•…€]/g, "?");
async function exportPdf(opts) {
  const { PDFDocument, rgb, StandardFonts, PDFName, PDFString, PDFArray, PDFNumber, BlendMode } = PDFLib;
  status("Building the PDF…"); const out = await PDFDocument.create(); out.setTitle(S.doc.name); out.setProducer("Lab Potato Doc Reader");
  const srcDoc = S.doc.src ? await PDFDocument.load(await S.doc.src.arrayBuffer(), { ignoreEncryption: true }) : null;
  const font = await out.embedFont(StandardFonts.Helvetica), mono = await out.embedFont(StandardFonts.Courier), serif = await out.embedFont(StandardFonts.TimesRoman);
  for (const entry of S.pages) {
    let page;
    if (entry.src != null && srcDoc) { const [cp] = await out.copyPages(srcDoc, [entry.src]); page = out.addPage(cp); }
    else { const w = entry.img ? entry.img.w : entry.blank.w, h = entry.img ? entry.img.h : entry.blank.h; page = out.addPage([w, h]); if (entry.img) { const bytes = b64.dec(entry.img.data.split(",")[1]); const im = /png/.test(entry.img.data.slice(0, 20)) ? await out.embedPng(bytes) : await out.embedJpg(bytes); page.drawImage(im, { x: 0, y: 0, width: w, height: h }); } }
    if (entry.rot) page.setRotation(PDFLib.degrees((page.getRotation().angle + entry.rot) % 360));
    const annots = annotsOf(entry.id), realAnnots = [];
    const addAnnotObj = dict => { const ref = out.context.register(out.context.obj(dict)); realAnnots.push(ref); };
    for (const a of annots) {
      const col = hexRgb(a.color || "#ffe066"), R = rgb(...col);
      if ((a.t === "hl" || a.t === "ul" || a.t === "st" || a.t === "area") && opts.interactive) {
        const rects = a.t === "area" ? [a.rect] : a.rects, quads = [], bb = [1e9, 1e9, -1e9, -1e9];
        for (const r of rects) { const [x1, y1, x2, y2] = normRect(r); quads.push(x1, y2, x2, y2, x1, y1, x2, y1); bb[0] = Math.min(bb[0], x1); bb[1] = Math.min(bb[1], y1); bb[2] = Math.max(bb[2], x2); bb[3] = Math.max(bb[3], y2); }
        addAnnotObj({ Type: "Annot", Subtype: a.t === "ul" ? "Underline" : a.t === "st" ? "StrikeOut" : "Highlight", Rect: bb, QuadPoints: quads, C: col, CA: a.t === "area" ? .5 : 1, F: 4, T: PDFString.of("Doc Reader"), Contents: PDFString.of(commentText(a)), M: PDFString.fromDate(new Date(a.at || Date.now())), NM: PDFString.of(a.id) });
        if (opts.draw) drawMarks(page, a, R);
      } else if (a.t === "hl" || a.t === "ul" || a.t === "st" || a.t === "area") drawMarks(page, a, R);
      else if (a.t === "note" && opts.interactive) addAnnotObj({ Type: "Annot", Subtype: "Text", Rect: [a.pt[0], a.pt[1] - 20, a.pt[0] + 20, a.pt[1]], Name: "Comment", C: col, F: 4, T: PDFString.of("Doc Reader"), Contents: PDFString.of(commentText(a)), M: PDFString.fromDate(new Date(a.at || Date.now())), Open: false });
      else if (a.t === "note") { page.drawCircle({ x: a.pt[0] + 6, y: a.pt[1] - 6, size: 7, color: R }); page.drawText(winAnsi(commentText(a)).slice(0, 300), { x: a.pt[0] + 16, y: a.pt[1] - 10, size: 7, font, color: rgb(.2, .2, .2), maxWidth: 200, lineHeight: 8.5 }); }
      else if (a.t === "ink") { for (const path of a.paths) { if (path.length < 2) continue; let d = `M ${path[0][0]} ${path[0][1]}`; for (let i = 1; i < path.length; i++) d += ` L ${path[i][0]} ${path[i][1]}`; page.drawSvgPath(d, { borderColor: rgb(...hexRgb(a.color)), borderWidth: a.width, borderLineCap: 1, x: 0, y: 0, scale: 1 }); } }
      else if (a.t === "shape") {
        const [x1, y1, x2, y2] = normRect(a.rect), C = rgb(...hexRgb(a.color));
        if (a.kind === "rect") page.drawRectangle({ x: x1, y: y1, width: x2 - x1, height: y2 - y1, borderColor: C, borderWidth: a.width });
        else if (a.kind === "whiteout") page.drawRectangle({ x: x1, y: y1, width: x2 - x1, height: y2 - y1, color: rgb(1, 1, 1) });
        else if (a.kind === "ellipse") page.drawEllipse({ x: (x1 + x2) / 2, y: (y1 + y2) / 2, xScale: (x2 - x1) / 2, yScale: (y2 - y1) / 2, borderColor: C, borderWidth: a.width });
        else { const [p, q] = a.pts; page.drawLine({ start: { x: p[0], y: p[1] }, end: { x: q[0], y: q[1] }, color: C, thickness: a.width }); if (a.kind === "arrow") { const ang = Math.atan2(q[1] - p[1], q[0] - p[0]), L = 6 + a.width * 3; for (const s of [-.45, .45]) page.drawLine({ start: { x: q[0], y: q[1] }, end: { x: q[0] - L * Math.cos(ang + s), y: q[1] - L * Math.sin(ang + s) }, color: C, thickness: a.width }); } }
      } else if (a.t === "image") { try { const bytes = b64.dec(a.data.split(",")[1]); const im = /png/.test(a.data.slice(0, 20)) ? await out.embedPng(bytes) : await out.embedJpg(bytes); const [x1, y1, x2, y2] = normRect(a.rect); page.drawImage(im, { x: x1, y: y1, width: x2 - x1, height: y2 - y1 }); } catch (e) { console.warn("image", e); } }
      else if (a.t === "text") { const [x1, y1, x2, y2] = normRect(a.rect); const f = a.bold ? await out.embedFont(StandardFonts.HelveticaBold) : font; page.drawText(winAnsi((a.body || "").replace(/\r/g, "")), { x: x1 + 3, y: y2 - a.size - 2, size: a.size, font: f, color: rgb(...hexRgb(a.color || "#111111")), maxWidth: Math.max(20, x2 - x1 - 6), lineHeight: a.size * 1.3 }); }
      else if (a.t === "edit") { const [x1, y1, x2, y2] = normRect(a.rect); page.drawRectangle({ x: x1 - 1, y: y1 - 1, width: x2 - x1 + 2, height: y2 - y1 + 2, color: rgb(1, 1, 1) }); const f = a.font === "serif" ? serif : a.font === "monospace" ? mono : font; page.drawText(winAnsi(a.text || ""), { x: x1, y: y1 + (y2 - y1 - a.size) / 2 + a.size * .15, size: a.size, font: f, color: rgb(...hexRgb(a.color || "#111111")) }); }
    }
    if (realAnnots.length) { const existing = page.node.lookup(PDFName.of("Annots")); const arr = existing instanceof PDFArray ? existing : out.context.obj([]); realAnnots.forEach(r => arr.push(r)); page.node.set(PDFName.of("Annots"), arr); }
  }
  if (opts.summary) {
    const md = notesMarkdown(); if (md) { const lines = md.replace(/^#+ /gm, "").split("\n"); let page = out.addPage([595, 842]), y = 800; page.drawText("Notes", { x: 50, y, size: 18, font }); y -= 30; for (const ln of lines) { const wrapped = wrapText(winAnsi(ln), font, 10, 495); for (const w of wrapped) { if (y < 50) { page = out.addPage([595, 842]); y = 800; } page.drawText(w, { x: 50, y, size: 10, font, color: rgb(.1, .1, .1) }); y -= 14; } } }
  }
  const bytes = await out.save(); if (opts.returnBytes) return bytes; download(new Blob([bytes], { type: "application/pdf" }), baseName(S.doc.name) + (opts.suffix || "-annotated") + ".pdf"); status("Exported", "ok");
}
function commentText(a) { let s = a.text || ""; (a.replies || []).forEach(r => s += "\n— " + r.text); if (a.quote && a.t !== "hl" && a.t !== "ul" && a.t !== "st") s = (s ? s + "\n" : "") + "“" + a.quote + "”"; return s; }
function drawMarks(page, a, R) { const { rgb } = PDFLib; const rects = a.t === "area" ? [a.rect] : a.rects; for (const r of rects) { const [x1, y1, x2, y2] = normRect(r); if (a.t === "hl" || a.t === "area") page.drawRectangle({ x: x1, y: y1, width: x2 - x1, height: y2 - y1, color: R, opacity: a.t === "area" ? .35 : .45, blendMode: PDFLib.BlendMode.Multiply }); else if (a.t === "ul") page.drawLine({ start: { x: x1, y: y1 + 1 }, end: { x: x2, y: y1 + 1 }, color: R, thickness: Math.max(1, (y2 - y1) * .08) }); else page.drawLine({ start: { x: x1, y: (y1 + y2) / 2 }, end: { x: x2, y: (y1 + y2) / 2 }, color: R, thickness: Math.max(1, (y2 - y1) * .1) }); } }
function wrapText(s, font, size, maxW) { const words = s.split(" "), lines = []; let cur = ""; for (const w of words) { const t = cur ? cur + " " + w : w; if (font.widthOfTextAtSize(t, size) > maxW && cur) { lines.push(cur); cur = w; } else cur = t; } lines.push(cur); return lines; }

/* Markdown export of a flow document: highlights as ==text==, comments as footnotes */
function flowToMarkdown(opts = {}) {
  if (S.webview) wvPull(true);
  const clone = flowEl.cloneNode(true); const notes = []; const seen = new Map();
  $$(".src-note,.readonly-note,iframe", clone).forEach(e => e.remove());
  $$(".cmt[data-id]", clone).forEach(el => { const id = el.dataset.id, c = S.doc.comments[id]; if (!c || (!c.text && !c.replies?.length)) { el.replaceWith(...el.childNodes); return; } let n = seen.get(id); if (!n) { n = notes.length + 1; seen.set(id, n); notes.push({ n, c, q: el.textContent }); } const fn = document.createTextNode(`[^${n}]`); el.after(fn); el.replaceWith(...el.childNodes); });
  $$("mark[data-id]", clone).forEach(el => { const c = S.doc.comments[el.dataset.id]; const t = document.createTextNode("==" + el.textContent + "=="); el.replaceWith(t); if (c?.text) { const n = notes.length + 1; notes.push({ n, c, q: el.textContent }); t.after(document.createTextNode(`[^${n}]`)); } });
  $$("li.task", clone).forEach(li => { const cb = li.querySelector("input[type=checkbox]"); const on = cb && (cb.checked || cb.hasAttribute("checked")); cb?.remove(); li.prepend(document.createTextNode(on ? "[x] " : "[ ] ")); });
  if (!opts.embedImages) $$("img[src^='data:']", clone).forEach((im, i) => { im.setAttribute("src", `image-${i + 1}.png`); });
  const td = new TurndownService({ headingStyle: "atx", codeBlockStyle: "fenced", bulletListMarker: "-", emDelimiter: "*" }); td.use(turndownPluginGfm.gfm);
  td.addRule("figure", { filter: "figure", replacement: (c, node) => { const im = node.querySelector("img"), cap = node.querySelector("figcaption"); return im ? `\n\n![${(cap?.textContent || im.alt || "").trim()}](${im.getAttribute("src")})\n\n` : c; } });
  td.addRule("underline", { filter: "u", replacement: c => `<u>${c}</u>` }); td.addRule("sup", { filter: ["sup", "sub"], replacement: (c, n) => `<${n.tagName.toLowerCase()}>${c}</${n.tagName.toLowerCase()}>` });
  let md = td.turndown(clone.innerHTML);
  if (notes.length) { md += "\n\n"; for (const { n, c, q } of notes) { md += `[^${n}]: ${(c.text || "").replace(/\n/g, "\n    ")}${c.replies?.length ? "\n    " + c.replies.map(r => "— " + r.text).join("\n    ") : ""}${c.text ? "" : `(on “${q.slice(0, 80)}”)`}\n`; } }
  if (S.doc.meta?.sourceUrl) md = `<!-- source: ${S.doc.meta.sourceUrl} -->\n\n` + md;
  return md.trim() + "\n";
}
async function exportMarkdown(opts = {}) {
  if (S.doc.kind === "flow") { const md = flowToMarkdown(opts); download(new Blob([md], { type: "text/markdown" }), baseName(S.doc.name) + ".md"); if (!opts.embedImages && /\]\(image-\d+\.png\)/.test(md)) toast("Images were written as image-N.png links; choose 'embed images' to keep them inside the file."); }
  else if (opts.text) { download(new Blob([await pdfToMarkdown()], { type: "text/markdown" }), baseName(S.doc.name) + ".md"); }
  else { const md = notesMarkdown() || `# Notes on ${S.doc.name}\n\n(no notes yet)\n`; download(new Blob([md], { type: "text/markdown" }), baseName(S.doc.name) + "-notes.md"); }
  status("Exported", "ok");
}
const DEFAULT_HEAD_CSS = `body{max-width:760px;margin:40px auto;padding:0 20px;font:17px/1.6 Charter,Georgia,serif;color:#222}img{max-width:100%}table{border-collapse:collapse}td,th{border:1px solid #ccc;padding:6px 9px}mark{background:var(--hl,#ffe066)}.cmt{background:#fff1b8;border-bottom:2px solid #f0c040}pre{background:#f3f3f3;padding:12px;border-radius:8px;overflow:auto}blockquote{border-left:3px solid #ccc;padding-left:1em;color:#555}`;
/* a complete HTML page: the file's own head when it came from an HTML file, plus the comments so they survive a round trip */
async function exportHtmlString(opts = {}) {
  if (S.webview) wvPull(true);
  let body = S.doc.kind === "pdf" ? await pdfToHtml() : flowEl.innerHTML;
  { const t = EL("div", { html: body }); $$(".on,.sel", t).forEach(e => { e.classList.remove("on", "sel"); if (!e.className) e.removeAttribute("class"); }); body = t.innerHTML; }   // no transient UI classes in the file
  const comments = Object.fromEntries(Object.entries(S.doc.comments || {}).filter(([id, c]) => c.text || c.replies?.length || body.includes(`data-id="${id}"`)));
  const cj = Object.keys(comments).length ? `\n<script type="application/json" id="lp-comments">${JSON.stringify(comments).replace(/<\//g, "<\\/")}</script>` : "";
  const head = S.doc.meta?.head ? S.doc.meta.head.replace(/<title>.*?<\/title>/is, "") + `<title>${esc(S.doc.name)}</title>` : `<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>${esc(S.doc.name)}</title><style>${DEFAULT_HEAD_CSS}</style>`;
  return `<!doctype html>\n<html>\n<head>\n${head}\n</head>\n<body>\n${body}${opts.appendComments === false ? "" : commentsHtml()}${cj}\n</body>\n</html>\n`;
}
async function exportHtml() { download(new Blob([await exportHtmlString()], { type: "text/html" }), baseName(S.doc.name) + ".html"); status("Exported", "ok"); }
/* the text of a PDF as HTML (headings by font size, paragraphs by spacing), with highlights and comments wrapped in */
async function pdfToHtml() {
  if (!S.pdf) return S.pages.map((p, i) => p.img ? `<figure><img src="${p.img.data}" alt="page ${i + 1}"></figure>` : "").join("");
  let html = "";
  for (const entry of S.pages) {
    if (entry.src == null) { if (entry.img) html += `<figure><img src="${entry.img.data}"></figure>`; continue; }
    const tc = await getTextContent({ entry, page: await getPage(entry) }); const items = tc.items.filter(i => i.str != null);
    const sizes = items.map(i => Math.abs(i.transform[3]) || i.height).filter(Boolean).sort((a, b) => a - b), med = sizes[sizes.length >> 1] || 10;
    let lines = [], cur = null;
    for (const it of items) { const y = it.transform[5], sz = Math.abs(it.transform[3]) || it.height; if (!cur || Math.abs(cur.y - y) > sz * .6) { cur = { y, sz, text: "", x: it.transform[4] }; lines.push(cur); } cur.text += (cur.text && !cur.text.endsWith(" ") && !it.str.startsWith(" ") && it.str ? " " : "") + it.str; cur.sz = Math.max(cur.sz, sz); }
    let para = "", paraSz = 0, lastY = null, lastSz = 0;
    const flush = () => { if (!para.trim()) { para = ""; return; } const t = para.replace(/\s+/g, " ").trim(); const tag = paraSz > med * 1.6 ? "h2" : paraSz > med * 1.22 ? "h3" : "p"; html += `<${tag}>${esc(t)}</${tag}>`; para = ""; paraSz = 0; };
    for (const ln of lines) { const gap = lastY == null ? 0 : lastY - ln.y; const newPara = lastY != null && (gap > lastSz * 1.7 || Math.abs(ln.sz - lastSz) > 1.5 || /[.:!?]$/.test(para.trim()) && gap > lastSz * 1.25); if (newPara) flush(); para += (para.endsWith("-") ? "" : " ") + ln.text; paraSz = Math.max(paraSz, ln.sz); lastY = ln.y; lastSz = ln.sz; }
    flush(); html += `<p class="src-note">— page ${S.pages.indexOf(entry) + 1} —</p>`;
  }
  // wrap highlights and comments around their text (spacing may differ, so compare without spaces)
  const box = EL("div", { html }); const tmp = flowEl; let n = 0;
  for (const a of S.doc.annots) { if (!a.quote) continue; const rs = looseRanges(box, a.quote.replace(/\s+/g, "").slice(0, 80)); if (!rs.length) continue; const nodes = []; const w = document.createTreeWalker(rs[0].commonAncestorContainer.nodeType === 3 ? rs[0].commonAncestorContainer.parentNode : rs[0].commonAncestorContainer, NodeFilter.SHOW_TEXT); let t; const r = rs[0]; if (r.startContainer === r.endContainer) { const node = r.startContainer; const after = node.splitText(r.endOffset), mid = node.splitText(r.startOffset); const el = EL(a.text ? "span" : "mark", { class: a.text ? "cmt" : null, "data-id": a.id, style: (a.text ? "--c:" : "--hl:") + (a.color || "#ffe066") }); mid.replaceWith(el); el.append(mid); n++; } }
  return box.innerHTML;
}
/* ---- save back to the file that was opened, or to a new file ---- */
async function verifyHandle(h) { try { if ((await h.queryPermission({ mode: "readwrite" })) === "granted") return true; return (await h.requestPermission({ mode: "readwrite" })) === "granted"; } catch (e) { return false; } }
async function sourceBlob(ext) {
  if (S.webview) wvPull(true);
  const d = S.doc;
  if (ext === "pdf") return new Blob([await exportPdf({ interactive: true, draw: false, summary: false, returnBytes: true })], { type: "application/pdf" });
  if (ext === "md" || ext === "markdown") return new Blob([d.kind === "pdf" ? await pdfToMarkdown() : flowToMarkdown({ embedImages: true })], { type: "text/markdown" });
  if (ext === "html" || ext === "htm") return new Blob([await exportHtmlString({ appendComments: false })], { type: "text/html" });
  if (ext === "txt") return new Blob([d.kind === "pdf" ? (await pdfToMarkdown()).replace(/[#>*=]/g, "") : flowEl.innerText], { type: "text/plain" });
  if (/^(png|jpe?g|webp|gif|bmp)$/.test(ext)) return pageImageBlob(S.pages[0], ext === "png" || ext === "gif" || ext === "bmp" ? "image/png" : "image/jpeg");
  if (ext === "lpdoc") return projectBlob();
  throw new Error("Can't write a ." + ext + " file");
}
async function pdfToMarkdown() { const html = await pdfToHtml(); const keep = flowEl.innerHTML; flowEl.innerHTML = html; try { return flowToMarkdown({ embedImages: true }); } finally { flowEl.innerHTML = keep; } }
async function saveToSource() {
  const d = S.doc; if (!d) return;
  if (!d.srcHandle) return saveAs();
  if (!(await verifyHandle(d.srcHandle))) return toast("No permission to write " + d.srcHandle.name + ". Use Save as… instead.");
  const ext = (d.meta.srcExt || "").toLowerCase();
  if (!S.confirmedOverwrite) {
    const v = await modal(`<h3>Save into ${esc(d.srcHandle.name)}?</h3><p>The file on your computer is replaced with this version${ext === "pdf" ? ", with your highlights and comments inside it" : ""}. Autosave in the browser continues as before.</p><div class="chkrow"><label><input type="checkbox" name="backup" checked> Download a copy of the original first (${esc(baseName(d.srcHandle.name))}-original.${esc(ext)})</label></div><div class="mrow"><button class="btn" data-cancel>Cancel</button><button class="btn primary" data-ok="ok">Save into the file</button></div>`);
    if (!v) return; S.confirmedOverwrite = true;
    if (v.backup) { if (d.src) download(d.src, baseName(d.srcHandle.name) + "-original." + ext); else if (d.orig != null) download(new Blob([d.orig]), baseName(d.srcHandle.name) + "-original." + ext); else if (d.pages?.[0]?.img) { const b = await (await fetch(d.pages[0].img.data)).blob(); download(b, baseName(d.srcHandle.name) + "-original." + ext); } }
  }
  status("Saving to " + d.srcHandle.name + "…");
  try { const blob = await sourceBlob(ext); const w = await d.srcHandle.createWritable(); await w.write(blob); await w.close(); await saveNow(); status("Saved to " + d.srcHandle.name, "ok"); toast("Saved into " + d.srcHandle.name + "."); }
  catch (e) { console.error(e); status("Could not save: " + (e.message || e), "err"); toast("Could not save into the file: " + (e.message || e)); }
}
async function saveAs() {
  const d = S.doc; const isPdf = d.kind === "pdf";
  const v = await modal(`<h3>Save as</h3><div class="opts">
    ${isPdf ? `<label class="opt"><input type="radio" name="fmt" value="pdf" checked><div><b>PDF</b><span>With your highlights and comments live inside (Acrobat, Preview, Zotero)</span></div></label>` : ""}
    <label class="opt"><input type="radio" name="fmt" value="html" ${isPdf ? "" : "checked"}><div><b>HTML</b><span>${isPdf ? "The text with headings, highlights and comments" : "The page as it is now, comments kept inside"}</span></div></label>
    <label class="opt"><input type="radio" name="fmt" value="md"><div><b>Markdown</b><span>==highlights== and comments as footnotes; images embedded</span></div></label>
    ${isPdf ? "" : `<label class="opt"><input type="radio" name="fmt" value="printpdf"><div><b>PDF</b><span>Through the print dialog (choose "Save as PDF" there)</span></div></label>`}
    <label class="opt"><input type="radio" name="fmt" value="lpdoc"><div><b>Project file (.lpdoc)</b><span>Everything, to reopen here later</span></div></label></div>
    <div class="mrow"><button class="btn" data-cancel>Cancel</button><button class="btn primary" data-ok="ok">Save</button></div>`);
  if (!v) return; if (v.fmt === "printpdf") return printFlow();
  const ext = v.fmt, mime = { pdf: "application/pdf", html: "text/html", md: "text/markdown", lpdoc: "application/json" }[ext], name = baseName(d.name) + "." + ext;
  if (window.showSaveFilePicker) {
    try { const h = await showSaveFilePicker({ suggestedName: name, types: [{ description: ext.toUpperCase(), accept: { [mime]: ["." + ext] } }] }); const blob = await sourceBlob(ext); const w = await h.createWritable(); await w.write(blob); await w.close(); if (ext !== "lpdoc") { d.srcHandle = h; d.meta.srcExt = ext; d.meta.srcName = h.name; S.confirmedOverwrite = true; } else { S.fileHandle = h; d.handle = h; } await saveNow(); status("Saved to " + h.name, "ok"); toast("Saved " + h.name + ". Ctrl+S saves there again."); } catch (e) { if (e.name !== "AbortError") toast("Could not save: " + (e.message || e)); }
  } else { download(await sourceBlob(ext), name); }
}
async function pageImageBlob(entry, mime) {
  const page = await getPage(entry), vp = page.getViewport({ scale: 2, rotation: pageRotation(entry, page) }), c = EL("canvas", { width: vp.width, height: vp.height }), ctx = c.getContext("2d");
  await page.render({ canvasContext: ctx, viewport: vp }).promise;
  // draw the marks: the vector layer through an SVG image, text boxes and images directly
  const tmp = { el: EL("div"), entry, page, vp, rendered: true }; drawAnnots(tmp); const svg = tmp.el.querySelector("svg"); svg.setAttribute("xmlns", "http://www.w3.org/2000/svg"); svg.setAttribute("width", vp.width); svg.setAttribute("height", vp.height);
  try { const im = await loadImage("data:image/svg+xml;charset=utf-8," + encodeURIComponent(svg.outerHTML.replace(/var\(--page-bg\)/g, "#fff"))); ctx.drawImage(im, 0, 0); } catch (e) { console.warn("svg layer", e); }
  for (const a of annotsOf(entry.id)) {
    const r = a.rect ? pdfRectToPx(tmp, a.rect) : null;
    if (a.t === "image") { try { ctx.drawImage(await loadImage(a.data), r[0], r[1], r[2] - r[0], r[3] - r[1]); } catch (e) { /* skip */ } }
    else if (a.t === "text" || a.t === "edit") { if (a.t === "edit") { ctx.fillStyle = "#fff"; ctx.fillRect(r[0] - 1, r[1] - 1, r[2] - r[0] + 2, r[3] - r[1] + 2); } ctx.fillStyle = a.color || "#111"; ctx.font = `${a.bold ? "bold " : ""}${a.size * 2}px ${a.font === "serif" ? "serif" : a.font === "monospace" ? "monospace" : "sans-serif"}`; ctx.textBaseline = "top"; (a.t === "edit" ? a.text : (a.body || "")).split("\n").forEach((ln, i) => ctx.fillText(ln, r[0] + (a.t === "edit" ? 0 : 6), r[1] + (a.t === "edit" ? (r[3] - r[1] - a.size * 2) / 2 : 4) + i * a.size * 2.6)); }
  }
  return new Promise(res => c.toBlob(res, mime, .92));
}
function commentsHtml() { const items = Object.entries(S.doc.comments).filter(([id, c]) => c.text || c.replies?.length); if (!items.length) return ""; return `<hr><h2>Comments</h2><ol>${items.map(([id, c]) => `<li><em>${esc($(`[data-id="${id}"]`, flowEl)?.textContent.slice(0, 120) || "")}</em><br>${esc(c.text || "")}${(c.replies || []).map(r => `<br>— ${esc(r.text)}`).join("")}</li>`).join("")}</ol>`; }
function printFlow() {
  if (S.webview) { wvPull(true); const d = wvDoc(), extra = d.createElement("div"); extra.innerHTML = commentsHtml(); d.body.append(extra); wvFrame().contentWindow.print(); setTimeout(() => extra.remove(), 1000); return; } const cs = $$(".cmt[data-id]", flowEl); let n = 0; const seen = new Map(); cs.forEach(el => { const c = S.doc.comments[el.dataset.id]; if (!c?.text) return; if (!seen.has(el.dataset.id)) seen.set(el.dataset.id, ++n); el.dataset.n = seen.get(el.dataset.id); }); const extra = EL("div", { class: "print-only", html: commentsHtml() }); flowEl.append(extra); const st = EL("style", {}, `@media print{.cmt[data-n]::after{content:" [" attr(data-n) "]";font-size:.75em;color:#555}}`); document.head.append(st); window.print(); setTimeout(() => { extra.remove(); st.remove(); }, 1000); }
async function exportMenu(anchor) {
  const pdf = S.doc.kind === "pdf";
  menu([
    { head: "Export as" },
    pdf ? { label: "PDF…", icon: "i-export", sub: "Highlights and comments live inside; opens in Acrobat, Preview, Zotero", fn: exportPdfDialog } : { label: "PDF (print)…", icon: "i-export", sub: "Choose 'Save as PDF' in the print dialog; comments listed at the end", fn: printFlow },
    { label: "HTML", icon: "i-web", sub: pdf ? "The text with headings, your highlights and comments" : "The page as it is now; comments kept inside", fn: exportHtml },
    { label: "Markdown", icon: "i-doc", sub: pdf ? "The text with ==highlights== and comments as footnotes" : "==highlights==, comments as footnotes, images linked", fn: () => exportMarkdown({ text: true }) },
    ...(pdf ? [{ label: "Markdown of the notes only", sub: "Highlights as quotes with your comments, by page", fn: () => exportMarkdown() }] : [{ label: "Markdown with images inside", sub: "Larger file, but one file", fn: () => exportMarkdown({ embedImages: true }) }]),
    { label: "Copy notes", fn: () => { navigator.clipboard.writeText(notesMarkdown()); toast("Copied the notes as Markdown."); } },
    { sep: true }, { label: "Project file (.lpdoc)", icon: "i-save", sub: "Everything, to reopen here later", fn: saveProjectFile }
  ], anchor, { right: true });
}
async function exportPdfDialog() {
  const v = await modal(`<h3>Export PDF</h3><p>Comments, highlights and the other marks are written into the PDF.</p><div class="opts">
    <label class="opt"><input type="radio" name="mode" value="interactive" checked><div><b>Live comments</b><span>Highlights and comment bubbles stay editable in Acrobat, Preview, Zotero and most readers. Drawings, text boxes, images and text edits are drawn in.</span></div></label>
    <label class="opt"><input type="radio" name="mode" value="flat"><div><b>Flattened</b><span>Everything is drawn into the page, like a printout. Comment bubbles become small notes in the margin.</span></div></label></div>
    <div class="chkrow"><label><input type="checkbox" name="summary" checked> Add a page at the end listing every highlight and comment</label></div>
    <div class="mrow"><button class="btn" data-cancel>Cancel</button><button class="btn primary" data-ok="ok">Export</button></div>`);
  if (!v) return; try { await exportPdf({ interactive: v.mode === "interactive", draw: false, summary: v.summary }); } catch (e) { console.error(e); status("Export failed", "err"); toast("Export failed: " + (e.message || e)); }
}
function saveMenu(anchor) {
  const h = S.doc.srcHandle;
  menu([
    h ? { label: "Save into " + h.name, icon: "i-save", k: "Ctrl+S", sub: "Replaces the file you opened with this version", fn: saveToSource } : { label: "Save to a file…", icon: "i-save", k: "Ctrl+S", sub: window.showSaveFilePicker ? "Pick where; Ctrl+S saves there from then on" : "Downloads the file", fn: saveAs },
    ...(h ? [{ label: "Save as…", sub: "A new file, in PDF, HTML or Markdown", fn: saveAs }] : []),
    { label: "Save project file (.lpdoc)", sub: "Everything in one file to keep, move or share", fn: saveProjectFile },
    { label: S.fileHandle ? "Autosaving to " + S.fileHandle.name : "Autosave to a file on this computer…", sub: S.fileHandle ? "Click to pick another file" : "Pick a file once; it is kept up to date as you work", fn: chooseAutosaveFile },
    { sep: true },
    { label: "Rename", fn: () => { $("#docTitle").focus(); $("#docTitle").select(); } },
    ...(S.doc.kind === "flow" && S.doc.origHtml ? [{ label: "Revert to the original text", sub: "Undoes every edit, keeps nothing you changed", fn: async () => { if (await modal(`<h3>Revert?</h3><p>All edits, highlights and comments in this document are removed.</p><div class="mrow"><button class="btn" data-cancel>Keep</button><button class="btn danger" data-ok="ok">Revert</button></div>`)) { flowEl.innerHTML = S.doc.origHtml; S.doc.comments = {}; flowChanged(); layoutMargin(); refreshNotes(); } } }] : []),
    { label: "Remove from this browser", danger: true, fn: async () => { if (await modal(`<h3>Remove "${esc(S.doc.name)}"?</h3><p>Removed from this browser's saved list. Project files you saved are not affected.</p><div class="mrow"><button class="btn" data-cancel>Keep</button><button class="btn danger" data-ok="ok">Remove</button></div>`)) { const id = S.doc.id; S.dirty = false; S.doc = null; await DB.del("docs", id); goHome(); } } }
  ], anchor, { right: true });
}

/* ---------- tools, find, read aloud, themes, PDF → document, start-up ---------- */
function setTool(t) {
  S.tool = t; $$("#pdfTools .tool").forEach(b => b.classList.toggle("on", b.dataset.tool === t));
  work.className = work.className.replace(/\btool-\S+/g, "").trim() + " tool-" + t;
  if (t !== "select") { S.sel = null; redrawAllAnnots(); } showCtx(); closeSelPop();
}
function buildSwatches() { const s = $("#swatches"); s.innerHTML = ""; COLORS.forEach(([c, n]) => s.append(EL("i", { class: "sw" + (S.color === c ? " on" : ""), style: "background:" + c, title: n, onclick: () => { S.color = c; Prefs.set("color", c); buildSwatches(); if (S.sel) { const a = annotById(S.sel); if (a && (a.t === "hl" || a.t === "ul" || a.t === "st" || a.t === "area" || a.t === "note")) { a.color = c; redrawAllAnnots(); changed(); } } } }))); }

/* ---- find (CSS highlights, so the text itself is untouched) ---- */
S.findQuery = ""; const findHL = typeof Highlight !== "undefined" && CSS.highlights ? { all: new Highlight(), cur: new Highlight() } : null;
if (findHL) { CSS.highlights.set("find", findHL.all); CSS.highlights.set("findcur", findHL.cur); document.head.append(EL("style", {}, "::highlight(find){background:rgba(255,224,102,.6)} ::highlight(findcur){background:rgba(255,140,0,.8);color:#000}")); }
function textRanges(root, q, caseSens) {
  const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, { acceptNode: n => n.parentElement.closest(".endOfContent,.pnum,.annots,.bubble") ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT }); const nodes = []; let s = "", n;
  while ((n = w.nextNode())) { nodes.push({ n, start: s.length }); s += n.data; if (root.classList?.contains("textLayer")) s += " "; }
  const hay = caseSens ? s : s.toLowerCase(), needle = caseSens ? q : q.toLowerCase(), out = []; let i = 0;
  const locate = pos => { let lo = 0, hi = nodes.length - 1; while (lo < hi) { const m = (lo + hi + 1) >> 1; if (nodes[m].start <= pos) lo = m; else hi = m - 1; } return nodes[lo]; };
  while ((i = hay.indexOf(needle, i)) !== -1) { const a = locate(i), b = locate(i + needle.length - 1); const r = document.createRange(); try { r.setStart(a.n, i - a.start); r.setEnd(b.n, Math.min(b.n.length, i + needle.length - b.start)); out.push(r); } catch (e) { /* across a gap */ } i += needle.length; }
  return out;
}
async function runFind() {
  const q = $("#findIn").value.trim(), cs = $("#findCase").checked; S.findQuery = q; findHL?.all.clear(); findHL?.cur.clear(); S.findRanges = []; S.findIdx = -1;
  const res = $("#findRes"), sum = $("#findSum"); res.innerHTML = ""; sum.textContent = ""; if (!q) return;
  if (S.doc.kind === "flow") {
    const rs = textRanges(flowEl, q, cs); S.findRanges = rs.map(r => ({ r })); rs.forEach(r => findHL?.all.add(r)); sum.textContent = rs.length + (rs.length === 1 ? " match" : " matches");
    rs.slice(0, 200).forEach((r, i) => { const t = r.startContainer.data, a = Math.max(0, r.startOffset - 30); res.append(EL("button", { class: "fr", onclick: () => gotoFind(i) }, EL("span", {}, t.slice(a, r.startOffset)), EL("mark", {}, t.slice(r.startOffset, r.startOffset + q.length)), EL("span", {}, t.slice(r.startOffset + q.length, r.startOffset + q.length + 40)))); });
    if (rs.length) gotoFind(0); return;
  }
  let total = 0; const hits = [];
  for (let i = 0; i < S.pages.length; i++) { const txt = await pageText(S.pages[i]); const hay = cs ? txt : txt.toLowerCase(), nd = cs ? q : q.toLowerCase(); let k = 0; while ((k = hay.indexOf(nd, k)) !== -1) { hits.push({ page: i + 1, pos: k, ctx: txt.slice(Math.max(0, k - 30), k + q.length + 40), q }); total++; k += nd.length; if (total > 500) break; } if (total > 500) break; }
  S.findRanges = hits; sum.textContent = total + (total === 1 ? " match" : " matches") + (total > 500 ? " (first 500)" : "");
  hits.slice(0, 300).forEach((h, i) => res.append(EL("button", { class: "fr", onclick: () => gotoFind(i) }, EL("span", { class: "pg" }, "p." + h.page), EL("span", {}, h.ctx.slice(0, h.pos - Math.max(0, h.pos - 30)).replace(/\s+/g, " ")), EL("mark", {}, q), EL("span", {}, h.ctx.slice(h.pos - Math.max(0, h.pos - 30) + q.length).replace(/\s+/g, " ")))));
  for (const v of S.views.values()) if (v.rendered) highlightFindOnPage(v);
  if (hits.length) gotoFind(0);
}
function highlightFindOnPage(v) { if (!findHL || !S.findQuery) return; const tl = v.el.querySelector(".textLayer"); if (!tl) return; textRanges(tl, S.findQuery, $("#findCase").checked).forEach(r => findHL.all.add(r)); }
async function gotoFind(i) {
  if (!S.findRanges.length) return; S.findIdx = (i + S.findRanges.length) % S.findRanges.length; $$(".fr").forEach((b, k) => b.classList.toggle("on", k === S.findIdx));
  const h = S.findRanges[S.findIdx]; findHL?.cur.clear();
  if (S.doc.kind === "flow") { findHL?.cur.add(h.r); const el = h.r.startContainer.parentElement; el.scrollIntoView({ block: "center" }); return; }
  goToPage(h.page); const v = [...S.views.values()][h.page - 1]; await renderPage(v); await new Promise(r => setTimeout(r, 60));
  const tl = v.el.querySelector(".textLayer"); if (!tl) return; const rs = textRanges(tl, S.findQuery, $("#findCase").checked); const same = S.findRanges.filter(x => x.page === h.page), k = same.indexOf(h); const r = rs[k] || rs[0]; if (r) { findHL?.cur.add(r); const rc = r.getBoundingClientRect(), vr = viewer.getBoundingClientRect(); if (rc.top < vr.top + 40 || rc.bottom > vr.bottom - 40) viewer.scrollTop += rc.top - vr.top - viewer.clientHeight / 2; }
}
function replaceFind(all) {
  if (S.doc.kind !== "flow") return; const rep = $("#replIn").value; const list = all ? S.findRanges.map(x => x.r) : [S.findRanges[Math.max(0, S.findIdx)]?.r].filter(Boolean); if (!list.length) return;
  for (const r of list.slice().reverse()) { r.deleteContents(); r.insertNode(document.createTextNode(rep)); } flowEl.normalize(); flowChanged(); pushHistory(); runFind();
}

/* ---- read aloud ---- */
async function speak(text) {
  if (!("speechSynthesis" in window)) return toast("This browser can't read aloud.");
  if (S.speaking) { speechSynthesis.cancel(); S.speaking = false; work.classList.remove("speaking"); if (!text) return; }
  if (!text) { const sel = getSelection(); text = sel && !sel.isCollapsed ? sel.toString() : S.doc.kind === "flow" ? flowEl.innerText : await pageText(S.pages[S.current - 1]); }
  if (!text?.trim()) return toast("Nothing to read on this page.");
  const u = new SpeechSynthesisUtterance(text.replace(/\s+/g, " ").slice(0, 20000)); u.rate = 1.05; u.lang = /[가-힣]/.test(text) ? "ko-KR" : "en-US";
  u.onend = u.onerror = () => { S.speaking = false; work.classList.remove("speaking"); }; S.speaking = true; work.classList.add("speaking"); speechSynthesis.speak(u);
}
/* ---- themes ---- */
function setTheme(t) { if (t === "auto") delete document.documentElement.dataset.theme; else document.documentElement.dataset.theme = t; Prefs.set("theme", t); if (S.doc?.kind === "pdf") redrawAllAnnots(); }
function themeMenu(anchor) { const cur = document.documentElement.dataset.theme || "auto"; menu([{ head: "Reading colours" }, ...[["auto", "Match the system"], ["light", "Light"], ["sepia", "Sepia (paper)"], ["dark", "Dark"]].map(([k, l]) => ({ label: l, on: cur === k, fn: () => setTheme(k) })), { sep: true }, { head: "Document font" }, ...[["serif", "Serif (book)"], ["sans", "Sans-serif"], ["mono", "Monospace"]].map(([k, l]) => ({ label: l, on: flowEl.dataset.font === k, fn: () => { flowEl.dataset.font = k; Prefs.set("flowFont", k); } }))], anchor, { right: true }); }
function zoomMenu(anchor) { const flow = S.doc?.kind === "flow", cur = flow ? (S.flowZoom || 1) : S.scale; menu([{ label: flow ? "Normal size" : "Fit width", on: S.zoomMode === "width", fn: () => setZoom("width") }, ...(flow ? [] : [{ label: "Fit page", on: S.zoomMode === "page", fn: () => setZoom("page") }]), { sep: true }, ...[50, 75, 100, 125, 150, 200, 300].map(z => ({ label: z + "%", on: S.zoomMode === "custom" && Math.round(cur * 100) === z, fn: () => setZoom("custom", z / 100) }))], anchor); }

/* ---- turn a PDF into an editable document: text with headings, highlights and comments carried over ---- */
async function convertToFlow() {
  if (!S.pdf) return toast("Only a real PDF can be converted; this document is an image.");
  status("Reading the text…"); const html = await pdfToHtml();
  const comments = {}; let carried = 0; for (const a of S.doc.annots) if (a.quote && html.includes(`data-id="${a.id}"`)) { comments[a.id] = { at: a.at, color: a.color, t: a.text ? "cmt" : "mark", text: a.text || "", replies: a.replies || [] }; carried++; }
  const d = newDoc("flow", baseName(S.doc.name) + " (editable)", { html, comments, meta: { from: S.doc.id, sourceUrl: S.doc.meta?.sourceUrl || "" } });
  await openDoc(d); S.doc.origHtml = html; layoutMargin(); refreshNotes();
  toast(`Made an editable copy${carried ? ` and carried ${carried} note${carried === 1 ? "" : "s"} over` : ""}. Figures are not copied; place them with the image button.`);
}

/* find text ignoring spaces: returns ranges in the live document */
function looseRanges(root, q) {
  const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT); const map = []; let s = "", n;
  while ((n = w.nextNode())) { for (let i = 0; i < n.data.length; i++) { const ch = n.data[i]; if (/\s/.test(ch)) continue; s += ch.toLowerCase(); map.push([n, i]); } }
  const out = []; let i = 0; const needle = q.toLowerCase(); if (!needle) return out;
  while ((i = s.indexOf(needle, i)) !== -1) { const [n1, o1] = map[i], [n2, o2] = map[i + needle.length - 1]; const r = document.createRange(); r.setStart(n1, o1); r.setEnd(n2, o2 + 1); out.push(r); i += needle.length; }
  return out;
}
/* ---- extension hooks: a captured page or a URL handed over by the extension ---- */
async function extStart() {
  const q = new URLSearchParams(location.search);
  if (q.get("cap") && IS_EXT) { const st = await chrome.storage.local.get(q.get("cap")); const cap = st[q.get("cap")]; if (cap) { chrome.storage.local.remove(q.get("cap")); if (cap.selection) return openDoc(newDoc("flow", (cap.title || "Selection").slice(0, 80), { html: cleanHtml(cap.selection, cap.url), meta: { sourceUrl: cap.url } })); return openHtmlDoc(cap.title || "page", cap.html, cap.url); } }
  if (q.get("url")) { $("#urlInput").value = q.get("url"); return openUrl(q.get("url")); }
  if (q.get("file") && IS_EXT) { try { const r = await fetch(q.get("file")); return openPdfDoc(newDoc("pdf", decodeURIComponent(q.get("file").split("/").pop()), { src: await r.blob(), meta: { sourceUrl: q.get("file") } })); } catch (e) { toast("Could not read the file: " + e.message); } }
}

/* ---- wiring ---- */
function bindUI() {
  document.addEventListener("click", e => {
    const b = e.target.closest("[data-act]"); if (!b) return; const act = b.dataset.act;
    const A = {
      openFile: async () => {
        if (window.showOpenFilePicker) { try { const hs = await showOpenFilePicker({ multiple: true, types: [{ description: "Documents", accept: { "application/pdf": [".pdf"], "text/markdown": [".md", ".markdown"], "text/html": [".html", ".htm"], "text/plain": [".txt"], "image/*": [".png", ".jpg", ".jpeg", ".webp", ".gif"], "application/json": [".lpdoc"] } }] }); for (const h of hs) await openFile(await h.getFile(), h); } catch (e) { if (e.name !== "AbortError") console.warn(e); } return; }
        const i = $("#fileIn"); i.value = ""; i.click();
      },
      pasteNew, newBlank: () => openDoc(newDoc("flow", "Untitled", { html: "<h1>Untitled</h1><p><br></p>" })), home: goHome,
      undo, redo, saveMenu: () => saveMenu(b), exportMenu: () => exportMenu(b),
      toggleLeft: () => { $("#left").classList.toggle("closed"); Prefs.set("left", !$("#left").classList.contains("closed")); }, toggleRight: () => { $("#right").classList.toggle("closed"); Prefs.set("right", !$("#right").classList.contains("closed")); },
      prevPage: () => goToPage(S.current - 1), nextPage: () => goToPage(S.current + 1), zoomIn: () => zoomBy(1.2), zoomOut: () => zoomBy(1 / 1.2), zoomMenu: () => zoomMenu(b),
      search: () => { showLeft("find"); $("#findIn").focus(); $("#findIn").select(); }, speak: () => speak(), themeMenu: () => themeMenu(b), convertFlow: convertToFlow,
      inlineCode: () => { const sel = getSelection(); if (!sel || sel.isCollapsed) return; insertHtml("<code>" + esc(sel.toString()) + "</code>"); }, checklist: toggleChecklist, alignMenu: () => alignMenu(b), link: linkPrompt,
      insertImage: () => pickImage(src => insertHtml(`<figure><img src="${src}"><figcaption></figcaption></figure><p><br></p>`)), tableMenu: () => tableMenu(b), flowHighlight, flowComment,
      webView: enterWebView,
      replaceOne: () => replaceFind(false), replaceAll: () => replaceFind(true), copyNotes: () => { navigator.clipboard.writeText(notesMarkdown()); toast("Copied the notes as Markdown."); }
    };
    if (A[act]) { if (b.closest("#flowTools")) e.preventDefault(); A[act](); }
  });
  $$("#flowTools [data-cmd]").forEach(b => b.addEventListener("pointerdown", e => { e.preventDefault(); cmd(b.dataset.cmd); }));
  $("#fileIn").addEventListener("change", e => { [...e.target.files].forEach(openFile); });
  $("#blockSel").addEventListener("change", e => setBlock(e.target.value)); $("#textColor").addEventListener("input", e => cmd("foreColor", e.target.value));
  $$("#pdfTools .tool").forEach(b => b.addEventListener("click", () => setTool(b.dataset.tool)));
  $("#pageIn").addEventListener("change", e => goToPage(+e.target.value || 1)); $("#pageIn").addEventListener("keydown", e => { if (e.key === "Enter") e.target.blur(); });
  $$(".ltab").forEach(t => t.addEventListener("click", () => showLeft(t.dataset.ltab)));
  $("#findForm").addEventListener("submit", e => { e.preventDefault(); if (S.findQuery === $("#findIn").value.trim() && S.findRanges.length) gotoFind(S.findIdx + 1); else runFind(); });
  $("#findIn").addEventListener("input", debounce(runFind, 300));
  $("#noteFilter").addEventListener("change", refreshNotes); $("#noteSearch").addEventListener("input", debounce(refreshNotes, 200));
  $("#docTitle").addEventListener("change", e => { if (S.doc) { S.doc.name = e.target.value.trim() || "Untitled"; document.title = S.doc.name + " · Doc Reader"; markDirty(); } });
  $("#docTitle").addEventListener("keydown", e => { if (e.key === "Enter") e.target.blur(); e.stopPropagation(); });
  $("#urlForm").addEventListener("submit", e => { e.preventDefault(); const u = $("#urlInput").value.trim(); if (u) openUrl(u); });
  // text selection → marks (PDF)
  pagesEl.addEventListener("pointerdown", e => { const tl = e.target.closest(".textLayer"); if (tl) tl.querySelector(".endOfContent")?.classList.add("active"); if (S.sel && !S.editingText && !e.target.classList.contains("drawlayer") && ["select", "erase", "highlight", "underline", "strike", "edit"].includes(S.tool) && !e.target.closest(".mk,.anode,.bubble,.editbox")) { S.sel = null; redrawAllAnnots(); showCtx(); } });
  // toolbar buttons must not take the selection away from the editor
  $$("#flowTools button, #tbar button[data-act=flowHighlight], #tbar button[data-act=flowComment]").forEach(b => b.addEventListener("pointerdown", e => e.preventDefault()));
  document.addEventListener("pointerup", e => {
    $$(".textLayer .endOfContent.active").forEach(x => x.classList.remove("active"));
    if (S.doc?.kind !== "pdf") return; const t = S.tool;
    setTimeout(() => { if (t === "highlight") markSelection("hl"); else if (t === "underline") markSelection("ul"); else if (t === "strike") markSelection("st"); else if (t === "select" && e.target.closest(".textLayer")) showSelPop(); }, 10);
  });
  document.addEventListener("selectionchange", () => { const s = getSelection(); if (!s || s.isCollapsed) closeSelPop(); });
  bindEditTool(); bindFlow();
  // drag and drop anywhere
  let dragN = 0; document.addEventListener("dragenter", e => { if ([...e.dataTransfer.types].includes("Files")) { dragN++; $("#dropOverlay").hidden = false; } }); document.addEventListener("dragleave", () => { if (--dragN <= 0) { dragN = 0; $("#dropOverlay").hidden = true; } });
  document.addEventListener("dragover", e => { if ([...e.dataTransfer.types].includes("Files")) e.preventDefault(); });
  document.addEventListener("drop", async e => { dragN = 0; $("#dropOverlay").hidden = true; const fs = [...e.dataTransfer.files]; if (!fs.length) return; if (e.target.closest("#flow") && fs.every(f => f.type.startsWith("image/"))) return; e.preventDefault();
    const items = [...e.dataTransfer.items]; for (let k = 0; k < fs.length; k++) { let h = null; try { h = items[k]?.getAsFileSystemHandle ? await items[k].getAsFileSystemHandle() : null; } catch (er) { /* no handle */ } await openFile(fs[k], h && h.kind === "file" ? h : null); } });
  $("#drop").addEventListener("keydown", e => { if (e.key === "Enter") $("[data-act=openFile]").click(); });
  // keyboard
  document.addEventListener("keydown", e => {
    const inEdit = e.target.closest("input,textarea,[contenteditable=true]"), mod = e.ctrlKey || e.metaKey;
    if (mod && e.key.toLowerCase() === "s") { e.preventDefault(); if (S.doc) { if (e.shiftKey) saveAs(); else saveToSource(); } return; }
    if (mod && e.key.toLowerCase() === "f" && S.doc) { e.preventDefault(); showLeft("find"); $("#findIn").focus(); $("#findIn").select(); return; }
    if (mod && e.key.toLowerCase() === "z" && !e.shiftKey && S.doc) { if (inEdit && e.target.closest("#pop,.editbox,.textbox")) return; e.preventDefault(); undo(); return; }
    if (mod && (e.key.toLowerCase() === "y" || (e.key.toLowerCase() === "z" && e.shiftKey)) && S.doc) { e.preventDefault(); redo(); return; }
    if (mod && e.key.toLowerCase() === "k" && S.doc?.kind === "flow") { e.preventDefault(); linkPrompt(); return; }
    if (mod && e.shiftKey && e.key.toLowerCase() === "h" && S.doc?.kind === "flow") { e.preventDefault(); flowHighlight(); return; }
    if (mod && e.altKey && e.key.toLowerCase() === "m" && S.doc?.kind === "flow") { e.preventDefault(); flowComment(); return; }
    if (mod && (e.key === "=" || e.key === "+") && S.doc) { e.preventDefault(); zoomBy(1.2); return; } if (mod && e.key === "-" && S.doc) { e.preventDefault(); zoomBy(1 / 1.2); return; } if (mod && e.key === "0" && S.doc) { e.preventDefault(); setZoom("width"); return; }
    if (inEdit || mod || e.altKey || !S.doc) return;
    if (S.doc.kind === "pdf") {
      const keys = { v: "select", h: "highlight", u: "underline", k: "strike", a: "area", c: "comment", t: "text", d: "pen", r: "shape", i: "image", e: "edit", x: "erase" }; const k = e.key.toLowerCase();
      if (keys[k]) { setTool(keys[k]); return; }
      if (e.key === "ArrowRight" || e.key === "PageDown") { goToPage(S.current + 1); e.preventDefault(); } if (e.key === "ArrowLeft" || e.key === "PageUp") { goToPage(S.current - 1); e.preventDefault(); }
      if ((e.key === "Delete" || e.key === "Backspace") && S.sel) { removeAnnot(S.sel); e.preventDefault(); }
      if (e.key === "Escape") { if (S.sel) { S.sel = null; redrawAllAnnots(); showCtx(); } else setTool("select"); }
    }
    if (e.key === "Escape" && S.speaking) speak();
  });
  viewer.addEventListener("wheel", e => { if ((e.ctrlKey || e.metaKey) && S.doc) { e.preventDefault(); zoomBy(e.deltaY < 0 ? 1.1 : 1 / 1.1); } }, { passive: false });
  addEventListener("resize", debounce(() => { if (S.doc?.kind === "pdf" && S.zoomMode === "width") setZoom("width"); if (S.doc?.kind === "flow") layoutMargin(); }, 200));
  addEventListener("beforeunload", e => { if (S.dirty && S.doc) { saveNow(); } });
  document.addEventListener("visibilitychange", () => { if (document.hidden && S.dirty) saveNow(); });
}
function showLeft(tab) { $("#left").classList.remove("closed"); $$(".ltab").forEach(t => t.classList.toggle("on", t.dataset.ltab === tab)); $$(".lpane").forEach(p => p.classList.toggle("on", p.dataset.lpane === tab)); Prefs.set("ltab", tab); }

async function init() {
  await Prefs.load(); S.color = Prefs.get("color", COLORS[0][0]); buildSwatches();
  const th = Prefs.get("theme", "auto"); if (th !== "auto") document.documentElement.dataset.theme = th;
  if (Prefs.get("left", true) === false) $("#left").classList.add("closed"); if (Prefs.get("right", true) === false) $("#right").classList.add("closed"); showLeft(Prefs.get("ltab", "pages"));
  bindUI(); bindWvBar(); bindLightbox(); listRecent();
  $("#webLayout").value = Prefs.get("webLayout", "original"); $("#webLayout").addEventListener("change", e => Prefs.set("webLayout", e.target.value));
  if (IS_EXT) { $("#extCard").hidden = true; $$("a[href^='https://labpotato']").forEach(a => a.target = "_blank"); }
  // pdf.js worker: from the file next to this page in the extension, or from the inline copy on the website
  try { if (window.PDF_WORKER_SRC) pdfjsLib.GlobalWorkerOptions.workerSrc = window.PDF_WORKER_SRC; else { const src = document.getElementById("pdfworker")?.textContent; if (src) pdfjsLib.GlobalWorkerOptions.workerPort = new Worker(URL.createObjectURL(new Blob([src.replace(/<\\\/script/g, "</script")], { type: "text/javascript" }))); } } catch (e) { console.warn("worker", e); }
  const started = await extStart();
  if (!started && !IS_EXT) { const q = new URLSearchParams(location.search); if (q.get("url")) openUrl(q.get("url")); }
  if (navigator.storage?.persist) navigator.storage.persist().catch(() => {});
}
document.addEventListener("DOMContentLoaded", init);
/* a few names on window, for the tests and the console */
Object.assign(window, { S, exportPdf, exportMarkdown, saveProjectFile, saveNow, goHome, convertToFlow, insertTable, insertImageFile, rotatePage, insertBlank, deletePage, setTheme, openUrl, openFile, flowHighlight, flowComment, saveToSource, exportHtmlString, pdfToHtml, pdfToMarkdown, setZoom, editImage, sourceBlob, flowChanged, redrawAllAnnots, selectAnnot, normRect, enterWebView, exitWebView, wvDoc, wvPull, openLightbox, Prefs });

})();